"""Run the original event-runtime test on two isolated serializer candidates."""
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
CANDIDATE = ROOT / 'json-serializer-candidate'
FEATURE = ROOT / 'feature'

if len(sys.argv) == 3 and sys.argv[1] == '--child':
    variant = sys.argv[2]
    assert variant in ('red', 'green') and os.getuid() == os.geteuid() == 1000
    os.umask(0o002)
    os.sched_setaffinity(0, {0, 1, 2, 3})
    os.environ['TMPDIR'] = '/tmp'
    os.environ['ASAN_OPTIONS'] = 'halt_on_error=1:detect_leaks=1'
    os.environ.pop('UBSAN_OPTIONS', None)
    command = [sys.executable, str(ROOT / 'run_validation.py'),
               'serializer-event-' + variant, str(FEATURE), 'ctest', '--test-dir',
               str(CANDIDATE / variant / 'build'), '--output-on-failure', '--parallel', '1']
    os.execv(sys.executable, command)

assert len(sys.argv) == 1 and os.getuid() == 1000
destination = ROOT / 'evidence/serializer-event-probe.json'
assert not destination.exists()
manifest_path = CANDIDATE / 'candidate-manifest.json'
manifest = json.loads(manifest_path.read_bytes())

def identity(path):
    path = pathlib.Path(path)
    with path.open('rb') as source:
        sha = hashlib.file_digest(source, 'sha256').hexdigest()
    return {'sha256': sha, 'bytes': path.stat().st_size}

paths = set(manifest['inputs']) | {str(manifest_path), __file__}
for variant in ('red', 'green'):
    for action in ('compile-runtime-types', 'link-event-runtime'):
        path = CANDIDATE / 'build-records' / (variant + '-' + action + '.json')
        build = json.loads(path.read_bytes())
        assert build['exit_code'] == 0 and build['inputs_unchanged']
        assert build['manifest_sha256'] == identity(manifest_path)['sha256']
        assert build.get('link_identity', {}).get('verified', True)
        paths.add(str(path))
        for output, expected in build['outputs'].items():
            assert identity(output) == expected
            paths.add(output)
        paths.update(build.get('actual_dependency_fingerprints_after_compile', {}))
    values = manifest['variants'][variant]
    assert identity(values['source'])['sha256'] == values['source_sha256']
    paths.update((values['source'], values['ctest_registration']))
    assert 'TIMEOUT 90' in pathlib.Path(values['ctest_registration']).read_text()
    name = 'serializer-event-' + variant
    assert not (ROOT / 'evidence' / (name + '.json')).exists()

for path, expected in manifest['inputs'].items():
    assert identity(path) == expected
before = {path: identity(path) for path in sorted(paths)}
record = {'record_kind': 'isolated_serializer_event_comparison',
          'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'One original logical suite, two executions. Original v3 test object and libraries; only runtime_types.cpp differs. Not a complete validation gate.',
          'before': before, 'runs': {}}

def save():
    destination.write_text(json.dumps(record, indent=2) + '\n')

save()
for variant in ('red', 'green'):
    args = ['sudo', '-n', 'unshare', '--mount', '--propagation', 'private', '--fork',
            str(ROOT / 'run_in_test_tmpfs.sh'), sys.executable, __file__, '--child', variant]
    print('START serializer-event-' + variant, flush=True)
    result = subprocess.run(args, cwd=ROOT)
    name = 'serializer-event-' + variant
    metadata = ROOT / 'evidence' / (name + '.json')
    completed = json.loads(metadata.read_bytes())
    assert isinstance(completed['exit_code'], int) and completed['finished_at']
    detail = CANDIDATE / variant / 'build/Testing/Temporary/LastTest.log'
    target = ROOT / 'evidence' / (name + '-detail.log')
    assert not target.exists()
    shutil.copyfile(detail, target)
    record['runs'][variant] = {'argv': args, 'wrapper_exit_code': result.returncode,
                               'record_sha256': identity(metadata)['sha256'],
                               'detail_log_sha256': identity(target)['sha256']}
    save()
    print('END serializer-event-' + variant + ' exit=' + str(result.returncode), flush=True)
record['after'] = {path: identity(path) for path in sorted(paths)}
record['inputs_unchanged'] = before == record['after']
record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
assert record['inputs_unchanged']
raise SystemExit(record['runs']['green']['wrapper_exit_code'])
