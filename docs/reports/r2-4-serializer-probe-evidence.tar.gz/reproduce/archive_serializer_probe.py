"""Audit and archive a failed isolated serializer probe; never execute members."""

import ast
import datetime
import difflib
import gzip
import hashlib
import io
import json
import pathlib
import re
import shlex
import sys
import tarfile


ROOT = pathlib.Path(__file__).resolve().parent
FEATURE = ROOT / 'feature'
CANDIDATE = ROOT / 'json-serializer-candidate'
BUILD = FEATURE / 'build-asan-clang-opt'
ARCHIVE = FEATURE / 'docs/reports/r2-4-serializer-probe-evidence.tar.gz'
VERIFICATION = ROOT / 'evidence/serializer-probe-bundle-verification.json'
MANIFEST_SHA256 = '59c8310d64a961d2ebac1159b93e8aa925499be61795b06831a96d79e2fa2050'
IMMUTABLE = {
    'feature/docs/reports/r2-4-evidence.tar.gz':
        '45ac14ee3558dfb8f18054f4d543d0598297c7032a012e457943ed806bea4f6c',
    'feature/docs/reports/r2-4-results.json':
        '78c718189cf951ac6a61352ee8390aa46d17502b91196a6377910abb1f7fb2fc',
    'feature/docs/reports/r2-4-asan-profile-evidence.tar.gz':
        '35c838fe112aa648b05f44f6f192fc0b3097fd39b7d356191dd1600898f710b8',
    'evidence/final-validation-plan.json':
        '282d031865d920b7cbf97cd1969d2150355cc90a82ad53a50127242d09b12a2b',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    size = 0
    hasher = hashlib.sha256()
    with pathlib.Path(path).open('rb') as source:
        while chunk := source.read(1024 * 1024):
            hasher.update(chunk)
            size += len(chunk)
    return {'sha256': hasher.hexdigest(), 'bytes': size}


def immutable_check():
    for relative, expected in IMMUTABLE.items():
        require(identity(ROOT / relative)['sha256'] == expected,
                'previous frozen deliverable changed: ' + relative)


def members():
    result = {}
    for name in ('serializer-event-probe.json', 'source-final-v3.json',
                 'source-final-v3.sha256', 'fetch-before-r24-handoff.json',
                 'fetch-before-r24-handoff.log'):
        result['evidence/' + name] = ROOT / 'evidence' / name
    for variant in ('red', 'green'):
        for suffix in ('.json', '.log', '-detail.log'):
            name = 'serializer-event-' + variant + suffix
            result['evidence/' + name] = ROOT / 'evidence' / name
    for name in ('run_json_serializer_event_probe.py', 'run_validation.py',
                 'run_in_test_tmpfs.sh', 'archive_serializer_probe.py'):
        result['reproduce/' + name] = ROOT / name
    candidate_names = [
        'candidate-manifest.json', 'oracle-manifest.json', 'conclusion.json',
        'production.patch', 'tests.patch', 'run_build.py', 'run_oracle_build.py',
        'tests/runtime_types_tests.cpp',
    ]
    for variant in ('red', 'green'):
        candidate_names += [variant + '/src/runtime_types.cpp',
                            variant + '/build/CTestTestfile.cmake',
                            variant + '/build/runtime_types.cpp.o.d',
                            'oracle-build/' + variant + '/CTestTestfile.cmake']
        for action in ('compile-runtime-types', 'link-event-runtime'):
            for suffix in ('.json', '.log'):
                candidate_names.append('build-records/' + variant + '-' + action + suffix)
    for name in candidate_names:
        result['reproduce/json-serializer-candidate/' + name] = CANDIDATE / name
    for name in ('CMakeLists.txt', 'tests/event_runtime_tests.cpp', 'tests/test_support.hpp',
                 'tests/runtime_types_tests.cpp', 'include/wls/runtime_types.hpp',
                 'build-asan-clang-opt/CMakeCache.txt', 'build-asan-clang-opt/build.ninja',
                 'build-asan-clang-opt/CMakeFiles/rules.ninja',
                 'build-asan-clang-opt/CTestTestfile.cmake'):
        result['reference/feature/' + name] = FEATURE / name
    return result


def collect():
    result = {}
    for name, path in members().items():
        require(path.is_file() and not path.is_symlink(), 'missing/non-regular member: ' + name)
        require(path.stat().st_size < 2 * 1024 * 1024, 'oversized member: ' + name)
        data = path.read_bytes()
        data.decode('utf-8')
        require(b'\0' not in data, 'non-text member: ' + name)
        result[name] = data
    return result


def audit(files):
    """Check existing bytes and bind actual commands to outputs, without subprocesses."""
    immutable_check()
    prefix = 'reproduce/json-serializer-candidate/'
    load = lambda name: json.loads(files[name])
    frozen = load('evidence/source-final-v3.json')
    manifest_bytes = files['evidence/source-final-v3.sha256']
    source = frozen['inputs']
    require(len(source) == frozen['count'] == 312 and
            digest(manifest_bytes) == frozen['manifest_sha256'] == MANIFEST_SHA256,
            'v3 input manifest changed')
    require({line.split('  ', 1)[1]: line.split('  ', 1)[0]
             for line in manifest_bytes.decode().splitlines()} == source,
            'v3 manifest bytes disagree with source record')
    references, cache = {}, {}

    def expect(path, expected):
        path = str(path)
        if path not in cache:
            cache[path] = identity(path)
        actual = cache[path]
        require(actual == expected, 'local identity differs: ' + path)
        if path in references:
            require(references[path] == expected, 'inconsistent recorded identity: ' + path)
        references[path] = expected

    for relative, expected in source.items():
        path = FEATURE / relative
        actual = identity(path)
        require(actual['sha256'] == expected, 'feature source changed: ' + relative)
        cache[str(path)] = actual
        expect(path, actual)
    manifest = load(prefix + 'candidate-manifest.json')
    oracle = load(prefix + 'oracle-manifest.json')
    conclusion = load(prefix + 'conclusion.json')
    probe = load('evidence/serializer-event-probe.json')
    require(probe['before'] == probe['after'] and len(probe['before']) == 744 and
            probe['inputs_unchanged'] is True and probe['finished_at'], 'probe is incomplete or changed')
    require(conclusion['status'] == 'NOT_ADOPTED' and
            conclusion['source']['production_patch_applied_to_feature'] is False,
            'candidate must remain unadopted')
    require(all(conclusion['oracle'][key] == 'NOT_RUN'
                for key in ('status', 'compilation', 'execution')), 'oracle was not run')
    require(conclusion['oracle']['runtime_equivalence_status'] == 'UNVERIFIED',
            'unexecuted oracle cannot establish equivalence')
    for path, expected in probe['before'].items():
        expect(path, expected)
    for plan in (manifest, oracle):
        require(plan['cwd'] == str(CANDIDATE) and plan['uid_required'] == 1000,
                'candidate planned working directory or identity changed')
        for path, expected in plan['inputs'].items():
            expect(path, expected)
    for path, expected in conclusion['final_file_identities'].items():
        expect(path, expected)
    red = files[prefix + 'red/src/runtime_types.cpp']
    green = files[prefix + 'green/src/runtime_types.cpp']
    require(red == (FEATURE / 'src/runtime_types.cpp').read_bytes() and red != green,
            'candidate was applied to feature or variants are identical')
    require(digest(red) == source['src/runtime_types.cpp'], 'red source is not v3')
    for relative, old, new in (
            ('src/runtime_types.cpp', red, green),
            ('tests/runtime_types_tests.cpp', files['reference/feature/tests/runtime_types_tests.cpp'],
             files[prefix + 'tests/runtime_types_tests.cpp'])):
        patch_name = 'production.patch' if relative.startswith('src/') else 'tests.patch'
        diff = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),
                     new.decode().splitlines(keepends=True), fromfile='a/' + relative,
                     tofile='b/' + relative)).encode()
        require(diff == files[prefix + patch_name], 'patch does not reproduce retained bytes')
    old_tests = files['reference/feature/tests/runtime_types_tests.cpp'].decode().splitlines(keepends=True)
    proposed_tests = files[prefix + 'tests/runtime_types_tests.cpp'].decode().splitlines(keepends=True)
    require(all(tag in ('equal', 'insert') for tag, *_ in
                difflib.SequenceMatcher(a=old_tests, b=proposed_tests, autojunk=False).get_opcodes()),
            'oracle changed original test source instead of only adding cases')
    for step_name, step in oracle['steps'].items():
        require(not (CANDIDATE / 'build-records' / (step_name + '.json')).exists(),
                'unexpected oracle compilation record')
        require(not (CANDIDATE / 'build-records' / (step_name + '.log')).exists(),
                'unexpected oracle compilation log')
        require(all(not pathlib.Path(path).exists() for path in step['outputs']),
                'unexpected compiled oracle output')
    records, outputs, build_rows, run_rows = {}, {}, {}, {}
    original_test_object = str(BUILD / 'CMakeFiles/event_runtime_tests.dir/tests/event_runtime_tests.cpp.o')
    for variant in ('red', 'green'):
        values = manifest['variants'][variant]
        require(digest(files[prefix + variant + '/src/runtime_types.cpp']) == values['source_sha256'],
                'variant source does not match plan')
        for action in ('compile-runtime-types', 'link-event-runtime'):
            name = variant + '-' + action
            step = manifest['steps'][name]
            record = load(prefix + 'build-records/' + name + '.json')
            records[name] = record
            require(record['record_kind'] == 'candidate_build' and record['step'] == name and
                    record['argv'] == step['argv'] and record['cwd'] == str(CANDIDATE),
                    'actual build command or working directory differs')
            require(record['uid'] == record['gid'] == 1000 and record['exit_code'] == 0 and
                    record['inputs_unchanged'] is True and record['finished_at'], 'build not completed')
            require(record['manifest_sha256'] == digest(files[prefix + 'candidate-manifest.json']) and
                    record['runner_sha256'] == digest(files[prefix + 'run_build.py']) and
                    record['input_fingerprints'] == manifest['inputs'], 'build input binding differs')
            require(record['log_sha256'] == digest(files[prefix + 'build-records/' + name + '.log']),
                    'build log identity differs')
            require(set(record['outputs']) == set(step['outputs']), 'missing actual build output')
            for path, expected in record['outputs'].items():
                expect(path, expected)
                outputs[path] = expected
            require('-O2' in record['argv'] and '-g' in record['argv'] and
                    '-fsanitize=address' in record['argv'] and '-DNDEBUG' not in record['argv'],
                    'candidate sanitizer/build flags differ')
            if step['kind'] == 'compile':
                require(record['candidate_source_sha256'] == values['source_sha256'] and
                        '-fno-omit-frame-pointer' in record['argv'], 'compile source/flags differ')
                dep = files[prefix + variant + '/build/runtime_types.cpp.o.d'].decode()
                dependency_names = set()
                for name_in_dep in shlex.split(dep.replace('\\\n', ' ').split(':', 1)[1]):
                    dep_path = pathlib.Path(name_in_dep)
                    dependency_names.add(str((dep_path if dep_path.is_absolute()
                                              else CANDIDATE / dep_path).resolve()))
                dependencies = record['actual_dependency_fingerprints_after_compile']
                require(set(dependencies) == dependency_names and len(dependencies) == 601,
                        'actual compiler dependencies differ from depfile')
                for path, expected in dependencies.items():
                    expect(path, expected)
            else:
                require(original_test_object in record['argv'] and
                        values['object'] in record['argv'], 'original test or override object missing')
                require(record['link_identity']['verified'] and
                        record['link_identity']['nm_exit_code'] == 0 and
                        len(record['link_identity']['canonical_definitions']) == 1,
                        'recorded link identity failed')
                link_map = pathlib.Path(values['event_runtime_link_map']).read_text()
                require(values['object'] in link_map and original_test_object in link_map and
                        'libwls_s1.a(runtime_types.cpp.o)' not in link_map,
                        'link map does not use the isolated override')
                require(len([line for line in link_map.splitlines() if
                             'wls::s1::canonical_json[abi:cxx11](boost::json::value const&)' in line]) == 1,
                        'canonical symbol is ambiguous in map')
                for library in ('libwls_s1.a', 'libwls_kernel.a'):
                    require(str(BUILD / library) in record['argv'], 'original library missing')
            build_rows[name] = {key: record[key] for key in
                               ('argv', 'cwd', 'uid', 'gid', 'exit_code', 'elapsed_seconds', 'outputs')}
        registration = files[prefix + variant + '/build/CTestTestfile.cmake'].decode()
        expected_registration = ('add_test(event_runtime "' + values['event_runtime_binary'] + '")\n'
            'set_tests_properties(event_runtime PROPERTIES TIMEOUT 90 WORKING_DIRECTORY "' + str(BUILD) + '")\n')
        require(registration == expected_registration, 'original suite registration/deadline differs')
        name = 'serializer-event-' + variant
        record = load('evidence/' + name + '.json')
        require(record['command'] == ['ctest', '--test-dir', str(CANDIDATE / variant / 'build'),
                '--output-on-failure', '--parallel', '1'] and record['cwd'] == str(FEATURE),
                'probe selected a different command')
        require(record['before'] == record['after'] == source and record['inputs_unchanged'],
                'feature source differs during probe')
        require(record['binaries_before'] == record['binaries_after'] and record['binaries_unchanged'],
                'probe binary changed')
        require(record['uid'] == record['gid'] == 1000 and record['umask'] == '0002' and
                record['cpu_affinity'] == [0, 1, 2, 3] and record['exit_code'] == 8 and record['finished_at'],
                'probe identity, completion or exit differs')
        require(record['environment']['ASAN_OPTIONS'] == 'halt_on_error=1:detect_leaks=1' and
                all(value == '0000000000000000' for value in record['capabilities'].values()),
                'probe sanitizer or privilege settings differ')
        require(record['binaries_after']['event_runtime_tests'] == outputs[values['event_runtime_binary']],
                'executed binary differs from successful isolated link output')
        require(record['binaries_after']['CTestTestfile.cmake']['sha256'] == digest(registration.encode()),
                'executed CTest configuration differs')
        require(record['log_sha256'] == digest(files['evidence/' + name + '.log']), 'probe log differs')
        require(probe['runs'][variant]['wrapper_exit_code'] == 8 and
                probe['runs'][variant]['record_sha256'] == digest(files['evidence/' + name + '.json']) and
                probe['runs'][variant]['detail_log_sha256'] == digest(files['evidence/' + name + '-detail.log']),
                'wrapper record does not bind completed probe')
        log = files['evidence/' + name + '.log'].decode()
        detail = files['evidence/' + name + '-detail.log'].decode()
        seconds = '90.48' if variant == 'red' else '90.49'
        require('0% tests passed, 1 tests failed out of 1' in log and
                re.search(r'1/1 Test #1: event_runtime\s+\.+\*\*\*Timeout\s+' + re.escape(seconds) + r' sec', log),
                'expected original Timeout result missing')
        require('Test time =  ' + seconds + ' sec' in detail and 'Test Failed.' in detail,
                'original LastTest evidence differs')
        require(files['evidence/' + name + '-detail.log'] ==
                (CANDIDATE / variant / 'build/Testing/Temporary/LastTest.log').read_bytes(),
                'LastTest snapshot changed')
        run_rows[variant] = {'status': 'Timeout', 'passed': 0, 'selected': 1,
                             'exit_code': 8, 'test_seconds': float(seconds),
                             'original_timeout_seconds': 90,
                             'binary': record['binaries_after']['event_runtime_tests']}
    for action in ('compile-runtime-types', 'link-event-runtime'):
        normalized = []
        for variant in ('red', 'green'):
            normalized.append([arg.replace(str(CANDIDATE / variant), '<VARIANT>')
                               for arg in records[variant + '-' + action]['argv']])
        require(normalized[0] == normalized[1], 'variant compiler/linker arguments differ beyond paths')
    ninja = files['reference/feature/build-asan-clang-opt/build.ninja'].decode()
    require('cmake_ninja_workdir = ' + str(BUILD) + '/' in ninja,
            'original configured Ninja working directory changed')
    for target in ('CMakeFiles/wls_s1.dir/src/runtime_types.cpp.o',
                   'CMakeFiles/event_runtime_tests.dir/tests/event_runtime_tests.cpp.o'):
        block = ninja.split('build ' + target + ':', 1)[1].split('\n\n', 1)[0]
        require('-fsanitize=address' in block and '-O2 -g ' in block and
                '-fno-omit-frame-pointer' in block and '-DNDEBUG' not in block,
                'original compile rule differs')
    fetch = load('evidence/fetch-before-r24-handoff.json')
    require(fetch['command'] == ['git', 'fetch', 'origin', '--prune'] and fetch['exit_code'] == 0 and
            fetch['finished_at'] and fetch['before'] == fetch['after'] == source and
            fetch['log_sha256'] == digest(files['evidence/fetch-before-r24-handoff.log']),
            'previously executed fetch record differs')
    summary = json.loads((FEATURE / 'docs/reports/r2-4-results.json').read_bytes())
    require(summary['local_validation_complete'] is False, 'failed main gate was relabeled complete')
    patterns = [rb'gh[pousr]_[A-Za-z0-9]{20,}', rb'github_pat_[A-Za-z0-9_]{30,}',
                rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}', rb'(?:AKIA|ASIA)[0-9A-Z]{16}',
                rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',
                rb'https?://[^\s/:]+:[^\s/@]+@', rb'(?i:Bearer)\s+[A-Za-z0-9_./+\-=]{40,}']
    suspects = sorted(name for name, data in files.items()
                      if any(re.search(pattern, data) for pattern in patterns))
    require(not suspects, 'possible credential pattern: ' + ', '.join(suspects))
    for name, data in files.items():
        if name.endswith('.py'):
            ast.parse(data)
    local_artifacts = {path: expected for path, expected in outputs.items()
                       if not path.endswith('.d')}
    require(len(local_artifacts) == 6, 'unexpected map/object/executable inventory')
    return {
        'candidate_status': 'NOT_ADOPTED', 'candidate_applied_to_feature': False,
        'oracle_compilation': 'NOT_RUN', 'oracle_execution': 'NOT_RUN',
        'runtime_equivalence': 'UNVERIFIED', 'local_validation_complete': False,
        'source_manifest_sha256': MANIFEST_SHA256, 'source_input_count': 312,
        'current_v3_source_identities_match': True, 'probe_input_count': 744,
        'current_probe_input_identities_match': True,
        'logical_original_suite_count': 1, 'original_suite_execution_count': 2,
        'completed_passing_original_suite_executions': 0, 'event_runtime_results': run_rows,
        'successful_candidate_compile_link_steps': build_rows,
        'original_ninja_configured_working_directory': str(BUILD),
        'actual_candidate_compile_link_working_directory': str(CANDIDATE),
        'original_test_object': {'local_path': original_test_object,
                                 **references[original_test_object]},
        'original_test_source_and_support_header': {
            str(FEATURE / name): references[str(FEATURE / name)]
            for name in ('tests/event_runtime_tests.cpp', 'tests/test_support.hpp')},
        'local_only_candidate_map_object_executable_artifacts': local_artifacts,
        'external_identity_references': references,
        'frozen_deliverables_unchanged': IMMUTABLE,
        'fetch_record': {'exit_code': 0, 'finished_at': fetch['finished_at'],
                         'record_sha256': digest(files['evidence/fetch-before-r24-handoff.json']),
                         'scope': 'Previously executed fetch only; no new Git command is run by this audit. This record alone does not establish branch HEAD, account permissions or a later final snapshot.'},
        'limitations': [
            'Two executions of one original suite both timed out at the unchanged 90-second deadline. Censored times do not establish relative complete runtime or zero performance effect.',
            'The proposed differential oracle source and plans were neither compiled nor run. They contribute zero completed test suites and do not establish byte/error equivalence.',
            'Four successful compiler/linker steps establish build and output identities, not semantic acceptance or a passing ASan/LSan gate.',
            'Project build inputs were checked before/after compilation; actual -MD system-header dependencies were fingerprinted after compilation. No earlier system-header snapshot is invented.',
            'Original test object, header/source, libraries, compile rules, candidate working directory and executed output digests are retained for review; maps/objects/executables remain local-only.',
            'The external candidate was not applied to frozen feature v3 and cannot be described as the final production code.',
            'The final source handoff snapshot is produced later by the parent and is not anticipated, declared complete or included recursively in this package.',
        ],
        'common_credential_pattern_matches': suspects,
    }


def create_archive():
    require(not ARCHIVE.exists(), 'refusing to replace serializer probe evidence')
    files = collect()
    result = audit(files)
    index = {
        'schema_version': 1, 'record_kind': 'unadopted_serializer_probe_text_evidence',
        'archived_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'Failed isolated candidate, source/plans and actual evidence; no tests or archived code executed during packaging.',
        'prearchive_audit': result,
        'files': {name: {'sha256': digest(data), 'bytes': len(data)}
                  for name, data in sorted(files.items())},
    }
    files['INDEX.json'] = (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode()
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(files.items()):
            path = pathlib.PurePosixPath(name)
            require(not path.is_absolute() and '..' not in path.parts, 'unsafe archive path')
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            entry.uid = entry.gid = 1000
            entry.mtime = 0
            archive.addfile(entry, io.BytesIO(data))
    encoded = gzip.compress(stream.getvalue(), mtime=0)
    immutable_check()
    with ARCHIVE.open('xb') as output:
        output.write(encoded)
    print(json.dumps({'archive': str(ARCHIVE), 'sha256': digest(encoded),
                      'archive_bytes': len(encoded), 'member_count': len(files),
                      'raw_bytes': sum(map(len, files.values())), 'candidate_status': 'NOT_ADOPTED',
                      'oracle_status': 'NOT_RUN', 'local_validation_complete': False}, indent=2))


def verify_archive():
    require(not VERIFICATION.exists(), 'refusing to replace serializer probe verification')
    files = {}
    allowed = set(members()) | {'INDEX.json'}
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        for entry in archive.getmembers():
            path = pathlib.PurePosixPath(entry.name)
            require(entry.isfile() and not path.is_absolute() and '..' not in path.parts and
                    entry.name in allowed and entry.name not in files and entry.size < 2 * 1024 * 1024,
                    'unexpected member/path/link/size')
            require(entry.mode == 0o644 and entry.uid == entry.gid == 1000, 'unexpected member mode')
            data = archive.extractfile(entry).read()
            data.decode('utf-8')
            require(b'\0' not in data and len(data) == entry.size, 'non-text or incomplete member')
            files[entry.name] = data
    require(set(files) == allowed, 'missing archive member')
    raw_bytes = sum(map(len, files.values()))
    require(raw_bytes < 8 * 1024 * 1024, 'oversized supplement')
    index_bytes = files.pop('INDEX.json')
    index = json.loads(index_bytes)
    require(index['schema_version'] == 1 and
            index['record_kind'] == 'unadopted_serializer_probe_text_evidence', 'wrong evidence type')
    require(set(index['files']) == set(files), 'index/member set differs')
    for name, data in files.items():
        require(index['files'][name] == {'sha256': digest(data), 'bytes': len(data)},
                'member digest differs: ' + name)
    require(files == collect(), 'archived bytes differ from local originals')
    audited = audit(files)
    require(audited == index['prearchive_audit'], 'recomputed audit differs')
    result = {
        'schema_version': 1, 'record_kind': 'serializer_probe_bundle_integrity_verification',
        'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'archive': str(ARCHIVE), **identity(ARCHIVE), 'member_count': len(allowed),
        'uncompressed_bytes': raw_bytes, 'index_sha256': digest(index_bytes),
        'bundle_integrity_verified': True, 'index_and_local_original_bytes_match': True,
        'candidate_status': 'NOT_ADOPTED', 'oracle_compilation': 'NOT_RUN',
        'oracle_execution': 'NOT_RUN', 'runtime_equivalence': 'UNVERIFIED',
        'local_validation_complete': False, 'event_runtime_results': audited['event_runtime_results'],
        'source_manifest_sha256': MANIFEST_SHA256, 'source_input_count': 312,
        'probe_input_count': 744, 'all_referenced_current_identities_match': True,
        'local_only_map_object_executable_count': 6, 'binary_database_map_payloads_archived': False,
        'candidate_compile_link_record_count': 4, 'all_compile_link_exit_codes_zero': True,
        'logical_original_suite_count': 1, 'original_suite_execution_count': 2,
        'completed_passing_original_suite_executions': 0,
        'archive_members_executed': False, 'tests_builds_or_git_commands_run_by_auditor': False,
        'frozen_deliverables_unchanged': IMMUTABLE, 'common_credential_pattern_matches': [],
        'scope_note': 'Read-only content and identity verification of the new archive. Failed candidate results and unexecuted oracle remain explicit; this does not establish ASan/LSan acceptance or any later handoff snapshot.',
    }
    with VERIFICATION.open('x') as output:
        output.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print('verification_sha256=' + identity(VERIFICATION)['sha256'])


if __name__ == '__main__':
    require(sys.argv[1:] in ([], ['--verify']), 'usage: archive_serializer_probe.py [--verify]')
    if sys.argv[1:]:
        verify_archive()
    else:
        create_archive()
