"""Run only a reviewed candidate compile/link step; never run test binaries."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time


root = Path(__file__).resolve().parent
if len(sys.argv) != 3 or sys.argv[1] not in ("candidate-manifest.json", "oracle-manifest.json"):
    raise SystemExit("usage: run_build.py MANIFEST STEP")
if os.getuid() != 1000 or os.geteuid() != 1000:
    raise SystemExit("candidate compilation requires ordinary UID 1000")
manifest_path = root / sys.argv[1]
manifest_bytes = manifest_path.read_bytes()
manifest = json.loads(manifest_bytes)
step_name = sys.argv[2]
step = manifest["steps"][step_name]
if step["kind"] not in ("compile", "link") or step["argv"][0] != "/usr/bin/clang++-18":
    raise SystemExit("only reviewed compiler/linker steps are accepted")


def fingerprint(path):
    path = Path(path)
    return {"sha256": hashlib.file_digest(path.open("rb"), "sha256").hexdigest(),
            "bytes": path.stat().st_size}


def check_inputs():
    for path, expected in manifest["inputs"].items():
        if fingerprint(path) != expected:
            raise RuntimeError("input identity changed: " + path)
    if "source" in step:
        if fingerprint(step["source"])["sha256"] != step["source_sha256"]:
            raise RuntimeError("candidate source identity changed")


records = root / "build-records"
records.mkdir(exist_ok=True)
record_path = records / (step_name + ".json")
log_path = records / (step_name + ".log")
if record_path.exists() or log_path.exists():
    raise SystemExit("refusing to overwrite candidate build evidence")
for output in step["outputs"]:
    path = Path(output)
    if not path.resolve().is_relative_to(root) or path.exists():
        raise SystemExit("output must be a fresh path inside the candidate: " + output)
check_inputs()
if "override_object" in step:
    variant = step_name.split("-", 1)[0]
    compiled = json.loads((records / (variant + "-compile-runtime-types.json")).read_text())
    if compiled["exit_code"] != 0 or fingerprint(step["override_object"]) != compiled["outputs"][step["override_object"]]:
        raise SystemExit("override object does not match its successful compile record")
record = {
    "record_kind": "candidate_build",
    "step": step_name,
    "argv": step["argv"],
    "cwd": str(root),
    "uid": os.getuid(),
    "gid": os.getgid(),
    "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "manifest_path": str(manifest_path),
    "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
    "runner_sha256": fingerprint(__file__)["sha256"],
    "input_fingerprints": manifest["inputs"],
    "candidate_source_sha256": step.get("source_sha256"),
}
with record_path.open("x") as output:
    json.dump(record, output, indent=2)
    output.write("\n")
started = time.monotonic()
with log_path.open("xb") as output:
    completed = subprocess.run(step["argv"], cwd=root, stdout=output, stderr=subprocess.STDOUT)
record.update(exit_code=completed.returncode,
              finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              elapsed_seconds=time.monotonic() - started,
              log_sha256=fingerprint(log_path)["sha256"])
record["outputs"] = {path: fingerprint(path) for path in step["outputs"] if Path(path).is_file()}
try:
    check_inputs()
    record["inputs_unchanged"] = True
except RuntimeError as error:
    record["inputs_unchanged"] = False
    record["identity_error"] = str(error)
if completed.returncode == 0 and step["kind"] == "compile":
    depfile = next(Path(path) for path in step["outputs"] if path.endswith(".d"))
    dependency_text = depfile.read_text().replace("\\\n", " ").split(":", 1)[1]
    dependencies = [Path(path).resolve() for path in shlex.split(dependency_text)]
    record["actual_dependency_fingerprints_after_compile"] = {
        str(path): fingerprint(path) for path in sorted(set(dependencies))
    }
    record["dependency_capture_note"] = (
        "Project inputs were checked before and after compilation; actual -MD dependency "
        "paths, including system headers, are fingerprinted after the compiler exits."
    )
if completed.returncode == 0 and step["kind"] == "link":
    binary = next(Path(path) for path in step["outputs"] if not path.endswith(".map"))
    link_map = next(Path(path) for path in step["outputs"] if path.endswith(".map"))
    symbols = subprocess.run(["nm", "-C", "--defined-only", str(binary)],
                             capture_output=True, text=True)
    canonical = [line for line in symbols.stdout.splitlines()
                 if line.endswith(" wls::s1::canonical_json[abi:cxx11](boost::json::value const&)")]
    record["link_identity"] = {
        "nm_exit_code": symbols.returncode,
        "canonical_definitions": canonical,
        "original_runtime_types_archive_member_absent":
            "libwls_s1.a(runtime_types.cpp.o)" not in link_map.read_text(),
    }
    record["link_identity"]["verified"] = (
        symbols.returncode == 0 and len(canonical) == 1
        and record["link_identity"]["original_runtime_types_archive_member_absent"]
    )
with record_path.open("w") as output:
    json.dump(record, output, indent=2)
    output.write("\n")
print(json.dumps({"step": step_name, "exit_code": completed.returncode,
                  "elapsed_seconds": record["elapsed_seconds"],
                  "inputs_unchanged": record["inputs_unchanged"],
                  "link_identity": record.get("link_identity"),
                  "record": str(record_path)}, ensure_ascii=False), flush=True)
if not record["inputs_unchanged"] or not record.get("link_identity", {}).get("verified", True):
    raise SystemExit(1)
raise SystemExit(completed.returncode)
