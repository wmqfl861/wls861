add_test(runtime_types "/mnt/d/codex-workspace/wls861-r2-4-20261029/json-serializer-candidate/oracle-build/green/runtime_types_tests")
set_tests_properties(runtime_types PROPERTIES TIMEOUT 90 WORKING_DIRECTORY "/mnt/d/codex-workspace/wls861-r2-4-20261029/feature/build-asan-clang-opt")
