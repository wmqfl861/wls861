"""Validate generated oracle inputs, then run a reviewed compile/link step."""

import hashlib
import json
from pathlib import Path
import runpy
import sys


root = Path(__file__).resolve().parent
if len(sys.argv) != 2:
    raise SystemExit("usage: run_oracle_build.py STEP")
step_name = sys.argv[1]
manifest = json.loads((root / "oracle-manifest.json").read_text())
step = manifest["steps"][step_name]
for path, record_name in step.get("generated_input_records", {}).items():
    record = json.loads((root / "build-records" / record_name).read_text())
    source = Path(path)
    identity = {"sha256": hashlib.file_digest(source.open("rb"), "sha256").hexdigest(),
                "bytes": source.stat().st_size}
    if record["exit_code"] != 0 or identity != record["outputs"][path]:
        raise SystemExit("generated input differs from successful compile: " + path)
sys.argv = [str(root / "run_build.py"), "oracle-manifest.json", step_name]
runpy.run_path(str(root / "run_build.py"), run_name="__main__")
