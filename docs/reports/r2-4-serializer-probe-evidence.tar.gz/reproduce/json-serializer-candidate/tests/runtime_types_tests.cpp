#include "wls/runtime_types.hpp"
#include "test_support.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <mutex>
#include <set>
#include <thread>

namespace {
using namespace wls::s1;


// Frozen v3 C++ algorithm: preserve the original per-key/scalar serialize and
// final DOM parse as a byte/error oracle independent of the reusable serializer.
void reference_append_canonical(const Json& value, std::string& out, std::size_t depth) {
    if (depth > 128) throw Error(ErrorCode::InvalidInput, "JSON exceeds canonical depth limit");
    if (value.is_object()) {
        std::vector<const boost::json::key_value_pair*> entries;
        for (const auto& member : value.as_object()) entries.push_back(&member);
        std::sort(entries.begin(), entries.end(), [](const auto* left, const auto* right) {
            return left->key() < right->key();
        });
        out.push_back('{');
        bool first = true;
        for (const auto* member : entries) {
            if (!first) out.push_back(',');
            first = false;
            out += boost::json::serialize(member->key());
            out.push_back(':');
            reference_append_canonical(member->value(), out, depth + 1);
        }
        out.push_back('}');
    } else if (value.is_array()) {
        out.push_back('[');
        bool first = true;
        for (const auto& element : value.as_array()) {
            if (!first) out.push_back(',');
            first = false;
            reference_append_canonical(element, out, depth + 1);
        }
        out.push_back(']');
    } else {
        if (value.is_double() && !std::isfinite(value.as_double()))
            throw Error(ErrorCode::InvalidInput, "non-finite JSON number");
        out += boost::json::serialize(value);
    }
}

std::string reference_canonical_json(const Json& value) {
    std::string result;
    reference_append_canonical(value, result, 0);
    // Program-created strings also need UTF-8 validation before hashing/storing.
    boost::json::parse_options options;
    options.max_depth = 128;
    boost::system::error_code ec;
    static_cast<void>(boost::json::parse(result, ec, {}, options));
    if (ec) throw Error(ErrorCode::InvalidInput, "canonical JSON contains invalid UTF-8 or structure");
    return result;
}

struct CanonicalObservation {
    bool rejected;
    ErrorCode code;
    std::string bytes_or_error;
};

CanonicalObservation observe_canonical(const Json& value,
        std::string (*encode)(const Json&)) {
    try { return {false, ErrorCode::InvalidInput, encode(value)}; }
    catch (const Error& error) { return {true, error.code(), error.what()}; }
}

CanonicalObservation check_original_canonical(const Json& value) {
    const auto original = observe_canonical(value, reference_canonical_json);
    const auto current = observe_canonical(value, canonical_json);
    CHECK(current.rejected == original.rejected);
    CHECK(current.code == original.code);
    CHECK(current.bytes_or_error == original.bytes_or_error);
    return current;
}

void canonical_cpp_bytes_match_original() {
    const std::vector<Json> scalars{
        nullptr, false, true, std::int64_t{0}, std::int64_t{-1}, std::uint64_t{0},
        std::numeric_limits<std::int64_t>::min(), std::numeric_limits<std::int64_t>::max(),
        std::numeric_limits<std::uint64_t>::max(),
        0.0, -0.0, 1.0, -1.0, 0.1, 1.2345678901234567, 1e-20, 1e20,
        std::numeric_limits<double>::denorm_min(), -std::numeric_limits<double>::denorm_min(),
        std::numeric_limits<double>::min(), std::numeric_limits<double>::max(),
        std::nextafter(1.0, 2.0), std::nextafter(1.0, 0.0),
        "", "plain", "中文🙂\u2028\u2029"
    };
    boost::json::array mixed;
    for (const auto& scalar : scalars) {
        CHECK(!check_original_canonical(scalar).rejected);
        mixed.push_back(scalar);
    }
    CHECK(canonical_json(Json(std::int64_t{1})) != canonical_json(Json(1.0)));
    CHECK(canonical_json(Json(0.0)) != canonical_json(Json(-0.0)));
    CHECK(canonical_json(Json(std::numeric_limits<std::int64_t>::min())) == "-9223372036854775808");
    CHECK(canonical_json(Json(std::numeric_limits<std::uint64_t>::max())) == "18446744073709551615");
    CHECK(!check_original_canonical(mixed).rejected);

    std::string controls;
    for (int value = 0; value < 32; ++value) controls.push_back(static_cast<char>(value));
    controls += "\"\\/";
    const std::string unicode = "中文🙂\u2028\u2029";
    boost::json::object object;
    for (const auto& key : std::vector<std::string>{"z", "a", "", "A", controls, unicode,
            std::string("nul\0key", 7), "line\nkey", "quote\"key", "slash/key", "back\\key"}) {
        object.emplace(key, boost::json::array{controls, unicode, mixed,
            boost::json::object{{"z", nullptr}, {"a", boost::json::array{}}}});
    }
    CHECK(!check_original_canonical(object).rejected);
    boost::json::object reverse;
    for (auto entry = object.rbegin(); entry != object.rend(); ++entry)
        reverse.emplace(entry->key(), entry->value());
    CHECK(canonical_json(object) == canonical_json(reverse));
    CHECK(!check_original_canonical(boost::json::array{object, reverse, nullptr, mixed, object}).rejected);

    boost::json::object wide;
    for (int index = 511; index >= 0; --index)
        wide.emplace("key_" + std::to_string(index), boost::json::array{index, index + 0.25, ""});
    CHECK(!check_original_canonical(wide).rejected);
}

void canonical_fragment_boundaries_match_original() {
    std::string controls;
    for (int value = 0; value < 32; ++value) controls.push_back(static_cast<char>(value));
    const std::string unicode = "中🙂\u2028\u2029";
    for (const std::size_t length : {0U, 1U, 255U, 256U, 4093U, 4094U, 4095U,
                                    4096U, 4097U, 8191U, 8192U, 8193U, 16385U}) {
        for (const char fill : {'a', '\\', '\"', '\n', '\0'}) {
            const std::string plain(length, fill);
            const std::string suffix = plain + controls + unicode;
            CHECK(!check_original_canonical(Json(plain)).rejected);
            CHECK(!check_original_canonical(Json(suffix)).rejected);
            const Json nested = boost::json::object{
                {suffix, boost::json::array{"", suffix, true, 1.0,
                    boost::json::object{{"after", ""}, {plain, suffix}}}},
                {"tail", boost::json::array{false, nullptr, suffix, "final"}}
            };
            CHECK(!check_original_canonical(nested).rejected);
        }
    }
    // Repeated small/large roots also check that serializer state is local to
    // one invocation and never survives a key/value or object/array transition.
    for (int repeat = 0; repeat < 3; ++repeat) {
        CHECK(!check_original_canonical(boost::json::array{"", std::string(9000, '\\'),
            boost::json::object{{"", ""}}, -0.0, "after"}).rejected);
        CHECK(canonical_json(Json("next")) == "\"next\"");
    }
}

Json nested_canonical_value(Json leaf, std::size_t levels, bool alternate_objects) {
    for (std::size_t level = 0; level < levels; ++level) {
        if (alternate_objects && level % 2 == 0)
            leaf = boost::json::object{{"nested", std::move(leaf)}};
        else leaf = boost::json::array{std::move(leaf)};
    }
    return leaf;
}

void canonical_rejections_match_original() {
    const std::vector<std::string> invalid_utf8{
        std::string(1, static_cast<char>(0xff)), std::string(1, static_cast<char>(0x80)),
        "\xc0\xaf", "\xc2", "\xe2\x82", "\xed\xa0\x80", "\xf4\x90\x80\x80"
    };
    for (const auto& invalid : invalid_utf8) {
        for (const std::size_t prefix : {0U, 4094U, 4095U, 4096U}) {
            const auto bad = std::string(prefix, 'x') + invalid + "suffix";
            CHECK(check_original_canonical(Json(bad)).rejected);
            CHECK(check_original_canonical(boost::json::object{{bad, "value"}}).rejected);
            CHECK(check_original_canonical(boost::json::array{"valid", bad, "after"}).rejected);
            CHECK(canonical_json(Json("after rejection")) == "\"after rejection\"");
        }
    }
    for (const double value : {std::numeric_limits<double>::infinity(),
            -std::numeric_limits<double>::infinity(), std::numeric_limits<double>::quiet_NaN()}) {
        CHECK(check_original_canonical(Json(value)).rejected);
        CHECK(check_original_canonical(boost::json::object{{"number", value}}).rejected);
        CHECK(check_original_canonical(boost::json::array{0, value, 1}).rejected);
    }
    for (const bool alternate : {false, true}) {
        for (const Json& leaf : std::vector<Json>{nullptr, boost::json::array{}, boost::json::object{}}) {
            CHECK(!check_original_canonical(nested_canonical_value(leaf, 126, alternate)).rejected);
            for (const std::size_t levels : {127U, 128U, 129U})
                (void)check_original_canonical(nested_canonical_value(leaf, levels, alternate));
            CHECK(check_original_canonical(nested_canonical_value(leaf, 130, alternate)).rejected);
        }
    }
}

void strict_json() {
    CHECK(parse_json_strict("  {\"中文\": [true, null, -2, 1.5]}\n").is_object());
    for (const std::string text : {"{\"a\":1,\"a\":2}", "{\"a\":1,\"\\u0061\":2}",
         "[{\"b\":1,\"b\":2}]", "{\"a\":{\"x\":1,\"x\":2}}", "{}{}", "{} x", "[1,]", "//x\n1",
         "1e400", "NaN", "Infinity", "\"\\uD800\"", "", " ", "{\"unterminated\":1"})
        test::throws<Error>([&] { (void)parse_json_strict(text); });
    const std::string invalid_utf8 = std::string("\"") + static_cast<char>(0xc0) + static_cast<char>(0xaf) + "\"";
    test::throws<Error>([&] { (void)parse_json_strict(invalid_utf8); });
    CHECK(parse_json_strict(R"({"same":1,"nested":{"same":2},"last":{"same":3}})").is_object());
    test::throws<Error>([] { (void)parse_json_strict("[1,2]", 4); });
    test::throws<Error>([] { (void)parse_json_strict("[[[]]]", 100, 2); });
    CHECK(parse_json_strict("18446744073709551615").as_uint64() == std::numeric_limits<std::uint64_t>::max());
}

void canonical_and_digest() {
    const auto left = parse_json_strict(R"({"z":[3,2,1],"a":{"y":2,"x":1}})");
    const auto right = parse_json_strict(R"({"a":{"x":1,"y":2},"z":[3,2,1]})");
    CHECK(canonical_json(left) == canonical_json(right));
    CHECK(canonical_json(left) == R"({"a":{"x":1,"y":2},"z":[3,2,1]})");
    CHECK(sha256_hex("abc") == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    CHECK(sha256_hex("") == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
    CHECK(sha256_hex(std::string("a\0b", 3)) != sha256_hex("a"));
    test::throws<Error>([] { (void)canonical_json(Json(std::numeric_limits<double>::infinity())); });
    test::throws<Error>([] { (void)canonical_json(Json(std::string(1, static_cast<char>(0xff)))); });
}

void decimal_money_limits_do_not_lose_microdollars() {
    for (int cents = 0; cents <= 20000; ++cents) {
        const auto spelling = std::to_string(cents / 100) + "." +
            (cents % 100 < 10 ? "0" : "") + std::to_string(cents % 100);
        CHECK(cost_limit_micro(parse_json_strict(spelling)) == static_cast<std::int64_t>(cents) * 10000);
    }
    CHECK(cost_limit_micro(parse_json_strict("2.01")) == 2010000);
    CHECK(cost_limit_micro(parse_json_strict("1e-6")) == 1);
    CHECK(cost_limit_micro(parse_json_strict("1e-7")) == 0);
    CHECK(cost_limit_micro(parse_json_strict("1.2345679")) == 1234567);
    CHECK(cost_limit_micro(parse_json_strict("2e2")) == 200000000);
    for (const auto spelling : {"-1", "true", "null", "\"2.01\"", "[]", "1e30"}) {
        bool invalid = false;
        try { (void)cost_limit_micro(parse_json_strict(spelling)); }
        catch (const Error& error) { invalid = error.code() == ErrorCode::InvalidInput; }
        CHECK(invalid);
    }
}

void catalog_shape_errors_are_user_errors() {
    validate_constraint_catalog_shape(parse_json_strict("[]"));
    validate_constraint_catalog_shape(parse_json_strict(R"([{"constraint_id":"c1","text":"original","source_revision":1}])"));
    for (const auto spelling : {R"([{"a":1,"b":2,"c":3}])",
         R"([{"constraint_id":5,"text":"x","source_revision":1}])",
         R"([{"constraint_id":"c1","text":5,"source_revision":1}])",
         R"([{"constraint_id":"c1","text":"x","source_revision":"1"}])",
         R"([{"constraint_id":"c1","text":"x","source_revision":true}])",
         R"([{"constraint_id":"c1","text":"x","source_revision":1.0}])",
         R"([{"constraint_id":"c1","text":"x","source_revision":18446744073709551615}])",
         R"([{"constraint_id":"c1","text":"x","source_revision":0}])", "{}", "[null]"}) {
        bool invalid = false;
        try { validate_constraint_catalog_shape(parse_json_strict(spelling)); }
        catch (const Error& error) { invalid = error.code() == ErrorCode::InvalidInput; }
        CHECK(invalid);
    }
}

void typed_ulids() {
    auto previous = new_id("req");
    CHECK(is_typed_id(previous, "req"));
    for (int i = 0; i < 1000; ++i) {
        const auto next = new_id("req");
        CHECK(next > previous);
        previous = next;
    }
    CHECK(!is_typed_id(previous, "tsk"));
    CHECK(!is_typed_id("req_8ZZZZZZZZZZZZZZZZZZZZZZZZZ", "req"));
    CHECK(!is_typed_id("req_01ARZ3NDEKTSV4RRFFQ69G5FAI", "req"));
    CHECK(!is_typed_id("req_01arz3ndektsv4rrffq69g5fav", "req"));
    test::throws<Error>([] { (void)new_id("not/a/prefix"); });
    test::throws<Error>([] { (void)new_id(""); });
    std::mutex mutex;
    std::set<std::string> ids;
    std::array<std::jthread, 4> threads;
    for (auto& thread : threads) thread = std::jthread([&] {
        for (int i = 0; i < 500; ++i) {
            const auto id = new_id("evt");
            std::lock_guard lock(mutex);
            ids.insert(id);
        }
    });
    for (auto& thread : threads) thread.join();
    CHECK(ids.size() == 2000);
}

void binding_round_trip_and_boundaries() {
    ExecutionBinding request;
    request.request_id = new_id("req");
    request.execution_epoch = 0;
    CHECK(execution_binding_from_json(to_json(request)) == request);
    auto task = request;
    task.task_id = new_id("tsk"); task.team_id = new_id("team");
    task.plan_revision = 1; task.task_revision = 1; task.execution_epoch = 1;
    CHECK(execution_binding_from_json(to_json(task)) == task);
    task.instruction_revision = 2; task.requirements_revision = 3;
    CHECK(execution_binding_from_json(parse_json_strict(canonical_json(to_json(task)))) == task);
    auto forged = to_json(task);
    forged.as_object()["extra_authority"] = true;
    test::throws<Error>([&] { (void)execution_binding_from_json(forged); });
    forged = to_json(task); forged.as_object()["policy_epoch"] = std::numeric_limits<std::uint64_t>::max();
    test::throws<Error>([&] { (void)execution_binding_from_json(forged); });
    forged = to_json(task); forged.as_object()["task_revision"] = 1.0;
    test::throws<Error>([&] { (void)execution_binding_from_json(forged); });
    forged = to_json(request); forged.as_object()["instruction_revision"] = 1;
    test::throws<Error>([&] { (void)execution_binding_from_json(forged); });
    for (const auto name : {"request_id", "task_id", "team_id"}) {
        forged = to_json(task); forged.as_object()[name] = "nonempty-but-not-a-typed-id";
        test::throws<Error>([&] { (void)execution_binding_from_json(forged); });
    }
    forged = to_json(task); forged.as_object()["task_id"] = task.team_id;
    test::throws<Error>([&] { (void)execution_binding_from_json(forged); });
    forged = to_json(task); forged.as_object()["request_id"] = task.request_id + std::string(1, '\0');
    test::throws<Error>([&] { (void)execution_binding_from_json(forged); });
    CHECK(role_from_string("team_lead") == wls::Role::TeamLead);
    test::throws<Error>([] { (void)role_from_string("admin"); });
}
} // namespace

int main() {
    return test::run({
        {"strict JSON rejects duplicates, bad UTF-8 and non-finite input", strict_json},
        {"canonical bytes and SHA-256 preserve content identity", canonical_and_digest},
        {"canonical C++ bytes match the frozen original algorithm", canonical_cpp_bytes_match_original},
        {"canonical key/value fragments match original bytes across buffer boundaries", canonical_fragment_boundaries_match_original},
        {"canonical UTF-8, nonfinite and depth rejections match the original", canonical_rejections_match_original},
        {"decimal money limits preserve every cent and round down sub-micro amounts", decimal_money_limits_do_not_lose_microdollars},
        {"catalog input shape rejects missing keys and wrong types as invalid input", catalog_shape_errors_are_user_errors},
        {"typed ULIDs are monotonic and unique across threads", typed_ulids},
        {"execution binding round trips keep request and task scopes distinct", binding_round_trip_and_boundaries}
    });
}
