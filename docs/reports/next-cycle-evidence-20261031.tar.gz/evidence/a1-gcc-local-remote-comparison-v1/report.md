本次为 **READ_ONLY_EVIDENCE_COMPARISON**，没有启动新的构建或测试。比较本地 `772feaee62086ddb0e7f605a7472721d3bc61406` 与 [A1 远端 Actions 41182062900](https://github.com/wmqfl861/wls861/actions/runs/41182062900) 的 `1c279f6770f5f4440adcf6b8ee2f51e2401d9a74` 原始证据。根因状态仍为 **UNDETERMINED**。

本地完整 **89 套 CTest：48 PASSED、39 TIMEOUT、2 FAILED**，CTest 退出 `8`，耗时 `7482.340725` 秒。远端同一组 **89 套全部 PASSED**，退出 `0`，耗时 `2267.143071` 秒。两边 JUnit 均记录 0 skipped / disabled，名称与注册计划逐项吻合。这里的套数不包含 unittest 方法或 subtest 的重复计数。本地状态 NOT_COMPLETE 表示门禁成功条件未满足；其执行已结束，并非仍在后台运行。

完整 89 行对应时长、外层状态和原期限在 [test-comparison.csv](/mnt/d/codex-workspace/wls861-next-20261031-065247/evidence/a1-gcc-local-remote-comparison-v1/test-comparison.csv) 与 [test-comparison.json](/mnt/d/codex-workspace/wls861-next-20261031-065247/evidence/a1-gcc-local-remote-comparison-v1/test-comparison.json)。以下为相关项目；TIMEOUT 的时间是截断观察，不能作为完整执行耗时或控制实验结果。

| CTest suite | 本地状态 / 秒 | 远端状态 / 秒 | 两侧原期限（秒） |
|---|---:|---:|---:|
| `https_transport` | FAILED / 44.0028 | PASSED / 12.3158 | 180 |
| `live_model_store_tls` | FAILED / 126.2060 | PASSED / 16.0045 | 180 |
| `live_workflow` | TIMEOUT / 300.0930 | PASSED / 156.6710 | 300 |
| `billing_baseline_e2e` | TIMEOUT / 900.0570 | PASSED / 417.5990 | 900 |
| `event_runtime` | TIMEOUT / 90.2635 | PASSED / 33.4162 | 90 |
| `single_agent_runtime` | TIMEOUT / 90.4012 | PASSED / 35.0017 | 90 |
| `r24_recovery_predicates_active` | PASSED / 63.3051 | PASSED / 5.5525 | 90 |
| `r24_recovery_predicates_terminal` | TIMEOUT / 90.4965 | PASSED / 10.2533 | 90 |
| `r24_recovery_cli_smoke` | PASSED / 61.0670 | PASSED / 5.5983 | 120 |
| `allocation_recovery_cli` | PASSED / 178.0000 | PASSED / 18.4361 | 180 |

两边原 89 项的名称、顺序、期限、规范化后的命令与属性完全相同；规范化仅替换 source/build/venv 路径。90 条实际 C++ 编译命令以及 configure argv 规范化后也逐项一致。两侧 GCC 均为 `g++-13 (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0`，Debug `-g`、C++20、原严格警告与 `-Werror`、`-fsanitize=address -fno-omit-frame-pointer`；ASan ON、UBSan OFF。构建 parallel 2，CTest parallel 1；build umask 0022，test umask 0002；ASAN_OPTIONS=`halt_on_error=1:detect_leaks=1`，UBSAN_OPTIONS=`halt_on_error=1:print_stacktrace=1`，LSAN_OPTIONS 未设置。环境清理函数逐字相同。

实际 before/after 清单显示，两侧各自源码和构建快照均未在运行期间改变。`src/`、`include/`、`db/`、`config/`、`prompts/`、`schemas/`、`third_party/` 中 **175 个输入的字节内容相同**；所有 9 个内容差异路径与 Git 提交差异一致，限于 CI、文档、门禁清单及测试 runner。原 workflow 脚本去掉两处 `ImmediateTextRunner` 接入后逐字相同，断言和期限未变；CMakeLists.txt 字节相同。这确认的是生产输入的字节边界，文件元数据和完整机器环境并不相同。

| 已记录环境 | 本地 | 远端 |
|---|---|---|
| Kernel / glibc | `Linux-6.8.0-147-generic-x86_64-with-glibc2.39` | `Linux-7.0.0-1017-azure-x86_64-with-glibc2.39` |
| CMake | `cmake version 3.28.3` | `cmake version 3.31.6` |
| Python banner | `3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]` | `3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]` |
| UID / GID | `1000 / 1000` | `1001 / 1001` |
| 共同源码文件 mode | 714 个 `0664` | 714 个 `0644` |
| 数据目录所在挂载 | `/mnt/d`, `/dev/vdb2`, ext4 `rw,relatime` | `/`, `/dev/sda1`, ext4 `rw,relatime,discard,journal_async_commit,nobarrier,errors=remount-ro,commit=30,data=writeback` |

两侧 60 个构建快照条目（包括 CMake 元数据）SHA-256 均不同，未声称它们是同一二进制。内核、挂载选项、文件 mode、CMake、UID/groups、路径以及未完整记录的 CPU/load/cgroup/runtime 状态都属于可比性限制。Python 版本 banner 一致不等于解释器及全部运行库哈希一致。远端通过不能关闭本地失败或历史 Clang 失败。

本地两个外层 FAILED 套件具有明确原始失败证据：

- `https_transport`：42 个 unittest 方法、1 个 FAIL。`test_partial_request_upload_deadline_is_not_free_retry_authority` 在 `tests/test_https_transport.py:710` 的 `assertEqual(len(peer.prefixes), 1)` 得到 `0 != 1`。该 fixture 只有收够 4096 字节后才把 prefix 放入列表；前面的 `assert_failed(result, "deadline")` 已完成。原场景期限 3500 ms、padding 900000 字节均未修改。这条堆栈说明预期前缀没有被完整记录，未给出实际 wire 上传量；后续上传证据断言尚未执行，不能据此推断零上传或重试权限问题。完整输出：[local-https_transport.log](/mnt/d/codex-workspace/wls861-next-20261031-065247/evidence/a1-gcc-local-remote-comparison-v1/local-https_transport.log)。
- `live_model_store_tls`：10 个 unittest 方法、1 个 FAIL、1 个 ERROR。`effective_live_capacity_can_persist_actual_limit_observation` 为原 18 秒子进程期限的 TimeoutExpired；`large_escaped_valid_output_fits_original_settlement_event` 为 accepted `0 != 1`。完整输出：[local-live_model_store_tls.log](/mnt/d/codex-workspace/wls861-next-20261031-065247/evidence/a1-gcc-local-remote-comparison-v1/local-live_model_store_tls.log)。

39 个外层 TIMEOUT 中，保留输出至少明确包含六套的内层 FAIL/ERROR：`live_workflow`、`billing_baseline_e2e`、`r1_window_cli_smoke`、`r2_integration_cli_smoke`、`s13_cli_smoke`、`s14_cli_smoke`。这些事实不能被“只有超时”概括。workflow 包含 cross-task 与 model-exhaustion FAIL；billing 包含已输出的多个 multi_agent/single_agent subtest FAIL。该历史样式 runner 未能在整套超时前输出其完整最终 traceback，缺失内容不能补写。

[local-failure-index.json](/mnt/d/codex-workspace/wls861-next-20261031-065247/evidence/a1-gcc-local-remote-comparison-v1/local-failure-index.json) 保留全部 41 个非通过 suite 的外层状态、已观测内层标记和从 JUnit 提取的完整输出索引。[comparison.json](/mnt/d/codex-workspace/wls861-next-20261031-065247/evidence/a1-gcc-local-remote-comparison-v1/comparison.json) 提供输入 SHA-256、工具链、环境、身份和所有相等性检查；[source-commit-diff.patch](/mnt/d/codex-workspace/wls861-next-20261031-065247/evidence/a1-gcc-local-remote-comparison-v1/source-commit-diff.patch) 保留提交差异。比较只说明不同环境下已观察到的结果差异，没有建立 CPU、存储、文件权限、工具链或实现缺陷的因果结论。
