WLS861 review evidence candidate 01

This archive is a reviewed-text candidate for the root coordinator. It contains
retained original bytes, not executable instructions. No member was executed by
the packaging task. index.json beside the tar.gz gives every member size/SHA-256,
its original path and category, plus archive identity and verification results.

Scope: original coordinator attachment and its actual local baseline/candidate
red-green runs; separately frozen legal local regressions (including four real
successful calls in the resource green case); component first fixture failure
and corrected green; non-author A3/A4 reviews and integration authorship limits;
T4 original GCC three one-shot method observations and the new observer tooling
I/O-fault red-green; Windows evidence-tool summaries and representative original
CTest LastTest/partial logs from synthetic selfchecks; four completed integrated
tooling steps (24 / 4 / 11 / 6), not product suites.

The original source/runner/input identities are metadata. Two complete historical
source overlays are deliberately omitted. Small frozen tooling candidate source
files and frozen local C++ regression fixtures are text evidence. Their synthetic
test constants are not live credentials. No binaries, temporary databases, private
key/certificate files, environment-secret files or production data are included.

Historical facts retain their own time scope. Attachment-pending NOT_RUN receipts
are not rewritten; later original attachment execution is separately recorded.
The first component fixture failure and first observer-tool failure remain present.
Passing tooling checks do not constitute native Windows product acceptance.
The three T4 method selections passed once on the original historical GCC drivers;
they are not a full product gate or three independent suites. GCC 48 pass / 2 fail /
39 timeout, Clang 29 pass / 10 timeout and old live_workflow causes stay UNRESOLVED.
Windows 11 ordinary-user acceptance stays NOT_RUN. Engineering review is not formal
coordinator PR approval or merge authorization.

The combined implementation context at selection was
976466720e5fb17f6dcc67b0660b74d246996426. Final local matrices and final-SHA remote CI
are outside this archive version. Their actual completed receipts belong in a
later independently frozen package; no pending result is prewritten as passed.
