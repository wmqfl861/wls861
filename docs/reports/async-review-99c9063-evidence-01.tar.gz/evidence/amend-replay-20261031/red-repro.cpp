// Standalone selection of the production regression cases, linked against
// the unmodified99 libraries. No alternate Store/model implementation.
#define main original_async_catalog_main
#include "../../amend/tests/async_coordinator_tests.cpp"
#undef main

int main() {
    schemas = std::make_shared<SchemaRegistry>(source / "schemas");
    base_sql = read_runtime_file(source / "db/schema.sql");
    store_sql = read_runtime_file(source / "db/migrations/004_s1_store.sql");
    tools_sql = read_runtime_file(source / "db/migrations/005_worker_tools.sql");
    events_sql = read_runtime_file(source / "db/migrations/006_event_runtime.sql");
    workflow_sql = read_runtime_file(source / "db/migrations/007_workflow_runtime.sql");
    acceptance_sql = read_runtime_file(source / "db/migrations/008_acceptance_runtime.sql");
    return test::run({
        {"AMEND replay preserves a queued current Dispatcher", amend_replay_preserves_queued_new_dispatcher},
        {"AMEND replay preserves an inflight current Dispatcher", amend_replay_preserves_inflight_new_dispatcher}});
}
