# R-A3-01 non-author source review

Reviewer: Codex agent `/root/concurrency_fix`, author of the separate R-A4
resource admission fix, not an author of the reviewed R-A3 patch. The review
was read-only; no files in `amend` were edited. Identity, reviewed file hashes,
base commit and exact patch hash are in `identity.json`.

Reviewed candidate 02 is based on
`99c9063f3e29cd6d69c56fb15815715d499a374a`; its complete diff SHA-256 is
`9aab2160d275a6b36611172984fd1cffe379e66925d8f66854d7f60eb106580e`.
The earlier candidate 01 patch (`1ac920b5cbd37469c52ca63503b6f55b9ee0635d54d991ed354c9f21fd792d4b`)
was a preparation snapshot, not a test result. Candidate 02 distinguishes the
current `business_accepted` projection from immutable submission evidence after
AMEND; this review uses the actual candidate 02 bytes.

No blocking finding was identified within the scope below. This is an
independent source review of the named candidate, not the coordinator's final
architecture acceptance, integration approval, merge authorization or a claim
of completed runtime validation.

## Scope and reasoning

| Boundary | Source reviewed | Finding |
| --- | --- | --- |
| Actual control versus exact replay | `src/async_coordinator.cpp`, `Impl::process_control`; `src/store.cpp`, `Store::amend`, `Store::cancel_request`, `Impl::replay` | Store still receives every control. Each actual control increments the request CAS; exact replay returns the original stored result without mutation. Under the declared single owner thread, that historical result cannot have a version above the row read immediately before the control. A larger result version therefore identifies a new transition without changing Store's API or bypassing its transaction. |
| Authorization before replay | `src/store.cpp`, `Impl::authorize` and `payload` | Store checks role, principal/request ownership and the issuing writer session before exact command replay. The patch does not issue a new Actor, replace command IDs, rewrite the original CAS or catch a rejected control and retry it. Changed text/catalog/CAS and foreign owner/session still fail in Store. |
| Scope of stop | `process_control` and the actual Store updates | AMEND advances requirements and team execution epochs; old calls have a lower captured requirements revision. Cancellation advances the Dispatcher epoch; old calls have a lower captured Dispatcher epoch. The patch checks each original request binding and stops only obsolete matching calls after an actual transition. A replay has no new callback-stop side effect. Calls from sibling requests are not selected. |
| Late results and UNKNOWN | Existing claim/execute/finish path, `Store::claim_offline_call`, actual cancel test | Stop is a request, not proof of completion or effect reversal. The unmodified path still settles the original response, checks original binding and feedback, and rejects stale business. The new actual-cancel regression observes an unresolved attempt before releasing the real FakeModel barrier, then checks the late original response and usage. |
| Terminal experience | `OfflineRuntime::capture_call`, `reserve_captured_call`, response application; Store reservation/claim/report and `validate_experience_target` | A current TeamLead experience call carries a current control binding and the separately immutable accepted-source snapshot. Source age does not make the current control obsolete. Store still validates current Actor/epoch, job CAS, source hash, ownership, single declared report tool and original claim. Ordinary terminal business remains refused. |
| Regression authenticity | Added 4 cases and strengthened original AMEND case in `tests/async_coordinator_tests.cpp` | Queued and in-flight replays compare request, original texts, event history, budget, attempt, final response/feedback and actual plan creation. Terminal experience is produced through a real private file, Worker submission, TeamLead check and Dispatcher acceptance; no accepted/experience rows are injected. Forged source hash and job CAS fail before new reservation. |
| Fixture concurrency and permissions | `GatedModel`, `Gate`, `test_support.hpp` | Stop observation is atomic. Original response JSON is copied under its own mutex, and model/gate waits are outside that mutex. `test::run` creates private fixtures under 0077; production workspace guards are unchanged. Original five-second barriers and CTest deadlines remain. |
| R-A4 compatibility | Reviewed R-A3 production hunk against the separate frozen R-A4 candidate | R-A3 changes only `process_control`; R-A4 leaves it untouched. A stopped never-enqueued resource waiter follows R-A4's explicit interrupted/unknown observation path. Exact replay leaves a current waiter's stop token unchanged. R-A3 fixture additions and R-A4 test header additions require ordinary integration of case registrations, not dropping either regression. |

## Method and limits

Read the full changed production hunk, added tests and implementation contract,
then followed the exact source guards listed above. The installed codebase
memory index covers an older checkout and omits the new async files; this review
uses the exact candidate source as the coverage fallback. It does not assert
current complete graph coverage.

No compiler or test process was started by this reviewer while the root agent
owned the serial build slot. The parent's recorded red counterexample is not
relabelled as a reviewer execution. Candidate execution, complete sanitizer
coverage, merged-source test identity and remote CI must be evaluated from their
own receipts. The combined patch still requires the full chosen validation
matrix and source snapshot check. No real model, paid API, production data or
production service was accessed.

The single Store owner assumption is material: borrowed `store()` access is
documented as host-thread-only and cannot be used concurrently. This patch does
not establish a new multi-writer protocol. Broader auditing of unrelated Store
and terminal workflow implementations was outside this review.
