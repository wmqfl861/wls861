# R-A3 candidate 03 fixture correction review

Reviewer: `/root/concurrency_fix`, still a non-author of R-A3. This addendum
preserves the original candidate 02 review and names the newly reviewed bytes.
Candidate 03 patch SHA-256:
`37d5cf748dd287555d8ccbece3979e261027ac14e4ce981bae65a2e2a6bfae57`.
Full identity is in `identity-candidate-03.json`.

The parent's first actual candidate run is retained in
`evidence/amend-candidate-suites-01`: CTest exit 8, no timeout, unchanged source;
Scheduler passed, Async reported 19 passed / 3 failed with `invalid typed ID
prefix`. These fixture errors were missed during the prior static review and
are not successful product validation or new product counterexamples.

Compared byte-for-byte with reviewed candidate 02, candidate 03 changes only
three `new_id` prefix literals: `stale-cas` to `stalecas`, `terminal-amend` to
`termamend`, and `terminal-cancel` to `termcancel`. The unchanged
`src/runtime_types.cpp::valid_prefix` accepts a lowercase leading letter and
only lowercase letters/digits, up to 32 bytes. All three replacement literals
meet those rules while preserving independent freshly generated command IDs.

No production code, expected ErrorCode, Store gate, comparison, fixture state,
barrier or test deadline was changed. The production source remains SHA-256
`1d3bad45995db868b96a224b575c2583d1f025b0d99cca02ea870139d72f887d`.
The original production and integration reasoning therefore remains applicable.
No additional blocking source finding was identified in this small correction.
The parent must still run candidate 03; this reviewer did not start a compiler
or test while the parent's resource build owned the build slot. This addendum
does not authorize merge or declare full/remote validation complete.
