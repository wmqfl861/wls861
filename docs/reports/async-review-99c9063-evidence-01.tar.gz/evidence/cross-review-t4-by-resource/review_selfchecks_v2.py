"""Non-author tooling checks only; no product driver, TLS request or compile."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import runpy
import signal
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock

REPO = Path(sys.argv[1]).resolve()
sys.argv = [sys.argv[0]]
sys.path.insert(0, str(REPO / "tests"))
import transport_test_observation as observation

spec = importlib.util.spec_from_file_location("review_diagnostic", REPO / "scripts/diagnose_transport_failures.py")
diagnostic = importlib.util.module_from_spec(spec)
spec.loader.exec_module(diagnostic)


class ToolingReviewChecks(unittest.TestCase):
    def test_observation_io_failure_cannot_prevent_original_peer_cleanup(self):
        # Load definitions only. /bin/false is never executed, and no Peer
        # listener or TLS context is created.
        with mock.patch.object(sys, "argv", ["review-fixture", "/bin/false", str(REPO)]):
            module = runpy.run_path(str(REPO / "tests/test_https_transport.py"), run_name="review_definitions_only")
        peer_class = module["Peer"]
        with tempfile.TemporaryDirectory(prefix="t4-review-observer-") as directory:
            observer = observation.Observation(Path(directory) / "observation.jsonl")
            stream = observer.stream
            class FailedStream:
                closed = False
                def write(self, _):
                    raise OSError("synthetic observation write failure")
                def flush(self):
                    pass
                def close(self):
                    self.closed = True
            observer.stream = FailedStream()
            stream.close()
            peer = peer_class.__new__(peer_class)
            peer.stop = threading.Event()
            peer.listener = mock.Mock()
            peer.thread = mock.Mock()
            peer.thread.is_alive.return_value = False
            peer.workers, peer.sockets, peer.requests, peer.prefixes, peer.errors = [], [], [], [], []
            peer.lock = threading.Lock()
            peer.accepted = 0
            escaped = None
            with mock.patch.dict(peer_class.close.__globals__, OBSERVATION=observer):
                try:
                    peer.close()
                except Exception as error:
                    escaped = type(error).__name__
            observed = {"observation_error_escaped": escaped, "stop_set": peer.stop.is_set(),
                        "listener_closed": peer.listener.close.called, "listener_joined": peer.thread.join.called}
            print("OBSERVER_CLEANUP " + json.dumps(observed, sort_keys=True), flush=True)
            observer.close()
            self.assertTrue(peer.stop.is_set(), "observation write failure bypassed the original stop/close/join path")
            peer.listener.close.assert_called_once()
            peer.thread.join.assert_called_once()
            self.assertIsNone(escaped)

    def test_runner_timeout_kills_its_real_synthetic_child_group(self):
        with tempfile.TemporaryDirectory(prefix="t4-review-runner-") as directory:
            output = Path(directory)
            runner = output / "diagnose_transport_failures.py"
            runner.write_text("""import json, os, pathlib, subprocess, sys, time
child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(30)'])
pathlib.Path(os.environ['TMPDIR']).parent.joinpath('pids.json').write_text(json.dumps({'leader': os.getpid(), 'child': child.pid}))
time.sleep(30)
""")
            plan = {"build": str(output), "scenarios": {"synthetic": {"python": sys.executable,
                    "method": "synthetic_process_cleanup_only", "timeout_s": 0.5}}}
            (output / "plan.json").write_text(json.dumps(plan))
            pids = {}
            try:
                # Exercise only run()'s process lifecycle with a declared
                # synthetic plan; original manifest validation is checked
                # separately, never bypassed for a product execution.
                with mock.patch.object(diagnostic, "check_plan"), mock.patch.object(diagnostic, "CASES", {"synthetic": None}):
                    self.assertEqual(diagnostic.run(argparse.Namespace(output=output)), 1)
                receipt = json.loads((output / "synthetic/execution.json").read_text())
                pids = json.loads((output / "synthetic/pids.json").read_text())
                def live(pid):
                    path = Path(f"/proc/{pid}/stat")
                    return path.exists() and path.read_text().rsplit(")", 1)[1].split()[0] != "Z"
                deadline = time.monotonic() + 1
                while any(live(pid) for pid in pids.values()) and time.monotonic() < deadline:
                    time.sleep(0.01)
                remaining = [pid for pid in pids.values() if live(pid)]
                print("RUNNER_CLEANUP " + json.dumps({"status": receipt["status"],
                    "leader_reaped": receipt["leader_reaped"], "signal": receipt["group_cleanup_signal"],
                    "live_synthetic_processes": len(remaining)}, sort_keys=True), flush=True)
                self.assertEqual(receipt["status"], "TIMEOUT")
                self.assertTrue(receipt["leader_reaped"])
                self.assertEqual(receipt["group_cleanup_signal"], "SIGKILL")
                self.assertEqual(remaining, [])
            finally:
                if pids:
                    try:
                        os.killpg(pids["leader"], signal.SIGKILL)
                    except ProcessLookupError:
                        pass


if __name__ == "__main__":
    unittest.main(verbosity=2)
