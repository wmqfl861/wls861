# T4 non-author review, first frozen candidate

Reviewer: Codex agent `/root/concurrency_fix`, not an author of the T4 patch.
Scope: the five files listed in `candidate-01-inputs.json`, captured before the
author's I/O correction. No author files were edited, and no product driver,
product test suite or compiler was executed by this reviewer.

Disposition at this snapshot: **CHANGES_REQUIRED for diagnostic tooling**.
One concrete blocking defect was found; the author and root were notified.
This does not identify a cause of the historical GCC/Clang product failures.

## Confirmed defect: observation failure can bypass original cleanup

`tests/test_https_transport.py::Peer.close` records `peer_close_start` before
setting the stop event, closing the listener or joining any thread.
`tests/transport_test_observation.py::Observation.record` lets stream write/flush
errors escape. An observation disk/write failure therefore skips the original
cleanup path. The same issue in the new prefix `finally` block can replace an
original connection exception with an observation error. The existing helper
test protects only an error while recording `subprocess_timeout`; it does not
cover the other hooks.

The independent lightweight selfcheck injected an actual `stream.write`
`OSError` into the real Observation helper and called the real `Peer.close`
method on disposable mocked cleanup endpoints. It did not create a TLS peer or
invoke a product driver. `review-selfchecks-01` exited 1 and printed:

```
OBSERVER_CLEANUP {"listener_closed": false, "listener_joined": false,
 "observation_error_escaped": "OSError", "stop_set": false}
```

Required correction: an observation I/O failure must not skip original cleanup
or replace an original result/exception. Preserve a separate, sanitized evidence
failure indication so an incomplete diagnostic cannot become a successful
diagnostic receipt. Re-run this unchanged selfcheck against the correction.

## Other checks

The author's eight lightweight selfchecks independently passed. The second
review selfcheck launched only a synthetic Python leader and child, exercised
the runner's outer timeout, and observed SIGKILL group cleanup, a reaped leader
and zero live synthetic processes. Both checks' exact argv, exits, elapsed times
and output are retained beside this review. These are tooling checks, not
product or sanitizer results.

Read-only verification of `prepared-v1/plan.json` succeeded: exact historical
head `772feaee62086ddb0e7f605a7472721d3bc61406`, 714 original input identities,
715 overlay files, two original driver binaries and three selected scenarios.
Both complete fixture ASTs, after removing the observation hooks, matched the
historical files. Original assertions, subprocess timeouts, method order and
3500 ms scenario limit were retained. The plan explicitly distinguishes selected
one-shot diagnostics from the original full-suite order and keeps
`historical_failures_closed=false`.

Default-off observation avoids file creation, clock sampling and JSON parsing.
Enabled output has bounded rows, fixed stage/field names, strict numeric/bool
types and enumerated/redacted strings. It does not copy raw payloads, IDs,
credential values, paths, hashes or exception messages into the observation.
Raw unittest output remains a separate private diagnostic log of the synthetic
fixtures. Environment filtering does not inherit model credentials, proxies,
preload or sanitizer suppression variables. Preparation freezes original source,
drivers, Python, references and copied runner before any product execution.

The process test covers ordinary same-group descendants, not escaped sessions
or a general sandbox proof. Production execution and final diagnostic evidence
remain the author's/root's responsibility after the blocking I/O issue is fixed.
The old graph generation lacks these files; review used exact source fallback.
