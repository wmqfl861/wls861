# T4 non-author review, corrected candidate

Reviewer: Codex `/root/concurrency_fix`, not an author of these five T4 files.
No author code was edited. The exact reviewed files are frozen under
`candidate-02-source/` and hashed in `candidate-02-inputs.json`.
Helper SHA-256: `66bd2f65939328315fca943f47aa4faccf119e8617054098b934d9c4c343d9d4`.
Runner SHA-256: `e1d1c5c6d2a2cca80fa5f35a40c1b95905896ed366b724c77d55ee3546e07699`.

The previously confirmed observation-I/O cleanup defect is fixed. Within this
five-file scope, no additional blocking finding remains. This conclusion is a
non-author tooling review; it is not product validation, proof of any historical
root cause, formal coordinator approval or permission to merge.

## Correction and actual independent checks

The helper now catches observation write/flush/close `OSError`/`ValueError`,
records in-memory failure, emits only a fixed sanitized warning and avoids
throwing I/O errors into original peer cleanup or network-exception paths. A
successful observation has a final closing marker. The collector requires that
marker, contiguous sequence numbers, bounded content, no limit marker and no
fixed I/O warning. The original method's return code and status remain separate;
a passing method with incomplete observations cannot make the diagnostic runner
return success. Unknown stage/field programming mistakes remain explicit.

The review's unchanged logical fault test was run on both frozen snapshots.
Version 2 of the review helper only adds the normal `.closed` stream property
needed by the corrected implementation; all cleanup assertions remain intact.
Both old and new run this same version 2 source:

| Lightweight tooling check | Actual result |
| --- | --- |
| Old candidate: observation I/O during real `Peer.close` method | Exit 1; stop=false, listener closed=false, joined=false, OSError escaped. |
| Corrected candidate: same fault and cleanup assertions | Exit 0; stop=true, listener closed=true, joined=true, no escaped exception. |
| Real synthetic Python leader/child outer timeout | Passed on both snapshots; TIMEOUT, SIGKILL process-group cleanup, leader reaped, zero live synthetic processes. |
| Corrected author's complete tooling selfcheck suite, independently rerun | 11/11 passed, exit 0, including actual disposable listener cleanup, original prefix ConnectionError identity and incomplete-observation collector refusal. |

Exact commands, UID 1000, durations and unmodified outputs are in
`review-v2-red.*`, `review-v2-green.*`, and `author-selfchecks-02.*`.
The earlier `review-selfchecks-01` failure, initial eight green selfchecks and
`review-candidate-01.md` remain intact. No C++ driver, TLS product request,
product test suite or compiler was executed by this reviewer. The author
selfcheck exercises a disposable listener without sending any request and
captures the partial-upload handler before its product invocation.

## Preserved requirements

Read-only `check_plan` passed for prepared-v2 and the five author files still
match the reviewed snapshot. The prepared plan binds historical source head
`772feaee62086ddb0e7f605a7472721d3bc61406`, all 714 historical input identities,
715 overlay files, both original driver binaries, the original Python, source
manifests, registration and copied runner. The two complete fixture ASTs after
removing observation hooks still match historical source. Assertions, method
order, driver invocation structure, 15/18-second subprocess limits, 3500 ms request
deadline and actual 180-second historical TLS suite deadlines remain intact.

Default-off observation performs no file, clock or JSON-parsing work. Enabled
observations are bounded and allow only fixed stages, fixed field names, strict
counts/flags and known or redacted enums. No dynamic exception message, request
or response body, credential, path, identifier or hash is copied into the
observation. Runner environment filtering excludes secrets/proxies/preload and
keeps the original explicit ASan/LSan and UBSan options. Raw synthetic unittest
output stays separate in the private diagnostic directory.

Preparation runs no product. Actual diagnostics run each of the three named
original methods once and refuse reuse of a started plan. Inputs are checked
before execution and after each scenario; per-scenario receipts survive failure.
The plan and completion keep `DIAGNOSTIC_NOT_GATE` and
`historical_failures_closed=false`. No diagnostic pass can close the prior GCC
48pass/2failed/39timeout, Clang 29pass/10timeout or live_workflow failures.

## Limits and handoff

Product diagnostic execution remains NOT_RUN by this reviewer. Root and the
author own the exclusive diagnostic window, actual product receipts and any
root-cause conclusion. Observation adds timing/JSON overhead, and selected
methods do not retain the full historical suite ordering; the plan discloses
both limits. The real process check covers ordinary same-group descendants,
not escaped sessions or general sandbox assurance. The stale graph lacks these
files; review used the exact source fallback.
