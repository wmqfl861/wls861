# T4 bounded historical TLS observations — 2026-10-31

The three selected original methods each ran **once**, all returned 0, all observation files ended completely, and before/after identity checks passed. This is three diagnostic method selections from two original suites, not three new suites or a complete product gate. No repetition was used to select green results. Historical GCC 48 pass / 2 failed / 39 timeout, Clang 29 pass / 10 timeout, and old live_workflow causes remain **UNRESOLVED**. The later A3/A4 defects do not explain earlier failures.

## Actual observations

| Original method | Selected run | Key original facts |
|---|---:|---|
| partial request upload | return 0; 5.894790 s collector / 5.661 s unittest | TLS reached ready; first recv 236 bytes; retained prefix 4096 bytes; supplied/reported upload 65536 of request body 901181 bytes; status/reason deadline; phase request_write; upload_may_have_occurred true; one accepted socket, no complete request, no remaining fixture thread |
| effective live capacity | return 0; 13.405899 s collector / 13.129 s unittest | Peer sent 3300099 bytes; original attempt INTERRUPTED, accepted 0; transport deadline_exceeded/reason deadline; body observed 3162011, retained 3145627 plus 101 header bytes = exact 3 MiB; raw body truncated; settlement present; consistent ledger; reserved/unknown cost 100; no resend authority |
| large escaped valid output | return 0; 6.514095 s collector / 6.227 s unittest | Peer body 1048508 bytes; original attempt COMPLETED, accepted 1; transport completed; original text character count 174662; settlement present; consistent ledger; unknown cost still 100; no resend authority |

The effective-capacity transport's own elapsed_us was 8312076, while the parent subprocess returned before its original 18-second limit and the method passed its original 16-second elapsed assertion. The code and configured request deadline were not changed. This observed elapsed time alone does not establish the cause of the historical parent timeout or identify an unfinished internal Store operation. In this selection the original bounded raw prefix and settlement were actually available. The historical run had no such returned evidence, which cannot be invented after the fact.

All original assertion bodies ran. The large-output case checked original response/body bytes and the 1–4 MiB settlement event/hash through SQLite. The effective-capacity case checked exact raw prefix content/size, truncation, settlement and unknown accounting. The upload case checked original upload counts, positive bounded prefix, exactly one accepted connection and no complete request. A zero prefix in an earlier run remains insufficient proof of zero upload and never grants retry authority.

## Source and execution identity

- Historical source HEAD: `772feaee62086ddb0e7f605a7472721d3bc61406`.
- All **714** original source manifest entries matched SHA-256 and mode. The private overlay contains **715** entries: only `tests/test_https_transport.py` and `tests/test_live_model_store.py` differ, plus the new observation helper.
- Original GCC `https_transport_driver`: `7b5c96afaddb6339b3091fd73a8d9dd50911fccd9ceb1e2e0a8cfab56be4ec02`.
- Original GCC `live_model_store_driver`: `299994c9013764886ebdfa37bdf42db8b298cdd1ee08635286dffc9d199844b0`.
- Full original source/overlay, binaries, historical manifests, Python and copied runner were verified before execution and after each selection. No product was rebuilt.
- UID 1000 on `/mnt/d`, actual `/dev/vdb2` ext4 mount. Each selected worker retained test umask `0002`, original `ASAN_OPTIONS=halt_on_error=1:detect_leaks=1`, `UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1`, and no LSAN suppressions. The original gate environment whitelist excludes credentials/proxies/preloads.
- The actual original TLS registrations have **180-second** outer bounds. The original 3500 ms request timeout, 15/18-second subprocess limits, 12/16-second elapsed assertions, waits and method order are unchanged. The other workflow suite's 300-second bound was not applied here.
- `pre-execution-environment.json` recorded no relevant compiler/CTest/driver jobs before execution. The root coordinator reserved the window without other builds or product gates. All three leaders were reaped naturally, group cleanup did not require SIGKILL, and post-execution inspection found no related workers/drivers.

## Tool implementation and independent review

Five T4 files implement default-off observations, an explicit prepare/run collector and tooling selfchecks. There is no production source/driver, Store/SQL, CMake/Make, existing Linux gate, history/handoff or third_party change in this commit. No product registration is added; the integrated catalog remains 92. The coordinator may separately register these tooling selfchecks as a CI step.

The helper's allowlist writes only stage names, monotonic offsets, numeric/boolean facts and fixed enums. Arbitrary strings and exceptions, raw request/response bytes, credentials, identifiers, hashes and paths are omitted; unknown enum strings are redacted. JSONL is created exclusively at 0600 and flushed after each bounded record. It is disabled unless explicitly requested; normal tests do not create observation files or perform the extra JSON parse. Enabled diagnostics add logging/parse overhead, documented in the prepared plan. Original assertion expressions and timeouts are retained.

A whole-file AST comparison removing only explicit observation hooks proved both test files otherwise identical to the historical source, including assertions, method order, socket behavior and deadlines. The 42 HTTPS and 10 Store methods, and TLS reuse by the 18-method workflow suite, loaded successfully without executing their products.

Non-author reviewer `/root/concurrency_fix` discovered a real defect in the first tool candidate: a log write failure could escape before Peer.close shutdown/join or replace the original prefix network error. Two added tooling regressions produced **8 pass / 2 ERROR, exit 1** on that candidate. This is a new tooling defect red example, not an old production red example. `selfchecks-v3-observer-red.*` preserve the raw failure. The first prepared plan remains **NOT_RUN**.

The fix records a fixed diagnostic I/O warning and incomplete-evidence state while allowing original cleanup and exceptions to proceed. A successful closing marker, ordered record sequence and absence of truncation/I/O warning are required by the collector; even a passing original method is not accepted as complete observations without them. The final **11 tooling selfchecks passed**, exit 0 (`selfchecks-v4-observer-green.*`). These include real disposable listener teardown on observer I/O failure, original partial-receive exception preservation, redaction, default-off behavior, original timeout propagation, bounded logs and refusal of incomplete evidence.

The independent reviewer retained a same-probe old/new red/green comparison, independently reran the 11 selfchecks, and tested actual synthetic Python parent/child process-group timeout cleanup. Those synthetic tool probes are not product/sanitizer gate results. Final review is recorded at `../cross-review-t4-by-resource/review-candidate-02.md`; it found no remaining blocker within these five files and did not grant formal PR/coordinator acceptance.

## Evidence and limits

- Exact commands, start/end times, exits and raw capture logs: `prepare-v1.*`, `prepare-v2.*`, `selfchecks-v1.*`, `selfchecks-v2.*`, `selfchecks-v3-observer-red.*`, `selfchecks-v4-observer-green.*`, `diagnostics-v2.*`.
- Historical source, observer overlay and runner manifests/hypotheses: `prepared-v2/plan.json`; author five-file manifest: `candidate-v2-inputs.json`.
- Each actual method has its original `stdout.log`, `stderr.log`, `observation.jsonl` and `execution.json` under `prepared-v2/{partial-upload,effective-capacity,large-escaped}/`.
- `prepared-v2/completion.json` records all three actual returns, complete observations, unchanged identities and `historical_failures_closed=false`.

The method selection does not reproduce the old complete suite's predecessors or machine load. All three selections passed on the retained historical binaries with observation-only Python changes. This falsifies an unconditional claim that these old binaries must fail each selected method in the current isolated window; it does not identify the previous failure's root cause. No extra runs or broader hypotheses were pursued. The final integrated release/sanitizer/CI matrix remains the root coordinator's separate work.
