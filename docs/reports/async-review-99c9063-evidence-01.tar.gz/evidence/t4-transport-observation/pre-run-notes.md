# T4 bounded transport observation preparation

Prepared 2026-10-31 as evidence_audit; independent review and product execution pending at this note's time scope. The supplied ce518883 review attachment is now present. Earlier notes recording its absence retain their earlier time scope.

Historical source: `772feaee62086ddb0e7f605a7472721d3bc61406`. Original GCC gate: 48 passed / 2 failed / 39 timeout. Historical Clang: 29 passed / 10 timeout. Historical live_workflow and full-gate root causes remain UNRESOLVED. New A3/A4 defects do not explain those earlier failures.

The prepared overlay copies all 714 historical source-manifest entries, preserving exact bytes and modes except the two observed Python scripts. It adds one helper, making 715 files. It uses the original GCC driver binaries without recompiling; both match the original binaries-before.json. Original source and overlay identities are checked before and after execution.

The three selected original methods are partial upload, effective live capacity, and large escaped valid output. They run separately once with the original historical test registration's 180-second outer bound; original 3500 ms transport deadline, 15/18-second subprocess bounds, 12/16-second assertions, and fixture waits remain unchanged. The 300-second workflow bound belongs to another suite, which this diagnostic does not execute. Selected methods omit full-suite predecessors, so passing a selection cannot close a historical full-suite failure.

The helper is disabled unless WLS_TEST_TRANSPORT_OBSERVATION names a new file. It flushes allowlisted stage, integer, boolean and fixed enum fields to 0600 JSONL. It never records raw headers/bodies, bearer values, original identifiers, hashes, paths, arbitrary exceptions or dynamic rejection strings; unknown strings become redacted. Original unittest stdout/stderr remain separate logs inside the private evidence directory and contain synthetic fixture data only. No real supplier, paid model or production service is involved.

The returned driver JSON is inspected before assertions can discard it. This adds diagnostic JSON parsing/timing overhead, while the original child timeout and assertion expressions stay unchanged. The observation records subprocess-return time before this parsing. TLS sendall completion is a peer-side completed write, not proof of client decoding, Store settlement, provider acceptance or accounting. Parent observations cannot locate an unfinished internal Store operation, and missing output on timeout cannot be invented.

The prepared plan records hypotheses rather than a cause: distinguish preparation/TLS/prefix retention for partial upload; returned transport/attempt status versus parent timeout for effective capacity; and transport/response status versus settlement refusal for escaped output. Prefix count 0 never proves zero upload or authorizes a retry.

Whole-file AST comparison, after removing only explicit observation calls/context wrappers, proves both test scripts equal the original source in all retained expressions, assertions, deadlines and method order. Eight lightweight tooling selfchecks passed; they are not added to the 92 product CTest registrations and are not product sanitizer results. No CMake, Make, production driver/library, CI gate, published SQL, third_party, historical report or handoff file is modified by T4.
