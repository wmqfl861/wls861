# T2 resource admission coverage map

Source candidate 02: `green-candidate-02.patch`, SHA-256
`4309d328de2cdefcd1a7645eca301404428879528b808c3093868f1c7adf6edf`.
Base: `99c9063f3e29cd6d69c56fb15815715d499a374a`.
This table records implemented assertions, not an execution result. The parent
agent owns serialized builds, run receipts, complete validation and integration.

| T2 requirement | Concrete assertions |
| --- | --- |
| Exact 2/2 cycle with four legitimate completions | `cross_pool_fifo_resource_heads_progress_before_slot_admission`: valid plans/orders/acks on distinct tasks, original Store reservation and claims, four successful futures, four single adapter invocations, exact request envelopes, original binding/response and durable feedback; per-key order; operation and claim deltas; no cancellation on green. |
| Baseline must demonstrate the actual cycle | Same frozen source linked with exact99's headers/libraries/assets; actual `resource-red-run-01` exit1, 1.218893 seconds, exact two AwaitingClaim/two Queued/two occupied normal slots/zero new model calls and a further zero-progress poll; close joins successfully before the failing `!structural_cycle` assertion. |
| Default 4/8 saturation and both reserves | Original `both_s1_pools_keep_their_review_execution_reserve` retains every prior bound and adds two cross-pool resource waiters. Host queues increase while each M1 pool still has only one runnable queued normal job; normal running remains 3/7, total running 4/8, review slots stay protected and all real results complete. |
| Normal/Review/Handoff and independent sibling | `resource_fifo_spans_normal_review_handoff_and_allows_siblings`: Normal Worker then Review Dispatcher then Handoff Worker for one key; a different-key normal Dispatcher commits while the first is still gated; each successor starts only after predecessor feedback, and the actual class/normal-running counts are checked. |
| Ready does not release the key | Original `same_resource_is_fifo_across_management_and_worker_pools` observes a real Ready result without polling the host. M1 has released its callback slot, but the successor owns no pool slot, original attempt is still pending and no feedback or new claim exists. |
| Non-head cancellation | `resource_waiter_cancel_preserves_active_predecessor`: cancellation finishes the undispatched waiter with unknown usage and no adapter/claim/effect, while the head remains executing. A newly admitted third waiter still cannot take the key until that same head completes. |
| Non-head AMEND | `resource_waiter_amend_preserves_original_capture_and_predecessor`: the old Handoff Worker receives no claim/model execution, preserves its revision-1 original envelope and unknown observation/reservation after real revision-2 AMEND; the sibling predecessor's request, budget and original attempt remain unchanged. |
| Failed settlement/feedback | `resource_waiter_cannot_bypass_persistence_failure`: actual SQLite trigger faults at settlement and feedback, preserved original completed response, never-invoked follower with explicit interrupted/unknown observation, retained slots, permanent halt, no business replay on evidence flush, effect count unchanged after retry. Two fault points in one case, not two suites. |
| Close and foreign destruction | `resource_waiter_close_records_original_unknown`: join real in-flight callback, settle undispatched follower without invented usage, no new business effects. `resource_waiter_foreign_destruction_preserves_pending_attempts`: no host Store writes; both original attempts remain pending then UNKNOWN on normal recovery, with original envelope/null response/no claim and stale old Actor refusal. |
| M1 fairness/compatibility | No Scheduler production/API changes. Original request/team fairness sequence assertions remain. Only the former assertion that a blocked cross-pool follower occupies a Worker slot is replaced by the corrected no-slot behavior plus stronger Ready/Store evidence checks. |

The existing async suite has 25 registered child cases in this branch. The full
product still has 92 CTest registrations. CTest's 180-second async limit and all
five-second test barriers remain unchanged. There is no new sleeping retry loop,
normal-slot borrowing, thread increase, relaxed permission or forced Actor/CAS.

All four attachment files from `docs/review-attachments-99c9063f` at `ce518883`
were read after retrieval; their exact hashes are in `attachment-inputs.json`.
The original independent cycle probe deliberately uses synthetic Error responses
and expects future exceptions; its `f.model(..., false, false, true)` sets
`error_response`, not `throws`. It remains immutable and is separately compiled
and run by the parent. The stronger new minimal case requires four actual
successful business completions and is not replaced by the original probe.
