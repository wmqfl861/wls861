# 两项修复整合核对，053ab2b

对象：数据盘 `combined/`，分支 `fix/async-review-99c9063-20261031`，
提交 `053ab2b2b1010651c3ac0b5d4e7adde02035743c`。审核者 `/root/independent_recovery_review`。
本记录是 R-A3 作者自查与 R-A4 原非作者复核后的整合核对，不能称为对自己 R-A3 修复的独立审核，
也不是第二模型评测、主协调者正式批准或合并授权。未编译、未运行产品测试、未修改仓库文件。

限定结论：没有发现合并遗漏或原测试语义被自动合并覆盖。
机器可复核的比较记录为 `integration-check-01.json`、`catalog-check-01.json`；
两个原组件的非作者复核边界继续见 `../cross-review-a4-by-amend/review-01.md` 和 `review-02.md`。

1. 两个原始独立提交为 R-A3 `065503e862f3147f3db1ee9e34a129c8091607e4`、
   R-A4 `a018d727445def59d7e0f81799793eccc6f23dd4`；集成提交分别为
   `876c4b90f8a8b146b432a7f808d6d149c3b80ca0`、`053ab2b2b1010651c3ac0b5d4e7adde02035743c`。
2. 整份集成 AsyncCoordinator 源精确等于原 R-A4 源中把唯一 99 旧 `process_control` 替换为 R-A3 新函数。
   所有其他字节均保留，证明实际转换／重放判断、旧需求／epoch stop 筛选和资源入池前资格、生命周期处理同时存在。
3. Async 注册子例为精确并集：原18，R-A3新增4，R-A4新增7，共29个唯一子例，仍然一个 CTest suite。
   原18中15个函数体逐字节保持基线，AMEND迟到、双池预留与跨池FIFO三个函数精确保留各作者加强版本。
   R-A3新增函数及共享重放回归体一致，两个 R-A4 新头文件完整一致。
4. `Fixture`、`Gate`、`Release`、原五秒 `until` 完全不变。`GatedModel` 精确保留已测 R-A3 版本，
   默认脚本仍为原 steps，stop 观察为 atomic，原 response 读写由独立 mutex 保护。
   全部 `tests/fixtures` Git 树仍为 `557fc4dc20b6f1f818654c58381f273a9ba8c225`。
5. Store 源/头/所有 store include、M1 Scheduler 源/头/原九例、SQL、CMakeLists、Makefile、Linux CI、GCC runner均未变。
   现有 baseline CMake 配置中的92个注册名与 reviewed manifest 名称集合完全一致；manifest逐字节未变，
   包含所有原期限，Async仍180秒。没有把29个方法算成29套，也没有自动改变92注册口径。
6. db、third_party、docs/handoff、历史 docs/reports 树与99相同。相对99的其他变化只有已单独集成的
   Windows证据工具修复 `88d08499df3c21051720696623a6b8d1c3e7746e`，不属于 Store/VFS/进程支持。
   `git diff --check 99 HEAD` exit0，核对时工作树干净。

已读取本轮原附件 source `aec4981953945e2e714564623cb15006bec97d4703ca6d02a4baa3c6595f8f84`
的 baseline 和两个组件候选运行收据、原始 stdout/stderr、前后身份清单；三份身份清单前后相同，见
`original-probe-identity-check-01.json`。原附件同源红绿已由 root 实际执行，和早先本地重建反例分开保留。
本核对只读取这些结果，没有重新执行它们。

combined 的实际完整矩阵、最终源码/二进制冻结、发布分支、最终 SHA 的远端 CI 和协调批准仍需主任务收据。
组件上的绿例不能自动变成 combined 绿例。图 generation `2026-10-31T06:55:42Z` 缺 Async 新文件，
因此本次依据精确提交源、提交树和实际 diff，不使用空图作完整性证明。
