# R-A4-01 非作者复核补记，候选 02

本补记保留 `review-01.md`，只核对作者新增的两个 T2 子例和文档更新。
审核者仍为 `/root/independent_recovery_review`，同模型非作者工程复核；不是正式协调批准。
实际暂存 patch SHA-256 为 `4309d328de2cdefcd1a7645eca301404428879528b808c3093868f1c7adf6edf`，
与冻结 `green-candidate-02.patch` 一致。文件身份见 `reviewed-inputs-02.json`。
生产源 SHA `19278fc63f13175b3220a80dfec2233bf1ecf760ac1b574d45cfd4214e1407a0` 与候选 01 一致。
本次没有编辑作者工作树，也没有启动编译或产品测试；暂存 `diff --check` exit 0。

`tests/async_resource_lifecycle_cases.hpp:170` 的新增交错用例，在合法 2/2 与双 reserve1 下将
Worker Normal、Dispatcher Review、Worker Handoff 按同 key 顺序提交，并使用另一 key 的 Dispatcher 兄弟。
真实 gate 观察 Normal 执行时另两项没有进模型，兄弟计划已正常提交；Normal 的反馈持久后 Review 才进入，
Review 的反馈持久后 Handoff 才进入。它检查了实际各池 outstanding、running/normal_running，
最终三调用 COMPLETED/accepted1、原 envelope/response/feedback、四个真实 claim 和预期 note 效果数量。
这覆盖了先前缺失的 host 层 Handoff 资格，而非只借用旧 M1 类别测试。

同文件 226 行的新 AMEND 用例，把另一个请求的 Worker Handoff 作为同 key 非头留在 host，
并对这个等待者执行真正的新 AMEND。它要求等待模型零调用、原捕获仍为需求1，当前请求需求2，
原 host_not_dispatched 响应、未知 usage 和保留预算都存在。不同请求的活动前驱 request/budget/attempt 完全不变，
释放真实前驱 gate 后它能正常提交计划。没有刷新旧身份、删除历史或伪造 Store 行。

前次指出的两个源码覆盖缺口已补，限定静态复核没有新增阻断。
当前是原18加7个新增子例，共25子例，仍然一个 Async CTest suite；两个故障点也仍是同一 lifecycle 子例。
两新增用例尚待 root 安排实际执行，不能据此声称本地验证、原附件同源红绿、远端 CI 或主协调批准已完成。
R-A3 的 `process_control` 修复仍须在最终集成中合入并共同验证；其余限制沿用 review-01。
