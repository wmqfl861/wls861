# R-A4-01 非作者工程复核，候选 01

审核者：`/root/independent_recovery_review`。日期：2026-10-31 UTC。
这是同模型、非 R-A4 作者的有界工程复核，不是第二模型评测、主协调者正式批准或合并授权。
审核工作树为 `resource/`，HEAD 为 `99c9063f3e29cd6d69c56fb15815715d499a374a`。
实际暂存 patch 的 SHA-256 为 `7285610985b2fd1e38ca54ac33da127de1a215652d0d4d5ec4a9bbc18927650e`，
与交付冻结 patch 一致。完整文件身份见 `reviewed-inputs-01.json`。

本次结论：在所读 R-A4 生产差异内，没有发现新的生产阻断；按原附件 NEXT 的 T2 验收要求，仍有两项应补的覆盖缺口。
候选构建、绿例、完整矩阵、最终集成和协调批准仍须分别记录，本复核不将静态判断写成已运行结果。
审核者没有修改 R-A4 源码/索引，也没有启动任何构建或产品测试。`git diff --cached --check` exit 0。

已完整读取新提供的四个原附件：

| 文件 | SHA-256 |
| --- | --- |
| REVIEW.md | `9b7a1b791abf49062382ee376821ce3f2e4f99af5efe1cd4d0c8cfd87b775cbe` |
| NEXT_AGENT_PROMPT.md | `41bcd7bfa72f2feeb3d7050db6bb42562b18fc504441107e2e5cf94a5b9272d2` |
| independent_async_repros.cpp | `aec4981953945e2e714564623cb15006bec97d4703ca6d02a4baa3c6595f8f84` |
| independent-reproduction.json | `48d147ec06c4b1d8009fdfdb97e3558f2fad7dc46587a9498dd7ffff13f39a92` |

之前 `resource-red-run-01` 是依审核描述本地重建的反例，不是这份原附件的执行。
它实际 exit 1、1.218893 秒，观察到两池各一普通槽被 AwaitingClaim 占用、四个新模型调用数为零，
随后命中 `!structural_cycle`；没有外层超时。原附件复现源的本地 baseline/candidate 执行由 root 安排，
本审核没有把附件 JSON 中 Debian/GCC14 的历史运行冒充本机结果。

采用 codebase-memory Verify 级。`list_projects`、`index_status`、相关 search 和 coverage 分页均已读取。
现有 `wls861-next-cycle` 图 generation 为 `2026-10-31T06:55:42Z`，Async 源、头和新测试均 missing，
相关符号检索为空。对本任务所需内容使用 `resource/` 实际文件和精确暂存差异 fallback，
没有用空图证明不存在调用或竞争。src/tests 两页共 26 条记录已读；与本限定差异无关的缺口没有被宣称覆盖。

实际源码判断如下：

1. `submit` 完成原始 OfflineRuntime 预约后，先用 `resource_predecessor` 扫描有界 host job 顺序，
   再向任一 M1 pool 入队（`src/async_coordinator.cpp:178,183,196`）。因此非资源头保持原预约和结果容量，
   但尚未占 pool 排队或执行槽。新资源头在一轮 poll 的 Done 清除后入队。这里不轮转 request/team，
   实际选择仍由原 `Scheduler::submit_fair`、`find_runnable`、`consume_turn` 完成。
2. `resource_predecessor` 仅接受之前同 key 的 `Done` 已结束，Ready/Retained 都继续持有 key。
   `finish` 只在原结算、业务结果/错误及反馈已持久化后 Done；反馈失败后 `retain` 仍围栏协调器。
   非头不能因 M1 slot 提前释放或已收到响应而越过未提交证据（同文件 310–346、423–460）。
3. 未入队的 Queued job 没有 callback。cancel/stop、halt、close 把它显式转入 Ready，
   产生原 `host_not_dispatched` Interrupted 观察，usage 仍未知；没有把无效 execution future 当成模型完成。
   已入队 job 必须观察 Scheduler future，`completion_observed` 只在成功 get 后置位。
   新增字段只由 owner 线程访问；callback 的 phase/response 发布仍在原 mutex 边界。
4. Store first claim、原 Actor/session、frozen binding、原 response/feedback 路径没有改变。
   `src/store.cpp`、M1 Scheduler 源/头、SQL、CMake 和 CI 对 99 基线的差异为空。
   host 普通容量减双预留、冻结 limits 验证以及独立 controls 均保留。
5. `stop_and_join` 先关闭并唤醒原 scheduled callbacks，再 join 两池。owner close 才保存证据；
   foreign destruction 不访问 Store，未入队的原预约留待原恢复置 UNKNOWN。
   halt 时不再入队，flush 只重试证据，不重做业务。没有增加线程或放宽五秒屏障/原 CTest 期限。
6. 与 R-A3 修复的逻辑相容：R-A4 不修改 `process_control`；合入 R-A3 后，真正 AMEND/cancel 可停止匹配的
   非头旧捕获，并由 R-A4 的 never-enqueued 分支记录未知观察；精确旧重放不会误停当前新捕获。
   当前 resource 独立工作树仍带 99 的旧 `process_control`，不能单独作为整个 A3/A4 已修好的交付。

T2 的已有源码覆盖为：2/2 真循环、四个合法新模型完整成功及真实 op/claim/envelope/settlement/feedback；
默认 4/8 同时饱和与两预留；跨池同 key FIFO 到 Ready 提交；非头 cancel 不干扰活动前驱；close；
foreign destruction；结算前故障及业务已提交后的反馈故障。原 18 个子例保留，新增五个仍共属一个 Async CTest suite（23 个子例），
不能报成 23 套。cycle 头文件与本地冻结红例 SHA `7007271c489611848f4900f93cd9ffcef373c04443bd9751c7bd5784c6f2a229` 相同。

仍需补的 T2 验收覆盖：

- Async host 的 `WorkClass::Handoff` 交错。现有新测试覆盖 Normal/Review，原 M1 九例覆盖 Handoff，
  但后者没有 host 延迟入队层。建议在同资源跨池 FIFO 中安排 Normal→Review→Handoff，并观察异 key 兄弟独立推进、原容量和原结算。
- 未入队资源等待者被真实 AMEND。已有 lifecycle 回归是 cancel，原 AMEND 回归是普通在途；建议补资源非头 AMEND，
  验证模型调用零、原身份/未知用量留存、无新业务效果、活动前驱不受扰，随后不以新身份重放旧捕获。

T1 对照：amend 工作树候选 02 的 queued/inflight 精确重放、多次与迟到重放、同键异参数/CAS/catalog、
错 owner/session、真实 AMEND/cancel stop 及当前 terminal experience 原源守卫覆盖与 NEXT T1 相符；它尚待实际候选测试。
原附件 T1 用 synthetic Error 响应观察 stop，候选新增测试还要求合法新计划实际提交；两者是不同测试输入，须分别记录原附件同源运行。

发布条件保持未决：补上述覆盖并执行后更新本非作者复核，运行原附件同源红绿、两改动合并的适用矩阵、
检查最终输入/二进制/远端 CI，最后交主协调者决定。历史 GCC 48/2/39timeout、Clang 29/10timeout 及旧 live_workflow 根因不由本次复核关闭。
