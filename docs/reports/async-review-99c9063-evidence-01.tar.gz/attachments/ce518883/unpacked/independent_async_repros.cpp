// Independent reviewer tests. Uses unchanged production sources and original
// fixture setup; does not modify the submitted checkout or public test catalog.
#define main upstream_async_tests_main
#include "async_coordinator_tests.cpp"
#undef main

namespace independent_review {
class StopObservingModel final : public ModelAdapter {
public:
    StopObservingModel(std::string model, std::shared_ptr<Gate> gate)
        : fake_([&] { auto script = steps(); for (auto& item : script) {
            item.status = ModelResultStatus::Error;
            item.error_code = "review_synthetic_error";
            item.error_message = "Review fixture, no business application";
            item.tool_calls.clear();
        } return script; }(), std::move(model)), gate_(std::move(gate)) {}
    AdapterCapabilities capabilities() const override { return fake_.capabilities(); }
    void validate(const ModelRequest& request) const override { fake_.validate(request); }
    ModelResponse complete(ModelRequest request, std::stop_token stop) const override {
        std::stop_callback observe(stop, [this] { observed_stop.store(true); });
        gate_->wait(stop, false);
        return fake_.complete(std::move(request));
    }
    mutable std::atomic<bool> observed_stop{false};
private:
    FakeModel fake_;
    std::shared_ptr<Gate> gate_;
};

void exact_amend_replay_must_not_cancel_post_amend_call() {
    Fixture f;
    AsyncCoordinator runtime(f.open(), schemas);
    const auto id = f.admit(runtime.store());
    const auto old_root = runtime.store().host_actor(Role::Root, id);
    const auto old_version = number(runtime.store().request(id), "state_version");
    const auto changed_text = read_runtime_file(source / "tests/fixtures/s1_amendment.txt");
    const auto constraints = fixture("s1_amended_constraints.json");
    const auto command = new_id("amend");
    auto applied = runtime.amend(old_root, old_version, changed_text, constraints, command);
    (void)runtime.poll(); const auto original_result = applied.get();
    const auto current = runtime.capture(id, Role::Dispatcher);
    auto gate = std::make_shared<Gate>(); Release release{gate};
    auto model = std::make_shared<StopObservingModel>(f.config.resolve(Role::Dispatcher).model, gate);
    auto result = runtime.submit(current, model);
    until(runtime, [&] { return gate->entered == 1; });
    CHECK(!model->observed_stop.load());
    const auto before = runtime.store().request(id);
    const auto budget_before = runtime.store().budget(id);
    auto replay = runtime.amend(old_root, old_version, changed_text, constraints, command);
    (void)runtime.poll();
    CHECK(replay.get() == original_result);
    CHECK(runtime.store().request(id) == before);
    CHECK(runtime.store().budget(id) == budget_before);
    std::cout << "AMEND_REPLAY original_result_equal=true request_unchanged=true budget_unchanged=true "
              << "new_call_stop_requested=" << model->observed_stop.load() << std::endl;
    CHECK(!model->observed_stop.load());
    gate->release(); runtime.drain();
    test::throws<Error>([&] { (void)result.get(); });
    CHECK(!model->observed_stop.load());
    CHECK(runtime.snapshot().outstanding == 0);
}

void cross_pool_fifo_must_not_hold_both_normal_slots_waiting_on_queued_predecessors() {
    Fixture f;
    AsyncCoordinatorLimits limits;
    limits.management_workers = 2; limits.worker_workers = 2;
    limits.business_capacity = 16;
    AsyncCoordinator runtime(f.open(), schemas, limits);
    const auto a = f.admit(runtime.store()), b = f.admit(runtime.store());
    const auto ta = f.ready(runtime.store(), a), tb = f.ready(runtime.store(), b);
    (void)ta;
    auto gm = std::make_shared<Gate>(), gw = std::make_shared<Gate>();
    Release rm{gm}, rw{gw};
    auto manager_blocker = runtime.submit(runtime.capture(b, Role::Dispatcher),
        f.model(gm, false, false, true), WorkClass::Normal, "block-manager");
    auto worker_blocker = runtime.submit(runtime.capture(a, Role::Worker, ta),
        f.model(gw, false, false, true), WorkClass::Normal, "block-worker");
    until(runtime, [&] { return gm->entered == 1 && gw->entered == 1; });
    // Keep each currently active request at its pool's ring head. Enqueue
    // cross-pool FIFO predecessors first, then the corresponding later jobs.
    auto ma = f.model({}, false, false, true), wb = f.model({}, false, false, true);
    auto mb = f.model({}, false, false, true), wa = f.model({}, false, false, true);
    auto fma = runtime.submit(runtime.capture(a, Role::Dispatcher), ma, WorkClass::Normal, "resource-X");
    auto fwb = runtime.submit(runtime.capture(b, Role::Worker, tb), wb, WorkClass::Normal, "resource-Y");
    auto fmb = runtime.submit(runtime.capture(b, Role::Dispatcher), mb, WorkClass::Normal, "resource-Y");
    auto fwa = runtime.submit(runtime.capture(a, Role::Worker, ta), wa, WorkClass::Normal, "resource-X");
    gm->release(); gw->release();
    bool cycle = false;
    AsyncCoordinatorSnapshot observed;
    const auto completed = [&] { return ready(fma) && ready(fwb) && ready(fmb) && ready(fwa); };
    const auto blocked_shape = [](const AsyncCoordinatorSnapshot& s) {
        return s.outstanding == 4 && s.awaiting_claim == 2 && s.queued == 2 && s.executing == 0 &&
            s.managers.normal_running == 1 && s.workers.normal_running == 1 &&
            s.managers.queued == 1 && s.workers.queued == 1 && s.resource_blocked == 2;
    };
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    while (!completed()) {
        (void)runtime.poll();
        const auto first = runtime.snapshot();
        if (ready(manager_blocker) && ready(worker_blocker) && blocked_shape(first)) {
            // Observe AwaitingClaim first, then give the owner another complete
            // pass. Legitimate resource heads would receive permission on this
            // pass. If both instead wait on queued predecessors, no worker can
            // release a Normal slot or generate another result independently.
            const auto progressed = runtime.poll();
            observed = runtime.snapshot();
            if (progressed == 0 && blocked_shape(observed) &&
                ma->calls == 0 && wb->calls == 0 && mb->calls == 0 && wa->calls == 0) {
                cycle = true; break;
            }
        }
        CHECK(std::chrono::steady_clock::now() < deadline);
        std::this_thread::yield();
    }
    std::cout << "CROSS_POOL_FIFO cycle=" << cycle << " awaiting=" << observed.awaiting_claim
              << " queued=" << observed.queued << " executing=" << observed.executing
              << " resource_blocked=" << observed.resource_blocked
              << " managers_normal_running=" << observed.managers.normal_running
              << " workers_normal_running=" << observed.workers.normal_running << std::endl;
    CHECK(!cycle);
    runtime.drain();
    test::throws<Error>([&] { (void)manager_blocker.get(); });
    test::throws<Error>([&] { (void)worker_blocker.get(); });
    for (auto* result : {&fma, &fwb, &fmb, &fwa})
        test::throws<Error>([&] { (void)result->get(); });
    CHECK(ma->calls == 1 && wb->calls == 1 && mb->calls == 1 && wa->calls == 1);
    CHECK(runtime.snapshot().outstanding == 0);

}
}
int main(int argc, char** argv) {
    schemas = std::make_shared<SchemaRegistry>(source / "schemas");
    base_sql = read_runtime_file(source / "db/schema.sql");
    store_sql = read_runtime_file(source / "db/migrations/004_s1_store.sql");
    tools_sql = read_runtime_file(source / "db/migrations/005_worker_tools.sql");
    events_sql = read_runtime_file(source / "db/migrations/006_event_runtime.sql");
    workflow_sql = read_runtime_file(source / "db/migrations/007_workflow_runtime.sql");
    acceptance_sql = read_runtime_file(source / "db/migrations/008_acceptance_runtime.sql");
    const std::string selected = argc > 1 ? argv[1] : "all";
    std::vector<test::Case> cases;
    if (selected == "all" || selected == "amend") cases.push_back({"exact AMEND replay does not stop a new-generation call", independent_review::exact_amend_replay_must_not_cancel_post_amend_call});
    if (selected == "all" || selected == "cycle") cases.push_back({"cross-pool FIFO does not deadlock fair normal slots", independent_review::cross_pool_fifo_must_not_hold_both_normal_slots_waiting_on_queued_predecessors});
    return test::run(cases);
}
