# CMake generated Testfile for 
# Source directory: /mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2
# Build directory: /mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/concurrency-v1/late-prepare-replay-omitted/build-opt-v2
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[r24_concurrency_phases]=] "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/concurrency-v1/late-prepare-replay-omitted/build-opt-v2/r24_concurrency_tests" "--group" "phases")
set_tests_properties([=[r24_concurrency_phases]=] PROPERTIES  TIMEOUT "90" _BACKTRACE_TRIPLES "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;172;add_test;/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;0;")
add_test([=[r24_concurrency_settlement]=] "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/concurrency-v1/late-prepare-replay-omitted/build-opt-v2/r24_concurrency_tests" "--group" "settlement")
set_tests_properties([=[r24_concurrency_settlement]=] PROPERTIES  TIMEOUT "90" _BACKTRACE_TRIPLES "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;172;add_test;/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;0;")
add_test([=[r24_concurrency_replay]=] "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/concurrency-v1/late-prepare-replay-omitted/build-opt-v2/r24_concurrency_tests" "--group" "replay")
set_tests_properties([=[r24_concurrency_replay]=] PROPERTIES  TIMEOUT "90" _BACKTRACE_TRIPLES "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;172;add_test;/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;0;")
add_test([=[r24_concurrency_cleanup]=] "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/concurrency-v1/late-prepare-replay-omitted/build-opt-v2/r24_concurrency_tests" "--group" "cleanup")
set_tests_properties([=[r24_concurrency_cleanup]=] PROPERTIES  TIMEOUT "90" _BACKTRACE_TRIPLES "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;172;add_test;/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;0;")
