# R2.4 single-guard sensitivity controls

These are artificial mutations used to check whether the new tests notice a missing guard. They are **not historical product defects**, are not the actual baseline, and cannot satisfy a requirement for a historical failing baseline. The fixed `079b52766ee0929472165a71a8563ce31671bb46` implementation already contains these guards. The coordinating agent observed its capacity cases passing 2/2; that positive result must remain positive.

The generator's author did not configure, compile or run these controls. The coordinating agent has separately executed the original generator to produce `generated-v1/`, with its command recorded outside this directory. Read the coordinating agent's raw command records and logs for actual build/test outcomes. The tables below describe **expected** sensitivity results, not executed results.

## Frozen generation inputs

`generate_controls.py` reads the fixed commit and verifies tree `68639e2d7eb9108739a3041a621412280a067202`. It verifies every exported file against the Git blob, checks exact SHA-256 for `src/worker_tools.cpp` and `src/store.cpp`, and requires each mutation string to occur exactly once. The checks remain enabled under `python -O`.

Each variant is copied independently from the fixed tree, with the same three new test files pinned by `control-inputs.json`. The only baseline file change is the one guard named in `production.diff`. Existing SQL, headers, API signatures, fixtures, original test files and source build instructions are copied unchanged. No symlinks/hardlinks share writable source with the original worktrees. Existing output directories are rejected. A failed partial generation is retained and must be retried under a fresh output name.

The generator writes `fixed-source-manifest.json`, per-variant full `source-manifest.json`, exact `production.diff`, before/after hashes and the changed-path list in `control.json`, plus generator/driver/test-input copies and command provenance in `generation.json`. It does not build or execute a program. An absent completed generation record means the generation did not finish.

The original executed generator has SHA-256 `3b9ce00ec87d4b746a083f19c0e38f8305150eded43bec8aa805c25f86a23a07`. Preserve it and `generated-v1/`; later generation changes must use a separate version and fresh destination.

## Six controls and expected assertions

| Variant | Exactly one omitted guard | Executable arguments | Expected failing assertion / affected subcases |
| --- | --- | --- | --- |
| `capacity-limit-no-global` | `failed_settlements.size() >= 4096` branch no longer sets the global fence; the branch and local set limit remain | `r24_settlement_capacity_tests capacity-boundary` | `active.settlement_capacity_exhausted` after the real 4097th registration attempt; 1 selected subcase |
| `allocation-catch-no-global` | The existing `catch (...)` no longer sets the global fence when the real set allocation throws injected `std::bad_alloc`; catch type remains unchanged | `r24_settlement_capacity_tests allocation-failure` | `active.failed_settlements.empty() && active.settlement_capacity_exhausted`; 1 selected subcase |
| `predicate-no-cancel-requested` | Only `CANCEL_REQUESTED` is omitted from the operation predicate; PREPARED/RUNNING remain | `r24_recovery_predicates_tests --group active` | `num(current, "dispatcher_epoch") == num(request, "dispatcher_epoch") + 1`; CANCEL_REQUESTED subcase only |
| `predicate-no-claimed-inbox` | The isolated CLAIMED inbox existence query is made false with `AND 0`; ACTIVE actor claims remain | `r24_recovery_predicates_tests --group active` | The same dispatcher epoch increment assertion; orphan inbox subcase only |
| `predicate-no-failed-experience` | Only FAILED is omitted from the experience job predicate; RUNNING/non-null claimed_by remain | Both predicate groups, run as separate processes | Active FAILED experience: dispatcher epoch assertion. DELIVERED FAILED experience: recovery event count assertion. One affected subcase in each 3-case group |
| `predicate-no-failed-cleanup` | Only FAILED is omitted from the cleanup job predicate; RUNNING/non-null claimed_by remain | `r24_recovery_predicates_tests --group terminal` | `after.at("status") == "PENDING" && after.at("claimed_by").is_null()`; DELIVERED and CANCELLED cleanup subcases |

The capacity test includes `../src/worker_tools.cpp` in its test translation unit. It must resolve to the variant's file. The 4095 prefilled set entries represent synthetic memory occupancy, **not 4095 real business executions**; two real failed settlements cross the boundary. The allocation test checks both the calibrated set-node allocation size and that exactly one allocation failed after the real result transaction rolled back.

The predicate tests assert that every other recovery trigger is absent before reopening. The legacy state injections retain original records and enforce the real SQLite schema/foreign-key/immutability constraints. A failure during admission, workspace setup or an earlier unrelated assertion is a fixture/control failure, not successful sensitivity evidence. In particular, the earlier nested constraints-array and missing workspace binding errors were fixed in the test source; their original failure logs must remain preserved as fixture errors.

There are two logical suites in this generator: capacity (two subprocess selections) and predicates (six subcases in two bounded groups). Do not count individual groups or subcases as independent suites. The additional concurrency driver support below does not add concurrency variants to this generator.

## Build choices for the coordinator

For a fresh generation, choose a new output directory. This command is an example, not a command executed by this author:

```bash
python3 controls/generate_controls.py --output /mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/generated-next
```

Each generated `<variant>/driver` is a standalone CMake driver that compiles the variant's entire original `wls_s1` library and the two test executables. It leaves source CMake files unchanged. Configure it with the same desired compiler/build/sanitizer flags as a normal isolated build; test entries retain 90 seconds. It configures only these diagnostic probe tests, while full project gates remain separate.

The optional optimized driver was added separately **after** the original generator was executed. Use `optimized-driver-v2/CMakeLists.txt`; preserve the original `optimized-driver/CMakeLists.txt` and its failed configure record. The v2 driver reuses only the fixed ordinary Release archives from `build-baseline-release`:

- `libwls_s1.a`: `81965f89acee235b7267fb54e776bf4565d2efa50495dfee4bded044d5a60f68`
- `libwls_kernel.a`: `3732f83f7402a947123203ab7599f7a25805c60a178d3034fd6a029253d1b2cd`
- Original `baseline-build-core.json`: `e01463e48b855b122ecfc8f001e66ce4783fc12df771b19bf8755c70b91c2a4f`

It checks the successful build record, original log hash, all 312 recorded before/after inputs against current baseline files, fixed baseline HEAD, compiler/Release flag compatibility, and every generated source-manifest entry. It writes `optimized-inputs.txt`, exports `compile_commands.json`, and emits a link map for each executable. It rejects sanitizer/non-Release reuse because these archives are not instrumented; complete sanitizer validation still requires fully instrumented builds.

The first optimized configuration exited 1 before compilation because CMake `load_cache` omitted the explicitly empty `CMAKE_CXX_FLAGS:STRING=` entry. The original unquoted comparison treated the missing variable name as a literal. This was a harness configuration error, not a product red case. A read-only `cmake -P` cache diagnostic reproduced that fact with exit 0; its script, raw output, command and output hash are preserved in `cache-value-diagnostic.*`. v2 requires exactly one raw cache record for each checked setting, preserves empty values, quotes comparisons, and prints actual/expected settings. It retains all identity checks. No configure/build/test was performed by this author for v2.

Example from the task root, using a new build directory because the failed cache is tied to the original driver source:

```bash
cmake -S controls/optimized-driver-v2 \
  -B controls/generated-v1/capacity-limit-no-global/build-opt-v2 -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DR24_SOURCE=/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/generated-v1/capacity-limit-no-global/source \
  -DR24_BASELINE_LIB_DIR=/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/build-baseline-release
cmake --build controls/generated-v1/capacity-limit-no-global/build-opt-v2 \
  --target r24_settlement_capacity_tests --parallel 2
ctest --test-dir controls/generated-v1/capacity-limit-no-global/build-opt-v2 \
  -R '^r24_settlement_capacity_boundary$' --output-on-failure
```

Run the matching pristine test under the same business conditions and preserve both raw logs, commands, real exit codes, before/after manifests and executable hashes. Sensitivity controls should exit nonzero at the predicted assertion. The runner must preserve that nonzero exit; it must not rewrite it as an ordinary test pass. A timeout, compiler error, unrelated assertion or unfinished process is inconclusive.

For Store mutations, the optimized driver compiles only the variant's `src/store.cpp` as an explicit OBJECT input before the imported archive. Inspect its link map and confirm that the override object is present and **`libwls_s1.a(store.cpp.o)` was not extracted**. For capacity and concurrency test translation units, confirm that **`libwls_s1.a(worker_tools.cpp.o)` was not extracted**, because the translation unit includes the variant implementation. Checking only archive filenames or test return values is insufficient.

The optimized driver also recognizes a separately generated variant containing `tests/r24_concurrency_tests.cpp` and registers the `phases`, `settlement`, `replay`, and `cleanup` groups at 90 seconds. Such a variant needs the same `control.json` fields (`name`, `baseline_commit`, `changed_production_paths`) and a complete `source-manifest.json` including the new test. Exactly one changed production path is accepted: `src/store.cpp` selects the Store override object; `src/worker_tools.cpp` relies on the test's private include. The coordinator owns generation and evidence for those additional variants.

## Old a6 API and library provenance

`a6-api-and-library-provenance.json` is a read-only audit, not a new test run. It confirms that the old baseline remains clean at `a6b8559018a599d7a806b05942857a56d69a00ce`, the four original configure/build/compile/link records have successful real exits and matching raw log hashes, their 308 input hashes still match, and all five captured binary/library identities match their current bytes.

The new predicate suite is statically API-compatible with a6: its referenced header/SQL/configuration/fixture scope differs only by the added `StoreActor.writer_session` field and comments, and the predicate source never names that field. **Compile against a6 headers if linking the old a6 archives**; mixing the new StoreActor layout with an old archive is ABI-incompatible.

No new predicate compilation or execution against a6 was performed by this author. a6 unconditionally calls selected-request recovery, so a future run may pass the necessary-recovery checks and then fail after `CHECKPOINT isolated recovery passed; checking idle reopen`. That is the already known repeated-open behavior, not a new historical missing-predicate defect. Original R2.4 red logs belong to their original test identities and cannot be substituted for this new suite.
