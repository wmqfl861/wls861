#!/usr/bin/env python3
"""Generate isolated single-guard sensitivity controls; never build or run them.

All source comes from the fixed Git commit, plus hash-pinned new tests. The
original worktrees and Git refs/objects are read only. Every output must be a
fresh descendant of this script's controls directory. Partial output is kept
on failure; use a new output name for a retry. Controls are artificial guard
removals, not historical product defects or historical red/green evidence.
"""
from __future__ import annotations

import argparse
import datetime
import difflib
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tarfile

COMMIT = "079b52766ee0929472165a71a8563ce31671bb46"
TREE = "68639e2d7eb9108739a3041a621412280a067202"
SOURCE_HASHES = {
    "src/worker_tools.cpp": "aedf1cfc9c428ae74b68da7922a57558996733ebe08832f809fa8c15467b689a",
    "src/store.cpp": "f196be42cd740f9484bf2f8b39f8ea668dd35ce6779ade31d4c59145216b3d7c",
}
TEST_PATHS = {
    "tests/r24_settlement_capacity_tests.cpp",
    "tests/r24_settlement_allocation_support.hpp",
    "tests/r24_recovery_predicates_tests.cpp",
}
MUTATIONS = {
    "capacity-limit-no-global": {
        "path": "src/worker_tools.cpp",
        "old": "if (active.failed_settlements.size() >= 4096) active.settlement_capacity_exhausted = true;",
        "new": "if (active.failed_settlements.size() >= 4096) { /* sensitivity control: global fence omitted */ }",
        "tests": ["r24_settlement_capacity_boundary"],
        "expected_assertions": ["active.settlement_capacity_exhausted"],
    },
    "allocation-catch-no-global": {
        "path": "src/worker_tools.cpp",
        "old": "catch (...) { active.settlement_capacity_exhausted = true; }",
        "new": "catch (...) { /* sensitivity control: global fence omitted */ }",
        "tests": ["r24_settlement_allocation_failure"],
        "expected_assertions": ["active.failed_settlements.empty() && active.settlement_capacity_exhausted"],
    },
    "predicate-no-cancel-requested": {
        "path": "src/store.cpp",
        "old": "SELECT op_id FROM ops WHERE request_id=? AND status IN ('PREPARED','RUNNING','CANCEL_REQUESTED') LIMIT 1",
        "new": "SELECT op_id FROM ops WHERE request_id=? AND status IN ('PREPARED','RUNNING') LIMIT 1",
        "tests": ["r24_recovery_predicates_active"],
        "expected_assertions": ['num(current, "dispatcher_epoch") == num(request, "dispatcher_epoch") + 1'],
    },
    "predicate-no-claimed-inbox": {
        "path": "src/store.cpp",
        "old": "SELECT event_seq FROM event_inbox WHERE request_id=? AND status='CLAIMED' LIMIT 1",
        "new": "SELECT event_seq FROM event_inbox WHERE request_id=? AND status='CLAIMED' AND 0 LIMIT 1",
        "tests": ["r24_recovery_predicates_active"],
        "expected_assertions": ['num(current, "dispatcher_epoch") == num(request, "dispatcher_epoch") + 1'],
    },
    "predicate-no-failed-experience": {
        "path": "src/store.cpp",
        "old": "SELECT experience_id FROM experience_jobs WHERE request_id=? AND status<>'DONE' AND (status IN ('RUNNING','FAILED') OR claimed_by IS NOT NULL) LIMIT 1",
        "new": "SELECT experience_id FROM experience_jobs WHERE request_id=? AND status<>'DONE' AND (status='RUNNING' OR claimed_by IS NOT NULL) LIMIT 1",
        "tests": ["r24_recovery_predicates_active", "r24_recovery_predicates_terminal"],
        "expected_assertions": [
            'num(current, "dispatcher_epoch") == num(request, "dispatcher_epoch") + 1',
            "after_events.size() == events.size() + (event_type.empty() ? 0U : 1U)",
        ],
    },
    "predicate-no-failed-cleanup": {
        "path": "src/store.cpp",
        "old": "SELECT cleanup_id FROM cleanup_jobs WHERE request_id=? AND status<>'DONE' AND (status IN ('RUNNING','FAILED') OR claimed_by IS NOT NULL) LIMIT 1",
        "new": "SELECT cleanup_id FROM cleanup_jobs WHERE request_id=? AND status<>'DONE' AND (status='RUNNING' OR claimed_by IS NOT NULL) LIMIT 1",
        "tests": ["r24_recovery_predicates_terminal"],
        "expected_assertions": ['after.at("status") == "PENDING" && after.at("claimed_by").is_null()'],
    },
}


def require(condition: bool, message: str) -> None:
    # Unlike a bare Python assert, input/uniqueness checks survive python -O.
    if not condition:
        raise RuntimeError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def main() -> None:
    controls = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=controls.parent / "baseline")
    parser.add_argument("--test-source", type=Path, default=controls.parent / "feature")
    parser.add_argument("--test-manifest", type=Path, default=controls / "control-inputs.json")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--only", nargs="+", choices=tuple(MUTATIONS), default=list(MUTATIONS))
    args = parser.parse_args()
    require(os.getuid() != 0, "run as an ordinary user")
    baseline = args.baseline.resolve()
    output = args.output.absolute()
    require(output.resolve().is_relative_to(controls) and output.resolve() != controls,
            "output must be a fresh descendant of controls/")
    require(not output.exists() and not output.is_symlink(), "refuse to overwrite any existing output")
    require(output.parent.is_dir() and output.parent.resolve() == output.parent,
            "output parent must already exist and have no symlink traversal")
    git_commands: list[dict] = []

    def git(*command: str) -> bytes:
        argv = ["git", "-C", str(baseline), *command]
        result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        git_commands.append({"argv": argv, "exit_code": result.returncode,
                             "stdout_sha256": sha(result.stdout),
                             "stderr": result.stderr.decode("utf-8", errors="replace")})
        require(result.returncode == 0, "read-only Git command failed: " + repr(argv))
        return result.stdout

    require(git("rev-parse", "HEAD").decode().strip() == COMMIT, "baseline HEAD changed")
    require(git("rev-parse", COMMIT + "^{tree}").decode().strip() == TREE, "baseline tree changed")
    require(git("status", "--porcelain", "--untracked-files=no") == b"", "baseline tracked files are dirty")
    entries = {}
    for item in git("ls-tree", "-r", "-z", COMMIT).split(b"\0"):
        if not item:
            continue
        header, raw_path = item.split(b"\t", 1)
        mode, kind, oid = header.decode().split()
        path = raw_path.decode()
        require(kind == "blob" and mode in {"100644", "100755"}, "unsupported tree entry: " + path)
        parts = PurePosixPath(path)
        require(not parts.is_absolute() and ".." not in parts.parts and ".git" not in parts.parts,
                "unsafe tree path: " + path)
        entries[path] = {"mode": mode, "git_blob": oid}
    archive_bytes = git("archive", "--format=tar", COMMIT)
    blobs = {}
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:") as archive:
        for member in archive.getmembers():
            if member.isdir():
                continue
            require(member.isfile() and member.name in entries and member.name not in blobs,
                    "unexpected archive member: " + member.name)
            stream = archive.extractfile(member)
            require(stream is not None, "missing archive data")
            data = stream.read()
            blob_hash = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
            require(blob_hash == entries[member.name]["git_blob"], "archive does not equal Git blob")
            blobs[member.name] = data
    require(blobs.keys() == entries.keys(), "archive path set differs from fixed Git tree")
    for path, expected in SOURCE_HASHES.items():
        require(sha(blobs[path]) == expected, "fixed production source SHA-256 differs: " + path)
        require((baseline / path).read_bytes() == blobs[path], "baseline worktree differs: " + path)
    manifest_bytes = args.test_manifest.read_bytes()
    manifest = json.loads(manifest_bytes)
    require(manifest["fixed_baseline_commit"] == COMMIT and set(manifest["tests"]) == TEST_PATHS,
            "unexpected test manifest scope")
    overlay = {}
    for path, expected in manifest["tests"].items():
        require(path not in blobs, "test overlay would replace an existing baseline path")
        data = (args.test_source / path).read_bytes()
        require(sha(data) == expected, "test source changed; review and freeze a new manifest: " + path)
        overlay[path] = data
    driver_bytes = (controls / "control-driver/CMakeLists.txt").read_bytes()
    # Validate every replacement before creating any destination.
    for name in args.only:
        mutation = MUTATIONS[name]
        require(blobs[mutation["path"]].count(mutation["old"].encode()) == 1,
                "replacement must match exactly once: " + name)
    output.mkdir(mode=0o700)
    (output / "generator-inputs").mkdir()
    shutil.copyfile(__file__, output / "generator-inputs/generate_controls.py")
    (output / "generator-inputs/control-inputs.json").write_bytes(manifest_bytes)
    (output / "generator-inputs/CMakeLists.txt").write_bytes(driver_bytes)
    write_json(output / "fixed-source-manifest.json", {
        path: {**entries[path], "sha256": sha(data), "bytes": len(data)}
        for path, data in sorted(blobs.items())})
    reports = []
    for name in ["pristine", *dict.fromkeys(args.only)]:
        variant = output / name
        source = variant / "source"
        source.mkdir(parents=True)
        content = {**blobs, **overlay}
        mutation = MUTATIONS.get(name)
        diff = ""
        if mutation:
            path = mutation["path"]
            content[path] = blobs[path].replace(mutation["old"].encode(), mutation["new"].encode(), 1)
            diff = "".join(difflib.unified_diff(blobs[path].decode().splitlines(keepends=True),
                content[path].decode().splitlines(keepends=True), fromfile="a/" + path, tofile="b/" + path))
        changed = [path for path in blobs if content[path] != blobs[path]]
        require(changed == ([mutation["path"]] if mutation else []), "unexpected production diff")
        file_manifest = {}
        for path, data in sorted(content.items()):
            destination = source / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            destination.chmod(int(entries[path]["mode"], 8) & 0o777 if path in entries else 0o644)
            require(destination.read_bytes() == data, "written source differs: " + path)
            file_manifest[path] = {"sha256": sha(data), "bytes": len(data)}
        (variant / "driver").mkdir()
        (variant / "driver/CMakeLists.txt").write_bytes(driver_bytes)
        (variant / "production.diff").write_text(diff)
        write_json(variant / "source-manifest.json", file_manifest)
        report = {
            "name": name, "classification": "pristine_positive_control" if not mutation else "artificial_single_guard_sensitivity_control",
            "baseline_commit": COMMIT, "baseline_tree": TREE,
            "changed_production_paths": changed, "added_test_paths": sorted(overlay),
            "source_changes": {path: {"before_sha256": sha(blobs[path]), "after_sha256": sha(content[path])} for path in changed},
            "production_diff_sha256": sha(diff.encode()), "mutation": mutation,
            "generated_only": True, "build_executed": False, "tests_executed": False,
        }
        write_json(variant / "control.json", report)
        reports.append(report)
    write_json(output / "generation.json", {
        "format": "r24-generated-controls-v1", "generation_status": "complete",
        "classification": "artificial sensitivity controls; not historical defects",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "argv": sys.argv,
        "cwd": str(Path.cwd()), "uid": os.getuid(), "gid": os.getgid(), "python": sys.version,
        "generator_sha256": sha(Path(__file__).read_bytes()), "test_manifest_sha256": sha(manifest_bytes),
        "driver_sha256": sha(driver_bytes), "git_archive_sha256": sha(archive_bytes),
        "baseline": str(baseline), "test_source": str(args.test_source.resolve()),
        "git_commands": git_commands, "variants": reports,
        "build_executed": False, "tests_executed": False,
    })
    print(json.dumps({"output": str(output), "variants": [r["name"] for r in reports],
                      "build_executed": False, "tests_executed": False}))


if __name__ == "__main__":
    main()
