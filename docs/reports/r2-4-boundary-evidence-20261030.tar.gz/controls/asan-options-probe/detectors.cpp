// Deliberately invalid standalone programs verify diagnostic configuration.
// This is not WLS product code, a Store fixture, or a product test suite.
#include <cstdlib>
#include <cstring>

volatile int observed_value = 0;

[[gnu::noinline]] int allocate_leak() {
    auto* value = static_cast<volatile unsigned char*>(std::malloc(64));
    if (value == nullptr) return 0;
    value[0] = 17;
    return value[0];
}

int main(int argc, char** argv) {
    if (argc < 2) return 2;
    if (std::strcmp(argv[1], "clean") == 0) return 0;
    if (std::strcmp(argv[1], "leak") == 0) {
        observed_value = allocate_leak();
        return 0;
    }
    auto* value = static_cast<volatile unsigned char*>(std::malloc(16));
    if (value == nullptr) return 3;
    value[0] = 5;
    auto* raw = const_cast<unsigned char*>(value);
    if (std::strcmp(argv[1], "overflow") == 0) {
        if (argc != 3) return 2;
        const int index = std::atoi(argv[2]);
        value[index] = 9;
        observed_value = value[index];
    } else if (std::strcmp(argv[1], "use-after-free") == 0) {
        std::free(raw);
        observed_value = value[0];
        return 0;
    } else if (std::strcmp(argv[1], "double-free") == 0) {
        void (*volatile release)(void*) = std::free;
        release(raw);
        release(raw);
        return 0;
    }
    std::free(raw);
    return 0;
}
