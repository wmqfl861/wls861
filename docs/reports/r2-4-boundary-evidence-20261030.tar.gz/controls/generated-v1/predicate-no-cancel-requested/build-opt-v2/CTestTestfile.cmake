# CMake generated Testfile for 
# Source directory: /mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2
# Build directory: /mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/generated-v1/predicate-no-cancel-requested/build-opt-v2
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[r24_recovery_predicates_active]=] "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/generated-v1/predicate-no-cancel-requested/build-opt-v2/r24_recovery_predicates_tests" "--group" "active")
set_tests_properties([=[r24_recovery_predicates_active]=] PROPERTIES  TIMEOUT "90" _BACKTRACE_TRIPLES "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;165;add_test;/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;0;")
add_test([=[r24_recovery_predicates_terminal]=] "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/generated-v1/predicate-no-cancel-requested/build-opt-v2/r24_recovery_predicates_tests" "--group" "terminal")
set_tests_properties([=[r24_recovery_predicates_terminal]=] PROPERTIES  TIMEOUT "90" _BACKTRACE_TRIPLES "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;166;add_test;/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;0;")
