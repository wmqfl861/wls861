# CMake generated Testfile for 
# Source directory: /mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2
# Build directory: /mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/generated-v1/capacity-limit-no-global/build-opt-v2
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[r24_settlement_capacity_boundary]=] "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/generated-v1/capacity-limit-no-global/build-opt-v2/r24_settlement_capacity_tests" "capacity-boundary")
set_tests_properties([=[r24_settlement_capacity_boundary]=] PROPERTIES  TIMEOUT "90" _BACKTRACE_TRIPLES "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;160;add_test;/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;0;")
add_test([=[r24_settlement_allocation_failure]=] "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/generated-v1/capacity-limit-no-global/build-opt-v2/r24_settlement_capacity_tests" "allocation-failure")
set_tests_properties([=[r24_settlement_allocation_failure]=] PROPERTIES  TIMEOUT "90" _BACKTRACE_TRIPLES "/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;161;add_test;/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030/controls/optimized-driver-v2/CMakeLists.txt;0;")
