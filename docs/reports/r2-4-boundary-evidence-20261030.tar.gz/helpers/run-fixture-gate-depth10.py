"""Run unchanged sanitizer binaries in an explicitly recorded fixture filesystem."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

r = Path(__file__).resolve().parent
backend, config, label, mode = sys.argv[1:]
assert backend in ('ext4', 'ram') and config in ('asan', 'ubsan') and mode in ('probe', 'full')
assert label.replace('-', '').isalnum()
meta = r / 'evidence' / (label + '-identity.json')
assert not meta.exists()
assert os.getuid() == os.getgid() == 1000
os.umask(0o002)
expected_tmp = r / ('tmp-ram' if backend == 'ram' else 'tmp-ext4-probe')
assert Path(os.environ['TMPDIR']) == expected_tmp
assert config == 'asan'
assert os.environ['ASAN_OPTIONS'] == 'halt_on_error=1:detect_leaks=1:malloc_context_size=10'
assert not os.environ.get('LSAN_OPTIONS')
assert os.environ['UBSAN_OPTIONS'] == 'halt_on_error=1:print_stacktrace=1'
status = {line.split(':', 1)[0]: line.split(':', 1)[1].strip()
          for line in Path('/proc/self/status').read_text().splitlines() if line.startswith(('Uid:', 'Gid:', 'Cap'))}
for key in ('CapInh', 'CapPrm', 'CapEff', 'CapAmb'):
    assert int(status[key], 16) == 0
mount = json.loads(subprocess.check_output(['findmnt', '-J', '-T', str(expected_tmp)]))
assert mount['filesystems'][0]['fstype'] == ('tmpfs' if backend == 'ram' else 'ext4')
binary_manifest = json.loads((r / 'evidence' / ('binaries-v2-' + config + '.json')).read_text())
def identities():
    result = {}
    for name, expected in binary_manifest.items():
        path = r / ('build-' + config) / name if name.endswith('.a') else r / 'feature' / ('build-exec-' + config) / name
        value = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}
        assert value == expected, name
        result[name] = value
    return result
before = identities()
pattern = '^event_runtime$' if mode == 'probe' else (r / 'evidence/sanitizer-selection.txt').read_text().strip()
inventory = json.loads(subprocess.check_output(['ctest', '--test-dir', str(r / ('build-' + config)), '--show-only=json-v1', '-R', pattern]))
assert len(inventory['tests']) == (1 if mode == 'probe' else 39)
context = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'backend': backend,
           'uid': os.getuid(), 'gid': os.getgid(), 'groups': os.getgroups(), 'status': status,
           'affinity': sorted(os.sched_getaffinity(0)), 'nice': os.getpriority(os.PRIO_PROCESS, 0),
           'mount_namespace': os.readlink('/proc/self/ns/mnt'), 'mount': mount,
           'before': before, 'test_inventory': inventory,
           'ASAN_OPTIONS': os.environ['ASAN_OPTIONS'], 'LSAN_OPTIONS': os.environ.get('LSAN_OPTIONS'),
           'note': 'Explicit 10-frame allocation/free diagnostic stacks; all previously enabled memory checks and LSan remain enabled. Suppression matching and grouping differ from default. Original binary, deadlines and assertions unchanged. RAM is not ext4 or power-loss proof.'}
with meta.open('x') as output:
    output.write(json.dumps(context, indent=2) + '\n')
timing = r / 'evidence' / (label + '-time.log')
assert not timing.exists()
command = ['/usr/bin/time', '-v', '-o', str(timing), 'ctest', '--test-dir', str(r / ('build-' + config)),
           '--output-on-failure', '--parallel', '1', '-R', pattern]
result = subprocess.run([sys.executable, str(r / 'record.py'), label, str(r / 'feature'), *command], cwd=r)
after = identities()
assert before == after
context.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit_code=result.returncode,
               after=after, identities_unchanged=True, timing_log_sha256=hashlib.sha256(timing.read_bytes()).hexdigest())
meta.write_text(json.dumps(context, indent=2) + '\n')
detail = r / ('build-' + config) / 'Testing/Temporary/LastTest.log'
if detail.exists():
    with (r / 'evidence' / (label + '-detail.log')).open('xb') as output:
        output.write(detail.read_bytes())
print(json.dumps({'label': label, 'backend': backend, 'exit_code': result.returncode,
                  'binary_identities_unchanged': True, 'test_count': len(inventory['tests'])}), flush=True)
raise SystemExit(result.returncode)
