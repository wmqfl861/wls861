#!/bin/bash
set -euo pipefail
test "$(id -u)" -eq 0
task_root=/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030
task_tmp="$task_root/tmp-ext4-probe"
test -d "$task_tmp"
test ! -L "$task_tmp"
test "$(realpath -- "$task_tmp")" = "$task_tmp"
test "$(stat -c %u -- "$task_tmp")" = 1000
test "$(readlink /proc/self/ns/mnt)" != "$(readlink /proc/1/ns/mnt)"
exec setpriv --reuid=1000 --regid=1000 --init-groups --reset-env -- \
  env TMPDIR="$task_tmp" PYTHONDONTWRITEBYTECODE=1 \
  ASAN_OPTIONS=halt_on_error=1:detect_leaks=1 \
  UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 "$@"
