"""Archive reviewed text evidence, preserving raw bytes and all failed records."""
import datetime,gzip,hashlib,io,json,pathlib,re,subprocess,tarfile
r=pathlib.Path(__file__).resolve().parent
w=r/'feature';dest=w/'docs/reports'
outputs=[dest/'r2-4-boundary-evidence-20261030.tar.gz',dest/'r2-4-boundary-evidence-20261030.members.json',dest/'r2-4-boundary-inputs-20261030.sha256']
assert not any(p.exists() for p in outputs)
required=['final-v2-release-umask0022','final-v2-release-umask0002','final-v2-clang-tests','final-v3-asan-ram-tests','final-v3-ubsan-ram-tests']
freeze=json.loads((r/'evidence/final-runtime-inputs.json').read_text())['paths']
gate_results={}
for name in required:
 value=json.loads((r/'evidence'/(name+'.json')).read_text())
 assert value['exit_code'] in (0,8) and value['finished_at'] and value['runtime_inputs_unchanged'] and value['runtime_inputs_after']==freeze,name
 raw=(r/'evidence'/(name+'.log')).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==value['log_sha256'],name
 summary=re.search(rb'(\d+)% tests passed, (\d+) tests failed out of (\d+)',raw)
 expected_count=89 if 'release' in name or 'clang' in name else 39
 assert summary is not None and int(summary[3])==expected_count,name
 failed=int(summary[2]);assert (failed==0)==(value['exit_code']==0),name
 gate_results[name]={'exit_code':value['exit_code'],'test_count':expected_count,'failed_tests':failed,'passed':failed==0}
verification=json.loads((r/'evidence/final-local-verification.json').read_text())
assert verification['evidence_verification_complete'] and verification['local_validation_complete']==all(v['passed'] for v in gate_results.values())
for path,sha in freeze.items():assert hashlib.sha256((w/path).read_bytes()).hexdigest()==sha,path
members={}
def add(path,name=None):
 assert path.is_file() and not path.is_symlink(),path
 data=path.read_bytes();data.decode('utf-8')
 assert b'\0' not in data,path
 label=name or str(path.relative_to(r))
 assert label not in members and not pathlib.PurePosixPath(label).is_absolute() and '..' not in pathlib.PurePosixPath(label).parts
 members[label]=data
for path in sorted((r/'evidence').iterdir()):
 if path.is_file() and path.suffix in ('.json','.log','.txt','.sha256') and not path.name.endswith('-progress.json'):
  try:obj=json.loads(path.read_text()) if path.suffix=='.json' else None
  except json.JSONDecodeError:raise
  if isinstance(obj,dict) and 'command' in obj and 'started_at' in obj:assert 'finished_at' in obj and 'exit_code' in obj,path
  add(path)
for glob in ('record.py','run-gates*.py','run-controls*.py','run-a6-identity-proof.py','prebuild-libraries.py','finalize-local-evidence.py','bundle-evidence.py',
             'run-in-data*.sh','run-fixture-gate*.py','observe-ram-fixture.py','build-ubsan-selected.py','run-asan-options-smoke.py'):
 for path in sorted(r.glob(glob)):add(path,'helpers/'+path.name)
for directory in ('baseline-probes-v1','baseline-probes-v2','baseline-probes-v3','baseline-probes-v4','legacy-a6-probe'):
 for path in sorted((r/directory).rglob('*')):
  if path.is_file() and not path.is_symlink() and path.suffix in ('.cpp','.hpp','.txt'):add(path)
for name in ('CMakeCache.txt','build.ninja'):
 add(r/'build-legacy-a6-probe'/name)
controls=r/'controls'
add(controls/'asan-options-probe/detectors.cpp')
for path in sorted(controls.iterdir()):
 if path.is_file() and path.suffix in ('.py','.json','.md','.cmake','.log'):add(path)
for name in ('control-driver','optimized-driver','optimized-driver-v2'):
 add(controls/name/'CMakeLists.txt')
for group in ('generated-v1','concurrency-v1'):
 base=controls/group
 for path in sorted(base.iterdir()):
  if path.is_file() and path.suffix=='.json':add(path)
  elif path.is_dir() and (path/'control.json').exists():
   for name in ('control.json','production.diff','source-manifest.json'):add(path/name)
   build=path/'build-opt-v2'
   if build.exists():
    for item in sorted(build.iterdir()):
     if item.is_file() and (item.suffix=='.map' or item.name in ('optimized-inputs.txt','compile_commands.json','CTestTestfile.cmake','CMakeCache.txt')):add(item)
# Original a6 proof chain is copied without changing its historical records.
old=r.parent/'wls861-r2-4-20261029/evidence'
for stem in ('baseline-configure-ready','baseline-build','baseline-regression-compile-review','baseline-regression-link-review',
             'baseline-r24-red-private-tmpfs','baseline-r24-cleanup-red-private-tmpfs','baseline-r24-cli-red-private-tmpfs'):
 for suffix in ('.json','.log'):add(old/(stem+suffix),'historical-a6/'+stem+suffix)
add(old/'baseline-final-counterexamples.json','historical-a6/baseline-final-counterexamples.json')
for key,data in members.items():
 assert not re.search(rb'-{5}BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-{5}',data),key
 assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|AKIA[0-9A-Z]{16})',data),key
 # No binary, database, symlink or archive member is permitted by the explicit selection above.
manifest={name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in sorted(members.items())}
with outputs[0].open('xb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as archive:
   for name,data in sorted(members.items()):
    item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.uid=0;item.gid=0;item.mtime=0
    archive.addfile(item,io.BytesIO(data))
with tarfile.open(outputs[0],mode='r:gz') as archive:
 seen={}
 for member in archive:
  assert member.isfile() and member.name in manifest and member.name not in seen
  data=archive.extractfile(member).read();seen[member.name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 assert seen==manifest
record={'format':'r24-boundary-text-evidence-v1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':outputs[0].name,'archive_sha256':hashlib.sha256(outputs[0].read_bytes()).hexdigest(),'archive_bytes':outputs[0].stat().st_size,'member_count':len(manifest),'all_members_text_utf8':True,'all_members_regular_files':True,'readback_verified':True,'local_validation_complete':verification['local_validation_complete'],'local_gate_results':gate_results,'members':manifest}
outputs[1].write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
outputs[2].write_bytes((r/'evidence/final-runtime-inputs.sha256').read_bytes())
print(json.dumps({k:v for k,v in record.items() if k!='members'},indent=2))
