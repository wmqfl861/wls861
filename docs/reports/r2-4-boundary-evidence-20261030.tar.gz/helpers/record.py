"""Record actual commands without overwriting earlier evidence."""
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
name, cwd, *command = sys.argv[1:]
cwd = pathlib.Path(cwd).resolve()
log = ROOT / 'evidence' / (name + '.log')
meta = ROOT / 'evidence' / (name + '.json')
assert not log.exists() and not meta.exists()
assert command


def inputs():
    paths = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others',
                                     '--exclude-standard'], cwd=cwd).split(b'\0')
    return {os.fsdecode(name): hashlib.sha256((cwd / os.fsdecode(name)).read_bytes()).hexdigest()
            for name in sorted(set(paths)) if name and
            not os.fsdecode(name).startswith('docs/') and os.fsdecode(name) not in
            ('AGENTS.md', 'README.md', 'CHANGELOG.md', '.gitignore')}


record = {'command': command, 'cwd': str(cwd), 'uid': os.getuid(), 'gid': os.getgid(),
          'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'runtime_inputs_before': inputs(),
          'environment': {k: os.environ.get(k) for k in ('TMPDIR', 'PYTHONDONTWRITEBYTECODE', 'ASAN_OPTIONS', 'UBSAN_OPTIONS')}}
mask = os.umask(0)
os.umask(mask)
record['umask'] = format(mask, '04o')
with meta.open('x') as output:
    output.write(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
with log.open('xb') as output:
    result = subprocess.run(command, cwd=cwd, stdout=output, stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start,
              finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              runtime_inputs_after=inputs(), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
record['runtime_inputs_unchanged'] = record['runtime_inputs_before'] == record['runtime_inputs_after']
meta.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ('command', 'exit_code', 'elapsed_seconds',
                                       'runtime_inputs_unchanged')}, ensure_ascii=False))
print('log=' + str(log))
raise SystemExit(result.returncode)
