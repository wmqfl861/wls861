"""Record storage and identity without running product code or tests."""
import datetime
import json
import os
from pathlib import Path
import subprocess

r = Path(__file__).resolve().parent
assert os.getuid() == os.getgid() == 1000
assert Path(os.environ['TMPDIR']) == r / 'tmp-ram'
status = {line.split(':', 1)[0]: line.split(':', 1)[1].strip()
          for line in Path('/proc/self/status').read_text().splitlines() if line.startswith(('Uid:', 'Gid:', 'Cap'))}
for key in ('CapInh', 'CapPrm', 'CapEff', 'CapAmb'):
    assert int(status[key], 16) == 0
mount = json.loads(subprocess.check_output(['findmnt', '-J', '-T', os.environ['TMPDIR']]))
assert mount['filesystems'][0]['fstype'] == 'tmpfs'
assert mount['filesystems'][0]['target'] == os.environ['TMPDIR']
result = {'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'uid': os.getuid(), 'gid': os.getgid(), 'status': status,
          'mount_namespace': os.readlink('/proc/self/ns/mnt'), 'mount': mount,
          'note': 'Ordinary-user read-only capability probe in a private namespace; no product test executed. RAM is not ext4 or the system disk.'}
with (r / 'evidence/ram-fixture-capability-v1.json').open('x') as output:
    output.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
