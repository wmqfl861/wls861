"""Verify completed gates, input/log hashes, and post-test binary identities."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

r = Path(__file__).resolve().parent
w = r / 'feature'
destination = r / 'evidence/final-local-verification.json'
assert not destination.exists()
freeze = json.loads((r / 'evidence/final-runtime-inputs.json').read_text())['paths']
assert len(freeze) == 316
listed = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others',
                                 '--exclude-standard'], cwd=w).split(b'\0')
actual_paths = {os.fsdecode(path) for path in listed if path and
                not os.fsdecode(path).startswith('docs/') and os.fsdecode(path) not in
                ('AGENTS.md', 'README.md', 'CHANGELOG.md', '.gitignore')}
assert actual_paths == set(freeze), {'unexpected': sorted(actual_paths - set(freeze)),
                                   'missing': sorted(set(freeze) - actual_paths)}
for path, digest in freeze.items():
    assert hashlib.sha256((w / path).read_bytes()).hexdigest() == digest, path
gate_counts = {'final-v2-release-umask0022': 89, 'final-v2-release-umask0002': 89,
               'final-v2-clang-tests': 89, 'final-v3-asan-ram-tests': 39, 'final-v3-ubsan-ram-tests': 39}
gates = {}
for name, count in gate_counts.items():
    meta = json.loads((r / 'evidence' / (name + '.json')).read_text())
    log = (r / 'evidence' / (name + '.log')).read_bytes()
    assert meta['exit_code'] in (0, 8) and meta['finished_at']
    assert meta['uid'] == 1000 and meta['gid'] == 1000
    assert meta['runtime_inputs_before'] == meta['runtime_inputs_after'] == freeze
    assert hashlib.sha256(log).hexdigest() == meta['log_sha256']
    summary = re.search(rb'(\d+)% tests passed, (\d+) tests failed out of (\d+)', log)
    assert summary is not None and int(summary[3]) == count, name
    failed = int(summary[2])
    assert (failed == 0) == (meta['exit_code'] == 0), name
    gates[name] = {key: meta[key] for key in ('exit_code', 'started_at', 'finished_at', 'elapsed_seconds',
                                             'umask', 'environment', 'log_sha256')}
    gates[name].update(test_count=count, passed_tests=count-failed, failed_tests=failed, passed=failed==0)
binaries = {}
configs = {}
for label in ('release', 'clang', 'asan', 'ubsan'):
    manifest = json.loads((r / 'evidence' / ('binaries-v2-' + label + '.json')).read_text())
    for name, expected in manifest.items():
        path = r / ('build-' + label) / name if name.endswith('.a') else w / ('build-exec-' + label) / name
        observed = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}
        assert observed == expected, str(path)
    binaries[label] = {'count': len(manifest), 'identical_after_tests': True,
                       'manifest_sha256': hashlib.sha256((r / 'evidence' / ('binaries-v2-' + label + '.json')).read_bytes()).hexdigest()}
    cache = (r / ('build-' + label) / 'CMakeCache.txt').read_text().splitlines()
    configs[label] = [line for line in cache if line.startswith(('CMAKE_BUILD_TYPE:', 'CMAKE_CXX_COMPILER:',
                       'CMAKE_CXX_FLAGS_DEBUG:', 'CMAKE_RUNTIME_OUTPUT_DIRECTORY:', 'WLS_ENABLE_ASAN:', 'WLS_ENABLE_UBSAN:'))]
    if label in ('asan', 'ubsan'):
        selected = json.loads((r / 'evidence' / ('ctest-v2-' + label + '-selected.json')).read_text())
        assert len(selected['tests']) == 39
        assert len([t for t in selected['tests'] if t['name'].startswith('r24_')]) == 11
        binary = w / ('build-exec-' + label) / 'r24_settlement_capacity_tests'
        symbols = subprocess.check_output(['nm', str(binary)])
        expected_symbol = b'__asan_init' if label == 'asan' else b'__ubsan_handle'
        assert expected_symbol in symbols
protected = ('src', 'include', 'db', 'third_party', 'docs/handoff', 'docs/spec/v0.4.1')
assert not subprocess.check_output(['git', 'diff', '--name-only', '079b52766ee0929472165a71a8563ce31671bb46', '--', *protected], cwd=w)
assert not subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', *protected], cwd=w)
subprocess.run(['git', 'diff', '--check'], cwd=w, check=True)
all_passed = all(gate['passed'] for gate in gates.values())
result = {'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'uid': os.getuid(),
          'frozen_input_count': len(freeze), 'frozen_inputs_unchanged': True, 'gates': gates,
          'binary_identities': binaries, 'configurations': configs, 'protected_paths_unchanged': list(protected),
          'evidence_verification_complete': True, 'local_validation_complete': all_passed,
          'note': 'Completed commands and binary readback are verified even when tests failed. local_validation_complete is true only when every gate passed. Commit, push and CI remain separate evidence.'}
with destination.open('x') as output:
    output.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if all_passed else 1)
