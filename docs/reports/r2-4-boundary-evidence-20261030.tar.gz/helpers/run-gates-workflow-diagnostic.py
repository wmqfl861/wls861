"""Select one unchanged unittest to capture a failure hidden by the full timeout.

This is a diagnostic only, never a replacement for the full ASan gate.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

r = Path(__file__).resolve().parent
w = r / 'feature'
label = 'asan-workflow-exhaustion-diagnostic-v1'
destination = r / 'evidence' / (label + '-identity.json')
assert not destination.exists()
assert os.getuid() == os.getgid() == 1000
assert os.environ['ASAN_OPTIONS'] == 'halt_on_error=1:detect_leaks=1'
assert Path(os.environ['TMPDIR']) == r / 'tmp-ram'
os.umask(0o002)
mount = json.loads(subprocess.check_output(['findmnt', '-J', '-T', os.environ['TMPDIR']]))
assert mount['filesystems'][0]['fstype'] == 'tmpfs'
driver = w / 'build-exec-asan/live_workflow_driver'
expected = json.loads((r / 'evidence/binaries-v2-asan.json').read_text())[driver.name]
def identities():
    paths = [driver, w / 'tests/test_live_workflow.py', w / 'tests/test_https_transport.py',
             w / 'scripts/evaluate_r3.py', Path(__file__).resolve()]
    return {str(path): {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                       'bytes': path.stat().st_size} for path in paths}
before = identities()
assert before[str(driver)] == expected
context = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'uid': os.getuid(), 'gid': os.getgid(), 'mount': mount, 'before': before,
           'note': 'One existing unittest selected without changing source, assertions, the 60-second host batches, the 240-second child bound or the 300-second outer bound. Not a full gate.'}
with destination.open('x') as output:
    output.write(json.dumps(context, indent=2) + '\n')
code = '''import runpy,sys,unittest
test,driver,source=sys.argv[1:]
sys.argv=[test,driver,source]
loaded=runpy.run_path(test,run_name="coverage_workflow_diagnostic")
suite=unittest.TestSuite([loaded["LiveWorkflow"]("test_model_exhaustion_escalates_original_rejected_submission")])
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
'''
python = r.parent / 'wls861-r2-4-20261029/test-venv/bin/python'
command = ['/usr/bin/timeout', '--signal=TERM', '--kill-after=5', '300', str(python), '-c', code,
           str(w / 'tests/test_live_workflow.py'), str(driver), str(w)]
result = subprocess.run([sys.executable, str(r / 'record.py'), label, str(w), *command], cwd=r)
after = identities()
assert before == after
context.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               exit_code=result.returncode, after=after, identities_unchanged=True)
destination.write_text(json.dumps(context, indent=2) + '\n')
print(json.dumps({'diagnostic': label, 'exit_code': result.returncode, 'identities_unchanged': True}))
raise SystemExit(result.returncode)
