"""Build the actual targets used by the frozen 39-test UBSan selection."""
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys

r = Path(__file__).resolve().parent
w = r / 'feature'
assert os.getuid() == 1000
os.umask(0o002)
os.environ.update(TMPDIR=str(r / 'tmp'), PYTHONDONTWRITEBYTECODE='1',
                 ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',
                 UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
def run(name, *command):
    subprocess.run([sys.executable, str(r / 'record.py'), name, str(w), *command], cwd=r, check=True)
run('final-v2-ubsan-configure', 'cmake', '-S', '.', '-B', '../build-ubsan', '-G', 'Ninja',
    '-DCMAKE_CXX_COMPILER=clang++-18', '-DCMAKE_RUNTIME_OUTPUT_DIRECTORY=' + str(w / 'build-exec-ubsan'),
    '-DPython3_EXECUTABLE=/mnt/d/codex-workspace/wls861-r2-4-20261029/test-venv/bin/python',
    '-DCMAKE_BUILD_TYPE=Debug', '-DCMAKE_CXX_FLAGS_DEBUG=-O2 -g', '-DWLS_ENABLE_UBSAN=ON')
pattern = (r / 'evidence/sanitizer-selection.txt').read_text().strip()
prefix = str(w / 'build-exec-ubsan') + '/'
names = []
targets = set()
for line in (r / 'build-ubsan/CTestTestfile.cmake').read_text().splitlines():
    match = re.fullmatch(r'add_test\(\[=\[(.*?)\]=\] (.*)\)', line)
    if match and re.fullmatch(pattern, match[1]):
        names.append(match[1])
        targets.update(Path(arg).name for arg in shlex.split(match[2]) if arg.startswith(prefix))
assert len(names) == 39 and len(targets) == 28
assert all(re.fullmatch(r'[a-z0-9_]+', name) for name in targets)
assert {'r24_settlement_capacity_tests', 'r24_recovery_predicates_tests', 'r24_concurrency_tests'} <= targets
selection = {'selected_tests': names, 'targets': sorted(targets),
             'note': 'All 28 executable targets and their production-library dependencies used by the existing 39-test selection; unrelated test executables are not claimed built.'}
with (r / 'evidence/ubsan-selected-build-targets.json').open('x') as output:
    output.write(json.dumps(selection, indent=2) + '\n')
run('final-v2-ubsan-build', 'cmake', '--build', '../build-ubsan', '--parallel', '2', '--target', *sorted(targets))
files = [p for p in (r / 'build-ubsan').iterdir() if p.is_file() and p.suffix == '.a']
files += [p for p in (w / 'build-exec-ubsan').iterdir() if p.is_file() and os.access(p, os.X_OK)]
identities = {p.name: {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size} for p in sorted(files)}
assert targets <= identities.keys()
with (r / 'evidence/binaries-v2-ubsan.json').open('x') as output:
    output.write(json.dumps(identities, indent=2) + '\n')
selected = json.loads(subprocess.check_output(['ctest', '--test-dir', str(r / 'build-ubsan'), '--show-only=json-v1', '-R', pattern]))
assert len(selected['tests']) == 39
with (r / 'evidence/ctest-v2-ubsan-selected.json').open('x') as output:
    output.write(json.dumps(selected, indent=2) + '\n')
print(json.dumps({'build_complete': True, 'executable_targets': len(targets), 'selected_tests': len(names),
                  'identity_count': len(identities), 'tests_executed_by_this_script': False}), flush=True)
