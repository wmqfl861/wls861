#!/bin/bash
set -euo pipefail
# This launcher must only run in a private mount namespace. Source, builds and
# evidence remain on the data disk; disposable sanitizer fixtures use RAM.
test "$(id -u)" -eq 0
task_root=/mnt/d/codex-workspace/wls861-r2-4-coverage-20261030
task_ram="$task_root/tmp-ram"
test -d "$task_ram"
test ! -L "$task_ram"
test "$(realpath -- "$task_ram")" = "$task_ram"
test "$(stat -c %u -- "$task_ram")" = 1000
test "$(readlink /proc/self/ns/mnt)" != "$(readlink /proc/1/ns/mnt)"
mount -t tmpfs -o size=2147483648,mode=0700,uid=1000,gid=1000,nosuid,nodev wls861-boundary-test-ram "$task_ram"
exec setpriv --reuid=1000 --regid=1000 --init-groups --reset-env -- \
  env TMPDIR="$task_ram" PYTHONDONTWRITEBYTECODE=1 \
  ASAN_OPTIONS=halt_on_error=1:detect_leaks=1 \
  UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 "$@"
