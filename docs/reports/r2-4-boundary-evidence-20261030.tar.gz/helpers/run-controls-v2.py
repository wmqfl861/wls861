"""Run isolated artificial controls with pinned baseline archives, recording every exit."""
import hashlib,json,os,pathlib,re,subprocess,sys
r=pathlib.Path(__file__).resolve().parent
os.environ['TMPDIR']=str(r/'tmp');os.environ['PYTHONDONTWRITEBYTECODE']='1';os.umask(0o022)
assert os.getuid()!=0
variants=[r/'controls/generated-v1/pristine']
variants += [p for p in sorted((r/'controls/generated-v1').iterdir()) if (p/'control.json').exists() and p.name!='pristine']
variants += [p for p in sorted((r/'controls/concurrency-v1').iterdir()) if (p/'control.json').exists() and p.name!='pristine']
results=[]
def run(name,argv,expected=0):
 v=subprocess.run([sys.executable,str(r/'record.py'),name,str(r/'baseline'),*map(str,argv)],cwd=r)
 if v.returncode!=expected:raise RuntimeError(f'{name}: exit={v.returncode}, expected={expected}')
for variant in variants:
 spec=json.loads((variant/'control.json').read_text());name=variant.name;b=variant/'build-opt-v2'
 run('control-v2-'+name+'-configure',['cmake','-S',r/'controls/optimized-driver-v2','-B',b,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DR24_SOURCE='+str(variant/'source'),'-DR24_BASELINE_LIB_DIR='+str(r/'build-baseline-release')])
 run('control-v2-'+name+'-build',['cmake','--build',b,'--parallel','1'])
 maps={}
 for p in b.glob('*.map'):
  data=p.read_bytes();txt=data.decode();maps[p.name]=hashlib.sha256(data).hexdigest()
  if 'src/store.cpp' in spec['changed_production_paths']:assert 'libwls_s1.a(store.cpp.o)' not in txt
  if p.name.startswith(('r24_settlement_capacity','r24_concurrency')):assert 'libwls_s1.a(worker_tools.cpp.o)' not in txt
 binaries={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in b.glob('*_tests')}
 (r/'evidence'/('control-v2-'+name+'-link-identity.json')).write_text(json.dumps({'maps_sha256':maps,'binary_sha256':binaries,'changed_production_paths':spec['changed_production_paths'],'archive_member_exclusion_verified':True},indent=2)+'\n')
 argv=['ctest','--test-dir',b,'-V','--parallel','1']
 if spec['mutation']:argv+=['-R','^('+'|'.join(spec['mutation']['tests'])+')$']
 run('control-v2-'+name+'-tests',argv,0 if name=='pristine' else 8)
 log=(r/'evidence'/('control-v2-'+name+'-tests.log')).read_text()
 if spec['mutation']:
  assert '***Timeout' not in log and 'Not Run' not in log
  matches=[s for s in spec['mutation']['expected_assertions'] if s in log]
  # Save actual assertion output even when the expected spelling differs.
  assertion_lines=[line for line in log.splitlines() if 'FAIL ' in line]
  assert assertion_lines, 'expected a runtime assertion, not a compilation or fixture failure'
 else:matches=[];assertion_lines=[]
 results.append({'variant':name,'classification':spec['classification'],'expected_exit':0 if name=='pristine' else 8,'actual_failures':assertion_lines,'expected_assertion_matches':matches})
 (r/'evidence/control-v2-results-progress.json').write_text(json.dumps(results,indent=2)+'\n')
(r/'evidence/control-v2-results.json').write_text(json.dumps(results,indent=2)+'\n')
