"""Check actual sanitizer flags and deliberate memory faults, outside the product."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

r = Path(__file__).resolve().parent
assert os.getuid() == 1000 and not os.environ.get('LSAN_OPTIONS')
os.umask(0o002)
os.environ.update(TMPDIR=str(r / 'tmp'), PYTHONDONTWRITEBYTECODE='1',
                 UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
base = 'halt_on_error=1:detect_leaks=1'
variant = base + ':malloc_context_size=10'
source = r / 'controls/asan-options-probe/detectors.cpp'
binary = r / 'controls/asan-options-probe/detectors'
def run(name, *command):
    return subprocess.run([sys.executable, str(r / 'record.py'), name, str(r / 'feature'), *command], cwd=r).returncode
assert run('asan-depth10-smoke-build', '/usr/bin/clang++-18', '-std=c++20', '-O2', '-g',
           '-Wall', '-Wextra', '-Wpedantic', '-Wconversion', '-Wshadow', '-Werror',
           '-fsanitize=address', '-fno-omit-frame-pointer', str(source), '-o', str(binary)) == 0
binary_hash = hashlib.sha256(binary.read_bytes()).hexdigest()
flags = {}
for label, options in (('default', base), ('depth10', variant)):
    os.environ['ASAN_OPTIONS'] = options + ':help=1'
    name = 'asan-options-' + label + '-help'
    assert run(name, str(binary), 'clean') == 0
    values = {}
    key = None
    for line in (r / 'evidence' / (name + '.log')).read_text().splitlines():
        stripped = line.strip()
        if re.fullmatch(r'[a-zA-Z0-9_]+', stripped): key = stripped
        value = re.search(r'\(Current Value: (.*?)\)', line)
        if value is not None and key is not None: values[key] = value[1]
    assert values, name
    flags[label] = values
assert flags['default'].keys() == flags['depth10'].keys()
differences = {key: {'default': flags['default'][key], 'depth10': flags['depth10'][key]}
               for key in flags['default'] if flags['default'][key] != flags['depth10'][key]}
assert differences == {'malloc_context_size': {'default': '30', 'depth10': '10'}}, differences
os.environ['ASAN_OPTIONS'] = variant
cases = {}
for mode, expected in (('overflow', 'AddressSanitizer: heap-buffer-overflow'),
                       ('use-after-free', 'AddressSanitizer: heap-use-after-free'),
                       ('double-free', 'AddressSanitizer: attempting double-free'),
                       ('leak', 'LeakSanitizer: detected memory leaks')):
    name = 'asan-depth10-detector-' + mode
    arguments = [str(binary), mode] + (['16'] if mode == 'overflow' else [])
    code = run(name, *arguments)
    log = (r / 'evidence' / (name + '.log')).read_text()
    assert code != 0 and expected in log, (mode, code)
    cases[mode] = {'exit_code': code, 'expected_diagnostic_found': True, 'record': name}
assert hashlib.sha256(binary.read_bytes()).hexdigest() == binary_hash
result = {'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'uid': os.getuid(),
          'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'binary_sha256': binary_hash,
          'actual_flag_count': len(flags['default']), 'actual_flag_differences': differences,
          'ASAN_OPTIONS': variant, 'LSAN_OPTIONS': os.environ.get('LSAN_OPTIONS'),
          'UBSAN_OPTIONS': os.environ['UBSAN_OPTIONS'], 'detector_cases': cases,
          'note': 'Four standalone deliberate faults confirm these detectors remain active. They are not additional WLS suites or proof of identical LSan grouping/suppression diagnostics.'}
with (r / 'evidence/asan-depth10-detector-verification.json').open('x') as output:
    output.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2), flush=True)
