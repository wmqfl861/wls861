"""Prepare independent toolchain libraries while the serial Release suite runs."""
import concurrent.futures,os,pathlib,subprocess,sys
r=pathlib.Path(__file__).resolve().parent
os.environ['TMPDIR']=str(r/'tmp');os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ['ASAN_OPTIONS']='halt_on_error=1:detect_leaks=1';os.environ['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1';os.umask(0o002)
def one(label):
 def run(suffix,args):
  subprocess.run([sys.executable,str(r/'record.py'),'prebuild-'+label+'-'+suffix,str(r/'feature'),*args],cwd=r,check=True)
 args=['cmake','-S','.','-B','../build-'+label,'-G','Ninja','-DCMAKE_CXX_COMPILER=clang++-18','-DCMAKE_RUNTIME_OUTPUT_DIRECTORY='+str(r/'feature'/('build-exec-'+label)),'-DPython3_EXECUTABLE=/mnt/d/codex-workspace/wls861-r2-4-20261029/test-venv/bin/python']
 args+=['-DCMAKE_BUILD_TYPE=Release'] if label=='clang' else ['-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_FLAGS_DEBUG=-O2 -g','-DWLS_ENABLE_'+label.upper()+'=ON']
 run('configure',args)
 run('libraries',['cmake','--build','../build-'+label,'--target','wls_s1','--parallel','1'])
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(one,label) for label in ('clang','asan','ubsan')]
 for f in futures:f.result()
