"""Execute recorded, sequential gates; stop at a real failure."""
import hashlib,json,os,pathlib,subprocess,sys
r=pathlib.Path(__file__).resolve().parent
os.environ['TMPDIR']=str(r/'tmp')
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ['ASAN_OPTIONS']='halt_on_error=1:detect_leaks=1'
os.environ['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
assert os.getuid()!=0
python='/mnt/d/codex-workspace/wls861-r2-4-20261029/test-venv/bin/python'
pattern=(r/'evidence/sanitizer-selection.txt').read_text().strip()
def run(name,*command,mask=0o002):
 os.umask(mask)
 subprocess.run([sys.executable,str(r/'record.py'),name,str(r/'feature'),*command],cwd=r,check=True)
def identity(label):
 b=r/('build-'+label)
 files=[p for p in b.iterdir() if p.is_file() and (os.access(p,os.X_OK) or p.suffix=='.a')]
 result={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(files)}
 (r/'evidence'/('binaries-'+label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 tests=subprocess.check_output(['ctest','--test-dir',str(b),'--show-only=json-v1'],cwd=r/'feature')
 (r/'evidence'/('ctest-'+label+'-inventory.json')).write_bytes(tests)
 if label in ('asan','ubsan'):
  selected=json.loads(subprocess.check_output(['ctest','--test-dir',str(b),'--show-only=json-v1','-R',pattern],cwd=r/'feature'))
  assert len(selected['tests'])==39,len(selected['tests'])
  (r/'evidence'/('ctest-'+label+'-selected.json')).write_text(json.dumps(selected,indent=2)+'\n')
for label in sys.argv[1:]:
 if label=='release':
  run('final-release-build','cmake','--build','../build-release','--parallel','2')
  identity(label)
  run('final-release-umask0022','ctest','--test-dir','../build-release','--output-on-failure','--parallel','1',mask=0o022)
  run('final-release-umask0002','ctest','--test-dir','../build-release','--output-on-failure','--parallel','1')
 else:
  cmd=['cmake','-S','.','-B','../build-'+label,'-G','Ninja','-DCMAKE_CXX_COMPILER=clang++-18','-DPython3_EXECUTABLE='+python]
  if label=='clang': cmd+=['-DCMAKE_BUILD_TYPE=Release']
  else: cmd+=['-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_FLAGS_DEBUG=-O2 -g','-DWLS_ENABLE_'+label.upper()+'=ON']
  run('final-'+label+'-configure',*cmd)
  run('final-'+label+'-build','cmake','--build','../build-'+label,'--parallel','2')
  identity(label)
  cmd=['ctest','--test-dir','../build-'+label,'--output-on-failure','--parallel','1']
  if label!='clang': cmd+=['-R',pattern]
  run('final-'+label+'-tests',*cmd)
