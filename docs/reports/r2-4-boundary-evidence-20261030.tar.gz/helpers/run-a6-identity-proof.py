"""Repeat the historical red probe with contemporaneous binary identities."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

r = Path(__file__).resolve().parent
baseline = r.parent / 'wls861-r2-4-20261029/baseline'
record = r / 'evidence/legacy-a6-identity-proof-v2.json'
assert not record.exists()
assert os.getuid() != 0
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=baseline).strip() == b'a6b8559018a599d7a806b05942857a56d69a00ce'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=baseline)
probe_inputs = json.loads((r / 'evidence/legacy-a6-probe-inputs.json').read_text())
files = [r / 'legacy-a6-probe' / name for name in probe_inputs]
files += [r / 'build-legacy-a6-probe/r24_recovery_predicates_tests',
          r / 'build-legacy-a6-probe/CMakeCache.txt', r / 'build-legacy-a6-probe/build.ninja',
          baseline / 'build-release/libwls_s1.a', baseline / 'build-release/libwls_kernel.a']
def identities():
    return {str(p): {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size}
            for p in files}
before = identities()
for name, digest in probe_inputs.items():
    assert before[str(r / 'legacy-a6-probe' / name)]['sha256'] == digest
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
os.environ['TMPDIR'] = str(r / 'tmp')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.umask(0o002)
result = subprocess.run([sys.executable, str(r / 'record.py'), 'legacy-a6-probe-tests-identity-v2',
                         str(baseline), 'ctest', '--test-dir', str(r / 'build-legacy-a6-probe'),
                         '-V', '--parallel', '1'], cwd=r)
after = identities()
log = (r / 'evidence/legacy-a6-probe-tests-identity-v2.log').read_text()
assert result.returncode == 8
assert before == after
assert log.count('CHECKPOINT isolated recovery passed; checking idle reopen') == 6
assert log.count('Database(fixture.path).snapshot() == stable') == 6
value = {'started_at': started, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'baseline': 'a6b8559018a599d7a806b05942857a56d69a00ce', 'exit_code': result.returncode,
         'before': before, 'after': after, 'identities_unchanged': True,
         'necessary_recovery_checkpoints': 6, 'idle_reopen_snapshot_failures': 6,
         'note': 'New run with hashes captured before and after execution; original v1 logs remain unchanged.'}
with record.open('x') as output:
    output.write(json.dumps(value, indent=2) + '\n')
print(json.dumps(value, indent=2))
