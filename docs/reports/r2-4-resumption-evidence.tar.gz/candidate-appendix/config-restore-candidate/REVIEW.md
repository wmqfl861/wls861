# Same-call frozen configuration byte reuse candidate

Status: production and compatibility source prepared; NOT_COMPILED / NOT_RUN.
No feature source, frozen manifest or original binary was changed by this candidate.
This is a performance candidate, not a demonstrated resolution of the ASan gate.

`restore` currently hashes supplied bytes, strictly parses them, canonicalizes the
parsed document and compares that encoding with the supplied bytes. It then calls
the private constructor, which validates the complete document and canonicalizes
the unchanged document again. `validate_document` itself runs only once; its
embedded YAML parsing, dependency hashes, role derivation and policy checks remain
necessary and are not removed.

The candidate owns the first canonical encoding in a local `std::string`, compares
it with the original bytes, and moves it into an optional private `CanonicalBytes`
argument. The constructor still validates options and the full document, checks
serialized capacity, recomputes SHA-256, restores role resolutions, enforces the
logical-Agent policy and copies complete dependencies. The normal catalog/freeze
entry supplies no bytes and retains its original canonical encoding. Both private
constructor calls are in `src/config_loader.cpp`; no class data member or public
API signature changes. All reused data belongs to this one invocation. No runtime
or Store boundary skips restoration or validation.

The two added cases are compatibility cases expected to pass both original and
candidate implementations; they do not demonstrate a semantic defect in the
original implementation. Existing 20 config-loader cases and their assertions
remain unchanged. The expanded suite has 22 logical cases:

- Local owned bytes preserve decimal numbers, Unicode, escapes, long original
  prompts, complete dependencies and all four role/model resolutions after the
  caller overwrites and destroys its input strings. A-B-A restoration proves
  request-local identity across repeated calls without cross-call state.
- Exact serialized capacity accepts and one-byte-smaller capacity rejects;
  lower file, YAML node and JSON depth budgets still reject. An embedded system
  dependency altered with a matching new hash still fails its comparison with
  the frozen document. Hash mismatch and correctly hashed noncanonical input
  remain rejected. A later valid call is independent of those failures.

Existing cases also cover current host acceptance-validator registrations,
tampered role derivations, changed dependency content/hash/closure, configuration
changes on disk, environmental check commands as data, unsupported policies and
literal environment paths. Final candidate verification must retain these cases.

`candidate-manifest.json` records precise compiler/linker argv and original ASan
flags from the original `build-asan-clang-opt/build.ninja`. Candidate include
directories precede the feature include path. Diagnostic links substitute an
explicit red/green config object before the original static libraries. Combined
diagnostic links also substitute the separately owned combined runtime-types
object. A full rebuild is required if adopted; these diagnostic links are not
final-source build acceptance. The helper only invokes the recorded compiler or
linker and reads symbols; it never runs a test binary. Compile outputs, full -MD
dependencies, input identity checks and linker identity are recorded per step.

The original `config_loader` and `event_runtime` CTest limits remain 90 seconds in
the isolated test registrations. No compilation or test may run while the root
Agent owns the current unchanged-v3 performance probe or complete ASan run.
