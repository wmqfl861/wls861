# Independent static review of external JSON candidates

Status: STATIC_REVIEW_COMPLETE; no test or candidate build was executed by this reviewer.
Disposition: DEFERRED_NOT_ADOPTED. Root is exclusively validating unchanged R2.4 v3.
This review is not a test-pass or performance-fix claim. Candidate compile records,
if present, belong to the implementing Agent; their execution is not attributed to
this review. No feature file, candidate source, manifest input or frozen artifact
was changed while recording this document.

## Reviewed inputs

| Input | SHA-256 |
| --- | --- |
| red/src/runtime_types.cpp | `60282aee148eaa5f11a2b7b4ad9a5b4a59c0a4bf87efa5127ec942fc8dde83a9` |
| green/src/runtime_types.cpp (SAX validation only) | `27dc42939f7906652553816b5f329441dd48758a710a425a07c4026683163ada` |
| combined/src/runtime_types.cpp (SAX plus local serializer reuse) | `38a7e341a6963e712fba083c7a9f8023a029238a52b29816998dd8b1fdf9237e` |
| tests/runtime_types_tests.cpp | `f23056b78d9a47fec690c979c98c62a5a0dda7fcc97ababff0a6b7f55928da03` |

Actual source hashes were independently read and compared with the implementing
Agent's reported identities. The original six test function bodies remain
byte-identical to feature. Four new compatibility cases are one expanded suite,
not four independent suites.

## SAX validation-only candidate

No blocking semantic issue was found in source review. CanonicalValidation's four
size limits match the installed Boost DOM handler's array/object/string/key limits.
It uses the same basic_parser, default numeric options and max_depth=128. EOF is
explicit and success requires no parser error, full input consumption and done().
The original append routine, sorting, scalar formatting, finite-double check and
recursive canonical depth guard remain unchanged. The original DOM numeric handler
only pushes converted values; it adds no finite rejection missing from this SAX
handler. Input comes from an existing JSON DOM, whose object keys are unique.
Invalid UTF-8 remains subject to the Boost parser. Avoiding the discarded DOM
changes allocation behavior; correctness and practical performance require testing.

## Combined serializer candidate

No additional blocking semantic issue was found. Boost's original serialize(value)
and serialize(key) themselves use the same serializer reset/read paths employed by
the candidate. Default options and the installed integer/double formatter remain,
including historical C++ number spellings that differ from Python canonical JSON.
Every key/scalar is drained to done() before reuse. A 4096-byte local buffer appends
only the returned data/size, preserving embedded NULs and partial escape/UTF-8 bytes
until the final SAX validation. Borrowed source lifetimes span complete drains;
no serializer state survives this canonical_json invocation. Sorting and array order
remain, and vector reserve only changes allocation strategy. A default serializer
may allocate a small continuation stack on its first long-string fragment, then
reuse it locally; net performance benefit cannot be inferred from this review.

## Oracle coverage and limits

The reference copies the frozen old C++ append algorithm and final DOM parse,
independently invoking production canonical_json for comparison. It compares exact
bytes, rejection status, ErrorCode and message, without using Python canonical JSON.
Coverage includes integer extrema, -0.0/0.0/1.0, finite double extrema and subnormals,
1024 deterministic double bit patterns, C0 controls, NUL, escapes, Unicode/non-BMP,
U+2028/U+2029, long keys and values across fragment boundaries, mixed nesting and
reset transitions, invalid UTF-8 in keys and values, nonfinite doubles, and pure or
mixed 127/128/129-depth boundaries. It includes 64 generated documents. These cases
were statically reviewed only. No memory-exhaustion behavior, timing result or
completed sanitizer acceptance is established by this document.

Further candidate build and test work is stopped while root validates unchanged
v3. Adoption would require explicit root scheduling, successful semantic and
performance checks, and a complete final-source rebuild and validation.
