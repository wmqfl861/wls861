"""Append a completed same-v3 ASan outcome; never overwrite historical results."""

import copy
import datetime
import hashlib
import json
import pathlib
import re
import sys


ROOT = pathlib.Path(__file__).resolve().parent
FEATURE = ROOT / 'feature'
EVIDENCE = ROOT / 'evidence'
OUTPUT = FEATURE / 'docs/reports/r2-4-resumption-results.json'
FULL = 'feature-asan-v3-resumption-full'
PROBE = 'feature-asan-v3-current-event-probe'
OLD_ASAN = 'feature-asan-session-final'
PROCESS = 'asan-resumption-final-process-check.json'
MANIFEST_SHA256 = '59c8310d64a961d2ebac1159b93e8aa925499be61795b06831a96d79e2fa2050'
VALIDATOR_SHA256 = '855a6d708f9a2f0d9de50960b9d1a239279e9bca9e4bb508f9187224dfc0f1a2'
RESUMPTION_PLAN_SHA256 = '7cbc69034c28e7ae2a00c6265a19096be85c4183aaddee99c7f90916a4fbecf4'
IMMUTABLE = {
    'feature/docs/reports/r2-4-results.json':
        '78c718189cf951ac6a61352ee8390aa46d17502b91196a6377910abb1f7fb2fc',
    'feature/docs/reports/r2-4-evidence.tar.gz':
        '45ac14ee3558dfb8f18054f4d543d0598297c7032a012e457943ed806bea4f6c',
    'feature/docs/reports/r2-4-asan-profile-evidence.tar.gz':
        '35c838fe112aa648b05f44f6f192fc0b3097fd39b7d356191dd1600898f710b8',
    'feature/docs/reports/r2-4-serializer-probe-evidence.tar.gz':
        '92bedd5a7547f3792f7b1d3eb976c93f8a3a9ceab9b5a905ea862e7e9dd2b0da',
    'evidence/final-validation-plan.json':
        '282d031865d920b7cbf97cd1969d2150355cc90a82ad53a50127242d09b12a2b',
}
REUSED = {
    'release_0022': 'feature-release-0022-session-final',
    'release_0002': 'feature-release-0002-session-final',
    'clang': 'feature-clang-session-final',
    'ubsan': 'feature-ubsan-session-final',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = pathlib.Path(path)
    hasher = hashlib.sha256()
    size = 0
    with path.open('rb') as source:
        while chunk := source.read(1024 * 1024):
            hasher.update(chunk)
            size += len(chunk)
    return {'sha256': hasher.hexdigest(), 'bytes': size}


def frozen_check():
    for relative, expected in IMMUTABLE.items():
        require(identity(ROOT / relative)['sha256'] == expected,
                'frozen historical artifact changed: ' + relative)


def validators():
    require(__debug__, 'do not disable evidence assertions with Python -O')
    require(identity(ROOT / 'summarize_final_validation.py')['sha256'] == VALIDATOR_SHA256,
            'reviewed original validator changed')
    # Import the reviewed local original, never a member extracted from an archive.
    sys.dont_write_bytecode = True
    import summarize_final_validation
    return summarize_final_validation


def completed_record(name):
    path = EVIDENCE / (name + '.json')
    require(path.exists(), 'required command has not run: ' + name)
    raw = path.read_bytes()
    record = json.loads(raw)
    require(type(record.get('exit_code')) is int and record.get('finished_at') and
            isinstance(record.get('after'), dict) and 'binaries_after' in record,
            'required command is unfinished; refuse final results: ' + name)
    log = (EVIDENCE / (name + '.log')).read_bytes()
    require(digest(log) == record['log_sha256'], 'completed log changed: ' + name)
    return raw, record, log


def preparation_status():
    """Keep unadopted preparation concise; large dependency maps remain local."""
    result = {}
    for folder, expected_count in (('json-validation-candidate', 10),
                                    ('config-restore-candidate', 0)):
        base = ROOT / folder
        plans = {}
        for filename in ('candidate-manifest.json', 'oracle-manifest.json'):
            path = base / filename
            if path.exists():
                plans[filename] = json.loads(path.read_bytes())
        require(plans, 'candidate preparation manifest missing: ' + folder)
        require(not list(base.glob('**/Testing/Temporary/LastTest.log')),
                'candidate execution has occurred; review appendix scope before publishing')
        records = sorted((base / 'build-records').glob('*.json'))
        require(len(records) == expected_count, 'candidate build inventory changed: ' + folder)
        rows = {}
        for path in records:
            record = json.loads(path.read_bytes())
            plan_name = pathlib.Path(record['manifest_path']).name
            require(plan_name in plans, 'unrecognized candidate plan')
            spec = plans[plan_name]['steps'][record['step']]
            require(record['argv'] == spec['argv'] and record['cwd'] == str(base) and
                    record['uid'] == record['gid'] == 1000 and record['exit_code'] == 0 and
                    record['finished_at'] and record['inputs_unchanged'] is True,
                    'candidate build is incomplete or differs: ' + str(path))
            require(record['manifest_sha256'] == identity(base / plan_name)['sha256'] and
                    record['runner_sha256'] == identity(base / 'run_build.py')['sha256'],
                    'candidate build provenance differs')
            log = path.with_suffix('.log')
            require(identity(log)['sha256'] == record['log_sha256'], 'candidate log differs')
            require(set(record['outputs']) == set(spec['outputs']), 'candidate outputs missing')
            for name, expected in record['outputs'].items():
                require(identity(name) == expected, 'candidate local output changed: ' + name)
            if spec['kind'] == 'link':
                require(record['link_identity']['verified'], 'candidate link identity failed')
            rows[record['step']] = {
                'record_local_path': str(path), 'record_identity': identity(path),
                'argv': record['argv'], 'cwd': record['cwd'], 'uid': record['uid'],
                'exit_code': record['exit_code'], 'elapsed_seconds': record['elapsed_seconds'],
                'log_local_path': str(log), 'log_identity': identity(log),
                'outputs_local_only': record['outputs'],
                'manifest_sha256': record['manifest_sha256'],
                'input_fingerprint_count': len(record['input_fingerprints']),
                'post_compile_dependency_count':
                    len(record.get('actual_dependency_fingerprints_after_compile', {})),
                'record_scope': 'Actual successful build only. No test execution or compatibility acceptance.',
            }
        if expected_count == 0:
            for plan in plans.values():
                for step in plan['steps'].values():
                    require(all(not pathlib.Path(path).exists() for path in step['outputs']),
                            'unexpected config candidate output')
        sources = {}
        for path in sorted(base.glob('**/*.cpp')) + sorted(base.glob('**/*.hpp')):
            if '/build/' not in str(path):
                sources[str(path)] = identity(path)
        if folder == 'json-validation-candidate':
            require((base / 'red/src/runtime_types.cpp').read_bytes() ==
                    (FEATURE / 'src/runtime_types.cpp').read_bytes(), 'runtime candidate adopted')
        else:
            for relative in ('src/config_loader.cpp', 'include/wls/config_loader.hpp',
                             'tests/config_loader_tests.cpp'):
                require((base / 'red' / relative).read_bytes() == (FEATURE / relative).read_bytes(),
                        'configuration candidate adopted')
        result[folder] = {
            'adoption': 'NOT_ADOPTED',
            'compilation': 'COMPLETED' if records else 'NOT_RUN',
            'tests': 'NOT_RUN', 'runtime_equivalence': 'UNVERIFIED',
            'completed_test_suite_count': 0,
            'manifest_local_references': {str(base / name): identity(base / name) for name in plans},
            'source_local_references': sources, 'builds': rows,
            'scope_note': 'Preparation outside feature; no change to the v3 build/run inputs. Large unchanged dependency maps are referenced by exact raw-record digest, not duplicated in the supplement.',
        }
        notes = ('status.json', 'INDEPENDENT-REVIEW.md') if expected_count else ('status.json', 'REVIEW.md')
        result[folder]['static_disposition_notes'] = {
            str(base / name): identity(base / name) for name in notes}
    return result


def compute():
    # Fail before hashing or creating any output when the final runner is active.
    full_raw, full, full_log = completed_record(FULL)
    detail_path = EVIDENCE / (FULL + '-detail.log')
    require(detail_path.exists(), 'completed full CTest detail has not been saved')
    process_path = EVIDENCE / PROCESS
    require(process_path.exists(), 'final read-only process observation is missing')
    v = validators()
    frozen_check()
    plan = json.loads((EVIDENCE / 'final-validation-plan.json').read_bytes())
    resumption_plan_path = EVIDENCE / 'resumption-plan.json'
    require(identity(resumption_plan_path)['sha256'] == RESUMPTION_PLAN_SHA256,
            'recorded resumption selection changed')
    resumption_plan = json.loads(resumption_plan_path.read_bytes())
    require(resumption_plan['effective_gates'] == {
                'release0022': REUSED['release_0022'], 'release0002': REUSED['release_0002'],
                'clang': REUSED['clang'], 'ubsan': REUSED['ubsan'], 'asan': FULL} and
            resumption_plan['source_manifest_sha256'] == MANIFEST_SHA256 and
            resumption_plan['source_count'] == 312 and
            resumption_plan['asan_scope']['registered_test_names'] ==
                plan['gates'][OLD_ASAN]['registered_test_names'] and
            resumption_plan['asan_scope']['regex'] == full['command'][-1],
            'effective selection differs from the recorded resumption plan')
    frozen = json.loads((EVIDENCE / 'source-final-v3.json').read_bytes())
    source = frozen['inputs']
    require(len(source) == frozen['count'] == plan['source']['count'] == 312,
            'source count differs')
    require(digest((EVIDENCE / 'source-final-v3.sha256').read_bytes()) ==
            frozen['manifest_sha256'] == plan['source']['manifest_sha256'] == MANIFEST_SHA256,
            'source manifest differs')
    require((FEATURE / 'docs/reports/r2-4-inputs.sha256').read_bytes() ==
            (EVIDENCE / 'source-final-v3.sha256').read_bytes(), 'repository input manifest differs')
    for relative, expected in source.items():
        require(identity(FEATURE / relative)['sha256'] == expected, 'current v3 source changed: ' + relative)
    old = json.loads((FEATURE / 'docs/reports/r2-4-results.json').read_bytes())
    require(old['local_validation_complete'] is False, 'old historical outcome changed')
    effective, builds = {}, {}

    def row_for(name, spec):
        raw, record, log = completed_record(name)
        row = v.validate_record(record, spec, source, log)
        row['record_sha256'] = digest(raw)
        return row, record

    for role, name in REUSED.items():
        row, record = row_for(name, plan['gates'][name])
        require(row == old['gates'][name] and row['status'] == 'PASSED',
                'reused same-v3 gate does not match immutable original: ' + name)
        require(len(record['binaries_before']) == len(record['binaries_after']) == 57,
                'original build identity inventory differs')
        effective[role] = {'record': name, 'provenance': 'reused_completed_same_v3_gate', 'result': row}
    for name, spec in plan['builds'].items():
        row, _ = row_for(name, spec)
        require(row == old['builds'][name] and row['status'] == 'PASSED',
                'reused build differs: ' + name)
        builds[name] = row
    historical, original_asan = row_for(OLD_ASAN, plan['gates'][OLD_ASAN])
    require(historical == old['gates'][OLD_ASAN] and historical['status'] == 'FAILED' and
            historical['exit_code'] == 8 and historical['ctest']['reported_total'] == 31 and
            historical['ctest']['reported_failed'] == 12, 'original failed ASan evidence differs')
    full_row = v.validate_record(full, plan['gates'][OLD_ASAN], source, full_log)
    full_row['record_sha256'] = digest(full_raw)
    require(full_row['execution_finished'], 'new gate is unfinished')
    require(full['binaries_before'] == full['binaries_after'] == original_asan['binaries_after'] and
            len(full['binaries_after']) == 57, 'new ASan identity differs from original v3')
    effective['asan'] = {'record': FULL, 'provenance': 'completed_same_v3_resumption', 'result': full_row}
    probe_spec = copy.deepcopy(plan['gates'][OLD_ASAN])
    probe_spec.update(command=['ctest', '--test-dir', 'build-asan-clang-opt', '--output-on-failure',
                              '--parallel', '1', '-R', '^event_runtime$'],
                      registered_count=1, registered_test_names=['event_runtime'],
                      test_timeouts_seconds={'event_runtime': 90.0})
    probe_row, probe = row_for(PROBE, probe_spec)
    require(probe_row['status'] == 'PASSED' and probe['binaries_before'] ==
            probe['binaries_after'] == full['binaries_before'], 'original event probe differs')
    require(full['started_at'] > probe['finished_at'], 'new full run predates completed probe')
    asan_build = FEATURE / plan['gates'][OLD_ASAN]['build_dir']
    for name, expected in full['binaries_after'].items():
        require(identity(asan_build / name) == expected, 'current ASan binary/build file changed: ' + name)
    configurations = {}
    for directory, original_files in old['configuration_evidence'].items():
        files = {}
        for name, original in original_files.items():
            raw = (FEATURE / directory / name).read_bytes()
            require(raw == original['text'].encode(), 'generated original configuration changed')
            files[name] = {'sha256': digest(raw), 'bytes': len(raw), 'text': raw.decode()}
        details = v.configuration_details(directory, files)
        require(details == old['configuration_details'][directory], 'configuration interpretation differs')
        for spec in plan['gates'].values():
            if spec['build_dir'] == directory:
                require(all(details['test_timeouts_seconds'][name] == seconds
                            for name, seconds in spec['test_timeouts_seconds'].items()),
                        'original timeout changed')
        configurations[directory] = {name: {key: value[key] for key in ('sha256', 'bytes')}
                                     for name, value in files.items()}
    details = {}
    for name in (PROBE, FULL):
        path = EVIDENCE / (name + '-detail.log')
        raw = path.read_bytes()
        text = raw.decode()
        require('End testing:' in text and 'Test time =' in text, 'CTest detail is incomplete: ' + name)
        detail_names = re.findall(r'^\d+/\d+ Test: (\S+)$', text, re.M)
        expected_names = ['event_runtime'] if name == PROBE else [entry['name'] for entry in
                         full_row['ctest']['observed_entries']]
        require(detail_names == expected_names, 'detail names differ from actual executed selection')
        require('event_runtime_tests' in text, 'original event executable missing from detail')
        details[name] = {'relative_path': 'evidence/' + path.name, **identity(path),
                         'observed_registered_items': len(detail_names)}
    process = json.loads(process_path.read_bytes())
    require(process.get('matches') == [] and process.get('permission_denied') == 0 and
            process.get('scope') == str(ROOT) + '/', 'final task process check is incomplete')
    require(process['at'] >= full['finished_at'], 'process observation precedes final completion')
    auxiliary = {}
    for key, original in old['auxiliary_records'].items():
        require(original['status'] == 'VERIFIED', 'original auxiliary result was not verified')
        path = EVIDENCE / original['record']
        require(identity(path)['sha256'] == original['sha256'], 'original auxiliary evidence changed')
        auxiliary[key] = {'record': original['record'], 'sha256': original['sha256'],
                          'status': 'REUSED_VERIFIED_SAME_SOURCE'}
    environment_path = EVIDENCE / 'validation-resumption-environment.json'
    environment = json.loads(environment_path.read_bytes())
    require(environment['source_manifest_sha256'] == MANIFEST_SHA256, 'resumption environment scope differs')
    complete = (all(item['result']['status'] == 'PASSED' for item in effective.values()) and
                all(row['status'] == 'PASSED' for row in builds.values()))
    result = {
        'schema_version': 1, 'record_kind': 'append_only_same_v3_validation_resumption',
        'baseline': plan['baseline'], 'branch': plan['branch'],
        'source_manifest_sha256': MANIFEST_SHA256, 'source_input_count': 312,
        'source_unchanged_from_original_validation': True,
        'same_asan_binary_and_build_identity_count': 57,
        'previous_frozen_artifacts': IMMUTABLE,
        'resumption_selection_record': {
            'relative_path': 'evidence/resumption-plan.json', **identity(resumption_plan_path),
            'recorded_at': resumption_plan['recorded_at'],
            'recorded_after_execution_started': resumption_plan['recorded_at'] > full['started_at'],
            'scope_note': 'Recorded after this run began; this is not a preregistered or pre-run frozen plan. Original selection and timeout identities are independently checked against the earlier frozen plan.'},
        'historical_summary_scope': 'r2-4-results.json remains the immutable earlier failure snapshot with local_validation_complete=false. This later summary evaluates the effective gate set without rewriting that history.',
        'effective_gates': effective, 'reused_builds': builds,
        'historical_asan_failure': {'record': OLD_ASAN, 'result': historical},
        'same_binary_event_probe': {'record': PROBE, 'result': probe_row},
        'detail_logs': details, 'configuration_identities': configurations,
        'reused_auxiliary_evidence': auxiliary,
        'environment_observation': {'relative_path': 'evidence/' + environment_path.name,
                                    **identity(environment_path),
                                    'interpretation': 'Point-in-time observations, not proof of a unique root cause or guaranteed repeatability.'},
        'final_process_observation': {'relative_path': 'evidence/' + PROCESS,
                                      **identity(process_path), 'data': process},
        'candidate_preparations': preparation_status(),
        'evidence_integrity_verified': True, 'local_validation_complete': complete,
        'publication_status': {'commit_verified': False, 'push_complete': False, 'remote_ci_complete': False},
        'publication_scope': 'This local validation supplement establishes no commit, push, remote Actions result or final committed-tree snapshot. The parent records those separately after they actually occur.',
        'counting': plan['gate_counting'],
        'limitations': [
            'The 31 ASan registrations are the original affected-suite selection, not a claim that all 81 registrations were run under ASan locally.',
            'The completed event probe is one diagnostic execution and does not independently satisfy the 31-item gate.',
            'Earlier failures, timeouts and interrupted runs remain immutable evidence; a later successful run does not prove they were solely environmental.',
            'External candidate sources and successful compilation are preparation only; their tests are NOT_RUN and they do not contribute to acceptance.',
        ],
    }
    frozen_check()
    return result


def main():
    require(not OUTPUT.exists(), 'refusing to overwrite resumption results')
    result = compute()
    result['recorded_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with OUTPUT.open('x') as output:
        output.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'results': str(OUTPUT), **identity(OUTPUT),
                      'effective_gate_statuses': {role: item['result']['status']
                                                 for role, item in result['effective_gates'].items()},
                      'local_validation_complete': result['local_validation_complete']}, indent=2))
    return 0 if result['local_validation_complete'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
