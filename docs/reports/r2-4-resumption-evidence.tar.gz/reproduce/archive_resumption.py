"""Append and verify same-v3 resumption evidence without executing archive members."""

import ast
import datetime
import gzip
import hashlib
import io
import json
import pathlib
import re
import sys
import tarfile


ROOT = pathlib.Path(__file__).resolve().parent
SUMMARY = ROOT / 'feature/docs/reports/r2-4-resumption-results.json'
ARCHIVE = ROOT / 'feature/docs/reports/r2-4-resumption-evidence.tar.gz'
VERIFICATION = ROOT / 'evidence/resumption-bundle-verification.json'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def helpers():
    require(__debug__, 'do not disable evidence assertions with Python -O')
    sys.dont_write_bytecode = True
    # These are the reviewed local scripts. No archive member is imported.
    import summarize_resumption
    return summarize_resumption


def member_sources(summary):
    result = {
        'evidence/r2-4-resumption-results.json': SUMMARY,
        'reference/r2-4-results.json': ROOT / 'feature/docs/reports/r2-4-results.json',
    }
    for name in ('source-final-v3.json', 'source-final-v3.sha256', 'final-validation-plan.json',
                 'resumption-plan.json', 'validation-resumption-environment.json',
                 'asan-resumption-final-process-check.json', 'fetch-during-r24-resumption.json',
                 'fetch-during-r24-resumption.log'):
        result['evidence/' + name] = ROOT / 'evidence' / name
    runs = {item['record'] for item in summary['effective_gates'].values()}
    runs.update(summary['reused_builds'])
    runs.update((summary['historical_asan_failure']['record'], summary['same_binary_event_probe']['record']))
    for name in sorted(runs):
        for suffix in ('.json', '.log'):
            result['evidence/' + name + suffix] = ROOT / 'evidence' / (name + suffix)
    for item in summary['detail_logs'].values():
        result[item['relative_path']] = ROOT / item['relative_path']
    for name in ('run_validation.py', 'run_in_test_tmpfs.sh', 'summarize_final_validation.py',
                 'summarize_resumption.py', 'archive_resumption.py'):
        result['reproduce/' + name] = ROOT / name
    small_appendix = {
        'json-validation-candidate': ('production.patch', 'combined-production.patch',
                                      'tests.patch', 'status.json', 'INDEPENDENT-REVIEW.md'),
        'config-restore-candidate': ('production.patch', 'tests.patch', 'status.json', 'REVIEW.md'),
    }
    for folder, names in small_appendix.items():
        for name in names:
            result['candidate-appendix/' + folder + '/' + name] = ROOT / folder / name
    return result


def collect(summary):
    result = {}
    for name, path in member_sources(summary).items():
        require(path.is_file() and not path.is_symlink(), 'missing/non-regular input: ' + name)
        require(path.stat().st_size < 5 * 1024 * 1024, 'oversized input: ' + name)
        data = path.read_bytes()
        data.decode('utf-8')
        require(b'\0' not in data, 'non-text evidence member: ' + name)
        result[name] = data
    require(sum(map(len, result.values())) < 12 * 1024 * 1024, 'oversized supplement')
    return result


def validate_payloads(files):
    h = helpers()
    summary = json.loads(files['evidence/r2-4-resumption-results.json'])
    expected = h.compute()
    actual = dict(summary)
    recorded_at = actual.pop('recorded_at')
    require(recorded_at and actual == expected, 'stored results differ from recomputed actual evidence')
    require(files['reference/r2-4-results.json'] ==
            (ROOT / 'feature/docs/reports/r2-4-results.json').read_bytes(),
            'original historical summary changed')
    require(json.loads(files['reference/r2-4-results.json'])['local_validation_complete'] is False,
            'historical failure was overwritten')
    require(files == collect(summary), 'payload bytes differ from current originals')
    original_validator = h.validators()
    completed_runs = []
    for name, data in files.items():
        if not name.endswith('.json'):
            continue
        record = json.loads(data)
        if original_validator.is_runner_record(record):
            require(original_validator.is_finished(record), 'unfinished runner in final supplement')
            log_name = name[:-5] + '.log'
            require(log_name in files and digest(files[log_name]) == record['log_sha256'],
                    'completed runner/log mismatch: ' + name)
            completed_runs.append(name)
    fetch = json.loads(files['evidence/fetch-during-r24-resumption.json'])
    require(fetch['command'] == ['git', 'fetch', 'origin', '--prune'] and
            fetch['exit_code'] == 0, 'resumption fetch record is not successful')
    source = json.loads(files['evidence/source-final-v3.json'])['inputs']
    require(fetch['before'] == fetch['after'] == source, 'fetch source snapshot differs')
    for row in summary['detail_logs'].values():
        require(digest(files[row['relative_path']]) == row['sha256'], 'detail snapshot differs')
    for folder, preparation in summary['candidate_preparations'].items():
        require(preparation['adoption'] == 'NOT_ADOPTED' and preparation['tests'] == 'NOT_RUN' and
                preparation['completed_test_suite_count'] == 0, 'candidate preparation became acceptance')
        for path, metadata in preparation['static_disposition_notes'].items():
            name = 'candidate-appendix/' + folder + '/' + pathlib.Path(path).name
            require(digest(files[name]) == metadata['sha256'], 'candidate static note changed')
    patterns = [rb'gh[pousr]_[A-Za-z0-9]{20,}', rb'github_pat_[A-Za-z0-9_]{30,}',
                rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}', rb'(?:AKIA|ASIA)[0-9A-Z]{16}',
                rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',
                rb'https?://[^\s/:]+:[^\s/@]+@', rb'(?i:Bearer)\s+[A-Za-z0-9_./+\-=]{40,}']
    suspects = sorted(name for name, data in files.items()
                      if any(re.search(pattern, data) for pattern in patterns))
    require(not suspects, 'possible credential pattern: ' + ', '.join(suspects))
    for name, data in files.items():
        if name.endswith('.py'):
            ast.parse(data)
    return summary, sorted(completed_runs)


def create_archive():
    require(not ARCHIVE.exists(), 'refusing to replace resumption evidence')
    require(SUMMARY.exists(), 'completed resumption summary is missing')
    summary = json.loads(SUMMARY.read_bytes())
    files = collect(summary)
    summary, runners = validate_payloads(files)
    index = {
        'schema_version': 1, 'record_kind': 'append_only_same_v3_resumption_evidence',
        'archived_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'summary_sha256': digest(files['evidence/r2-4-resumption-results.json']),
        'source_manifest_sha256': summary['source_manifest_sha256'],
        'local_validation_complete': summary['local_validation_complete'],
        'effective_gate_statuses': {role: item['result']['status']
                                   for role, item in summary['effective_gates'].items()},
        'historical_asan_status': summary['historical_asan_failure']['result']['status'],
        'previous_frozen_artifacts': summary['previous_frozen_artifacts'],
        'completed_runner_records': runners,
        'scope': 'Actual completed same-v3 revalidation plus reused same-source native/UBSan/build records. Earlier failed evidence is retained; no published commit or remote CI outcome is established.',
        'candidate_appendix_scope': 'Small patches and static notes only. Exact local build-record/manifest and output hashes are in the summary; repeated system-header maps, objects, binaries and link maps are not archived. Candidate tests remain NOT_RUN.',
        'files': {name: {'sha256': digest(data), 'bytes': len(data)}
                  for name, data in sorted(files.items())},
    }
    files['INDEX.json'] = (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode()
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(files.items()):
            path = pathlib.PurePosixPath(name)
            require(not path.is_absolute() and '..' not in path.parts, 'unsafe archive path')
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            entry.uid = entry.gid = 1000
            entry.mtime = 0
            archive.addfile(entry, io.BytesIO(data))
    encoded = gzip.compress(stream.getvalue(), mtime=0)
    helpers().frozen_check()
    with ARCHIVE.open('xb') as output:
        output.write(encoded)
    print(json.dumps({'archive': str(ARCHIVE), 'sha256': digest(encoded),
                      'bytes': len(encoded), 'member_count': len(files),
                      'uncompressed_bytes': sum(map(len, files.values())),
                      'local_validation_complete': summary['local_validation_complete'],
                      'effective_gate_statuses': index['effective_gate_statuses']}, indent=2))


def verify_archive():
    require(not VERIFICATION.exists(), 'refusing to replace resumption verification')
    summary = json.loads(SUMMARY.read_bytes())
    allowed = set(member_sources(summary)) | {'INDEX.json'}
    files = {}
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        for entry in archive.getmembers():
            path = pathlib.PurePosixPath(entry.name)
            require(entry.isfile() and not path.is_absolute() and '..' not in path.parts and
                    entry.name in allowed and entry.name not in files and
                    entry.size < 5 * 1024 * 1024, 'unexpected member/path/link/size')
            require(entry.mode == 0o644 and entry.uid == entry.gid == 1000, 'unsafe member mode')
            data = archive.extractfile(entry).read()
            data.decode('utf-8')
            require(b'\0' not in data and len(data) == entry.size, 'non-text or incomplete member')
            files[entry.name] = data
    require(set(files) == allowed, 'archive member inventory differs')
    total_bytes = sum(map(len, files.values()))
    require(total_bytes < 12 * 1024 * 1024, 'oversized supplement')
    index_bytes = files.pop('INDEX.json')
    index = json.loads(index_bytes)
    require(index['schema_version'] == 1 and
            index['record_kind'] == 'append_only_same_v3_resumption_evidence', 'wrong supplement type')
    require(set(index['files']) == set(files), 'index/member mismatch')
    for name, data in files.items():
        require(index['files'][name] == {'sha256': digest(data), 'bytes': len(data)},
                'member hash differs: ' + name)
    summary, runners = validate_payloads(files)
    statuses = {role: item['result']['status'] for role, item in summary['effective_gates'].items()}
    require(index['summary_sha256'] == digest(files['evidence/r2-4-resumption-results.json']) and
            index['effective_gate_statuses'] == statuses and
            index['local_validation_complete'] is summary['local_validation_complete'] and
            index['completed_runner_records'] == runners and
            index['historical_asan_status'] == 'FAILED' and
            index['previous_frozen_artifacts'] == summary['previous_frozen_artifacts'],
            'index outcome or historical scope differs')
    h = helpers()
    result = {
        'schema_version': 1, 'record_kind': 'resumption_bundle_integrity_verification',
        'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'archive': str(ARCHIVE), **h.identity(ARCHIVE), 'member_count': len(allowed),
        'uncompressed_bytes': total_bytes, 'index_sha256': digest(index_bytes),
        'summary_sha256': index['summary_sha256'],
        'bundle_integrity_verified': True, 'index_and_current_original_bytes_match': True,
        'completed_runner_records': runners, 'effective_gate_statuses': statuses,
        'historical_asan_status': 'FAILED', 'historical_local_validation_complete': False,
        'local_validation_complete': summary['local_validation_complete'],
        'source_manifest_sha256': summary['source_manifest_sha256'], 'source_input_count': 312,
        'same_original_asan_binary_build_identities': 57,
        'candidate_tests_run_or_adoption_claimed': False,
        'previous_frozen_artifacts_unchanged': summary['previous_frozen_artifacts'],
        'unsafe_paths_links_binary_database_map_payloads_found': False,
        'common_credential_pattern_matches': [], 'archive_members_executed': False,
        'publication_status': summary['publication_status'],
        'scope_note': 'Independent read-only recomputation from reviewed local validators, matching archive bytes and original records. An integrity success does not promote failed gates; commit/push/remote CI remain outside this local supplement.',
    }
    with VERIFICATION.open('x') as output:
        output.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print('verification_sha256=' + h.identity(VERIFICATION)['sha256'])


if __name__ == '__main__':
    require(sys.argv[1:] in ([], ['--verify']), 'usage: archive_resumption.py [--verify]')
    if sys.argv[1:]:
        verify_archive()
    else:
        create_archive()
