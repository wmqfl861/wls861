# Event evidence public revision v2

This new archive replaces one private host-environment observation object in the original event evidence archive. The rejected original ZIP and original report remain unchanged on the data disk; their identities are recorded in PUBLIC-REVISION.json.

The original archive had92 files:88 evidence members and4 controls. Of those evidence members87 remain byte-for-byte identical; one LastTest uses an exact BYTE_RANGE_REPLACE_V1 projection. All bytes outside the14893-byte object, all assertions and every JUnit outcome remain unchanged. The4 controls are rebuilt and PUBLIC-REVISION.json is added, giving93 files. File counts are not test counts.

PROVENANCE.json records the current source-member mapping and retains the old provenance under an explicitly historical key. MEMBERS.json excludes itself and SHA256SUMS; SHA256SUMS excludes itself. These current controls bind the revised bytes; old control identities are recorded separately, without presenting old checksums as current validation.

The unchanged scan-receipt.json remains historical evidence of the original limited scan, which missed this object. Current structural privacy checks and the independent exact-archive review remain external to avoid self-reference. No product or archived program was executed; no sanitizer failure, root cause, approval or merge status is changed by this packaging revision.
