# event command 规范字节复用：独立复核及真实 red/green 审核

结论为 **NO_STATIC_BLOCKER_AND_VERIFIED_TARGET_RED_GREEN_WITH_FIVE_FOCUSED_CTESTS**。本报告确认冻结探针在未修改的 579 生产库上完成有效目标 red、在单函数候选库上完成 green，并对 ZCode10 补丁完成非作者只读复核。五项已有 CTest 通过也已独立核验。未发现本次局部字节复用绕过 Store、事务、CAS、Actor/session/epoch 或事件容量边界的静态问题。

本轮没有运行编译器、探针或产品测试，也没有改源码、旧证据、其他工作树或 Git；审核的是父任务实际执行的记录。完整矩阵尚未在本报告中审核；序列化次数的机制收益不能替代实测性能，更不能认定已有 Timeout/fairness 失败的历史根因。

## 冻结对象

| 对象 | SHA-256 |
| --- | --- |
| ZCode08/09 最终同源探针，16150 bytes，最终计数断言位于 292 行 | 03f286cd1f357f4e2f4b3cb531d5fdf49cd74866da19ca8230b80402688a1856 |
| 原始 src/store.cpp | 96d9194ac01bdc9d0f7edb964665dd896bb3ec858bfdbcdb68313be66df48931 |
| ZCode10 候选 src/store.cpp | 7b234b88a369a246e0f1fa5c42001d466608d4876822a51595914517989fc3dc |
| 本报告冻结的 reviewed.patch | 62b9977bd4b2a91e6e509219d6a90b1efad1c6e28613ae8dd8cc2dcdb1434aca |
| 实际旧版探针二进制 | 1be7f6e084e59b8929b7169a55ab7b781cc9a8268597c3897ac04947d0a92357 |
| baseline libwls_s1.a，9606704 bytes | 27d4259e1c3d6db42dcb440a6ca06555fe0e79fc7ec8c8ef60fc90661bd06891 |
| baseline libwls_kernel.a，506710 bytes | a780803a40cb241a40454fad86b7ec19da7e28babb66110aa49ce6f0f2e1767f |
| 旧版编译产生的 old-probe.d | b29d7165ceb17eb24ef4a9044b67fbf571668d14cea9e1fd79a8ef40c844b8c0 |
| 实际候选探针二进制 | a6dc63c16517aec1b1b06780cf693ae6c07facc01ee2616abdd6ece5e17c67d6 |
| 候选 libwls_s1.a | 46b249ffca506c557170e0279e2c7419dc2c0eca471378be01d7e3f3debed504 |

源工作区为 /mnt/d/codex-workspace/wls861-zcode-followup-20261101-wvm7aclp/zcode，构建/执行和最初复核时 HEAD 是579e3c7675bc2abb336dde6a95bfddf2139f47cd，带精确候选字节的 src/store.cpp 未提交差异，5行增加、1行删除；探针当时是独立未跟踪文件，git diff --check退出0。独立 event-baseline 也是579，审核时干净。

随后父任务正常创建本地提交 **08dad7e815b9c3c84d3bd2393818b2030a6e0cde**。本 Agent 独立核对其父提交为579，改动仅 src/store.cpp 与该探针；直接读取 commit tree 的两个 blob，SHA分别等于上面的7b234b和03f286运行输入，工作树干净。旧运行回执正确记录parent579及精确dirty输入，不能追改成08。父任务报告该提交尚未推送，本 Agent 未查询远端；这是本地代码/运行字节映射，见commit-mapping.json。

## 真实旧版 red 的执行与身份

| 已有执行记录 | 实际结果 |
| --- | --- |
| candidate-release-build-01：cmake --build build-zcode-release --parallel 2 | exit 0，660.1629495238885 秒；在干净 579 源码上执行，保存的 793 项 before/after 源清单相同。 |
| event-probe-old-compile-01：GCC13 C++20、O3、DNDEBUG、原严格警告及 Werror、pthread、MD 依赖、GNU wrap，与 baseline 头和冻结生产库链接 | exit 0，26.855185760185122 秒，stderr 空，outer_timeout=false；保存的 793 项源清单相同。 |
| event-probe-old-run-01：直接运行冻结 old-probe | exit 1，0.7766836369410157 秒，outer_timeout=false；普通 UID/GID1000，数据盘独立 TMPDIR；保存的 793 项源清单相同。 |

原始 stdout 为：

~~~text
START store event serializes its original plan command once
EVENT_COMMAND_SERIALIZATIONS=2
EVENT_COMMAND_SERIALIZATIONS_REPLAY=1
RESULT 0 passed, 1 failed
~~~

原始 stderr 仅一行，指向冻结探针绝对路径的 **292: published_count == 1**。本 Agent 独立核对了表达式及对应源码行，而不是只接受 exit 1 或“2 次”的描述。最终断言前没有其他失败，所以该单方法中的 stronger expected command、持久效果、原字节、重放和拒绝检查确实全部到达。没有将这些子检查计为多个独立测试套件。

old-input-before、old-binary-before、old-after 中的 43 项保存输入列表相同，old-after 的 inputs_after 也相同；保存的 binary_before/after 与当前冻结二进制字节一致。按本 Agent 的明确范围，独立重新 SHA-256 检查了其中 42 项，全部匹配；唯一未重读/重哈希的 src/runtime_types.cpp 只核对保存的前后元数据相同，它的源码分析不属于本轮。该限制见 verified-red.json，不能把它表述成“本 Agent 独立重哈希全部43项”。

baseline-libraries/identity.json 将这两份冻结 archive 指向实际 full 579 Release build 输出；独立校验 archive 哈希与该 copy 收据、probe 输入一致。full build 完成时间 03:39:59 早于 copy 的 03:40:34，也早于编译 03:44:22。以这些普通构建、复制、输入和结束记录构成来源证据链；本 Agent 没有另行重建二进制。full build、probe compile、probe run 的记录 PID 审核时均已不存在，没有把未结束的后台任务算作完成。

## own-version include 问题已经在这次真实 red 中核实

编译 argv 使用冻结到独立 evidence/event-serialization-red-green-02 的同字节探针，-I 指向 event-baseline/tests/repros，WLS_SOURCE_DIR 是 event-baseline 的绝对路径。冻结探针目录的 ../store_tests.cpp 审核时不存在。

更关键的是实际编译器 old-probe.d：共 623 项依赖，其中 11 项项目路径分别来自独立冻结探针及 event-baseline 自己的夹具/头文件；确有 event-baseline/tests/repros/../store_tests.cpp、test_support.hpp、store_actor_support.hpp 和 include/wls/store.hpp，未出现候选 zcode 工作树依赖。因此前次审核提出的相对 include 混版风险，在这次旧版执行中得到实际依赖证据排除。候选编译仍须分别核实自己的依赖，不能用旧版依赖替代。

原命令使用真正旧库及 own-version 头/资源，并保留 GNU wrap 的准确符号。旧版实际 count=2 而非 0，也证实本次链接包装确实命中目标。不是因为编译错误、非法夹具、早期授权错误或 wrapper 未命中造成的 red。

## 最终探针的静态与实测范围

探针仍使用真实临时 Store、合法 admit、由当前 Store 签发的 Dispatcher，第一次只发布一个 plan。计数仅包围这次 public publish_plan：payload helper 只组合字段；初次 replay 无旧行；body 的 json_text 没有顶层 type==plan，不能命中 wrapper。因此本次观察到的两个初次命中与当前 Store event 的 hash canonical 和 json_text canonical 一致。wrapper 保留真实生产函数，结构检测不再调用 canonical；验证阶段计数关闭；same-key replay 单独观测为1，不计入初次目标。

修订探针新增的 body 包含合法 open object 元数据：嵌套 object/array、UTF-8/转义、null、int64、uint64 最大值、double 和 negative zero。没有 nodes，不绕过 brief/nodes 守卫；没有伪造模型或外部事实。这些值已在真实旧版运行中通过所有前置检查，因此不能把该 red 归因于未证实的 body 夹具。

新增独立 expected_command 由原 body、完整 actor_json 持久字段、captured CAS 与 requirements 构成，且在计数区间外生成 expected canonical bytes/hash。原 SQLite payload/hash 逐字等于该预期；parsed command 的 body、actor、版本分别核对。publication 只增一个 state_version、一个 plan_revision 和一个 event，保留 epoch/requirements/config identity/snapshot/budget。

重放及最后的拒绝检查保留完整已冻结 request/snapshot/budget/plan、请求和全局 event count、选定历史列、原 payload/result/hash。foreign session 在原 key 和新 key 均要求 Stale；同 key 改意图要求 Conflict。最终 count 检查在这些检查之后，旧版日志已证明到达。

保留精确限制：

- probe_raw_event_bytes 快照的是 **seq/type/command_id/command_sha256/payload/result 六列**，不是 events 所有列或整个 SQLite 文件。event_id、actor、created_at 未包含在这份历史串中。该补丁本身不修改这些 SQL 列或其绑定，但不能把探针的历史比较描述成全列物理字节证明。
- foreign session 是负例，不是“保存曾经有效旧 Actor 后真实 recovery/epoch 切换”的完整场景；不能取代 R2.4 原回归套件。
- budget 只验证本次 plan/replay 不额外改变预算，没有 reserve/settle 或非零计费业务。
- 原库与候选各自的独立 expected bytes 检查不能直接等同于跨版本复制稳定 base snapshot 的 raw-byte 差分；不同运行会生成不同身份。由于本补丁不改变 canonical 实现或 command，这一局部等价性还由下面的源码复核支持。
- 它是一个手动探针、一个方法；没有注册 CTest，没有调整原期限或 sanitizer。旧版 Release build/probe 不能当 ASan/UBSan、完整产品矩阵或远端 CI 的通过。

## ZCode10 单函数补丁复核

reviewed.patch 的有效变化仅为：

~~~cpp
guard_capacity_event(request_id, command);
const auto event_id = new_id("evt");
const auto encoded_command = json_text(command, payload_limit);
// 原 INSERT：
{event_id, request_id, type, actor, command_id,
 sha256_hex(encoded_command), encoded_command,
 json_text(result, 16 * 1024 * 1024), stamp()}
~~~

原 request scope、command_id、type、capacity guard 顺序和内容逐字保留。event_id 在 guard 后、command 编码前生成，保留原 braced-init 左侧 new_id 的相对位置。json_text 未修改，仍 canonical → 原 payload_limit 字节上限 → 严格 parse → 返回字节。hash 与 payload 使用同一个 const 局部字符串，不跨函数、事务、Store、身份或调用缓存。

对同一不可变 command，复用的正是旧 payload 路径经校验返回的规范字节；原 hash 的 canonical 来自同一确定编码契约，因此成功路径 hash/payload 对应关系保持。没有修改 result 的16MiB限制；默认1MiB、live结算4MiB及旧/Fake1MiB的调用方上限完全保留。replay 自己的 fingerprint 未动。

SQL、capacity_event_inserted、route_event(...sqlite3_last_insert_rowid(db))、observe_capacity 均保持原样及顺序。没有增加或移出事务，没有碰锁、BEGIN IMMEDIATE、CAS、authorize/binding/epoch、claim/settle/feedback 边界、UNKNOWN、process exit、Workspace、cleanup 或终态条件。所有源码跟踪差异仅在此处，未发现 Store 外层跳过或权限放宽。

异常行为须准确描述：编码失败仍在 execute 前，原周围事务负责 rollback；scope/type/capacity、command 校验与 result 校验的业务优先顺序保持。新版本在 SHA 前完成 command 字节校验，而旧版先做一次 hash canonical/SHA，再做 payload 字节校验；hash、字符串复制、分配或 crypto 故障与校验失败的精细求值顺序不完全相同。这是局部实现差异，不能宣称所有分配/熵源/crypto 异常的相对时间逐一等价。event_id 的相对生成位置已明确保留。

这项静态等价结论只绑定上面的候选 SHA 和 patch SHA；若字节发生变化，需要重新核对。源码没有历史 SQL、third_party、旧报告或迁移差异。

## 真实候选 green 与五项已有 CTest

本 Agent 已追加读取并核验候选原始命令、日志、结束状态、before/after输入/二进制、编译依赖和focus JUnit/完整复制日志。结果不是依据父任务转述。

| 已有执行记录 | 实际结果 |
| --- | --- |
| candidate-event-release-build-01，原Release增量构建 | exit0，81.35468797199428秒，普通UID1000，outer_timeout=false。 |
| event-probe-candidate-compile-01，冻结同源03f286探针，以候选自己的头和生产库编译 | exit0，24.24781563412398秒，stderr空，outer_timeout=false。 |
| event-probe-candidate-run-01 | exit0，0.7950434980448335秒，count=1、replay=1，START/PASS/RESULT 1 passed, 0 failed，stderr空。 |
| event-focused-release-01，串行选定五项已有CTest，umask0002 | exit0，记录器21.754975744057447秒，CTest内部21.03秒；runtime_types/store/event_store/audit24_capacity/r24_recovery全部通过，无失败、超时、跳过或选中未运行项。 |

四轮保存源清单各793项before/after完全一致，记录PID审核时均已结束。候选probe的43项保存输入及binary前后完全一致，独立重哈希42项全部匹配；runtime_types.cpp仍只检查已保存元数据，不读取/重哈希源码。新依赖文件的项目输入来自候选自己的夹具和头，没有baseline依赖；同一冻结probe SHA保持03f286。

将两边的路径归一为各自source-relative、archive和同源probe后，43项保存输入的差异**仅src/store.cpp和libwls_s1.a**；其余夹具、头、kernel archive、probe及保存的runtime_types源码身份相同。这支持本次单因素计数对照：原2次→候选1次，独立replay均1次。不同运行的随机请求身份仍不构成跨库全列字节差分。

对五项focus，本 Agent独立解析了92项完整test-plan、JUnit以及复制的完整LastTest.log，确认准确选中五项，无failure/skipped。五个原TIMEOUT均90秒。61项binary/control文件的before/after清单相同，实际文件哈希全部匹配；选中五个二进制与test-plan命令相符。JUnit部分system-out因1024字节阈值截断，完整LastTest.log则含五项各自结束的RESULT且全部0failed、五个Test Passed；未将截断JUnit误称完整方法原文。

这里只有**五个已有CTest**和**一个独立探针方法**。92是注册目录总数，另外87项不属于本次focus，不能把本结果写成92/92或完整Release两umask完成。ASAN_OPTIONS环境变量存在不代表Release库带ASan，不能据此宣称sanitizer通过。计数wrapper的0.7767/0.7950秒两个单样本也不能作为加速/减速结论。

本轮一次元数据检查脚本先因“候选archive位于source/build目录下”的路径分类顺序触发assert exit1；调整为优先识别archive后完整重跑核验通过。该检查器分类错误及修正保存在verified-green-focused.json，未涉及产品执行或改变任何产品测试。

## 后续与本轮状态

父任务已在本地提交08后启动原92项完整Release0022矩阵，本报告不等待或推断其结果。仍需核验所需完整矩阵、两umask、sanitizer、其他集成及远端CI。次数证明与未加wrapper的耗时对照须分开，runtime_types优化或其他poll调整不得混入本次归因。这是限定范围的非作者工程复核，不替代主协调Agent的整体架构或下一阶段审核。

本轮状态：

- STATIC_PATCH_REVIEW_COMPLETE：TRUE；未发现本有界补丁静态阻塞。
- TARGET_RED_VERIFIED：TRUE，真实 unmodified579，count2/replay1，仅最终292行失败。
- CANDIDATE_GREEN_AUDITED：TRUE，同源03f286、真实候选库、count1/replay1、整项退出0。
- FIVE_FOCUSED_CTESTS_AUDITED：TRUE，5/5通过、0跳过，原90秒期限。
- PRODUCT_MATRIX_COMPLETE：未由本报告判定。
- PERFORMANCE_BENEFIT_MEASURED：FALSE。
- HISTORICAL_ROOT_CAUSE：OPEN。

codebase-memory 使用现有旧图与9路径 coverage；新 repro 缺失，Store/头/夹具 partial，图根和generation不代表当前7b源码。相关实现以精确源码及 frozen diff 为准，未依图作穷尽调用或完整性结论。证据包含verified-red.json、verified-green-focused.json、commit-mapping.json、reviewed.patch、source-check.json、图覆盖、输入哈希及收据；其checksum验证只证明证据包一致性。

