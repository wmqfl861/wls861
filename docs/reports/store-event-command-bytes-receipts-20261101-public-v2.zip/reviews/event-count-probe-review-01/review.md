# Store event 同源计数探针只读复核

结论：`READY_FOR_SCOPED_EXECUTION_WITH_IDENTITY_CONDITIONS`。已读 ZCode 提交给父任务的 187 行探针；没有发现当前首个 plan 计数会混入 reservation/settlement fingerprint 的静态路径。可以在下面的 own-version 源码、头文件、SQL/config 资源和生产库身份冻结条件下执行，用作“同一个 event command 少一次 canonical”的机制证据。这里没有编译、运行或确认 red/green，也没有批准任何产品性能或完整安全验收结论。

审核对象为 `tests/repros/store_event_serialization_same_source.cpp`，SHA-256：`ba53968e2924fa7f4fa4cf0adc61604e3352ec987000c23bf1cb08e38c52ca87`。收尾来源 HEAD 及其他输入哈希见 input-manifest.json。当前生产 store.cpp 仍为 `96d9194ac01bdc9d0f7edb964665dd896bb3ec858bfdbcdb68313be66df48931`。本轮源码、其他工作树和旧证据均未修改，所有写入只在本新证据目录。

## 计数是否命中真正目标

- 探针第 110–115 行仅围住首次 public publish_plan。admit、host_actor、原 CAS/revision 获取和 key/body 准备均在 counting=false 时完成。数据只在一个 Store、一个线程上使用，普通计数器适合这个限定夹具。
- wrapper 第 54–59、83–85 行先要求顶层 object 的 type=="plan"，再结构遍历 marker；遍历不调用 canonical/parse/serialize，wrapper 始终调用真实 production canonical 函数，不伪造 JSON 或 Store 结果。marker 检查范围比精确 body.goal 稍宽，但单次首次 plan 的当前夹具没有其他匹配 command。
- 当前 Store::publish_plan 第 2868 行的 payload helper 仅组合 type/actor/body/版本字段，不 canonical。replay 先查询记录，该 fresh command 无旧 event，查询无结果会直接返回；body 写 plans 时虽会 json_text(body)，body 没有顶层 type，不能命中计数。当前初次 publication 剩下两个匹配调用均位于 event：SHA 的 canonical_json(command)，以及 json_text(command,payload_limit) 内的 canonical_json。
- 验证读取和 canonical(parsed payload) 时 counting 已关闭。same-key replay 单独打开计数；它应从 replay fingerprint 产生自己的命中，不应合并进初次 publication 的目标计数。探针只输出 replay 次数，未断言；不能声称这个次数已被测试。
- GNU ld --wrap 只作用于对应未定义外部符号引用。之前 nm 确认冻结旧 ASan archive 的 store.cpp.o 存在该未定义引用，尚未检查本轮新构建的每个实际 archive。执行方应冻结实际库/链接身份，并观察旧版真实次数，不能把无命中、LTO 内联、ABI 不匹配或错误库解释成有效 red。

对当前静态源码，旧版期望打印 EVENT_COMMAND_SERIALIZATIONS=2。有效旧版 red 需要同时满足真实次数为 2，且最终唯一目标失败是第 176 行 published_count==1；这样此前的 durable、replay 和拒绝断言确实已完成。若打印 0、编译失败、SQL/config 夹具失败、Store 前置异常或任何其他 CHECK 失败，应标记为探针/环境未成立，不能算目标反例。候选应打印 1 且整个单方法退出 0。次数变化不提供耗时收益证明。

## 必须冻结的 own-version 身份

探针第 19 行使用引号相对 include：

`#include "../store_tests.cpp"`

C++ 会先查探针源文件自身目录。因此，**从 ZCode 原 tests/repros 路径直接编译时，添加 -I <old-version>/tests/repros 不能覆盖已经找到的当前 store_tests.cpp**。这样会混用版本，旧版 red 证据无效。

父任务拟采用的方案可以成立：将完全相同字节的探针冻结到独立证据目录，确保该目录的 ../store_tests.cpp 不存在；再由 -I <version>/tests/repros 解析到该版本的 tests/store_tests.cpp。应记录 include 搜索的实际解析结果或依赖清单，并避免其他更早的 -I 目录包含可命中的 ../store_tests.cpp。该版本 tests/repros 目录也必须实际存在。不能仅依据命令上有一个 -I 就声称已经满足。

更明确的长期方案是由 ZCode 提供可选的绝对源码快照 include 宏，并在编译 argv 直接指定该版本 tests/store_tests.cpp 的绝对路径。它能避免相对搜索意外命中；这属于建议，本 Agent 未修改探针。

还须同时冻结并使用：

1. 对应版本自己的 tests/store_tests.cpp、test_support.hpp、store_actor_support.hpp，以及 include/wls 和所需第三方头；不能只换静态库。
2. WLS_SOURCE_DIR 的值为该版本绝对根路径，并作为真实带字符串引号的宏传入。它控制 schema.sql、004、005 以及 input() 复制的 config/examples、prompts，不能指向另一个版本。该宏只选择资源根，不能修复第 19 行 include 的版本混用。
3. 对应源码构建的生产 libwls_s1.a、libwls_kernel.a，以及项目现有依赖：SQLite、Crypto、CURL、yaml、Threads。包含完整 store_tests.cpp 会把其余测试函数也编入翻译单元，不能按单一探针表面依赖随意省库。GCC/Clang、libstdc++ ABI、Boost 头、sanitizer/LTO 配置也须与该版本库匹配。
4. 在普通 UID 下运行，将 TMPDIR 指向数据盘上的独立临时根。TempDir 使用 mkdtemp，原 test::run 在方法期间施加 0077，使临时目录/DB 满足普通用户权限条件；探针不操作生产数据、不调用真实模型。

原 Store legacy trusted-SQL 构造器接受 base_sql 和 004，测试没有强行升级全部 schema；读取 005 是其包含的原 tests 主程序资源约定，本方法未传它给 Store。当前合法 goal object 直接复用原 Fixture::plan 的形状，并带有效 UTF-8、反斜线和引号；没有伪造 grant、attempt、claim 或传输事实，不会产生供应商模型请求。

## 已有断言与其可证明的范围

| 项目 | 实际覆盖 | 尚未证明 |
| --- | --- | --- |
| 持久事件 | 以 request_id + command_id 查唯一 event，且请求仅一个 plan event；读取真实 SQLite TEXT。 | 不比较两版本全数据库；随机 request/principal/key/timestamp 使不同运行不能直接逐字比较整库。 |
| payload/hash | SHA(payload)==command_sha256；payload 严格解析、同版本重新 canonical 后逐字一致；有 type 和 marker。 | 没有独立构造 expected command，没有逐字段断言原 body/actor/CAS/revision；marker 仍在时错误字段也可能通过。不能仅据此称完整原意图字节等价。 |
| result | 原 TEXT 严格解析后等于 public published 返回值，重放后原 result TEXT 不变。 | 初次 result 没有与独立预期 revision/state_version 对比；自洽不是完整行为等价。 |
| replay | same-key 原 body 返回相同结果；request、snapshot、budget、plan、原 payload/result 和原 key 行数不变。 | 重放后未重查 command_sha256 或所有历史行；replay 打印次数未断言。 |
| 预算 | replay 前后真实 Store::budget 相同。 | 没有 reserve/settle/非零预算业务，此处只能证明该 plan replay 没额外预算变化。 |
| changed intent | 同 key 改 goal 要求 Conflict。 | 拒绝后仅复查 request state_version 与原 key 行数，未重查完整 request/snapshot/budget/plan/hash/历史。 |
| Actor | Dispatcher 由真实 host_actor 签发；修改 writer_session、用新 key 必须 Stale。authorize(false) 也检查 writer_session，先于 replay/CAS，所以预期错误成立。 | 这是 foreign session 负例，不是持有曾经有效旧 Actor 再 recovery/epoch 切换的测试；不能代替 R2.4 旧身份隔离套件。 |

当前 raw SQL 的变量只来自真实 Store 生成的 request_id/new_id key，未接受外部输入；本轮无需将此测试扩大成通用 SQL 接口。probe_raw_text 在 CHECK 失败时不是 RAII 清理，可能让失败诊断伴随资源噪声；正常和预期最终 count 失败前已关闭 SQLite 句柄，不影响当前目标 red 的静态判断。

如果只将结果命名为“首个 plan event canonical 次数反例”，以上断言可支撑受限执行。若要声称“修复保持完整 command 原字节和所有拒绝的零副作用”，应先由 ZCode 最小补强：

- 在计数区间外根据固定 body、Dispatcher 的全部 actor_json 字段及 captured expected/requirements 独立构造完整 expected command，检查 parsed command 完全相同，且 raw payload 等于 expected canonical 字节；独立检查发布后的 revision/state_version 和 plan body。
- 重放后再次核对原 command_sha256；对两次拒绝后重复核对全部已冻结 request/snapshot/budget/plan、原 payload/hash/result 和请求总事件数，避免只查旧 key 漏掉新事件。
- 跨版本完整字节等价另用稳定合法 base snapshot 和稳定业务身份做差分，并逐列区分随机字段；不能宣称本探针当前已经提供该差分。

这些是审核建议，本轮没有新增或执行断言；也不建议为了计数证据扩大到所有恢复、清理、计费或终态验收。

## 证据与状态

使用 codebase-memory 的现有图及 check_index_coverage；图 generation 仍为 2026-10-31T06:55:42Z、另一个旧工作树，不能代表当前输入。新 repro freshness=missing；store_tests 第 131 行和 Store 第 217、1714–1715 行标为 partial，相关夹具/guard/member 源码已回读。头文件有关构造器、host_actor/publish_plan 和被引用声明以真实源码为准，不依赖图的完整性。图覆盖原响应和只读检查回执保存在 graph-and-inspections.json。

本轮完成状态为 `STATIC_REVIEW_COMPLETE`；执行为 `NOT_RUN`；red/green 为 `NOT_VERIFIED`；性能收益为 `UNMEASURED`；历史根因为 `OPEN`。原产品失败、完整本地矩阵和远端 CI 状态均不因此改变。SHA256SUMS 仅校验证据包完整性。

