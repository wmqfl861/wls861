"""Archive raw success, failure and explicitly partial evidence without binaries."""
import datetime
import gzip
import io
import json
import pathlib
import tarfile

from summarize_final_validation import digest, is_finished, is_runner_record

ROOT = pathlib.Path(__file__).resolve().parent
REPRODUCERS = (
    'run_validation.py', 'run_in_test_tmpfs.sh', 'verify_protected.py',
    'run_sanitizer_gate.py', 'run_concurrency_candidate.py', 'run_settlement_candidate.py',
    'record_generated_assets.py', 'record_generated_assets_v2.py', 'verify_remote_source.py',
    'monitor_sanitizer_gate.py', 'run_fixed_gate.py', 'run_final_validation_sequence.py',
    'diagnose_live_workflow_case.py',
    'diagnose_billing_cases.py',
    'diagnose_live_workflow_details.py',
    'run_asan_diagnostics.py',
    'summarize_final_validation.py', 'archive_evidence.py', 'verify_evidence_bundle.py',
)
BACKUP_FILES = ('summarize_final_validation.py', 'archive_evidence.py',
                'verify_evidence_bundle.py', 'run_sanitizer_gate.py', 'MANIFEST.json')


def main():
    source = ROOT / 'evidence'
    target = ROOT / 'feature/docs/reports/r2-4-evidence.tar.gz'
    assert not target.exists(), 'refusing to replace frozen evidence archive'
    files = {}
    for path in sorted(source.iterdir()):
        if path.suffix not in ('.log', '.json', '.sha256') or path.name.startswith('github-'):
            continue
        assert path.is_file() and not path.is_symlink(), path
        files['evidence/' + path.name] = path.read_bytes()
    summary = ROOT / 'feature/docs/reports/r2-4-results.json'
    assert 'evidence/r2-4-results.json' not in files
    files['evidence/r2-4-results.json'] = summary.read_bytes()
    assert 'evidence/final-validation-plan.json' in files
    summary_record = json.loads(files['evidence/r2-4-results.json'])
    assert summary_record['plan_sha256'] == digest(files['evidence/final-validation-plan.json'])
    # Refuse a moving snapshot before creating the immutable archive. A partial
    # record is valid evidence, but later bytes cannot impersonate that snapshot.
    for section in ('gates', 'builds'):
        for name, row in summary_record[section].items():
            record_name, log_name = 'evidence/' + name + '.json', 'evidence/' + name + '.log'
            if row['status'] == 'NOT_RUN':
                assert record_name not in files and log_name not in files, name
                continue
            assert digest(files[record_name]) == row['record_sha256'], name
            log_sha = row.get('log_snapshot_sha256')
            assert (log_name not in files if log_sha is None else digest(files[log_name]) == log_sha), name
    for row in summary_record['auxiliary_records'].values():
        name = 'evidence/' + row['record']
        assert (name not in files if row['status'] == 'NOT_RUN' else digest(files[name]) == row['sha256']), name
    for name in REPRODUCERS:
        files['reproduce/' + name] = (ROOT / name).read_bytes()
    for name in BACKUP_FILES:
        files['reproduce/delivery-scripts-v2/' + name] = (ROOT / 'delivery-scripts-v2' / name).read_bytes()
    for candidate in ('concurrency-candidate', 'settlement-session-candidate'):
        for variant in ('red', 'green'):
            for relative in ('src/worker_tools.cpp', 'tests/worker_tools_tests.cpp'):
                name = candidate + '/' + variant + '/' + relative
                files['reproduce/' + name] = (ROOT / name).read_bytes()
        extras = ('candidate-manifest.json', 'baseline-observer.patch') if candidate == 'concurrency-candidate' else (
            'candidate-manifest.json', 'production.patch', 'tests.patch',
            'initial-tests.cpp', 'initial-manifest.json', 'initial-tests.patch')
        for relative in extras:
            name = candidate + '/' + relative
            files['reproduce/' + name] = (ROOT / name).read_bytes()
    index = {
        'schema_version': 2,
        'archived_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'contents': 'Raw logs, records, manifests, textual configuration evidence and reproducers. No binaries or databases.',
        'partial_snapshot_note': 'Incomplete runner JSON/log bytes are archived as observed at packaging time; no exit code or completion is invented.',
        'incomplete_command_snapshots': [], 'observation_records_with_command': [],
        'summary_sha256': digest(files['evidence/r2-4-results.json']),
        'plan_sha256': digest(files['evidence/final-validation-plan.json']), 'files': {},
    }
    for name, data in files.items():
        kind = 'artifact'
        if name.endswith('.json'):
            record = json.loads(data)
            if is_runner_record(record):
                finished = is_finished(record)
                kind = 'runner_complete' if finished else 'runner_incomplete'
                if not finished:
                    index['incomplete_command_snapshots'].append(name)
                else:
                    log_name = name[:-5] + '.log'
                    assert log_name in files and digest(files[log_name]) == record['log_sha256'], log_name
            elif isinstance(record, dict) and 'command' in record:
                kind = 'observation'
                index['observation_records_with_command'].append(name)
            else:
                kind = 'json'
        index['files'][name] = {'bytes': len(data), 'sha256': digest(data), 'kind': kind}
    index['incomplete_command_snapshots'].sort()
    index['observation_records_with_command'].sort()
    files['INDEX.json'] = (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode()
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(files.items()):
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            entry.mtime = 0
            entry.uid = entry.gid = 1000
            archive.addfile(entry, io.BytesIO(data))
    encoded = gzip.compress(stream.getvalue(), mtime=0)
    with target.open('xb') as output:
        output.write(encoded)
    print(json.dumps({'files': len(files), 'raw_bytes': sum(map(len, files.values())),
                      'archive_bytes': len(encoded), 'archive_sha256': digest(encoded),
                      'incomplete_command_snapshots': index['incomplete_command_snapshots']}, indent=2))


if __name__ == '__main__':
    main()
