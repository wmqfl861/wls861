"""Apply the frozen ordinary-user conditions and exec the unchanged recorder."""
import hashlib
import json
import os
import pathlib
import sys

root = pathlib.Path(__file__).resolve().parent
plan = json.loads((root / 'evidence/final-validation-plan.json').read_text())
name, = sys.argv[1:]
gate = plan['gates'][name]
assert os.getuid() == gate['uid'] == 1000
assert os.getgid() == gate['gid'] == 1000
frozen = json.loads((root / 'evidence' / plan['source']['record']).read_text())
assert frozen['manifest_sha256'] == plan['source']['manifest_sha256']
assert all(hashlib.sha256((root / 'feature' / p).read_bytes()).hexdigest() == h
           for p, h in frozen['inputs'].items())
os.umask(int(gate['umask'], 8))
os.sched_setaffinity(0, gate['cpu_affinity'])
for key, value in gate['environment'].items():
    if value is None:
        os.environ.pop(key, None)
    else:
        os.environ[key] = value
os.execv(sys.executable, [sys.executable, str(root / 'run_validation.py'),
                         name, gate['cwd'], *gate['command']])
