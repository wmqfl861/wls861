#!/usr/bin/env python3
"""Select original billing E2E methods without changing either paired condition.

Run with the same Python, WLS binary, source root, and validation environment as
the original CTest entry. Apply its original 900-second bound externally. The
original test owns all setup, parameters, assertions, subprocess timeouts, and
the multi_agent/single_agent loops; this launcher only selects method names.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys


METHODS = {
    "amend": "BillingBaselineIntegration.test_02_two_task_partial_amend_pair",
    "exhausted": "BillingBaselineIntegration.test_04_exhausted_rework_owner_question_pair",
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("wls", type=Path, help="the original CTest WLS binary")
    parser.add_argument("source", type=Path, help="the original CTest source root")
    parser.add_argument(
        "--case", choices=("both", *METHODS), default="both",
        help="select original methods; every selected method keeps both conditions",
    )
    options = parser.parse_args()
    binary = options.wls.resolve()
    source = options.source.resolve()
    test_file = source / "tests/test_billing_baseline_e2e.py"
    if not binary.is_file():
        parser.error(f"WLS binary is missing: {binary}")
    if not test_file.is_file():
        parser.error(f"original test file is missing: {test_file}")
    selected = list(METHODS.values()) if options.case == "both" else [METHODS[options.case]]
    os.execv(sys.executable, [
        sys.executable, "-u", str(test_file), str(binary), str(source), *selected,
    ])


if __name__ == "__main__":
    main()
