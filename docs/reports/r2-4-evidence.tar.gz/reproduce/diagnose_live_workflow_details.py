#!/usr/bin/env python3
"""Run one original workflow test and observe bounded fields only on failure.

Use the original validation environment and an external 300-second limit. The
test method, driver, input parameters, assertions, and deadlines are unchanged.
The observer reads only the original method's traceback-local result after a
failure has been recorded. It never emits raw responses, prompts, credentials,
exception messages, identifiers, paths, or arbitrary frame locals.
"""
from __future__ import annotations

import json
import pathlib
import runpy
import sys
import unittest


ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = ROOT / "feature"
TEST_FILE = SOURCE / "tests/test_live_workflow.py"
DRIVER = SOURCE / "build-asan-clang-opt/live_workflow_driver"
METHOD = "test_model_exhaustion_escalates_original_rejected_submission"
MAX_ITEMS = 32
MAX_STRING = 1000
STOP_REASONS = frozenset({
    "quiescent", "call_limit", "needs_accounting", "deadline", "cancelled", "error",
})
BLOCK_CODES = frozenset({
    "capacity_waiting_input", "call_limit", "manager_limit", "missing_script",
    "amendment_pending", "unexpected", "claim_release_failed", "waiting",
    "workspace_missing", "event_missing", "operation_incomplete", "worker_limit",
    "cancelled", "deadline", "needs_accounting", "acceptance_pending",
    "rework_blocked", "submission_pending", "invalid_input", "unauthorized",
    "conflict", "stale", "not_ready", "unknown_outcome", "quota", "storage",
    "unsupported", "corrupt", "invalid_error_code",
})


def permitted_string(value, allowed, fallback):
    if type(value) is str and len(value) <= MAX_STRING and value in allowed:
        return value
    return fallback


def nonnegative_integer(value):
    return value if type(value) is int and 0 <= value <= (1 << 63) - 1 else None


def phase_summary(phase, index):
    if type(phase) is not dict:
        return {"phase": index, "status": "invalid_report_type"}
    blocked = phase.get("blocked")
    calls = phase.get("calls")
    summary = {
        "phase": index,
        "stop_reason": permitted_string(
            phase.get("stop_reason"), STOP_REASONS, "unrecognized_stop_reason"
        ),
        "calls_count": len(calls) if type(calls) is list else None,
        "blocked_count": len(blocked) if type(blocked) is list else None,
        "blocked_codes": [],
        "blocked_codes_truncated": type(blocked) is list and len(blocked) > MAX_ITEMS,
    }
    if type(blocked) is list:
        summary["blocked_codes"] = [
            permitted_string(
                item.get("code") if type(item) is dict else None,
                BLOCK_CODES, "unrecognized_code",
            )
            for item in blocked[:MAX_ITEMS]
        ]
    for key in ("elapsed_ms", "max_batch_duration_ms", "network_started_calls",
                "provider_calls", "unobserved_send_claims"):
        summary[key] = nonnegative_integer(phase.get(key))
    accounting = phase.get("accounting")
    if type(accounting) is dict and type(accounting.get("ready")) is bool:
        summary["accounting_ready"] = accounting["ready"]
    return summary


def failure_observation(test, error):
    observation = {
        "observation": "original_live_workflow_failure_fields_v1",
        "method": METHOD,
        "status": "original_result_not_found",
    }
    traceback = error[2]
    while traceback is not None:
        frame = traceback.tb_frame
        if (frame.f_code.co_name == METHOD
                and pathlib.Path(frame.f_code.co_filename).resolve() == TEST_FILE
                and frame.f_locals.get("self") is test):
            observation["failure_line"] = traceback.tb_lineno
            result = frame.f_locals.get("result")
            if type(result) is dict and type(result.get("reports")) is list:
                reports = result["reports"]
                observation.update({
                    "status": "original_result_observed",
                    "reports_count": len(reports),
                    "reports_truncated": len(reports) > MAX_ITEMS,
                    "reports": [phase_summary(phase, index)
                                for index, phase in enumerate(reports[:MAX_ITEMS])],
                })
            break
        traceback = traceback.tb_next
    return observation


class ObservedFailureResult(unittest.TextTestResult):
    def addFailure(self, test, error):
        super().addFailure(test, error)
        try:
            observation = failure_observation(test, error)
            print(json.dumps(observation, ensure_ascii=True, allow_nan=False), flush=True)
        except Exception:
            # Observation must not replace the original failure or its status.
            pass


def main():
    sys.path.insert(0, str(TEST_FILE.parent))
    sys.argv = [str(TEST_FILE), str(DRIVER), str(SOURCE)]
    namespace = runpy.run_path(str(TEST_FILE), run_name="workflow_single_case")
    suite = unittest.TestSuite([namespace["LiveWorkflow"](METHOD)])
    result = unittest.TextTestRunner(
        verbosity=2, resultclass=ObservedFailureResult
    ).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()
