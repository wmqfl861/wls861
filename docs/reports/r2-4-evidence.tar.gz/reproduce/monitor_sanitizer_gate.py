"""Observe one approved sanitizer gate without running or controlling tests.

Usage: python3 monitor_sanitizer_gate.py NAME BUILD_DIRECTORY
The output is an append-only JSON document, completed when observation stops.
Only selected /proc fields are read; environ and cmdline are never opened.
"""

from __future__ import annotations

import datetime
import json
import os
from pathlib import Path
import signal
import sys
import time
from typing import Any


ALLOWED_GATES = {
    "feature-asan-session-final": "build-asan-clang-opt",
    "feature-ubsan-session-final": "build-ubsan-clang-opt",
}
TARGET_UID = 1000
INTERVAL_SECONDS = 2.0
STARTUP_GRACE_SECONDS = 60.0
MAX_OBSERVATION_SECONDS = 4 * 60 * 60
PROC = Path("/proc")
CPU_FIELDS = (
    "user", "nice", "system", "idle", "iowait", "irq", "softirq", "steal",
    "guest", "guest_nice",
)


def utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def error_kind(error: Exception) -> str:
    if isinstance(error, (FileNotFoundError, ProcessLookupError)):
        return "vanished"
    if isinstance(error, PermissionError):
        return "permission_denied"
    if isinstance(error, (ValueError, IndexError, KeyError)):
        return "unparseable"
    return "read_error"


def read_stat(pid: int) -> dict[str, Any]:
    raw = (PROC / str(pid) / "stat").read_text()
    opening, closing = raw.find("("), raw.rfind(")")
    if opening < 0 or closing <= opening:
        raise ValueError("invalid proc stat")
    fields = raw[closing + 2:].split()
    return {
        "pid": pid,
        "comm": raw[opening + 1:closing],
        "state": fields[0],
        "ppid": int(fields[1]),
        "utime": int(fields[11]),
        "stime": int(fields[12]),
        "threads": int(fields[17]),
        "starttime": int(fields[19]),
        "rss_pages": int(fields[21]),
    }


def ordinary_user(pid: int) -> bool:
    for line in (PROC / str(pid) / "status").read_text().splitlines():
        if line.startswith("Uid:"):
            ids = [int(value) for value in line.split()[1:]]
            return len(ids) == 4 and all(value == TARGET_UID for value in ids)
    return False


def read_exe(pid: int) -> str | None:
    try:
        return os.readlink(PROC / str(pid) / "exe")
    except (FileNotFoundError, ProcessLookupError):
        # Zombies can retain a stat entry after their executable link disappears.
        return None


def build_executable(exe: str | None, build_directory: Path) -> bool:
    if exe is None:
        return False
    target = exe.removesuffix(" (deleted)")
    return Path(os.path.normpath(target)).is_relative_to(build_directory)


def process_sample(
    build_directory: Path,
    known: dict[tuple[int, int], tuple[int, int]],
) -> dict[str, Any]:
    live: dict[int, dict[str, Any]] = {}
    errors: dict[str, int] = {}

    def failed(error: Exception) -> None:
        kind = error_kind(error)
        errors[kind] = errors.get(kind, 0) + 1

    for entry in PROC.iterdir():
        if not entry.name.isdecimal():
            continue
        pid = int(entry.name)
        try:
            process = read_stat(pid)
            if not ordinary_user(pid):
                continue
            process["exe"] = read_exe(pid)
            # Ensure the UID and executable belong to the same process identity.
            if read_stat(pid)["starttime"] != process["starttime"]:
                continue
            live[pid] = process
        except (OSError, ValueError, IndexError, KeyError) as error:
            failed(error)

    selected: dict[int, tuple[int, int]] = {}
    for pid, process in live.items():
        identity = (pid, process["starttime"])
        if build_executable(process["exe"], build_directory):
            selected[pid] = identity
        elif identity in known:
            selected[pid] = known[identity]

    # Resolve children regardless of /proc enumeration order. Previously observed
    # descendants remain attributable after their parent exits or is reparented.
    changed = True
    while changed:
        changed = False
        for pid, process in live.items():
            parent = process["ppid"]
            if pid not in selected and parent in selected:
                if process["starttime"] >= live[parent]["starttime"]:
                    selected[pid] = selected[parent]
                    changed = True

    samples = []
    for pid, root_identity in sorted(selected.items()):
        process = live[pid]
        identity = (pid, process["starttime"])
        try:
            # Re-check identity and UID after scanning other processes. An exec
            # may change the path, which is recorded without inspecting argv.
            current = read_stat(pid)
            if current["starttime"] != process["starttime"] or not ordinary_user(pid):
                continue
            current["exe"] = read_exe(pid)
            if read_stat(pid)["starttime"] != process["starttime"]:
                continue
            if identity == root_identity and identity not in known:
                if not build_executable(current["exe"], build_directory):
                    continue
            current["uid"] = TARGET_UID
            current["rss_bytes"] = current["rss_pages"] * os.sysconf("SC_PAGE_SIZE")
            current["root_pid"], current["root_starttime"] = root_identity
            try:
                current["wchan"] = (PROC / str(pid) / "wchan").read_text().strip()
            except OSError as error:
                current["wchan"] = None
                current["wchan_read_error"] = error_kind(error)
            known[identity] = root_identity
            samples.append(current)
        except (OSError, ValueError, IndexError, KeyError) as error:
            failed(error)
    return {"processes": samples, "proc_read_errors": errors}


def system_sample() -> dict[str, Any]:
    result: dict[str, Any] = {"cpu_ticks": {}, "pressure": {}}
    try:
        for line in (PROC / "stat").read_text().splitlines():
            fields = line.split()
            if fields and (fields[0] == "cpu" or fields[0][3:].isdecimal()):
                if fields[0].startswith("cpu"):
                    result["cpu_ticks"][fields[0]] = dict(zip(CPU_FIELDS, map(int, fields[1:])))
            elif fields and fields[0] in ("procs_running", "procs_blocked"):
                result[fields[0]] = int(fields[1])
    except (OSError, ValueError, IndexError) as error:
        result["stat_read_error"] = error_kind(error)
    for resource in ("cpu", "memory", "io"):
        try:
            # Preserve the kernel's exact PSI values without deriving causality.
            result["pressure"][resource] = (PROC / "pressure" / resource).read_text().strip()
        except OSError as error:
            result["pressure"][resource] = {"read_error": error_kind(error)}
    return result


def gate_sample(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text())
        if not isinstance(value, dict):
            raise ValueError("gate record is not an object")
        started = value.get("started_at")
        if not isinstance(started, str):
            raise ValueError("gate record has no start timestamp")
        start_time = datetime.datetime.fromisoformat(started)
        result: dict[str, Any] = {"state": "running", "started_at": started}
        finished, exit_code = value.get("finished_at"), value.get("exit_code")
        if isinstance(finished, str) and type(exit_code) is int:
            finish_time = datetime.datetime.fromisoformat(finished)
            if finish_time >= start_time:
                result.update(state="finished", finished_at=finished, exit_code=exit_code)
        return result
    except FileNotFoundError:
        return {"state": "not_created"}
    except (OSError, ValueError, TypeError) as error:
        # The runner rewrites its JSON in place, so partial JSON is transient.
        return {"state": "temporarily_unreadable", "read_error": error_kind(error)}


def main() -> int:
    if len(sys.argv) != 3:
        raise SystemExit("usage: monitor_sanitizer_gate.py NAME BUILD_DIRECTORY")
    name, build = sys.argv[1:]
    if ALLOWED_GATES.get(name) != build:
        raise SystemExit("name/build pair is not an approved final sanitizer gate")
    if os.getuid() != TARGET_UID or os.geteuid() != TARGET_UID:
        raise SystemExit("observer must run as ordinary UID 1000")

    task_root = Path(__file__).resolve().parent
    feature = (task_root / "feature").resolve(strict=True)
    build_directory = (feature / build).resolve(strict=True)
    if not build_directory.is_dir() or build_directory.parent != feature:
        raise SystemExit("approved build directory must be directly within feature")
    evidence = task_root / "evidence"
    gate_path = evidence / (name + ".json")
    output_path = evidence / (name + "-process-observation.json")
    try:
        descriptor = os.open(output_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o600)
    except FileExistsError:
        raise SystemExit("refusing to overwrite process observation: " + str(output_path))

    stop_signal: list[int] = []

    def request_stop(signum: int, _frame: Any) -> None:
        stop_signal.append(signum)

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)
    header = {
        "record_kind": "process_observation",
        "format_version": 1,
        "name": name,
        "gate_record": str(gate_path),
        "build_directory": str(build_directory),
        "observer_pid": os.getpid(),
        "observer_uid": os.getuid(),
        "target_uid": TARGET_UID,
        "started_at": utc_now(),
        "sample_interval_seconds": INTERVAL_SECONDS,
        "startup_grace_seconds": STARTUP_GRACE_SECONDS,
        "maximum_observation_seconds": MAX_OBSERVATION_SECONDS,
        "clock_ticks_per_second": os.sysconf("SC_CLK_TCK"),
        "page_size_bytes": os.sysconf("SC_PAGE_SIZE"),
        "scope": "UID 1000 build executables and observed UID 1000 descendants",
        "limitations": [
            "Processes or ancestry that exist only between samples may be missed.",
            "Kernel process fields are successive observations, not an atomic snapshot.",
            "Observation termination never terminates or changes a test process.",
        ],
    }
    started = time.monotonic()
    next_sample = started
    known: dict[tuple[int, int], tuple[int, int]] = {}
    count = 0
    gate_seen = False
    last_gate: dict[str, Any] = {"state": "not_created"}
    stop_reason = "observer_error"
    return_code = 1
    observer_error: str | None = None
    with os.fdopen(descriptor, "w", encoding="utf-8") as output:
        output.write(json.dumps(header, ensure_ascii=False, indent=2)[:-2] + ',\n  "samples": [\n')
        output.flush()
        print(str(output_path), flush=True)
        try:
            while True:
                last_gate = gate_sample(gate_path)
                gate_seen = gate_seen or last_gate["state"] in ("running", "finished")
                now = time.monotonic()
                sample = {
                    "at": utc_now(),
                    "elapsed_seconds": now - started,
                    "gate_state": last_gate["state"],
                    "system": system_sample(),
                    **process_sample(build_directory, known),
                }
                if count:
                    output.write(",\n")
                output.write(json.dumps(sample, ensure_ascii=False, separators=(",", ":")))
                output.flush()
                count += 1
                if last_gate["state"] == "finished":
                    stop_reason, return_code = "gate_finished", 0
                    break
                if stop_signal:
                    stop_reason, return_code = "observer_signal", 128 + stop_signal[0]
                    break
                elapsed = time.monotonic() - started
                if not gate_seen and elapsed >= STARTUP_GRACE_SECONDS:
                    stop_reason, return_code = "gate_not_started_within_grace", 2
                    break
                if elapsed >= MAX_OBSERVATION_SECONDS:
                    stop_reason, return_code = "observation_limit_reached", 3
                    break
                next_sample += INTERVAL_SECONDS
                # Do not run catch-up bursts if host scheduling delayed a sample.
                if next_sample < time.monotonic():
                    next_sample = time.monotonic() + INTERVAL_SECONDS
                time.sleep(max(0.0, next_sample - time.monotonic()))
        except Exception as error:
            observer_error = type(error).__name__
        finally:
            footer = {
                "finished_at": utc_now(),
                "elapsed_seconds": time.monotonic() - started,
                "sample_count": count,
                "stop_reason": stop_reason,
                "observer_exit_code": return_code,
                "gate": last_gate,
                "observer_signal": stop_signal[0] if stop_signal else None,
                "observer_error": observer_error,
            }
            output.write("\n  ],\n  \"completion\": " + json.dumps(footer, ensure_ascii=False, indent=2) + "\n}\n")
            output.flush()
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
