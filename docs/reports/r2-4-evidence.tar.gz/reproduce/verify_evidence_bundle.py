"""Check exact bundled evidence and recompute outcomes; do not execute members."""
import datetime
import json
import pathlib
import re
import tarfile

from summarize_final_validation import (
    MANIFEST_SHA256, METADATA, configuration_details, ctest_observation,
    digest, is_finished, is_runner_record, validate_record,
)

ROOT = pathlib.Path(__file__).resolve().parent


def main():
    bundle = ROOT / 'feature/docs/reports/r2-4-evidence.tar.gz'
    result_file = ROOT / 'evidence/evidence-bundle-verification.json'
    assert not result_file.exists(), 'refusing to replace completed bundle verification'
    payloads = {}
    with tarfile.open(bundle, 'r:gz') as archive:
        for entry in archive.getmembers():
            path = pathlib.PurePosixPath(entry.name)
            assert entry.isfile() and not path.is_absolute() and '..' not in path.parts
            assert entry.name not in payloads and entry.size < 10 * 1024 * 1024
            assert entry.name == 'INDEX.json' or path.parts[0] in ('evidence', 'reproduce')
            assert path.suffix in ('.json', '.log', '.sha256', '.py', '.sh', '.cpp', '.patch')
            payloads[entry.name] = archive.extractfile(entry).read()
    assert sum(map(len, payloads.values())) < 30 * 1024 * 1024
    index = json.loads(payloads['INDEX.json'])
    assert index['schema_version'] == 2
    assert set(index['files']) == set(payloads) - {'INDEX.json'}
    incomplete, observations = [], []
    log_digests = {digest(data) for name, data in payloads.items() if name.endswith('.log')}
    for name, metadata in index['files'].items():
        data = payloads[name]
        assert metadata['bytes'] == len(data) and metadata['sha256'] == digest(data), name
        assert not data.startswith((b'\x7fELF', b'SQLite format 3\0', b'!<arch>\n')), name
        assert not pathlib.PurePosixPath(name).name.startswith('github-'), name
        kind = 'artifact'
        if name.endswith('.json'):
            record = json.loads(data)
            if is_runner_record(record):
                finished = is_finished(record)
                kind = 'runner_complete' if finished else 'runner_incomplete'
                if not finished:
                    incomplete.append(name)
            elif isinstance(record, dict) and 'command' in record:
                kind = 'observation'
                observations.append(name)
            else:
                kind = 'json'
            if isinstance(record, dict) and 'log_sha256' in record:
                log_name = name[:-5] + '.log'
                assert log_name in payloads and digest(payloads[log_name]) == record['log_sha256'], log_name
            if isinstance(record, dict) and 'detail_log_sha256' in record:
                assert record['detail_log_sha256'] in log_digests, name
        assert metadata['kind'] == kind, name
    assert sorted(incomplete) == index['incomplete_command_snapshots']
    assert sorted(observations) == index['observation_records_with_command']
    patterns = [
        rb'gh[pousr]_[A-Za-z0-9]{20,}', rb'github_pat_[A-Za-z0-9_]{30,}',
        rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}', rb'(?:AKIA|ASIA)[0-9A-Z]{16}',
        rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',
        rb'https?://[^\s/:]+:[^\s/@]+@', rb'(?i:Bearer)\s+[A-Za-z0-9_./+\-=]{40,}',
    ]
    suspects = sorted(name for name, data in payloads.items()
                      if any(re.search(pattern, data) for pattern in patterns))
    assert not suspects, 'possible credentials require inspection in: ' + ', '.join(suspects)
    # Use the reviewed local pure validators, never import or execute archive members.
    for name in ('summarize_final_validation.py', 'verify_evidence_bundle.py'):
        assert payloads['reproduce/' + name] == (ROOT / name).read_bytes(), name
    plan_bytes = payloads['evidence/final-validation-plan.json']
    summary_bytes = payloads['evidence/r2-4-results.json']
    assert digest(plan_bytes) == index['plan_sha256']
    assert digest(summary_bytes) == index['summary_sha256']
    assert summary_bytes == (ROOT / 'feature/docs/reports/r2-4-results.json').read_bytes()
    plan, summary = json.loads(plan_bytes), json.loads(summary_bytes)
    assert plan['schema_version'] == 1 and summary['schema_version'] == 2
    assert summary['plan_sha256'] == digest(plan_bytes)
    assert plan['source']['manifest_sha256'] == MANIFEST_SHA256
    frozen = json.loads(payloads['evidence/' + plan['source']['record']])
    manifest = payloads['evidence/' + plan['source']['manifest']]
    assert digest(manifest) == frozen['manifest_sha256'] == MANIFEST_SHA256
    source = frozen['inputs']
    assert len(source) == frozen['count'] == plan['source']['count'] == 312
    parsed_manifest = {line.split('  ', 1)[1]: line.split('  ', 1)[0]
                       for line in manifest.decode().splitlines()}
    assert parsed_manifest == source
    assert summary['input_manifest'] == {key: frozen[key] for key in ('at', 'count', 'manifest_sha256')}
    assert summary['baseline'] == plan['baseline'] and summary['branch'] == plan['branch']
    assert len(plan['gates']) == 5 and len(plan['builds']) == 4
    for section in ('gates', 'builds'):
        assert set(summary[section]) == set(plan[section])
        for name, spec in plan[section].items():
            raw = payloads.get('evidence/' + name + '.json')
            record = json.loads(raw) if raw is not None else None
            log = payloads.get('evidence/' + name + '.log')
            row = validate_record(record, spec, source, log)
            row['record_sha256'] = digest(raw) if raw is not None else None
            assert summary[section][name] == row, name
            if section == 'gates' and record is not None:
                assert summary['binary_identities'][name] == {
                    'before': record['binaries_before'], 'after': record.get('binaries_after')}
    assert set(summary['binary_identities']) == {
        name for name in plan['gates'] if 'evidence/' + name + '.json' in payloads}
    directories = {spec['build_dir'] for spec in plan['builds'].values()}
    assert set(summary['configuration_evidence']) == set(summary['configuration_details']) == directories
    for directory, files in summary['configuration_evidence'].items():
        details = configuration_details(directory, files)
        assert details == summary['configuration_details'][directory]
        for name, spec in plan['gates'].items():
            if spec['build_dir'] != directory:
                continue
            assert all(details['test_timeouts_seconds'][test] == seconds
                       for test, seconds in spec['test_timeouts_seconds'].items())
            assert set(spec['registered_test_names']) <= set(details['registered_test_names'])
            identities = summary['binary_identities'].get(name)
            if identities:
                for phase in ('before', 'after'):
                    if identities[phase] is not None:
                        assert all(identities[phase][file]['sha256'] == value['sha256']
                                   for file, value in files.items())
    snapshots = {frozen['manifest_sha256']: source}
    expected_prior = []
    for filename in plan['prior_source_records']:
        prior = json.loads(payloads['evidence/' + filename])
        snapshots[prior['manifest_sha256']] = prior['inputs']
        expected_prior.append({'record': filename, 'manifest_sha256': prior['manifest_sha256']})
    assert summary['prior_input_manifests'] == expected_prior
    assert set(summary['superseded_or_diagnostic_runs']) == set(plan['historical_runs'])
    for name in plan['historical_runs']:
        raw = payloads['evidence/' + name + '.json']
        record = json.loads(raw)
        row = {key: record.get(key) for key in METADATA}
        row.update(record_sha256=digest(raw), source_snapshot=next((key for key, value in snapshots.items()
                   if record.get('before') == record.get('after') == value), None),
                   scope_note='Historical or diagnostic execution; never substitutes for a v3 gate.')
        if record['command'][0] == 'ctest':
            row['ctest'] = ctest_observation(payloads['evidence/' + name + '.log'])
        assert summary['superseded_or_diagnostic_runs'][name] == row, name
    assert set(summary['auxiliary_records']) == set(plan['auxiliary_records'])
    for label, filename in plan['auxiliary_records'].items():
        raw = payloads.get('evidence/' + filename)
        row = summary['auxiliary_records'][label]
        if raw is None:
            assert row == {'status': 'NOT_RUN', 'record': filename}
            continue
        record = json.loads(raw)
        assert row == {'status': 'VERIFIED', 'record': filename, 'sha256': digest(raw), 'data': record}
        if label == 'protected_files':
            assert record['baseline'] == plan['baseline']
            assert set(record['groups']) == {'db/', 'third_party/', 'docs/handoff/', 'docs/reports/'}
            assert all(not group['mismatches'] for group in record['groups'].values())
            assert len(record['records']) == 323 and all(item['identical'] for item in record['records'])
        if label == 'generated_install_assets':
            assert len(record['files']) == 12
    for candidate, counterexample in (
            ('concurrency-candidate', 'concurrency-counterexamples.json'),
            ('settlement-session-candidate', 'settlement-counterexamples.json')):
        base = 'reproduce/' + candidate + '/'
        manifest_raw = payloads[base + 'candidate-manifest.json']
        counter = json.loads(payloads['evidence/' + counterexample])
        assert digest(manifest_raw) == counter['candidate_manifest_sha256']
        candidate_manifest = json.loads(manifest_raw)
        assert candidate_manifest == counter['source_inputs']
        for variant, spec in candidate_manifest['candidates'].items():
            assert digest(payloads[base + variant + '/src/worker_tools.cpp']) == spec['source_sha256']
            assert digest(payloads[base + variant + '/tests/worker_tools_tests.cpp']) == spec['test_sha256']
    initial = json.loads(payloads['reproduce/settlement-session-candidate/initial-manifest.json'])
    initial_test = payloads['reproduce/settlement-session-candidate/initial-tests.cpp']
    assert all(digest(initial_test) == spec['test_sha256'] for spec in initial['candidates'].values())
    backup = json.loads(payloads['reproduce/delivery-scripts-v2/MANIFEST.json'])
    for name, metadata in backup['files'].items():
        data = payloads['reproduce/delivery-scripts-v2/' + name]
        assert digest(data) == metadata['sha256'] and len(data) == metadata['bytes']
    local_complete = (
        all(row['status'] == 'PASSED' for section in ('gates', 'builds') for row in summary[section].values()) and
        all(row['status'] == 'VERIFIED' for row in summary['auxiliary_records'].values()))
    assert summary['evidence_integrity_verified'] is True
    assert summary['local_validation_complete'] is local_complete
    result = {
        'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'bundle_sha256': digest(bundle.read_bytes()), 'bundle_bytes': bundle.stat().st_size,
        'summary_sha256': digest(summary_bytes), 'plan_sha256': digest(plan_bytes),
        'member_count': len(payloads), 'uncompressed_bytes': sum(map(len, payloads.values())),
        'bundle_integrity_verified': True, 'all_index_entries_and_completed_log_hashes_match': True,
        'incomplete_command_snapshots': incomplete, 'observation_records_with_command': observations,
        'gate_statuses': {name: row['status'] for name, row in summary['gates'].items()},
        'local_validation_complete': local_complete, 'unsafe_paths_links_binary_database_magic_found': False,
        'common_credential_pattern_matches': [],
        'scope_note': 'Exact bundle integrity and truthful outcomes were verified without executing archived code. Integrity success does not turn failed, interrupted or missing tests into passing validation.',
    }
    with result_file.open('x') as output:
        output.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
