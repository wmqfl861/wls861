"""Execute a recorded candidate compile/link/run argv without shell interpolation."""
import hashlib
import json
import os
import pathlib
import sys

root = pathlib.Path(__file__).resolve().parent
variant, phase, record_name = sys.argv[1:]
assert variant in ('red', 'green') and phase in ('compile', 'link', 'run')
manifest_path = root / 'settlement-session-candidate/candidate-manifest.json'
manifest = json.loads(manifest_path.read_text())
candidate = manifest['candidates'][variant]
for relative, key in [('src/worker_tools.cpp', 'source_sha256'), ('tests/worker_tools_tests.cpp', 'test_sha256')]:
    path = root / 'settlement-session-candidate' / variant / relative
    assert hashlib.sha256(path.read_bytes()).hexdigest() == candidate[key], path
args = [sys.executable, str(root / 'run_validation.py'), record_name, candidate['source_root'], *candidate[phase + '_argv']]
os.execv(sys.executable, args)
