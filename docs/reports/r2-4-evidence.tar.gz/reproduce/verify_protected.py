import datetime, hashlib, json, pathlib, stat, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
repo=root/'feature'
base='a6b8559018a599d7a806b05942857a56d69a00ce'
report=root/'evidence'/sys.argv[1]
assert not report.exists()
entries=subprocess.check_output(['git','ls-tree','-r','-z',base,'--','db','third_party','docs/handoff','docs/reports'],cwd=repo).split(b'\0')
records=[]
for entry in entries:
    if not entry: continue
    meta,raw_path=entry.split(b'\t'); mode,kind,oid=meta.decode().split(); name=raw_path.decode()
    original=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo)
    path=repo/name; observed=path.lstat()
    actual_mode='120000' if stat.S_ISLNK(observed.st_mode) else ('100755' if observed.st_mode & 0o111 else '100644') if stat.S_ISREG(observed.st_mode) else 'other'
    data=path.readlink().as_posix().encode() if stat.S_ISLNK(observed.st_mode) else path.read_bytes() if stat.S_ISREG(observed.st_mode) else b''
    records.append({'path':name,'git_mode':mode,'actual_mode':actual_mode,'blob':oid,'bytes':len(original),'sha256':hashlib.sha256(original).hexdigest(),'actual_sha256':hashlib.sha256(data).hexdigest(),'identical':data==original and actual_mode==mode})
groups={}
for prefix in ['db/','third_party/','docs/handoff/','docs/reports/']:
    items=[r for r in records if r['path'].startswith(prefix)]
    groups[prefix]={'count':len(items),'bytes':sum(r['bytes'] for r in items),'mismatches':[r['path'] for r in items if not r['identical']]}
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':base,'groups':groups,'records':records}
report.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(groups,indent=2)); sys.exit(any(not r['identical'] for r in records))
