"""Archive only validation logs/records, never build products or databases."""
import datetime, gzip, hashlib, io, json, pathlib, tarfile
root=pathlib.Path(__file__).resolve().parent
source=root/'evidence'
target=root/'feature/docs/reports/r2-4-evidence.tar.gz'
index={'archived_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'contents':'Raw validation logs, command records, SHA-256 manifests and reproducer scripts only','files':{}}
files={}
unfinished=set()
for path in sorted(source.glob('*.json')):
    record=json.loads(path.read_bytes())
    if 'command' in record and not isinstance(record.get('exit_code'),int):
        unfinished.add(path.stem)
index['excluded_unfinished_command_records']=sorted(unfinished)
for path in sorted(source.iterdir()):
    if path.suffix not in ('.log','.json','.sha256'):continue
    if path.name.startswith('github-'):continue
    if path.stem in unfinished:continue
    raw=path.read_bytes()
    files['evidence/'+path.name]=raw
for name in ['run_validation.py','run_in_test_tmpfs.sh','verify_protected.py','run_sanitizer_gate.py','run_concurrency_candidate.py','record_generated_assets.py','summarize_final_validation.py','archive_evidence.py','verify_evidence_bundle.py']:
    files['reproduce/'+name]=(root/name).read_bytes()
for variant in ('red','green'):
    for relative in ('src/worker_tools.cpp','tests/worker_tools_tests.cpp'):
        name='concurrency-candidate/'+variant+'/'+relative
        files['reproduce/'+name]=(root/name).read_bytes()
for relative in ('candidate-manifest.json','baseline-observer.patch'):
    name='concurrency-candidate/'+relative
    files['reproduce/'+name]=(root/name).read_bytes()
for name,data in files.items():index['files'][name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
files['INDEX.json']=(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode()
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w',format=tarfile.PAX_FORMAT) as archive:
    for name,data in sorted(files.items()):
        entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;entry.uid=1000;entry.gid=1000
        archive.addfile(entry,io.BytesIO(data))
encoded=gzip.compress(stream.getvalue(),mtime=0)
assert not target.exists(), 'refusing to replace frozen evidence archive'
target.write_bytes(encoded)
print({'files':len(files),'raw_bytes':sum(map(len,files.values())),'archive_bytes':len(encoded),'archive_sha256':hashlib.sha256(encoded).hexdigest()})
