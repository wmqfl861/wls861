"""Validate the final evidence bundle without extracting or executing members."""
import datetime
import hashlib
import json
import pathlib
import re
import tarfile

root = pathlib.Path(__file__).resolve().parent
bundle = root / 'feature/docs/reports/r2-4-evidence.tar.gz'
result_file = root / 'evidence/evidence-bundle-verification.json'
assert not result_file.exists(), 'refusing to replace a completed bundle verification'
payloads = {}
with tarfile.open(bundle, 'r:gz') as archive:
    for entry in archive.getmembers():
        path = pathlib.PurePosixPath(entry.name)
        assert entry.isfile() and not path.is_absolute() and '..' not in path.parts
        assert entry.name not in payloads
        assert entry.size < 10 * 1024 * 1024
        assert entry.name == 'INDEX.json' or path.parts[0] in ('evidence', 'reproduce')
        assert path.suffix in ('.json', '.log', '.sha256', '.py', '.sh', '.cpp', '.patch')
        payloads[entry.name] = archive.extractfile(entry).read()
assert sum(map(len, payloads.values())) < 30 * 1024 * 1024
index = json.loads(payloads['INDEX.json'])
assert set(index['files']) == set(payloads) - {'INDEX.json'}
for name, metadata in index['files'].items():
    data = payloads[name]
    assert metadata['bytes'] == len(data)
    assert metadata['sha256'] == hashlib.sha256(data).hexdigest(), name
    assert not data.startswith((b'\x7fELF', b'SQLite format 3\0', b'!<arch>\n')), name
    assert not pathlib.PurePosixPath(name).name.startswith('github-'), name
    if name.endswith('.json'):
        record = json.loads(data)
        if 'command' in record:
            assert isinstance(record.get('exit_code'), int), name
        if 'log_sha256' in record:
            log_name = name[:-5] + '.log'
            assert log_name in payloads, log_name
            assert hashlib.sha256(payloads[log_name]).hexdigest() == record['log_sha256'], log_name
patterns = [
    rb'gh[pousr]_[A-Za-z0-9]{30,}',
    rb'github_pat_[A-Za-z0-9_]{30,}',
    rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,}',
    rb'AKIA[0-9A-Z]{16}',
    rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    rb'https?://[^\s/:]+:[^\s/@]+@',
    rb'(?i:Bearer)\s+[A-Za-z0-9_./+\-=]{40,}',
]
suspects = sorted(name for name, data in payloads.items() if any(re.search(pattern, data) for pattern in patterns))
assert not suspects, 'possible credentials require inspection in: ' + ', '.join(suspects)
required = [
    'baseline-final-counterexamples.json', 'source-final-v2.json', 'source-final-v2.sha256',
    'concurrency-counterexamples.json',
    'protected-files-final.json', 'generated-install-assets-final.json',
    'feature-release-0022-r24-final.json', 'feature-release-0002-r24-final.json',
    'feature-clang-r24-final.json', 'feature-asan-r24-exclusive.json',
    'feature-ubsan-r24-exclusive.json',
]
assert all('evidence/' + name in payloads for name in required)
result = {
    'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'bundle_sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(),
    'bundle_bytes': bundle.stat().st_size,
    'member_count': len(payloads),
    'uncompressed_bytes': sum(map(len, payloads.values())),
    'all_index_entries_and_log_hashes_match': True,
    'all_command_records_have_exit_code': True,
    'required_final_records_present': True,
    'unsafe_paths_links_binary_database_magic_found': False,
    'common_credential_pattern_matches': [],
    'excluded_unfinished_commands': index['excluded_unfinished_command_records'],
    'scope_note': 'Pattern and file-type checks cover this exact bundle only; no archived code was executed.',
}
result_file.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
