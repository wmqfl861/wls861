import datetime, hashlib, json, pathlib, re, subprocess
root=pathlib.Path(__file__).resolve().parent
repo=root/'feature'; evidence=root/'evidence'
frozen=json.loads((evidence/'source-final-v2.json').read_text())
source=frozen['inputs']
assert len(source)==312
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==digest for p,digest in source.items())
gate_names=['feature-release-0022-r24-final','feature-release-0002-r24-final','feature-asan-r24-exclusive','feature-ubsan-r24-exclusive','feature-clang-r24-final']
affinities={'feature-release-0022-r24-final':[2],'feature-release-0002-r24-final':[2],'feature-asan-r24-exclusive':[0,1,2,3],'feature-ubsan-r24-exclusive':[0,1,2,3],'feature-clang-r24-final':[3]}
build_dirs={'feature-release-0022-r24-final':'build-release','feature-release-0002-r24-final':'build-release','feature-asan-r24-exclusive':'build-asan-clang-opt','feature-ubsan-r24-exclusive':'build-ubsan-clang-opt','feature-clang-r24-final':'build-clang'}
sanitizer_scope=json.loads((evidence/'sanitizer-focused-scope.json').read_text())
result={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':'a6b8559018a599d7a806b05942857a56d69a00ce','branch':'feat/r2-4-demand-driven-recovery','scope':'Offline local code development and disposable tests only; no provider/paid/production calls','input_manifest':{k:frozen[k] for k in ['at','count','manifest_sha256']},'gate_counting':'81 registered executions for each full Release/Clang gate; 31 affected registered executions for each ASan/UBSan gate. R2.4 remains three logical suites with 26 subcases, not 26 suites','gates':{},'builds':{},'binary_identities':{},'superseded_or_diagnostic_runs':{}}
for name in gate_names:
    r=json.loads((evidence/(name+'.json')).read_text())
    expected_command=['ctest','--test-dir',build_dirs[name],'--output-on-failure','--parallel','1']
    if name in ('feature-asan-r24-exclusive','feature-ubsan-r24-exclusive'):
        expected_command+=['-R',sanitizer_scope['regex']]
    assert r['command']==expected_command and pathlib.Path(r['cwd'])==repo,name
    assert r['exit_code']==0 and r['inputs_unchanged'] and r['binaries_unchanged'], name
    assert r['before']==r['after']==source, name
    assert r['uid']==1000 and r['gid']==1000 and r['cpu_affinity']==affinities[name], name
    assert all(int(v,16)==0 for v in r['capabilities'].values()),name
    assert r['umask']==('0022' if name=='feature-release-0022-r24-final' else '0002'),name
    if 'asan-r24' in name:
        assert r['environment']['ASAN_OPTIONS']=='halt_on_error=1:detect_leaks=1',name
    if 'ubsan-r24' in name:
        assert r['environment']['UBSAN_OPTIONS']=='halt_on_error=1:print_stacktrace=1',name
    log=(evidence/(name+'.log')).read_bytes();assert hashlib.sha256(log).hexdigest()==r['log_sha256']
    expected_count=31 if name in ('feature-asan-r24-exclusive','feature-ubsan-r24-exclusive') else 81
    assert f'100% tests passed, 0 tests failed out of {expected_count}'.encode() in log,name
    result['gates'][name]={'registered_count':expected_count,**{k:r[k] for k in ['command','cwd','uid','gid','groups','umask','environment','cpu_affinity','nice','capabilities','mount_namespace','tmp_mounts','started_at','finished_at','exit_code','elapsed_seconds','inputs_unchanged','binaries_unchanged','log_sha256']}}
    result['binary_identities'][name]=r['binaries_after']
for name in ['feature-build-release-r24-final','feature-build-clang-r24-final','feature-build-asan-r24-final','feature-build-ubsan-r24-final']:
    r=json.loads((evidence/(name+'.json')).read_text());assert r['exit_code']==0 and r['inputs_unchanged'] and r['before']==r['after']==source,name
    result['builds'][name]={k:r[k] for k in ['command','uid','gid','started_at','finished_at','exit_code','elapsed_seconds','inputs_unchanged','log_sha256']}
for directory in ['build-release','build-clang','build-asan-clang-opt','build-ubsan-clang-opt']:
    ninja=(repo/directory/'build.ninja').read_text()
    flags=sorted(set(line.strip() for line in ninja.splitlines() if line.startswith('  FLAGS =') or line.startswith('  LINK_FLAGS =')))
    result.setdefault('compiler_flags',{})[directory]=flags
    if 'clang-opt' in directory:
        assert not any('NDEBUG' in flag for flag in flags),directory
        cache=(repo/directory/'CMakeCache.txt').read_text().splitlines()
        assert 'CMAKE_BUILD_TYPE:STRING=Debug' in cache,directory
        assert 'CMAKE_CXX_FLAGS_DEBUG:STRING=-O2 -g' in cache,directory
        assert 'CMAKE_CXX_COMPILER:STRING=/usr/bin/clang++-18' in cache,directory
        asan=directory=='build-asan-clang-opt'
        assert 'WLS_ENABLE_ASAN:BOOL='+('ON' if asan else 'OFF') in cache,directory
        assert 'WLS_ENABLE_UBSAN:BOOL='+('OFF' if asan else 'ON') in cache,directory
        sanitizer='-fsanitize=address' if asan else '-fsanitize=undefined'
        cpp_flags=[flag for flag in flags if '-std=c++20' in flag]
        assert cpp_flags and all(sanitizer in flag and '-Werror' in flag and '-fno-omit-frame-pointer' in flag for flag in cpp_flags),directory
        assert any(flag.startswith('LINK_FLAGS =') and sanitizer in flag for flag in flags),directory
        if not asan:assert all('-fno-sanitize-recover=undefined' in flag for flag in cpp_flags),directory
for name in ['feature-release-0022','feature-release-0022-final','feature-release-0022-serial','feature-release-0002-serial','feature-clang-serial','feature-clang-serial-recheck','feature-build-asan-clang-opt','feature-build-ubsan-clang-opt','feature-asan-final','feature-asan-r24-final','feature-asan-r24-deadline-diagnostic','feature-build-ubsan','feature-sandbox-no-compiler-retry']:
    r=json.loads((evidence/(name+'.json')).read_text());result['superseded_or_diagnostic_runs'][name]={k:r.get(k) for k in ['command','uid','umask','exit_code','elapsed_seconds','inputs_unchanged','log_sha256']}
result['sanitizer_scope']=json.loads((evidence/'sanitizer-focused-scope.json').read_text())
result['baseline_counterexamples']=json.loads((evidence/'baseline-final-counterexamples.json').read_text())
result['deterministic_concurrency_counterexample']=json.loads((evidence/'concurrency-counterexamples.json').read_text())
result['prior_input_manifest']=json.loads((evidence/'source-final.json').read_text())['manifest_sha256']
result['generated_install_assets']=json.loads((evidence/'generated-install-assets-final.json').read_text())
protected=json.loads((evidence/'protected-files-final.json').read_text());assert all(not v['mismatches'] for v in protected['groups'].values());result['protected_files']=protected['groups']
result['publication_note']='This evidence freezes local gates before creating the commit. Exact commit, remote ref, Actions and source snapshot are verified separately after normal publication; local success does not imply remote CI.'
output=repo/'docs/reports/r2-4-results.json';assert not output.exists();output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print({'local_gates':len(result['gates']),'full_registered_count':81,'focused_registered_count':31,'inputs':len(source),'results_sha256':hashlib.sha256(output.read_bytes()).hexdigest()})
