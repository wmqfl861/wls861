import json, os, pathlib, sys
root=pathlib.Path(__file__).resolve().parent
name,build=sys.argv[1:]
builds={'feature-asan-r24-exclusive':'build-asan-clang-opt','feature-ubsan-r24-exclusive':'build-ubsan-clang-opt'}
assert name in builds and build==builds[name]
scope=json.loads((root/'evidence/sanitizer-focused-scope.json').read_text())
assert scope['registered_count']==31
os.execv(sys.executable,[sys.executable,str(root/'run_validation.py'),name,str(root/'feature'),'ctest','--test-dir',build,'--output-on-failure','--parallel','1','-R',scope['regex']])
