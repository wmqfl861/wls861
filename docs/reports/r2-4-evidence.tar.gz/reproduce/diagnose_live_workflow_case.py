"""Run the original failed method without changing its assertions or deadlines."""
import pathlib
import runpy
import sys
import unittest

root = pathlib.Path(__file__).resolve().parent
source = root / 'feature'
test_file = source / 'tests/test_live_workflow.py'
driver = source / 'build-asan-clang-opt/live_workflow_driver'
sys.path.insert(0, str(test_file.parent))
sys.argv = [str(test_file), str(driver), str(source)]
namespace = runpy.run_path(str(test_file), run_name='workflow_single_case')
suite = unittest.TestSuite([namespace['LiveWorkflow'](
    'test_model_exhaustion_escalates_original_rejected_submission')])
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
