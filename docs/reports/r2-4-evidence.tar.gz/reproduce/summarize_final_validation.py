"""Freeze truthful v3 outcomes; failed tests never weaken evidence checks."""
import datetime
import hashlib
import json
import pathlib
import re
import stat

ROOT = pathlib.Path(__file__).resolve().parent
MANIFEST_SHA256 = '59c8310d64a961d2ebac1159b93e8aa925499be61795b06831a96d79e2fa2050'
CAPABILITIES = {'CapInh', 'CapPrm', 'CapEff', 'CapAmb'}
METADATA = ('command', 'cwd', 'uid', 'gid', 'groups', 'umask', 'environment',
            'cpu_affinity', 'nice', 'capabilities', 'mount_namespace', 'tmp_mounts',
            'started_at', 'finished_at', 'exit_code', 'elapsed_seconds',
            'inputs_unchanged', 'binaries_unchanged', 'log_sha256')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def is_runner_record(record):
    # Observation records can contain a command without being runner executions.
    return isinstance(record, dict) and all(key in record for key in
        ('command', 'cwd', 'started_at', 'before', 'binaries_before'))


def is_finished(record):
    if 'exit_code' not in record and 'finished_at' not in record:
        return False
    assert type(record.get('exit_code')) is int and record.get('finished_at')
    return True


def ctest_observation(log):
    text = log.decode('utf-8', errors='replace') if log is not None else ''
    totals = re.findall(r'(?m)^\d+% tests passed, (\d+) tests failed out of (\d+)\s*$', text)
    assert len(totals) <= 1, 'multiple CTest summaries in one command log'
    entries = []
    for name, outcome, seconds in re.findall(
            r'(?m)^\s*\d+/\d+\s+Test\s+#\d+:\s+(\S+)\s+(.+?)\s+([0-9.]+)\s+sec\s*$', text):
        entries.append({'name': name, 'outcome': outcome.strip(), 'seconds': float(seconds),
                        'passed': bool(re.search(r'\bPassed\b', outcome)),
                        'timeout': 'Timeout' in outcome})
    assert len({entry['name'] for entry in entries}) == len(entries), 'duplicate registered execution'
    return {'reported_total': int(totals[0][1]) if totals else None,
            'reported_failed': int(totals[0][0]) if totals else None,
            'observed_entries': entries,
            'timeout_names': [entry['name'] for entry in entries if entry['timeout']]}


def validate_record(record, spec, source, log):
    """Pure validation shared with the bundle verifier; absent facts stay absent."""
    if record is None:
        assert log is None
        return {'status': 'NOT_RUN', 'execution_finished': False, 'exit_code': None,
                'registered_count': spec.get('registered_count'), 'observed': None}
    assert is_runner_record(record)
    assert record['command'] == spec['command'] and record['cwd'] == spec['cwd']
    assert record['before'] == source
    for key in ('uid', 'gid', 'umask', 'cpu_affinity'):
        assert record[key] == spec[key], key
    assert set(record['capabilities']) == CAPABILITIES
    assert all(int(value, 16) == 0 for value in record['capabilities'].values())
    for key, expected in spec['environment'].items():
        assert key in record['environment'] and record['environment'][key] == expected, key
    if spec.get('require_private_tmpfs'):
        assert record['mount_namespace']
        assert any(' - tmpfs ' in line and line.split()[4] == '/tmp' and
                   {'nosuid', 'nodev'} <= set(line.split()[5].split(',')) and
                   not any(part.startswith('shared:') for part in line.split()[6:])
                   for line in record['tmp_mounts'])
    ctest = spec['kind'] == 'ctest'
    if ctest:
        assert len(spec['registered_test_names']) == len(set(spec['registered_test_names'])) == spec['registered_count']
        assert set(spec['test_timeouts_seconds']) == set(spec['registered_test_names'])
        assert isinstance(record['binaries_before'], dict) and record['binaries_before']
        assert {'CMakeCache.txt', 'CTestTestfile.cmake', 'build.ninja'} <= set(record['binaries_before'])
    finished = is_finished(record)
    if finished:
        assert record['before'] == record['after'] == source
        assert record['inputs_unchanged'] is True
        assert log is not None and digest(log) == record['log_sha256']
        if ctest:
            assert record['binaries_before'] == record['binaries_after']
            assert record['binaries_unchanged'] is True
    result = {key: record.get(key) for key in METADATA}
    result.update(execution_finished=finished, registered_count=spec.get('registered_count'),
                  log_snapshot_sha256=digest(log) if log is not None else None,
                  source_before_verified=True, source_after_verified=True if finished else None,
                  binary_before_after_verified=True if ctest and finished else None)
    observed = ctest_observation(log) if ctest else None
    result['ctest'] = observed
    if ctest:
        expected_names = set(spec['registered_test_names'])
        observed_names = {entry['name'] for entry in observed['observed_entries']}
        assert observed_names <= expected_names, 'unexpected registered test in gate log'
        selection_complete = (observed['reported_total'] == spec['registered_count'] and
                              observed_names == expected_names)
        result['selection_complete'] = selection_complete
    if not finished:
        result['status'] = 'INCOMPLETE'
    elif record['exit_code'] < 0:
        result['status'] = 'INTERRUPTED'
    elif record['exit_code'] != 0:
        result['status'] = 'FAILED'
    elif ctest and not (selection_complete and observed['reported_failed'] == 0 and
                       all(entry['passed'] for entry in observed['observed_entries'])):
        result['status'] = 'INCOMPLETE'
    else:
        result['status'] = 'PASSED'
    return result


def configuration_details(directory, files):
    """Validate captured text, retaining the original generated timeout properties."""
    assert set(files) == {'CMakeCache.txt', 'CTestTestfile.cmake', 'build.ninja'}
    for record in files.values():
        raw = record['text'].encode()
        assert digest(raw) == record['sha256'] and len(raw) == record['bytes']
    ninja = files['build.ninja']['text']
    flags = sorted({line.strip() for line in ninja.splitlines()
                    if line.startswith(('  FLAGS =', '  LINK_FLAGS ='))})
    cpp_flags = [flag for flag in flags if '-std=c++20' in flag]
    assert cpp_flags and all('-Werror' in flag for flag in cpp_flags)
    if directory in ('build-asan-clang-opt', 'build-ubsan-clang-opt'):
        cache = files['CMakeCache.txt']['text'].splitlines()
        assert not any('NDEBUG' in flag for flag in flags)
        assert 'CMAKE_BUILD_TYPE:STRING=Debug' in cache
        assert 'CMAKE_CXX_FLAGS_DEBUG:STRING=-O2 -g' in cache
        assert 'CMAKE_CXX_COMPILER:STRING=/usr/bin/clang++-18' in cache
        asan = directory == 'build-asan-clang-opt'
        assert 'WLS_ENABLE_ASAN:BOOL=' + ('ON' if asan else 'OFF') in cache
        assert 'WLS_ENABLE_UBSAN:BOOL=' + ('OFF' if asan else 'ON') in cache
        sanitizer = '-fsanitize=address' if asan else '-fsanitize=undefined'
        assert all(sanitizer in flag and '-fno-omit-frame-pointer' in flag for flag in cpp_flags)
        assert any(flag.startswith('LINK_FLAGS =') and sanitizer in flag for flag in flags)
        if not asan:
            assert all('-fno-sanitize-recover=undefined' in flag for flag in cpp_flags)
    ctest = files['CTestTestfile.cmake']['text']
    names = re.findall(r'^add_test\(\[=\[(.*?)\]=\]', ctest, re.M)
    timeouts = {name: float(value) for name, value in re.findall(
        r'^set_tests_properties\(\[=\[(.*?)\]=\].*? TIMEOUT "([^"]+)"', ctest, re.M)}
    assert len(names) == len(set(names)) == 81 and set(timeouts) == set(names)
    return {'compiler_flags': flags, 'registered_test_names': names,
            'test_timeouts_seconds': timeouts}


def main():
    repo, evidence = ROOT / 'feature', ROOT / 'evidence'
    output = repo / 'docs/reports/r2-4-results.json'
    assert not output.exists(), 'refusing to replace frozen results'
    plan_bytes = (evidence / 'final-validation-plan.json').read_bytes()
    plan = json.loads(plan_bytes)
    assert plan['schema_version'] == 1 and len(plan['gates']) == 5 and len(plan['builds']) == 4
    assert plan['source']['manifest_sha256'] == MANIFEST_SHA256
    frozen = json.loads((evidence / plan['source']['record']).read_bytes())
    source = frozen['inputs']
    assert len(source) == frozen['count'] == plan['source']['count'] == 312
    assert digest((evidence / plan['source']['manifest']).read_bytes()) == frozen['manifest_sha256'] == MANIFEST_SHA256
    assert all(digest((repo / path).read_bytes()) == value for path, value in source.items())
    result = {'schema_version': 2, 'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'baseline': plan['baseline'], 'branch': plan['branch'],
              'scope': 'Offline disposable tests only; no provider/paid/production calls.',
              'plan_sha256': digest(plan_bytes), 'input_manifest': {key: frozen[key] for key in ('at', 'count', 'manifest_sha256')},
              'gate_counting': plan['gate_counting'], 'gates': {}, 'builds': {},
              'binary_identities': {}, 'configuration_evidence': {}, 'configuration_details': {},
              'auxiliary_records': {}, 'superseded_or_diagnostic_runs': {}}
    for section in ('gates', 'builds'):
        for name, spec in plan[section].items():
            path = evidence / (name + '.json')
            raw = path.read_bytes() if path.exists() else None
            record = json.loads(raw) if raw is not None else None
            log_path = path.with_suffix('.log')
            log = log_path.read_bytes() if log_path.exists() else None
            row = validate_record(record, spec, source, log)
            row['record_sha256'] = digest(raw) if raw is not None else None
            result[section][name] = row
            if section == 'gates' and record is not None:
                result['binary_identities'][name] = {'before': record['binaries_before'], 'after': record.get('binaries_after')}
    for directory in sorted({spec['build_dir'] for spec in plan['builds'].values()}):
        files = {}
        for name in ('CMakeCache.txt', 'CTestTestfile.cmake', 'build.ninja'):
            data = (repo / directory / name).read_bytes()
            files[name] = {'sha256': digest(data), 'bytes': len(data), 'text': data.decode()}
        details = configuration_details(directory, files)
        result['configuration_evidence'][directory] = files
        result['configuration_details'][directory] = details
        for name, spec in plan['gates'].items():
            if spec['build_dir'] != directory:
                continue
            assert all(details['test_timeouts_seconds'][test] == seconds for test, seconds in spec['test_timeouts_seconds'].items())
            assert set(spec['registered_test_names']) <= set(details['registered_test_names'])
            identities = result['binary_identities'].get(name)
            if identities:
                for phase in ('before', 'after'):
                    if identities[phase] is not None:
                        assert all(identities[phase][file]['sha256'] == value['sha256'] for file, value in files.items())
    snapshots = {frozen['manifest_sha256']: source}
    result['prior_input_manifests'] = []
    for filename in plan['prior_source_records']:
        prior = json.loads((evidence / filename).read_bytes())
        snapshots[prior['manifest_sha256']] = prior['inputs']
        result['prior_input_manifests'].append({'record': filename, 'manifest_sha256': prior['manifest_sha256']})
    for name in plan['historical_runs']:
        raw = (evidence / (name + '.json')).read_bytes()
        record = json.loads(raw)
        log = (evidence / (name + '.log')).read_bytes()
        if is_finished(record):
            assert digest(log) == record['log_sha256']
        row = {key: record.get(key) for key in METADATA}
        row.update(record_sha256=digest(raw), source_snapshot=next((key for key, value in snapshots.items()
                   if record.get('before') == record.get('after') == value), None),
                   scope_note='Historical or diagnostic execution; never substitutes for a v3 gate.')
        if record['command'][0] == 'ctest':
            row['ctest'] = ctest_observation(log)
        result['superseded_or_diagnostic_runs'][name] = row
    for label, filename in plan['auxiliary_records'].items():
        path = evidence / filename
        if not path.exists():
            result['auxiliary_records'][label] = {'status': 'NOT_RUN', 'record': filename}
            continue
        raw = path.read_bytes()
        record = json.loads(raw)
        if label == 'protected_files':
            assert record['baseline'] == plan['baseline']
            assert set(record['groups']) == {'db/', 'third_party/', 'docs/handoff/', 'docs/reports/'}
            assert all(not group['mismatches'] for group in record['groups'].values())
            assert len(record['records']) == 323 and all(item['identical'] for item in record['records'])
        elif label == 'generated_install_assets':
            assert len(record['files']) == 12
            for name, identity in record['files'].items():
                path = repo / name
                assert stat.S_ISREG(path.lstat().st_mode)
                assert digest(path.read_bytes()) == identity['sha256'] and path.stat().st_size == identity['bytes']
                assert oct(stat.S_IMODE(path.stat().st_mode)) == identity['mode']
        result['auxiliary_records'][label] = {'status': 'VERIFIED', 'record': filename,
                                            'sha256': digest(raw), 'data': record}
    result['evidence_integrity_verified'] = True
    result['local_validation_complete'] = (
        all(row['status'] == 'PASSED' for section in ('gates', 'builds') for row in result[section].values()) and
        all(row['status'] == 'VERIFIED' for row in result['auxiliary_records'].values()))
    result['publication_note'] = ('A failed/incomplete gate keeps LOCAL_VALIDATION_COMPLETE false and blocks publication. '
        'This summary does not establish a commit, remote ref, Actions success or source-snapshot verification.')
    with output.open('x') as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'local_validation_complete': result['local_validation_complete'],
                      'gate_statuses': {name: row['status'] for name, row in result['gates'].items()},
                      'results_sha256': digest(output.read_bytes())}, indent=2))
    # The failure report is durable before returning a nonzero validation outcome.
    return 0 if result['local_validation_complete'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
