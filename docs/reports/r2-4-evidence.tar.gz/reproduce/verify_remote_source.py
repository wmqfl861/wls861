"""Read and compare an exact-SHA Actions source artifact; execute no artifact code."""
import datetime
import gzip
import hashlib
import io
import json
import pathlib
import re
import subprocess
import sys
import zipfile

root = pathlib.Path(__file__).resolve().parent
repo = root / 'feature'
repository = 'wmqfl861/wls861'
run_id, commit = sys.argv[1:]
assert run_id.isdigit() and re.fullmatch(r'[0-9a-f]{40}', commit)
record_path = root / 'evidence' / ('github-source-' + commit + '.json')
assert not record_path.exists(), 'refusing to replace a source verification record'

def capture(args):
    return subprocess.check_output(args, cwd=repo, stdin=subprocess.DEVNULL)

def api(path):
    return json.loads(capture(['gh', 'api', 'repos/' + repository + path]))

run = api('/actions/runs/' + run_id)
assert run['head_sha'] == commit
assert run['status'] == 'completed' and run['conclusion'] == 'success'
assert run['path'] == '.github/workflows/source-snapshot.yml'
artifacts = api('/actions/runs/' + run_id + '/artifacts')
matches = [a for a in artifacts['artifacts'] if a['name'] == 'source-' + commit]
assert len(matches) == 1 and not matches[0]['expired']
artifact = matches[0]
archive_bytes = capture(['gh', 'api', 'repos/' + repository + '/actions/artifacts/' + str(artifact['id']) + '/zip'])
artifact_digest = 'sha256:' + hashlib.sha256(archive_bytes).hexdigest()
if artifact.get('digest'):
    assert artifact['digest'] == artifact_digest
with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
    expected = {'COMMIT', 'TREE', 'SHA256SUMS', 'source.tar.gz'}
    assert set(archive.namelist()) == expected and len(archive.namelist()) == 4
    assert sum(info.file_size for info in archive.infolist()) < 100 * 1024 * 1024
    files = {name: archive.read(name) for name in expected}
tree = capture(['git', '--no-replace-objects', 'rev-parse', commit + '^{tree}']).strip().decode()
assert files['COMMIT'] == (commit + '\n').encode()
assert files['TREE'] == (tree + '\n').encode()
source_digest = hashlib.sha256(files['source.tar.gz']).hexdigest()
assert files['SHA256SUMS'] == (source_digest + '  source.tar.gz\n').encode()
local_tar = capture(['git', '--no-replace-objects', 'archive', '--format=tar', commit])
remote_tar = gzip.decompress(files['source.tar.gz'])
assert remote_tar == local_tar, 'remote source tar differs from the local commit archive'
frozen = json.loads((root / 'evidence/source-final-v3.json').read_text())
for path, expected_hash in frozen['inputs'].items():
    data = capture(['git', '--no-replace-objects', 'show', commit + ':' + path])
    assert hashlib.sha256(data).hexdigest() == expected_hash, path
result = {
    'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repository': repository,
    'commit': commit,
    'tree': tree,
    'workflow_run': {'id': run['id'], 'url': run['html_url'], 'status': run['status'], 'conclusion': run['conclusion']},
    'artifact': {'id': artifact['id'], 'name': artifact['name'], 'digest': artifact_digest},
    'source_tar_gz_sha256': source_digest,
    'source_tar_sha256': hashlib.sha256(remote_tar).hexdigest(),
    'local_git_archive_identical': True,
    'frozen_input_count': len(frozen['inputs']),
    'frozen_input_manifest_sha256': frozen['manifest_sha256'],
    'frozen_inputs_match_commit': True,
    'note': 'Only artifact metadata and bytes were read; no archived program was extracted or executed.',
}
record_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
