"""Record final generated installation assets without implying earlier snapshots."""
import datetime
import hashlib
import json
import pathlib
import stat

root = pathlib.Path(__file__).resolve().parent
evidence = root / 'evidence'
output = evidence / 'generated-install-assets-session-final.json'
assert not output.exists()
record = {
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Final supplemental identities of generated installation assets. These files were not in the original runner binary before/after collection; this record makes no retrospective before/after claim.',
    'files': {},
}
for label, directory in [('release', 'build-release'), ('clang', 'build-clang'), ('asan', 'build-asan-clang-opt'), ('ubsan', 'build-ubsan-clang-opt')]:
    build = json.loads((evidence / ('feature-build-' + label + '-session-final.json')).read_text())
    assert build['exit_code'] == 0 and build['inputs_unchanged']
    assert build['before'] == build['after'] == json.loads((evidence / 'source-final-v3.json').read_text())['inputs']
    for name in ['wls-runtime-manifest.json', 'install_wls_runtime_resources.cmake', 'cmake_install.cmake']:
        path = root / 'feature' / directory / name
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode)
        data = path.read_bytes()
        if name.endswith('.json'):
            json.loads(data)
        record['files'][directory + '/' + name] = {
            'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': oct(stat.S_IMODE(info.st_mode)),
        }
output.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print({'generated_asset_count': len(record['files']), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest()})
