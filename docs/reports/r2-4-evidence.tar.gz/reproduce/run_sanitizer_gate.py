"""Run only the fixed v3 sanitizer command; the outer runner sets process policy."""
import json
import os
import pathlib
import sys

root = pathlib.Path(__file__).resolve().parent
name, build = sys.argv[1:]
plan = json.loads((root / 'evidence/final-validation-plan.json').read_text())
assert name in ('feature-asan-session-final', 'feature-ubsan-session-final')
spec = plan['gates'][name]
assert spec['build_dir'] == build and spec['sanitizer'] in ('address', 'undefined')
scope = json.loads((root / 'evidence/sanitizer-focused-scope.json').read_text())
assert spec['registered_count'] == scope['registered_count'] == 31
assert spec['registered_test_names'] == scope['registered_test_names']
assert spec['command'] == ['ctest', '--test-dir', build, '--output-on-failure',
                           '--parallel', '1', '-R', scope['regex']]
assert os.getuid() == spec['uid'] and os.getgid() == spec['gid']
assert sorted(os.sched_getaffinity(0)) == spec['cpu_affinity']
mask = os.umask(0)
os.umask(mask)
assert format(mask, '04o') == spec['umask']
for key, expected in spec['environment'].items():
    assert os.environ.get(key) == expected, key
os.execv(sys.executable, [sys.executable, str(root / 'run_validation.py'),
                         name, spec['cwd'], *spec['command']])
