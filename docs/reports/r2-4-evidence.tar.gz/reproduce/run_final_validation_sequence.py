"""Run the fixed final gates; failed tests remain failed and do not skip later gates."""
import concurrent.futures
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import threading

root = pathlib.Path(__file__).resolve().parent
evidence = root / 'evidence'
plan_path = evidence / 'final-validation-plan.json'
plan = json.loads(plan_path.read_text())
frozen = json.loads((evidence / plan['source']['record']).read_text())
output = evidence / 'final-validation-sequence.json'
assert not output.exists(), 'refusing to replace a prior sequence'
for name in plan['gates']:
    assert not (evidence / (name + '.json')).exists(), name
for name in plan['builds']:
    build = json.loads((evidence / (name + '.json')).read_text())
    assert build['exit_code'] == 0 and build['inputs_unchanged'], name
    assert build['before'] == build['after'] == frozen['inputs'], name
record = {'record_kind': 'validation_sequence',
          'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'uid': os.getuid(), 'plan_sha256': hashlib.sha256(plan_path.read_bytes()).hexdigest(),
          'gates': {}}
lock = threading.Lock()

def save():
    output.write_text(json.dumps(record, indent=2) + '\n')

def run_gate(name):
    gate = plan['gates'][name]
    args = ['sudo', '-n', 'unshare', '--mount', '--propagation', 'private', '--fork',
            str(root / 'run_in_test_tmpfs.sh'), '/usr/bin/python3',
            str(root / 'run_fixed_gate.py'), name]
    observer = None
    if gate['sanitizer']:
        observer = subprocess.Popen([sys.executable, str(root / 'monitor_sanitizer_gate.py'),
                                     name, gate['build_dir']], cwd=root)
    with lock:
        record['gates'][name] = {'wrapper_argv': args,
                                'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        save()
    print('START ' + name, flush=True)
    completed = subprocess.run(args, cwd=root)
    entry = {'wrapper_exit_code': completed.returncode,
             'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    detail = root / 'feature' / gate['build_dir'] / 'Testing/Temporary/LastTest.log'
    meta = evidence / (name + '.json')
    if meta.exists() and 'finished_at' in json.loads(meta.read_text()):
        dest = evidence / (name + '-detail.log')
        assert not dest.exists()
        shutil.copyfile(detail, dest)
        entry['detail_log_sha256'] = hashlib.sha256(dest.read_bytes()).hexdigest()
    if observer:
        try:
            entry['observer_exit_code'] = observer.wait(timeout=15)
        except subprocess.TimeoutExpired:
            # Stop only this auxiliary observer, never a test or CTest process.
            observer.terminate()
            entry['observer_exit_code'] = observer.wait(timeout=10)
            entry['observer_stop_reason'] = 'auxiliary observer failed to finish after test wrapper'
    with lock:
        record['gates'][name].update(entry)
        save()
    print('END ' + name + ' exit=' + str(completed.returncode), flush=True)
    return completed.returncode

save()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(run_gate, name) for name in
               ['feature-release-0022-session-final', 'feature-clang-session-final']]
    outcomes = [future.result() for future in futures]
for name in ['feature-release-0002-session-final', 'feature-asan-session-final',
             'feature-ubsan-session-final']:
    outcomes.append(run_gate(name))
record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record['all_wrappers_succeeded'] = all(rc == 0 for rc in outcomes)
save()
raise SystemExit(0 if record['all_wrappers_succeeded'] else 1)
