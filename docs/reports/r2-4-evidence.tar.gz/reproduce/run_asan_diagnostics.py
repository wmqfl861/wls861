"""Run three original failing methods serially after all frozen gates end."""
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
repo = root / 'feature'
evidence = root / 'evidence'
cases = {
    'live-workflow': ('feature-asan-live-workflow-single-diagnostic', 300,
                      [str(root / 'diagnose_live_workflow_case.py')]),
    'billing-amend': ('feature-asan-billing-amend-diagnostic', 900,
                     [str(root / 'diagnose_billing_cases.py'),
                      str(repo / 'build-asan-clang-opt/wls'), str(repo), '--case', 'amend']),
    'billing-exhausted': ('feature-asan-billing-exhausted-diagnostic', 900,
                         [str(root / 'diagnose_billing_cases.py'),
                          str(repo / 'build-asan-clang-opt/wls'), str(repo), '--case', 'exhausted']),
}

if len(sys.argv) == 3 and sys.argv[1] == '--inner':
    name, limit, args = cases[sys.argv[2]]
    assert os.getuid() == os.geteuid() == 1000 and os.getgid() == 1000
    os.umask(0o002)
    os.sched_setaffinity(0, [0, 1, 2, 3])
    os.environ['TMPDIR'] = '/tmp'
    os.environ['ASAN_OPTIONS'] = 'halt_on_error=1:detect_leaks=1'
    os.environ.pop('UBSAN_OPTIONS', None)
    command = ['env', '--chdir=' + str(repo / 'build-asan-clang-opt'),
               'timeout', '--signal=TERM', '--kill-after=2s', str(limit) + 's',
               str(root / 'test-venv/bin/python'), '-u', *args]
    os.execv(sys.executable, [sys.executable, str(root / 'run_validation.py'),
                             name, str(repo), *command])

assert len(sys.argv) == 1
plan = json.loads((evidence / 'final-validation-plan.json').read_text())
source = json.loads((evidence / 'source-final-v3.json').read_text())['inputs']
for name in plan['gates']:
    gate = json.loads((evidence / (name + '.json')).read_text())
    assert isinstance(gate['exit_code'], int) and gate['finished_at']
    assert gate['before'] == gate['after'] == source and gate['binaries_unchanged']
for label in ('asan', 'ubsan'):
    observer = json.loads((evidence / ('feature-' + label + '-session-final-process-observation.json')).read_text())
    assert observer['completion']['stop_reason'] == 'gate_finished'
output = evidence / 'asan-diagnostic-sequence.json'
assert not output.exists()
identities = ['diagnose_live_workflow_case.py', 'diagnose_billing_cases.py',
              'feature/build-asan-clang-opt/wls', 'feature/build-asan-clang-opt/live_workflow_driver']
def hashes():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in identities}
record = {'record_kind': 'diagnostic_sequence',
          'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Original methods, both billing conditions, unchanged inner deadlines and assertions. '
                   'Each diagnostic retains the original containing suite outer deadline; does not replace full gates.',
          'before': hashes(), 'cases': {}}
def save():
    output.write_text(json.dumps(record, indent=2) + '\n')
save()
outcomes = []
for key, (name, limit, args) in cases.items():
    command = ['sudo', '-n', 'unshare', '--mount', '--propagation', 'private', '--fork',
               str(root / 'run_in_test_tmpfs.sh'), '/usr/bin/python3', str(pathlib.Path(__file__).resolve()),
               '--inner', key]
    print('START ' + name, flush=True)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    outcome = subprocess.run(command, cwd=root).returncode
    record['cases'][name] = {'wrapper_argv': command, 'started_at': started,
                            'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                            'wrapper_exit_code': outcome, 'outer_limit_seconds': limit}
    save()
    outcomes.append(outcome)
    print('END ' + name + ' exit=' + str(outcome), flush=True)
record.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), after=hashes())
record['diagnostic_inputs_unchanged'] = record['before'] == record['after']
assert record['diagnostic_inputs_unchanged']
save()
raise SystemExit(0 if all(code == 0 for code in outcomes) else 1)
