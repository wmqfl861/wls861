本次对 `976466720e5fb17f6dcc67b0660b74d246996426` 正式本机矩阵和实际归档的独立只读核对已完成，证据关系一致。**本机正式结果仍为 FAIL_OR_INCOMPLETE，三项超时未关闭。** 审核者 `/root/evidence_audit` 不是 T1/T2 修复作者，没有编译、执行产品、重跑测试或执行归档内容。

| 正式配置 | 外层 umask | 实际 CTest 执行/注册 | 通过 | 超时 | CTest 退出码 |
| --- | --- | --- | ---: | --- | ---: |
| GCC Release 全量 | 0022 | 92/92 | 92 | 无 | 0 |
| GCC Release 全量 | 0002 | 92/92 | 91 | owned_capacity，JUnit 90.7389 秒，原限90秒 | 8 |
| Clang 严格编译，相关套件 | 0002 | 2/92 | 2 | 无 | 0 |
| GCC Debug UBSan，相关套件 | 0002 | 2/92 | 1 | async_coordinator，JUnit 180.182 秒，原限180秒 | 8 |
| GCC Debug ASan/LSan，相关套件 | 0002 | 2/92 | 1 | async_coordinator，JUnit 180.587 秒，原限180秒 | 8 |

五轮合计 **190 次 CTest 套件执行：187 通过、3 超时、0 其他失败、0 skipped/notrun**。这是重复配置下的执行次数，产品目录仍为92项。三个定向配置各自其余90项本机未执行，不能合称全量 sanitizer/Clang 通过。所有正式轮次都正常形成完整退出记录，外层 recorder 没有超时；三项是 CTest 内部原期限超时。

Release 两轮与 Clang 的 Async 原始方法输出分别都是29/29，五轮 Scheduler 均9/9。UBSan、ASan 的 Async 原始方法输出为空，不能把其它配置的方法通过数搬到 sanitizer 配置，也不能从空缓冲输出推断停在哪个方法。ASan 的 leak detection 为 `halt_on_error=1:detect_leaks=1`，但进程被期限终止，不能声称 Async 获得完整的干净泄漏检查结论。

`check_completed_matrix.py` 是本审核的新只读核查程序，实际退出0（`check-completion.json`），没有导入或调用原采集器/打包器。它独立对照四配置13个 configure/build/CTest 完成步骤、5份完整JUnit、5份完整LastTest、原命令/UID/umask/退出码，重算计数并核总结果。785项源码SHA/字节数/mode、所有步骤的source-before/source-after、当前干净976工作树一致；四配置共82个构建/二进制身份记录（Release61，其余各7）前后及当前文件一致。完整92注册名称/期限、两库与两测试的编译参数以及sanitizer链接参数也核验。

原正式执行的PID、recorder PID和进程组在只读/proc快照时均无残留。快照同时出现随后启动的独立诊断编排器与UBSan资源探针编译/链接进程；`post-formal-process-classification.json` 用诊断启动时间、preflight和process.json将它们与正式任务区分。这个结论只覆盖该时点的原任务组/路径，不声称全机没有其它服务或此后不会启动任务。

实际 `review-final-package-01` 已独立逐成员核验：**301个regular UTF-8成员（299原文本+2生成清单/说明）、1,704,167字节归档**。tar成员名、大小、SHA、0644模式以及uid/gid/mtime均匹配索引；299个原文本逐字匹配现保留文件。内部MEMBERS、外部index、SHA256SUMS及最终COMPLETE receipt相互一致，归档内容未执行或extract到文件系统。原preflight与assembly执行回执均exit0。

- archive SHA-256：`bd0363668d724649233ce14d9a5abd33a74dfca7026c1ee4d2881a9201198240`
- index SHA-256：`95c8f21b6122e8b95bf954366f28878c94163bcf2054a8e3bd25b6c38a84ca5d`

候选02 assembler确实选入新完成ASan的configure/build/CTest原命令、原退出码8、完整JUnit、LastTest及源码/二进制清单。包内矩阵和index均保存当前三项非通过，`historical_failures_closed=false`、`local_validation_complete_promoted=false`；没有遗漏这三项正式结果。历史原反例及夹具失败的480成员旧包SHA仍是 `c1431a300cc77537ef86e782d8ea91e945aa853e724f2175b11f09470daa6614`，已核它仍包含原失败轮次。旧原始证据由该旧包与保留路径承载，不能声称新301成员包独自包含全部历史原日志；交付时应保留两包及各自索引。

最小补证采用**单独的小文本包**，不改原301成员包。范围限定为定向诊断execution（完成后）、其preparation、本次final audit、local-matrix-verification、final-package-execution及prepublication-inputs六个目录；精确选项和排除项见 `supplement-selection-plan.json`。待诊断完成后再冻结原命令/退出/日志、前后源码/库身份、探针二进制哈希及进程收尾记录，排除tmp、二进制、DB、秘密和链接。诊断属于DIAGNOSTIC_NOT_FULL_GATE，无论结果如何都不能覆盖上述三个正式超时。当前核查不构成协调Agent的正式验收或合并批准。
