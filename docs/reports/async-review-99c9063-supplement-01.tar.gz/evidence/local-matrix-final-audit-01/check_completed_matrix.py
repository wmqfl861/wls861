"""Read retained evidence, Git metadata and procfs; no product/tool/archived-code execution."""
from pathlib import Path, PurePosixPath
import datetime, hashlib, json, os, re, shlex, subprocess, tarfile
import xml.etree.ElementTree as ET

ROOT=Path('/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649')
TREE=ROOT/'combined'; E=ROOT/'evidence'; OUT=E/'local-matrix-final-audit-01'
HEAD='976466720e5fb17f6dcc67b0660b74d246996426'
inputs={}
def digest(data): return hashlib.sha256(data).hexdigest()
def read_raw(path):
    path=Path(path)
    if not path.is_absolute(): path=ROOT/path
    data=path.read_bytes(); inputs[str(path)]={'bytes':len(data),'sha256':digest(data)}
    return data
def read(path):return json.loads(read_raw(path))
def sha_file(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git','-C',str(TREE),*args])

matrix=read(E/'local-final-matrix.json')
assert matrix['product_commit']==HEAD and matrix['observed_selected_result']=='FAIL_OR_INCOMPLETE'
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('status','--porcelain')==b''
frozen=read(E/matrix['source_manifest'])
assert len(frozen)==785 and digest(read_raw(E/matrix['source_manifest']))==matrix['source_manifest_sha256']
assert set(git('ls-files','-z').decode().rstrip('\0').split('\0'))==set(frozen)
for name,record in frozen.items():
    data=read_raw(TREE/name)
    assert len(data)==record['bytes'] and digest(data)==record['sha256']
    assert (TREE/name).stat().st_mode&0o777==record['mode']
catalog_raw=read(TREE/'tests/gcc_asan_expected_tests.json')['tests']
catalog={row['name']:row['timeout'] for row in catalog_raw}
assert len(catalog_raw)==len(catalog)==92
expected_configs={'release':['0022','0002'],'clang':['0002'],'ubsan':['0002'],'asan-affected':['0002']}
assert set(matrix['configurations'])==set(expected_configs)
rows=[]; build_checks={}; recorded_processes=[]; step_count=0
for config,masks in expected_configs.items():
    prefix='final-'+config+'-01'; directory=E/prefix; build=TREE/('build-review-'+config)
    summary=read(directory/'result.json'); recorded_steps=read(directory/'steps.json')
    assert summary['configuration']==config and summary['head']==HEAD and summary['binary_identity_unchanged']
    assert summary['steps']==recorded_steps==matrix['configurations'][config]['steps']
    names=['configure','build']+['ctest-'+mask for mask in masks]
    assert [v['name'] for v in recorded_steps]==names
    for step in recorded_steps:
        step_count+=1
        assert step['round']==prefix+'-'+step['name']
        r=E/step['round']; completion=read(r/'completion.json'); command=read(r/'command.json')
        assert completion['head']==command['head']==HEAD and command['uid']==1000
        assert command['argv']==completion['argv'] and command['cwd']==str(TREE)
        assert command['started_at_utc']==completion['started_at_utc'] and completion['finished_at_utc']>=completion['started_at_utc']
        assert completion['source_unchanged'] and completion['source_count']==785
        assert read(r/'source-before.json')==read(r/'source-after.json')==frozen
        assert step['exit']==(124 if completion['outer_timeout'] else completion['exit_code'])
        assert completion['outer_timeout'] is False
        process=read(r/'process.json'); assert process['pid']==completion['pid']
        recorded_processes.append({'round':step['round'],**process})
    before=read(directory/'binaries-before.json'); after=read(directory/'binaries-after.json')
    assert before==after and len(after)==matrix['configurations'][config]['binary_records']
    required={'CMakeCache.txt','CTestTestfile.cmake','compile_commands.json','async_coordinator_tests','scheduler_tests','libwls_s1.a','libwls_kernel.a'}
    actual={p.name for p in build.iterdir() if p.is_file() and (os.access(p,os.X_OK) or p.suffix=='.a' or p.name in required)}
    assert required<=set(after) and actual==set(after)
    for name,sha in after.items():assert sha_file(build/name)==sha,(config,name)
    plan=read(directory/'test-plan.json')['tests']
    assert len(plan)==92 and len({t['name'] for t in plan})==92
    for test in plan:
        props={p['name']:p['value'] for p in test['properties']}
        assert not props.get('DISABLED',False) and props['TIMEOUT']==catalog[test['name']]
    sanitizer={'ubsan':'-fsanitize=undefined','asan-affected':'-fsanitize=address'}.get(config)
    compiler='/usr/bin/clang++-18' if config=='clang' else '/usr/bin/g++-13'
    compile_entries=read(build/'compile_commands.json'); compile_counts={}
    for target in ['wls_s1','wls_kernel','async_coordinator_tests','scheduler_tests']:
        chosen=[c for c in compile_entries if 'CMakeFiles/'+target+'.dir/' in c['command']]
        assert chosen
        for entry in chosen:
            args=shlex.split(entry['command'])
            assert args[0]==compiler and '-Werror' in args
            if sanitizer: assert sanitizer in args and '-g' in args
        compile_counts[target]=len(chosen)
    for target in ['async_coordinator_tests','scheduler_tests']:
        args=shlex.split(read_raw(build/'CMakeFiles'/(target+'.dir')/'link.txt').decode())
        if sanitizer: assert sanitizer in args
    build_checks[config]={'binary_record_count':len(after),'all_current_hashes_match_before_after':True,
                         'compile_entries':compile_counts,'sanitizer':sanitizer}
    for mask in masks:
        run=next(v for v in matrix['configurations'][config]['runs'] if v['umask']==mask)
        r=E/(prefix+'-ctest-'+mask); completion=read(r/'completion.json'); command=read(r/'command.json')
        assert completion==run['completion'] and command==run['command'] and command['umask']==mask
        junit_path=directory/('junit-'+mask+'.xml'); junit_raw=read_raw(junit_path); junit=ET.fromstring(junit_raw)
        assert digest(junit_raw)==run['junit_sha256']
        cases=list(junit.iter('testcase')); expected=set(catalog) if config=='release' else {'scheduler','async_coordinator'}
        assert len(cases)==len(expected) and {c.attrib['name'] for c in cases}==expected
        timeouts=[c.attrib['name'] for c in cases if c.find('failure') is not None and c.find('failure').attrib.get('message')=='Timeout']
        failed_all=[c.attrib['name'] for c in cases if c.find('failure') is not None or c.find('error') is not None]
        skipped=[c.attrib['name'] for c in cases if c.find('skipped') is not None or c.attrib.get('status') in ('notrun','disabled')]
        assert skipped==[]
        assert int(junit.attrib['tests'])==len(cases) and int(junit.attrib['failures'])==len(failed_all)
        assert int(junit.attrib['skipped'])==0 and int(junit.attrib['disabled'])==0
        assert timeouts==failed_all==run['timeout_names'] and run['failed_names']==[]
        assert run['passed']==len(cases)-len(failed_all) and run['executed']==len(cases)
        assert completion['exit_code']==(8 if failed_all else 0)
        log_raw=read_raw(directory/('ctest-'+mask+'-original-logs')/'LastTest.log')
        assert digest(log_raw)==run['lasttest_sha256']
        log=log_raw.decode(); assert re.search(r'^End testing:',log,re.M)
        matches=list(re.finditer(r'^\d+/92 Testing: (\S+)\n',log,re.M))
        assert [m.group(1) for m in matches]==[c.attrib['name'] for c in cases]
        method_summaries={}; failure_times={}
        for index,(match,case) in enumerate(zip(matches,cases)):
            name=case.attrib['name']; end=matches[index+1].start() if index+1<len(matches) else len(log)
            section=log[match.start():end]
            assert ('Test Failed.' if name in failed_all else 'Test Passed.') in section
            output=section.split('Output:\n----------------------------------------------------------\n',1)[1].split('<end of output>',1)[0]
            results=re.findall(r'^RESULT (\d+) passed, (\d+) failed$',output,re.M)
            if name in ('async_coordinator','scheduler','owned_capacity'):
                method_summaries[name]={'junit_seconds':case.attrib['time'],'raw_output_bytes':len(output.encode()),'results':results}
            if name in failed_all:
                failure_times[name]=case.attrib['time']; assert output==''
        assert method_summaries['scheduler']['results']==[('9','0')]
        if config in ('release','clang'): assert method_summaries['async_coordinator']['results']==[('29','0')]
        if config=='asan-affected': assert command['environment']['ASAN_OPTIONS']=='halt_on_error=1:detect_leaks=1'
        if config=='ubsan': assert command['environment']['UBSAN_OPTIONS']=='halt_on_error=1:print_stacktrace=1'
        rows.append({'configuration':config,'umask':mask,'registered':92,'selected':len(cases),'executed':len(cases),
            'passed':len(cases)-len(failed_all),'timeout_names':timeouts,'non_timeout_failures':[],
            'skipped':0,'outside_selection_notrun':92-len(cases),'ctest_exit':completion['exit_code'],
            'outer_timeout':completion['outer_timeout'],'collector_seconds':completion['seconds'],
            'failure_junit_seconds':failure_times,'method_summaries':method_summaries})

# Observe completed groups and current task paths. Exclude only this auditor's own process ancestry.
ancestors=set(); pid=os.getpid()
while pid and pid not in ancestors:
    ancestors.add(pid)
    try: pid=int(Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[1])
    except OSError: break
known_ids={int(p[k]) for p in recorded_processes for k in ('pid','pgid','recorder_pid')}
known_groups={int(p['pgid']) for p in recorded_processes}
live_ids=[p for p in sorted(known_ids) if Path(f'/proc/{p}').exists()]
related=[]; group_members=[]; vanished=0; inaccessible=0
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name) in ancestors: continue
    try:
        fields=(proc/'stat').read_text().rsplit(')',1)[1].split(); group=int(fields[2])
        if group in known_groups: group_members.append({'pid':int(proc.name),'pgid':group,'state':fields[0]})
        try: cwd=os.readlink(proc/'cwd'); exe=os.readlink(proc/'exe')
        except PermissionError: inaccessible+=1;continue
        if str(ROOT) in cwd or str(ROOT) in exe:
            related.append({'pid':int(proc.name),'comm':(proc/'comm').read_text().strip(),'pgid':group,'cwd':cwd,'exe':exe})
    except (FileNotFoundError,ProcessLookupError):vanished+=1
    except PermissionError:inaccessible+=1
write('post-formal-process-snapshot.json',{'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'original_recorded_processes':recorded_processes,'original_pid_recorder_pid_still_present':live_ids,
    'members_of_original_recorded_process_groups':group_members,'other_processes_with_task_cwd_or_exe':related,
    'excluded_auditor_ancestor_pids':sorted(ancestors),'unreadable_other_process_metadata_count':inaccessible,
    'processes_vanished_during_scan':vanished,
    'claim_scope':'Point-in-time procfs check for these ordinary-user task groups/paths, not proof about unrelated privileged services or future launches.'})
assert live_ids==[] and group_members==[]

package=E/'review-final-package-01'; index=read(package/'index.json'); receipt=read(package/'receipt.json')
archive=package/'wls861-review-final-evidence-01.tar.gz'; archive_sha=sha_file(archive)
assert archive_sha==receipt['archive_sha256']=='bd0363668d724649233ce14d9a5abd33a74dfca7026c1ee4d2881a9201198240'
assert digest(read_raw(package/'index.json'))==receipt['index_sha256']=='95c8f21b6122e8b95bf954366f28878c94163bcf2054a8e3bd25b6c38a84ca5d'
assert receipt['status']=='COMPLETE' and receipt['collector_observed_selected_result']=='FAIL_OR_INCOMPLETE'
assert index['member_count']==receipt['members']==len(index['members'])==301
assert index['historical_failures_closed'] is False and index['local_validation_complete_promoted'] is False
for line in read_raw(package/'SHA256SUMS').decode().splitlines():
    sha,name=line.split('  ',1);assert sha_file(package/name)==sha
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers(); assert len(members)==301 and len({m.name for m in members})==301
    assert {m.name for m in members}==set(index['members'])
    for member in members:
        assert member.isfile() and member.mode==0o644 and member.uid==member.gid==member.mtime==0
        assert not member.name.startswith('/') and '..' not in PurePosixPath(member.name).parts
        data=tar.extractfile(member).read();data.decode('utf-8',errors='strict')
        expected=index['members'][member.name]
        assert len(data)==expected['size'] and digest(data)==expected['sha256']
        if expected['source'] is not None: assert data==read_raw(Path(expected['source']))
        if member.name=='MEMBERS.json': internal=json.loads(data)
    assert set(internal['members'])==set(index['members'])-{'MEMBERS.json'}
    for name,value in internal['members'].items():assert value==index['members'][name]
for row,archived in zip(rows,index['actual_local_runs']):
    assert row['configuration']==archived['configuration'] and row['umask']==archived['umask']
    assert row['ctest_exit']==archived['exit_code']
    assert row['passed']==archived['collector_reported_counts']['passed']
    assert row['timeout_names']==archived['collector_reported_counts']['timeout_names']
for name in ['preflight','assembly']:
    assert read(E/'final-package-execution-01'/(name+'.json'))['exit']==0
    assert read_raw(E/'final-package-execution-01'/(name+'.stderr'))==b''
collector=read(E/'local-matrix-verification-01/completion.json');assert collector['collector_exit']==0 and collector['product_tests_launched']==0
assert collector['script_sha256']==digest(read_raw(ROOT/'verify_local_final.py'))
original_archive=E/'review-package-01/wls861-review-evidence-01.tar.gz'
assert sha_file(original_archive)=='c1431a300cc77537ef86e782d8ea91e945aa853e724f2175b11f09470daa6614'
prior_index=read(E/'review-package-01/index.json')
prior_names=set(prior_index['members'])
required_prior=['evidence/amend-candidate-suites-01/stdout.log','evidence/amend-candidate-suites-01/completion.json',
    'evidence/original-baseline-amend-01/stdout.log','evidence/original-baseline-cycle-01/stdout.log',
    'evidence/amend-red-run-01/stdout.log','evidence/resource-red-run-01/stdout.log']
assert all(p in prior_names for p in required_prior)
assert len(prior_names)==480
write('matrix-and-package-verification.json',{'status':'READ_ONLY_EVIDENCE_VERIFIED','target':HEAD,
    'source_inputs':785,'recorded_steps_checked':step_count,'configuration_binary_checks':build_checks,'rows':rows,
    'totals':{'ctest_suite_invocations':sum(r['executed'] for r in rows),'passed':sum(r['passed'] for r in rows),
              'timeouts':sum(len(r['timeout_names']) for r in rows),'non_timeout_failures':0,'skipped':0,
              'unique_product_registrations':92,'not_distinct_suites':'Repeated configurations are invocations, not independent product suites.'},
    'formal_overall_result':'FAIL_OR_INCOMPLETE','all_formal_process_groups_ended':True,
    'current_task_path_processes':related,
    'package':{'archive_sha256':archive_sha,'members_verified':301,'original_source_text_members':299,
               'all_member_bytes_match_index_and_retained_sources':True,'three_timeout_rounds_preserved':True,
               'assembler_executed_by_auditor':False,'tar_members_extracted_to_filesystem':False,
               'prior_480_member_package_unchanged_and_contains_original_failed_rounds':True},
    'suggested_separate_supplement':['evidence/local-matrix-final-audit-01','evidence/local-matrix-verification-01',
        'evidence/final-package-execution-01','completed-only diagnostic commands/exits/logs/input+binary identities'],
    'supplement_must_not_replace_failed_formal_runs':True})
write('input-identities.json',{'files':inputs,'package_archive_sha256':archive_sha})
print(json.dumps({'rows':[{k:v for k,v in r.items() if k!='method_summaries'} for r in rows],
                  'steps_checked':step_count,'binary_record_count':sum(v['binary_record_count'] for v in build_checks.values()),
                  'source_count':785,'archive_members':301,'original_process_ids_remaining':live_ids,
                  'original_process_groups_remaining':group_members,'current_task_path_processes':related},indent=2))
