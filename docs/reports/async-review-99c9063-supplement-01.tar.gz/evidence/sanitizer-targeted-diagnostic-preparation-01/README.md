# Sanitizer 定向诊断准备（未编译、未运行）

本目录分类为 **DIAGNOSTIC_NOT_FULL_GATE**。只准备后续命令和冻结输入证明；编译次数为 0，产品/探针执行次数为 0。是否执行由父代理在当前 ASan 构建和选定 CTest 链完全结束后决定。本材料由 R-A4 实现作者准备，**不构成 R-A4 独立代码复核**。

准备时产品输入是干净的 `976466720e5fb17f6dcc67b0660b74d246996426`，分支 `fix/async-review-99c9063-20261031`。785 项 tracked 源码的字节、模式和 SHA-256 已冻结在 `combined-source-preparation.json`。本次只写本目录；未修改 combined、冻结探针、构建设置或已有证据。

## 已有 UBSan 证据

`final-ubsan-01` 已完成配置、构建及两个注册测试的选定执行。Scheduler 9 方法通过，JUnit 用时 0.0651483 秒；Async 仍在原 180 秒期限内 Timeout，JUnit 实际 180.182 秒。整个 CTest invocation 用时 181.46409428608604 秒、exit 8、outer_timeout=false；source_unchanged=true、source_count=785。其余 90 个 CTest 注册在这一本地 UBSan 配置下 NOT_RUN。

完整 LastTest 的 Async Output 段为空，JUnit system-out 也是 0 字节，**没有可定位的已刷新方法名**。不能据此判断停在哪一方法，也不能声称该轮已经运行过两个目标 P1。原日志、JUnit、退出回执和 build identity before/after 均已原字节复制到 references；来源路径和摘要见 `reference-index.json`。本次没有新增 flush、使用 stdbuf、修改缓冲或重新运行 Async。

## 冻结探针及既有 red/green

`frozen-probe-inputs.json` 验证了现有五个源码输入与历史冻结 SHA 一致。后续命令直接编译原 `evidence/frozen-local-repros/` 路径，未复制后修改、裁剪方法体、另造断言、扩大 5 秒夹具屏障或改为伪造 Store 条件。

| 探针 | 同一 binary 中实际执行的方法 | 已有基线 red | 已有 Release green |
|---|---|---|---|
| AMEND | queued current Dispatcher、inflight current Dispatcher 两方法一起 | 99c9063，exit 1，0 pass/2 fail，0.711347 秒 | 065503e，exit 0，2 pass，0.720005 秒 |
| resource | cross-pool resource heads progress before slot admission 单方法 | 99c9063，exit 1，结构性 cycle=1，new_model_calls=0，1.218893 秒 | a018d72，exit 0，cycle=0、new_model_calls=4、accepted=4、FIFO preserved，1.244749 秒 |

上述是之前已经存在的结果，本次没有重跑。两项旧版 red 均非 timeout。合法资源探针使用真实 Store/FakeModel 业务过程，检查四次调用的请求 envelope、响应 binding、accepted/settlement、tool_feedback、claim/ops 数量和资源 FIFO。它并非原外部附件中的 Error 响应探针；原附件未提供/未执行的范围仍保留在历史回执。AMEND 两方法也检查真实 Store 结果及旧取消回放对当前 Dispatcher 的副作用。

## 后续命令与计数

精确 structured argv 在 `command-plan.json`，等价 shell 展示在 `commands.md`。所有计划目前是 NOT_RUN。严格顺序为 UBSan AMEND、UBSan resource、ASan AMEND、ASan resource；每项编译一次，编译成功后执行一次。不得同时编译或执行产品，不得重复失败探针选取绿色结果。

每配置是 **两个定向诊断 binary，合计三个方法**；跨配置最多四次诊断执行、六次方法执行。这既不是完整 Async，也不是六个独立测试套件，更不是 92 注册的完整 sanitizer 门禁。AMEND 的两个方法不拆开重复运行。

编译使用各自 async_coordinator_tests 已生成的 Debug 编译/链接设置：g++-13、-g、C++20、五项严格警告与 -Werror、相应 sanitizer 和 frame-pointer；UBSan 保留 -fno-sanitize-recover=undefined。没有 Release 的 -O3/-DNDEBUG，没有新增 -pthread；当前两配置生成链接命令本身没有 -pthread。原生成命令和匹配 compile_commands entry 已冻结在 `build-metadata-at-preparation.json` 及 references。

两个配置均使用 combined 的真实 headers、test_support、SQL、schemas、config/examples、prompts 与 fixtures，通过带字面引号的 WLS_SOURCE_DIR 定位。UBSan 只链接 build-review-ubsan 的两个静态库；ASan 只链接 build-review-asan-affected 的两个静态库。四个系统动态库也保持原生成链接顺序。

复用 run_recorded.py；每轮 umask 0002、普通 UID 1000、各自数据盘 TMPDIR。recorder 设置 ASAN_OPTIONS=halt_on_error=1:detect_leaks=1 和 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1，捕获 stdout/stderr、退出码、开始/结束时间、进程组、负载及源码前后身份。

每次编译 watchdog 为既有探针编译的 240 秒；**每次探针执行 watchdog 为 180 秒**，不采用历史绿色 run 的 240 秒。冻结源码内部 5 秒屏障保持原值。recorder 的 TERM 后至多 5 秒 KILL 清理宽限不算成功执行期限；outer_timeout 或任何 timeout 都必须记录为 timeout。最坏顺序预算为 4×240+4×180=1680 秒，另加有限清理和 identity 采集时间；这是上界而非已发生用时。需要编译的是四个单翻译单元探针，链接已建静态库，不重建产品。

## 执行前条件和证据责任

1. 父代理确认当前 ASan build/CTest 整条链已经退出且已有完整回执；检查同一任务下不再有构建或测试子进程运行。不要通过终止当前链抢占资源。ASan 未完成时不得开始任何计划。
2. 核实 combined HEAD 仍为 9764667 且干净，785 项输入与准备清单一致；核实五个冻结探针 SHA。若父代理已提交文档或变更输入，应显式建立新的来源关联，而不能静默将本准备归给新 SHA。
3. 当前 UBSan 的七项身份已实读并与 final-ubsan-01/binaries-after 完全匹配，见 `ubsan-completed-build-identities.json`。**准备时 ASan 的 libwls_s1.a 尚不存在**，其最终库/测试 binary 的身份必须等父链结束后冻结并对照该链最终身份。本目录不预先声称 ASan 构建或测试成功。
4. 在每项 compile 前与 run 后，保存原五个探针、对应配置两静态库、相关 generated flags/link/compile_commands、compiler、系统动态库的 SHA。所有 tracked headers/SQL/schema/config/fixtures 由 recorder 的完整源码前后清单覆盖，仍须对准备清单核实。
5. 每项编译后、执行前及执行后另记新 binary 的 bytes/mode/SHA。现有 recorder 不负责二进制/静态库身份，不能只凭它的 source_unchanged 就宣称编译输入及 binary 一致。编译失败就记录本项失败和 execution NOT_RUN，不修改源码/参数重试。
6. recorder 继承环境。运行前只核实 LSAN_OPTIONS、LD_PRELOAD、LD_LIBRARY_PATH、CPATH、CPLUS_INCLUDE_PATH、LIBRARY_PATH、GCC_EXEC_PREFIX、COMPILER_PATH 均为空；记录变量名与是否为空即可，禁止输出秘密。不得新增 suppressions、preload、付费 provider 或真实服务调用。FakeModel 不需要真实凭据。
7. 四项 compile/run 的 evidence 和 tmp round 名现在均不存在；沿用命令中唯一名称，禁止覆盖既有回执。编译输出路径属于 recorder 创建的该轮 TMPDIR，执行轮另用新 TMPDIR。
8. 每项正常完成或超时后均检查该轮进程组没有遗留子进程；出现遗留则先真实记录并由父代理处理，不能与下一项重叠。保留所有实际 stdout/stderr 和退出回执，无输出的 timeout 不推断方法定位。

本准备没有提供新的产品断言、完整门禁聚合器或自动宣称 PASS 的脚本。父代理若选择执行，应分别记录实际结果；任何绿色目标诊断仅支持这两个 P1 在该 instrumentation 下的定向结果。**完整 Async 的本机 UBSan Timeout、其他本机 Release/transport/sanitizer 历史问题、LOCAL_VALIDATION_COMPLETE=false 以及正式复核结论均不能因此关闭。**
