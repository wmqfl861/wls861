# Prepared commands — NOT RUN

Classification: `DIAGNOSTIC_NOT_FULL_GATE`. Execute only after the parent has completed the ASan build/CTest chain, checked the README prerequisites, frozen final own-configuration library identities, and decided to perform this bounded diagnostic.

Commands are displays of structured argv in `command-plan.json`, generated with Python `shlex.join`; no command below was executed in preparation. The recorder creates each fresh tmp output directory before the compiler starts. Do not repeat a failed probe or change its source/deadline.

## UBSAN / amend

Compile once:

```bash
python3 -B /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/run_recorded.py --round sanitizer-targeted-ubsan-amend-compile-01 --cwd /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined --umask 0002 --timeout 240 -- /usr/bin/g++-13 '-DWLS_SOURCE_DIR="/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined"' -I/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/tests -I/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/include -isystem /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/third_party/valijson/include -isystem /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/third_party/libyaml/include -g -std=c++20 -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror -fsanitize=undefined -fno-sanitize-recover=undefined -fno-omit-frame-pointer /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/evidence/frozen-local-repros/amend-repro.cpp -o /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/tmp/sanitizer-targeted-ubsan-amend-compile-01/amend-probe /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/build-review-ubsan/libwls_s1.a /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/build-review-ubsan/libwls_kernel.a /usr/lib/x86_64-linux-gnu/libsqlite3.so /usr/lib/x86_64-linux-gnu/libcrypto.so /usr/lib/x86_64-linux-gnu/libcurl.so /usr/lib/x86_64-linux-gnu/libyaml.so
```

After successful compile, record the resulting binary SHA-256 and unchanged input/library identities. Run once:

```bash
python3 -B /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/run_recorded.py --round sanitizer-targeted-ubsan-amend-run-01 --cwd /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined --umask 0002 --timeout 180 -- /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/tmp/sanitizer-targeted-ubsan-amend-compile-01/amend-probe
```

## UBSAN / resource

Compile once:

```bash
python3 -B /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/run_recorded.py --round sanitizer-targeted-ubsan-resource-compile-01 --cwd /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined --umask 0002 --timeout 240 -- /usr/bin/g++-13 '-DWLS_SOURCE_DIR="/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined"' -I/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/tests -I/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/include -isystem /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/third_party/valijson/include -isystem /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/third_party/libyaml/include -g -std=c++20 -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror -fsanitize=undefined -fno-sanitize-recover=undefined -fno-omit-frame-pointer /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/evidence/frozen-local-repros/resource-repro.cpp -o /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/tmp/sanitizer-targeted-ubsan-resource-compile-01/resource-probe /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/build-review-ubsan/libwls_s1.a /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/build-review-ubsan/libwls_kernel.a /usr/lib/x86_64-linux-gnu/libsqlite3.so /usr/lib/x86_64-linux-gnu/libcrypto.so /usr/lib/x86_64-linux-gnu/libcurl.so /usr/lib/x86_64-linux-gnu/libyaml.so
```

After successful compile, record the resulting binary SHA-256 and unchanged input/library identities. Run once:

```bash
python3 -B /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/run_recorded.py --round sanitizer-targeted-ubsan-resource-run-01 --cwd /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined --umask 0002 --timeout 180 -- /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/tmp/sanitizer-targeted-ubsan-resource-compile-01/resource-probe
```

## ASAN / amend

Compile once:

```bash
python3 -B /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/run_recorded.py --round sanitizer-targeted-asan-amend-compile-01 --cwd /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined --umask 0002 --timeout 240 -- /usr/bin/g++-13 '-DWLS_SOURCE_DIR="/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined"' -I/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/tests -I/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/include -isystem /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/third_party/valijson/include -isystem /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/third_party/libyaml/include -g -std=c++20 -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror -fsanitize=address -fno-omit-frame-pointer /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/evidence/frozen-local-repros/amend-repro.cpp -o /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/tmp/sanitizer-targeted-asan-amend-compile-01/amend-probe /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/build-review-asan-affected/libwls_s1.a /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/build-review-asan-affected/libwls_kernel.a /usr/lib/x86_64-linux-gnu/libsqlite3.so /usr/lib/x86_64-linux-gnu/libcrypto.so /usr/lib/x86_64-linux-gnu/libcurl.so /usr/lib/x86_64-linux-gnu/libyaml.so
```

After successful compile, record the resulting binary SHA-256 and unchanged input/library identities. Run once:

```bash
python3 -B /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/run_recorded.py --round sanitizer-targeted-asan-amend-run-01 --cwd /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined --umask 0002 --timeout 180 -- /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/tmp/sanitizer-targeted-asan-amend-compile-01/amend-probe
```

## ASAN / resource

Compile once:

```bash
python3 -B /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/run_recorded.py --round sanitizer-targeted-asan-resource-compile-01 --cwd /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined --umask 0002 --timeout 240 -- /usr/bin/g++-13 '-DWLS_SOURCE_DIR="/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined"' -I/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/tests -I/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/include -isystem /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/third_party/valijson/include -isystem /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/third_party/libyaml/include -g -std=c++20 -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror -fsanitize=address -fno-omit-frame-pointer /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/evidence/frozen-local-repros/resource-repro.cpp -o /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/tmp/sanitizer-targeted-asan-resource-compile-01/resource-probe /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/build-review-asan-affected/libwls_s1.a /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined/build-review-asan-affected/libwls_kernel.a /usr/lib/x86_64-linux-gnu/libsqlite3.so /usr/lib/x86_64-linux-gnu/libcrypto.so /usr/lib/x86_64-linux-gnu/libcurl.so /usr/lib/x86_64-linux-gnu/libyaml.so
```

After successful compile, record the resulting binary SHA-256 and unchanged input/library identities. Run once:

```bash
python3 -B /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/run_recorded.py --round sanitizer-targeted-asan-resource-run-01 --cwd /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/combined --umask 0002 --timeout 180 -- /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/tmp/sanitizer-targeted-asan-resource-compile-01/resource-probe
```

