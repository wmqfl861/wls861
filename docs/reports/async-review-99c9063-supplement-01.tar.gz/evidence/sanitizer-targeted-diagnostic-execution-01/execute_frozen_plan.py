"""Execute the four previously frozen diagnostic commands once, sequentially."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


ROOT = Path('/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649')
REPO = ROOT / 'combined'
OUT = Path(__file__).resolve().parent
PREP = ROOT / 'evidence/sanitizer-targeted-diagnostic-preparation-01'
PLAN = json.loads((PREP / 'command-plan.json').read_text())
SOURCE = json.loads((PREP / 'combined-source-preparation.json').read_text())
BUILD_NAMES = {'ubsan': 'build-review-ubsan', 'asan': 'build-review-asan-affected'}
FORMAL_NAMES = {'ubsan': 'final-ubsan-01', 'asan': 'final-asan-affected-01'}


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def identity(path):
    state = path.stat()
    return {'bytes': state.st_size, 'mode': oct(state.st_mode & 0o777), 'sha256': sha(path)}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def process_inventory(group=None):
    names = {'cc1plus', 'g++', 'g++-13', 'c++', 'cmake', 'make', 'gmake', 'ctest',
             'amend-probe', 'resource-probe', 'async_coordinator_tests', 'scheduler_tests'}
    records = []
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit():
            continue
        try:
            fields = (directory / 'stat').read_text().rsplit(')', 1)[1].split()
            pgid = int(fields[2])
            argv = [x.decode(errors='replace') for x in
                    (directory / 'cmdline').read_bytes().split(b'\0') if x]
            comm = (directory / 'comm').read_text().strip()
            selected = pgid == group if group is not None else (
                comm in names or (argv and Path(argv[0]).name in names))
            if selected:
                records.append({'pid': int(directory.name), 'pgid': pgid,
                                'state': fields[0], 'comm': comm, 'argv': argv})
        except (OSError, ProcessLookupError):
            continue
    return records


def source_snapshot():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=REPO).split(b'\0')
    files = {os.fsdecode(name): identity(REPO / os.fsdecode(name)) for name in names if name}
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    status = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO, text=True)
    return {'head': head, 'worktree_status': status, 'source_count': len(files), 'files': files}


def input_snapshot(paths):
    return {str(path): identity(path) for path in paths}


def read_round(round_name, recorder_exit, expected_argv):
    directory = ROOT / 'evidence' / round_name
    completion = json.loads((directory / 'completion.json').read_text())
    command = json.loads((directory / 'command.json').read_text())
    process = json.loads((directory / 'process.json').read_text())
    actual_argv = expected_argv[expected_argv.index('--') + 1:]
    assert completion['argv'] == command['argv'] == actual_argv
    assert completion['head'] == command['head'] == PLAN['expected_head']
    assert completion['source_count'] == 785 and completion['source_unchanged']
    assert command['uid'] == os.getuid() != 0 and command['umask'] == '0002'
    assert command['worktree_status'] == ''
    assert command['environment']['ASAN_OPTIONS'] == 'halt_on_error=1:detect_leaks=1'
    assert command['environment']['UBSAN_OPTIONS'] == 'halt_on_error=1:print_stacktrace=1'
    expected_exit = 124 if completion['outer_timeout'] else completion['exit_code']
    assert recorder_exit == expected_exit or (
        expected_exit < 0 and recorder_exit == 256 + expected_exit)
    residual = process_inventory(process['pgid'])
    result = {'round': round_name, 'recorder_exit': recorder_exit,
              'completion': completion, 'residual_process_group': residual,
              'stdout': identity(directory / 'stdout.log'),
              'stderr': identity(directory / 'stderr.log')}
    copied = OUT / 'rounds' / round_name
    shutil.copytree(directory, copied)
    for path in directory.iterdir():
        if path.is_file():
            assert sha(path) == sha(copied / path.name)
    assert not residual, 'Residual process group prevents subsequent execution'
    return result


def run_recorded(argv, round_name):
    print(json.dumps({'event': 'starting', 'round': round_name, 'utc': utc()}), flush=True)
    with (OUT / (round_name + '-recorder.stdout.log')).open('xb') as stdout:
        with (OUT / (round_name + '-recorder.stderr.log')).open('xb') as stderr:
            result = subprocess.run(argv, cwd=REPO, stdout=stdout, stderr=stderr, check=False)
    receipt = read_round(round_name, result.returncode, argv)
    write(OUT / (round_name + '-receipt.json'), receipt)
    print(json.dumps({'event': 'completed', 'round': round_name,
                      'recorder_exit': result.returncode,
                      'seconds': receipt['completion']['seconds'],
                      'outer_timeout': receipt['completion']['outer_timeout']}), flush=True)
    return receipt


def main():
    write(OUT / 'orchestrator-started.json', {'started_at_utc': utc(), 'pid': os.getpid(),
          'classification': 'DIAGNOSTIC_NOT_FULL_GATE', 'attempt_policy': 'ONCE_PER_PROBE_PER_CONFIGURATION'})
    assert os.getuid() != 0
    assert PLAN['expected_head'] == '976466720e5fb17f6dcc67b0660b74d246996426'
    assert len(PLAN['plans']) == 4
    assert source_snapshot() == SOURCE
    assert not process_inventory(), 'A compiler or product test is already active'
    empty_environment = {name: not bool(os.environ.get(name))
                         for name in PLAN['required_empty_environment_variables']}
    assert all(empty_environment.values()), 'Uncontrolled compiler/sanitizer environment'
    frozen = json.loads((PREP / 'frozen-probe-inputs.json').read_text())
    for name, expected in frozen.items():
        assert identity(Path(name)) == expected
    paths = {Path(name) for name in frozen}
    tools = json.loads((PREP / 'tool-identities.json').read_text())
    for key in ['compiler', 'recorder']:
        row = tools[key]
        assert identity(Path(row['path'])) == {k: row[k] for k in ['bytes', 'mode', 'sha256']}
        paths.add(Path(row['path']))
    for name, expected in tools['linked_system_libraries'].items():
        assert identity(Path(name)) == expected
        paths.add(Path(name))
    formal = {}
    for config, build_name in BUILD_NAMES.items():
        prior = ROOT / 'evidence' / FORMAL_NAMES[config]
        result = json.loads((prior / 'result.json').read_text())
        before = json.loads((prior / 'binaries-before.json').read_text())
        after = json.loads((prior / 'binaries-after.json').read_text())
        complete = json.loads((ROOT / 'evidence' /
            (FORMAL_NAMES[config] + '-ctest-0002') / 'completion.json').read_text())
        assert result['head'] == complete['head'] == PLAN['expected_head']
        assert before == after and result['binary_identity_unchanged']
        assert complete['source_unchanged'] and complete['source_count'] == 785
        assert not process_inventory(complete['pid'])
        assert any(s['name'] == 'build' and s['exit'] == 0 for s in result['steps'])
        for name, expected in after.items():
            path = REPO / build_name / name
            assert sha(path) == expected
            paths.add(path)
        for name in ['flags.make', 'link.txt']:
            path = REPO / build_name / 'CMakeFiles/async_coordinator_tests.dir' / name
            assert sha(path) == sha(PREP / 'references' / (config + '-' + name))
            paths.add(path)
        formal[config] = {'result': result, 'completion': complete, 'verified_build_identities': after}
    for probe in PLAN['plans']:
        assert probe['maximum_compile_attempts'] == probe['maximum_execution_attempts'] == 1
        assert probe['compile_watchdog_seconds'] == 240
        assert probe['execution_watchdog_seconds'] == 180
        assert probe['unchanged_fixture_barrier_seconds'] == 5
        assert not Path(probe['binary']).exists()
        for round_name in [probe['compile_round'], probe['run_round']]:
            assert not (ROOT / 'evidence' / round_name).exists()
            assert not (ROOT / 'tmp' / round_name).exists()
    paths = sorted(paths)
    common_before = input_snapshot(paths)
    write(OUT / 'input-identities-before.json', common_before)
    write(OUT / 'source-before.json', SOURCE)
    write(OUT / 'preflight.json', {'utc': utc(), 'head': PLAN['expected_head'], 'uid': os.getuid(),
          'gid': os.getgid(), 'source_count': 785, 'source_matches_preparation': True,
          'frozen_sources_match': True, 'formal_chains_completed': formal,
          'active_product_processes': [], 'environment_empty': empty_environment,
          'plan_path': str(PREP / 'command-plan.json'), 'plan_sha256': sha(PREP / 'command-plan.json')})
    (OUT / 'rounds').mkdir()
    summaries = []
    for probe in PLAN['plans']:
        label = probe['configuration'] + '-' + probe['probe']
        snapshot = input_snapshot(paths)
        assert snapshot == common_before and source_snapshot() == SOURCE
        assert not process_inventory()
        write(OUT / (label + '-inputs-before-compile.json'), snapshot)
        compiled = run_recorded(probe['compile_recorder_argv'], probe['compile_round'])
        after_compile = input_snapshot(paths)
        write(OUT / (label + '-inputs-after-compile.json'), after_compile)
        assert after_compile == common_before and source_snapshot() == SOURCE
        summary = {'configuration': probe['configuration'], 'probe': probe['probe'],
                   'classification': 'DIAGNOSTIC_NOT_FULL_GATE', 'compile_attempts': 1,
                   'execution_attempts': 0, 'compile': compiled, 'run': None,
                   'method_names': probe['method_names'], 'observed_result': 'NOT_RUN'}
        if compiled['recorder_exit'] == 0 and not compiled['completion']['outer_timeout']:
            binary_before = identity(Path(probe['binary']))
            write(OUT / (label + '-binary-after-compile-before-run.json'), binary_before)
            assert not process_inventory()
            summary['execution_attempts'] = 1
            ran = run_recorded(probe['run_recorder_argv'], probe['run_round'])
            binary_after = identity(Path(probe['binary']))
            after_run = input_snapshot(paths)
            write(OUT / (label + '-binary-after-run.json'), binary_after)
            write(OUT / (label + '-inputs-after-run.json'), after_run)
            assert binary_before == binary_after
            assert after_run == common_before and source_snapshot() == SOURCE
            summary.update(run=ran, binary=binary_before, binary_unchanged=True,
                           inputs_unchanged=True, source_unchanged=True,
                           observed_result='TIMEOUT' if ran['completion']['outer_timeout'] else
                           ('EXIT_ZERO_PENDING_RAW_LOG_ASSESSMENT' if ran['recorder_exit'] == 0 else 'FAIL'))
        else:
            summary['observed_result'] = 'COMPILE_FAILED_EXECUTION_NOT_RUN'
        summaries.append(summary)
        write(OUT / (label + '-result.json'), summary)
    after = input_snapshot(paths)
    source_after = source_snapshot()
    processes_after = process_inventory()
    write(OUT / 'input-identities-after.json', after)
    write(OUT / 'source-after.json', source_after)
    assert after == common_before and source_after == SOURCE and not processes_after
    write(OUT / 'execution-receipt.json', {'finished_at_utc': utc(),
          'classification': 'DIAGNOSTIC_NOT_FULL_GATE', 'head': PLAN['expected_head'],
          'source_count': 785, 'source_unchanged': True, 'all_inputs_unchanged': True,
          'active_product_processes_after': processes_after,
          'compile_attempts': sum(x['compile_attempts'] for x in summaries),
          'execution_attempts': sum(x['execution_attempts'] for x in summaries),
          'full_async_timeouts_closed': False, 'independent_a4_review': False,
          'results': summaries})
    print(json.dumps({'event': 'all_planned_diagnostics_finished',
                      'classification': 'DIAGNOSTIC_NOT_FULL_GATE',
                      'results': [{'configuration': x['configuration'], 'probe': x['probe'],
                                   'observed_result': x['observed_result']} for x in summaries]}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        write(OUT / 'orchestrator-failure.json', {'utc': utc(), 'exception': type(error).__name__,
              'message': str(error), 'classification': 'DIAGNOSTIC_NOT_FULL_GATE',
              'active_product_processes': process_inventory()})
        raise
