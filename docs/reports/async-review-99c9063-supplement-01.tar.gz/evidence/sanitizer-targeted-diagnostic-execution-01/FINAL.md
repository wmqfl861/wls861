# 冻结 sanitizer 定向诊断：3 PASS / 1 FAIL

**DIAGNOSTIC_NOT_FULL_GATE**。本批四项诊断均按原准备命令执行完毕；四次编译、四次运行，各项均只一次，无重试。合计六次方法执行，五次通过、一次失败；不是六个测试套件。产品输入为 `976466720e5fb17f6dcc67b0660b74d246996426` 的 785 项 tracked 文件。

| 配置 | 冻结探针 | 编译 exit / 秒 | 运行 exit / 秒 | 方法结果 |
|---|---|---:|---:|---|
| ubsan | amend | 0 / 65.470818 | 0 / 5.790741 | 2 PASS / 0 FAIL |
| ubsan | resource | 0 / 65.782118 | 0 / 9.705964 | 1 PASS / 0 FAIL |
| asan | amend | 0 / 53.718590 | 0 / 15.798956 | 2 PASS / 0 FAIL |
| asan | resource | 0 / 58.916776 | 1 / 27.799066 | 0 PASS / 1 FAIL |

UBSan AMEND 与 ASan/LSan AMEND 均运行原 queued、inflight 两方法。UBSan resource 原始输出确认 `cycle=0 new_model_calls=4 accepted=4 resource_fifo=preserved`；原请求 envelope、响应 binding、结算、tool_feedback、claim/ops 及 FIFO 断言均由原冻结探针执行。三个通过探针的 stderr 为 0 字节。

**ASan resource 失败**：原始 stdout 为 `RESULT 0 passed, 1 failed`，stderr 指向冻结 `resource-regression-suite.cpp:136` 的原 `std::chrono::steady_clock::now() < deadline` 断言。该 until helper 在第 133 行设置原 5 秒期限。本轮运行总记录用时 27.799066 秒、exit 1、outer_timeout=false；不是外层 180 秒 watchdog 超时。

原始失败行：

```text
FAIL cross-pool resource heads progress before slot admission: /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/evidence/frozen-local-repros/resource-regression-suite.cpp:136: std::chrono::steady_clock::now() < deadline
```

资源案例会多次调用同一 until helper，现有输出没有标识失败的具体调用点；没有 CROSS_POOL_FIFO 成功或结构性 cycle 标记。不能认定四次业务调用已经成功，也不能将该失败归因为机器负载、ASan 开销或已重现原资源死锁。未新增输出、放宽断言、扩大期限或重跑。

四轮 probe 实际日志没有 ASan/LSan/UBSan 错误报告。这仅描述实际输出；ASan 资源业务回归仍然失败。两个配置继续使用自身已完成的静态库与 generated Debug 严格 flags，UBSan 保留 -fno-sanitize-recover=undefined；ASan 保持 detect_leaks=1。运行 UID/GID 1000、umask 0002、每轮数据盘独立 TMPDIR。编译 watchdog 240 秒，运行 watchdog 180 秒，原 5 秒屏障未修改。

785 项产品源码、原五个冻结探针、两配置完成库/注册 binary/generated 命令、compiler、系统链接库全程身份一致。每个新探针 binary 均记录编译后运行前、运行后 SHA/bytes/mode，全部一致。原 recorder 每轮 command、completion、stdout/stderr、process 与 source before/after 已逐字节复制到 `rounds/`，copy 来源与 SHA 见 `round-copy-index.json`。每轮完成后进程组为空；最终再次检查没有相关编译或测试进程。

核心证据：`FINAL.json` 是日志评估结果；`execution-receipt.json` 是执行器原始回执（其中 exit0 的状态有意保留 PENDING_RAW_LOG_ASSESSMENT）；`preflight.json` 绑定父代理已完成的正式 UBSan/ASan 链及实际库；`input-identities-before.json`、`input-identities-after.json` 与各探针中间清单记录输入身份；`source-before.json`、`source-after.json` 冻结完整 785 项。`execute_frozen_plan.py` 与原 `command-plan.json` 的 SHA 都有记录，脚本未改变任何产品源码或诊断参数。

原正式本机矩阵仍为 FAIL_OR_INCOMPLETE：Release 0002 owned_capacity Timeout、UBSan Async Timeout、ASan Async Timeout 均未关闭。两个 sanitizer 的其他 90 个注册本机 NOT_RUN 范围保持不变；完整 Async 也不因定向通过变为通过。`LOCAL_VALIDATION_COMPLETE=false`。本次由 A4 作者执行，不是 A4 独立审核。

本目录只记录该授权范围内四项有限诊断，没有调用真实模型或服务、未推送、未修改 combined、冻结准备和历史证据。ASan 资源探针新失败的后续调查由主协调 Agent 决定，当前原因 UNRESOLVED。
