import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

assert os.geteuid() != 0
log, *command = sys.argv[1:]
assert command
mask = os.umask(0)
os.umask(mask)
started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
started = time.monotonic()
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
elapsed = time.monotonic() - started
metadata = {'command': command, 'cwd': os.getcwd(), 'uid': os.geteuid(), 'gid': os.getegid(),
            'invoking_umask': f'{mask:04o}', 'started_at_utc': started_at,
            'exit_code': result.returncode, 'elapsed_seconds': elapsed,
            'executable_sha256': hashlib.sha256(pathlib.Path(command[0]).read_bytes()).hexdigest()}
header = json.dumps(metadata, ensure_ascii=False).encode() + b'\n'
raw = header + result.stdout
pathlib.Path(log).write_bytes(raw)
metadata['log_sha256'] = hashlib.sha256(raw).hexdigest()
metadata['log'] = log
pathlib.Path(log + '.json').write_text(json.dumps(metadata, indent=2) + '\n')
for line in result.stdout.splitlines():
    if line.startswith((b'RESULT', b'FAIL', b'Ran ', b'OK')):
        print(line.decode(errors='replace'))
print(json.dumps({'exit': result.returncode, 'seconds': elapsed, 'log': log}))
raise SystemExit(result.returncode)
