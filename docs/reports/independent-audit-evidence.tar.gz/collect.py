from pathlib import Path
import hashlib, importlib.metadata, json, os, platform, shutil, subprocess, sys, time

assert os.getuid() != 0
root = Path('/tmp/wls861-independent-audit')
evidence = Path('/tmp/wls861-audit-evidence')
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

paths = {line.split('  ', 1)[1] for line in
         (root / 'docs/reports/r2a3-r3-offline-inputs.sha256').read_text().splitlines()}
paths.update(str(p.relative_to(root)) for p in (root / 'scripts').glob('*.py'))
manifest = ''.join(digest(root / path) + '  ' + path + '\n' for path in sorted(paths))
(evidence / 'final-inputs.sha256').write_text(manifest)
if '--inputs-only' in sys.argv:
    print(json.dumps({'source_inputs': len(paths), 'manifest_sha256': hashlib.sha256(manifest.encode()).hexdigest()}))
    raise SystemExit(0)
environment = {
    'uid': os.getuid(), 'gid': os.getgid(), 'captured_epoch': time.time(),
    'platform': platform.platform(), 'python': sys.version,
    'jsonschema': importlib.metadata.version('jsonschema'),
    'source_input_count': len(paths), 'input_manifest_sha256': hashlib.sha256(manifest.encode()).hexdigest(),
    'latest_source_input_mtime_epoch': max((root / path).stat().st_mtime for path in paths),
    'tools': {}, 'binaries_sha256': {},
}
for name, args in {'g++': ['g++', '--version'], 'ld': ['ld', '--version'],
                   'cmake': ['cmake', '--version'], 'ninja': ['ninja', '--version'],
                   'openssl': ['openssl', 'version']}.items():
    environment['tools'][name] = subprocess.check_output(args, text=True).splitlines()[0]
for kind in ('release', 'asan', 'ubsan'):
    directory = Path('/tmp/wls861-audit-build-' + kind)
    environment['binaries_sha256'][kind] = {
        p.name: digest(p) for p in sorted(directory.iterdir())
        if p.is_file() and (p.name in ('wls', 'wls861') or p.name.endswith('_tests'))
    }
previous = json.loads(Path('/tmp/wls861-validation-three/environment.json').read_text())
baseline_binary = Path('/tmp/wls861-three-build-dev/wls')
environment['baseline_cli_sha256'] = digest(baseline_binary)
environment['baseline_cli_matches_prior_release_evidence'] = (
    environment['baseline_cli_sha256'] == previous['binaries_sha256']['dev']['wls'])
assert environment['baseline_cli_matches_prior_release_evidence']
(evidence / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n')
shutil.copyfile('/tmp/wls861-three-gate.py', evidence / 'gate.py')
shutil.copyfile(__file__, evidence / 'collect.py')
print(json.dumps({'source_inputs': len(paths), 'manifest_sha256': environment['input_manifest_sha256'],
                  'uid': os.getuid(), 'baseline_cli_verified': True}))
