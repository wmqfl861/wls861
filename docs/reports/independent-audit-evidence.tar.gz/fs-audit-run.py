import os
import pathlib
import subprocess
import sys
import time
import datetime
import hashlib
import json

assert os.geteuid() != 0
target, log = sys.argv[1:]
mask = os.umask(0)
os.umask(mask)
started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
started = time.monotonic()
result = subprocess.run([target], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
elapsed = time.monotonic() - started
header = f"uid={os.geteuid()} gid={os.getegid()} umask={mask:04o} cwd={os.getcwd()} command={target}\n".encode()
footer = f"\nexit={result.returncode} seconds={elapsed:.3f}\n".encode()
raw = header + result.stdout + footer
pathlib.Path(log).write_bytes(raw)
metadata = {
    "started_at_utc": started_at,
    "command": [target], "cwd": os.getcwd(),
    "uid": os.geteuid(), "gid": os.getegid(), "invoking_umask": f"{mask:04o}",
    "exit_code": result.returncode, "elapsed_seconds": elapsed,
    "log": log, "log_sha256": hashlib.sha256(raw).hexdigest(),
    "executable_sha256": hashlib.sha256(pathlib.Path(target).read_bytes()).hexdigest(),
}
pathlib.Path(log + ".json").write_text(json.dumps(metadata, indent=2) + "\n")
for line in result.stdout.splitlines():
    if line.startswith((b"RESULT", b"FAIL", b"[ENV]")):
        sys.stdout.buffer.write(line + b"\n")
sys.stdout.buffer.write(footer)
raise SystemExit(result.returncode)
