import hashlib
import json
import pathlib
import subprocess

root = pathlib.Path('/tmp/wls861-independent-audit')
evidence = pathlib.Path('/tmp/wls861-audit-evidence')
temporary = pathlib.Path('/tmp/wls861-audit-filesystem-tests')
baseline = '72f74d6fd9261fab2fb372370080b93006fc4fdb'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

sources = [
    'src/sandbox_posix.cpp', 'src/cleanup_posix.cpp',
    'tests/doctor_diagnostics_tests.cpp', 'tests/cleanup_tests.cpp', 'tests/sandbox_tests.cpp',
    'tests/test_support.hpp', 'src/sandbox_doctor.inc',
    'docs/implementation/R2a-deployment-diagnostics.md',
    'docs/implementation/S1-owned-cleanup.md',
]
common = ['g++', '-std=c++20', '-O2', '-Wall', '-Wextra', '-Wpedantic', '-Wconversion',
          '-Wshadow', '-Werror', '-Iinclude', '-Itests']
link = ['/tmp/wls861-three-build-dev/libwls_s1.a', '/tmp/wls861-three-build-dev/libwls_kernel.a',
        '-lsqlite3', '-lcrypto', '-Wl,-l:libyaml-0.so.2']
build_inputs = {
    'doctor-red': ['tests/doctor_diagnostics_tests.cpp'],
    'cleanup-red': ['tests/cleanup_tests.cpp'],
    'doctor-green': ['src/sandbox_posix.cpp', 'tests/doctor_diagnostics_tests.cpp'],
    'cleanup-green': ['src/cleanup_posix.cpp', 'tests/cleanup_tests.cpp'],
    'sandbox-green': ['tests/sandbox_tests.cpp'],
}
builds = []
for name, inputs in build_inputs.items():
    builds.append({
        'name': name,
        'command': ['runuser', '-u', 'nobody', '--'] + common + inputs + link + ['-o', str(temporary / name)],
        'cwd': str(root), 'exit_code': 0,
        'uid_selected_by_runuser': 65534, 'gid_selected_by_runuser': 65534,
        'started_at_utc': None,
        'compile_time_note': 'Exact compile timestamp and compile-time umask were not recorded.',
    })
runs = []
for name in ['doctor-open-eof-baseline-recorded.log', 'cleanup-names-baseline-recorded.log',
             'doctor-open-eof-green-recorded.log', 'cleanup-names-green-recorded.log',
             'sandbox-eof-green-recorded.log']:
    record = json.loads((evidence / 'logs' / (name + '.json')).read_text())
    record['log'] = 'logs/' + name
    record['runner'] = str(temporary / 'run.py')
    record['test_body_umask'] = 'preserved invoking umask' if name.startswith('doctor-') else '0077 set by tests/test_support.hpp::run; sandbox fixture also temporarily tests 0002'
    record['test_body_umask_basis'] = 'Implementation setting; the per-process invoking umask above was measured by the runner.'
    runs.append(record)

checks = []
for path in ['src/sandbox_posix.cpp', 'src/cleanup_posix.cpp']:
    git_bytes = subprocess.check_output(['git', 'show', baseline + ':' + path], cwd=root)
    old_bytes = (pathlib.Path('/tmp/wls861-r2a3-r3-dev') / path).read_bytes()
    checks.append({'path': path, 'git_sha256': hashlib.sha256(git_bytes).hexdigest(),
                   'prior_build_source_sha256': hashlib.sha256(old_bytes).hexdigest(),
                   'source_matches_release': git_bytes == old_bytes})

output = {
    'baseline_commit': baseline,
    'scope': 'Focused filesystem audit experiments, not full release gates or strong sandbox deployment acceptance.',
    'baseline_linkage': {
        'libraries': {path: digest(pathlib.Path(path)) for path in link[:2]},
        'prior_build_source_verification': checks,
        'note': 'Red binaries link the preserved prior release libraries. Green doctor/cleanup binaries override their audited module with current source; sandbox_tests.cpp includes the current sandbox implementation under its established supervisor-only test macro.',
    },
    'compiler': subprocess.check_output(['g++', '--version'], text=True).splitlines()[0],
    'builds': builds, 'runs': runs,
    'final_source_sha256': {path: digest(root / path) for path in sources},
    'helper_sha256': {'run.py': digest(temporary / 'run.py'), 'metadata.py': digest(temporary / 'metadata.py')},
    'case_scope': {
        'doctor-red': {'total': 32, 'passed': 30, 'failed': 2},
        'cleanup-red': {'total': 21, 'passed': 20, 'failed': 1},
        'doctor-green': {'total': 32, 'passed': 32, 'failed': 0},
        'cleanup-green': {'total': 23, 'passed': 23, 'failed': 0},
        'sandbox-green': {'total': 19, 'passed': 19, 'failed': 0},
        'notes': [
            'Cleanup red was compiled before the two new negative guard cases were added. Only its accepted-name case is claimed as reproduced failing on the release baseline. Its original test-source hash was not captured; final_source_sha256 is explicitly the later final source.',
            'Doctor red-2 and recorded red use the final 32-case source. The earlier doctor-open-eof-baseline-red.log ran a 31-case binary before the zero-size case compiled; that earlier binary is no longer retained.',
            'During test authoring a duplicate zero-size test definition caused one local compile failure and the shared initial build failure. It was removed before these successful builds; shared original failure output remains in build-release-initial.log.',
            'Recorded runs repeat the same binaries to measure uid/gid/cwd/umask and preserve actual timestamps. Earlier red and focused-green logs remain unmodified.',
        ],
    },
}
(evidence / 'fs-audit-metadata.json').write_text(json.dumps(output, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'path': str(evidence / 'fs-audit-metadata.json'), 'runs': len(runs), 'source_files': len(sources),
                  'baseline_source_matches_release': all(x['source_matches_release'] for x in checks)}))
