import hashlib
import json
import pathlib
import subprocess

root = pathlib.Path('/tmp/wls861-independent-audit')
evidence = pathlib.Path('/tmp/wls861-audit-evidence')
temporary = pathlib.Path('/tmp/wls861-audit-filesystem-tests')
published = '72f74d6fd9261fab2fb372370080b93006fc4fdb'
pre_addendum = '84291e6d39369b2155c40f0d27265217fcf00901'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

sources = ['src/offline_runtime.cpp', 'src/config_loader.cpp', 'tests/offline_runtime_tests.cpp',
           'tests/config_loader_tests.cpp', 'tests/test_doctor_diagnostics_cli.py']
common = ['g++', '-std=c++20', '-O2', '-Wall', '-Wextra', '-Wpedantic', '-Wconversion',
          '-Wshadow', '-Werror', '-Iinclude', '-Itests']
link = ['/tmp/wls861-three-build-dev/libwls_s1.a', '/tmp/wls861-three-build-dev/libwls_kernel.a',
        '-lsqlite3', '-lcrypto', '-Wl,-l:libyaml-0.so.2']
inputs = {
    'runtime-reader-red': ['tests/offline_runtime_tests.cpp'],
    'config-reader-red': ['tests/config_loader_tests.cpp'],
    'runtime-reader-green': ['src/offline_runtime.cpp', 'tests/offline_runtime_tests.cpp'],
    'config-reader-green': ['-isystem', 'third_party/libyaml/include', 'src/config_loader.cpp', 'tests/config_loader_tests.cpp'],
}
builds = []
for name, files in inputs.items():
    builds.append({'name': name,
                   'command': ['runuser', '-u', 'nobody', '--'] + common + files + link + ['-o', str(temporary / name)],
                   'cwd': str(root), 'exit_code': 0, 'uid_selected_by_runuser': 65534,
                   'gid_selected_by_runuser': 65534, 'compile_timestamp_and_umask': None})
runs = []
for name in ['input-readers-runtime-red.log', 'input-readers-config-red.log', 'input-readers-doctor-cli-red.log',
             'input-readers-runtime-green.log', 'input-readers-config-green.log']:
    record = json.loads((evidence / 'logs' / (name + '.json')).read_text())
    record['log'] = 'logs/' + name
    record['test_body_umask'] = 'invoking umask preserved' if 'doctor-cli' in name else '0077 explicitly set by tests/test_support.hpp::run'
    record['test_body_umask_basis'] = 'Implementation setting; invoking_umask was measured by the runner.'
    runs.append(record)
baseline_sources = []
for path in sources[:2]:
    released_bytes = subprocess.check_output(['git', 'show', published + ':' + path], cwd=root)
    prior_bytes = subprocess.check_output(['git', 'show', pre_addendum + ':' + path], cwd=root)
    old_build_bytes = (pathlib.Path('/tmp/wls861-r2a3-r3-dev') / path).read_bytes()
    baseline_sources.append({'path': path, 'published_source_sha256': hashlib.sha256(released_bytes).hexdigest(),
                             'pre_addendum_source_sha256': hashlib.sha256(prior_bytes).hexdigest(),
                             'prior_build_source_sha256': hashlib.sha256(old_build_bytes).hexdigest(),
                             'all_three_source_versions_match': released_bytes == prior_bytes == old_build_bytes})
output = {
    'published_baseline_commit': published,
    'pre_addendum_code_commit': pre_addendum,
    'release_gate_boundary': '84291e6 does not include these shared-reader corrections. Earlier full-gate results for that code cannot certify this addendum. Root performs new final gates against the combined final code and inputs.',
    'scope': 'Two shared-reader manifestations of the existing special-file open finding; not new strong-sandbox acceptance.',
    'baseline_source_comparisons': baseline_sources,
    'preserved_baseline_artifacts_sha256': {path: digest(pathlib.Path(path)) for path in link[:2] + ['/tmp/wls861-three-build-dev/wls']},
    'builds': builds,
    'runs': runs,
    'final_source_sha256': {path: digest(root / path) for path in sources},
    'case_scope': {
        'runtime_red': {'passed': 9, 'failed': 1, 'registered_cases': 10},
        'config_red': {'passed': 18, 'failed': 1, 'registered_cases': 19},
        'doctor_cli_red': {'registered_cases': 12, 'failed_subtests': 2,
                           'failed_options': ['--sandbox-manifest', '--config']},
        'runtime_green': {'passed': 10, 'failed': 0, 'registered_cases': 10},
        'config_green': {'passed': 19, 'failed': 0, 'registered_cases': 19},
        'new_registered_cases': 2,
        'notes': [
            'Doctor CLI strengthens one existing special-manifest test with two actual IN_OPEN observations; it adds no registered CLI case.',
            'The same final test sources were used for each red and green build. The red CLI uses the preserved published-baseline wls executable.',
            'Each focused green executable compiles its own corrected reader and links remaining unchanged dependencies from the preserved old library. Final combined executable and sanitizer coverage belong to root final gates.',
            'A separate focused doctor CLI green was deliberately omitted because root final Release and sanitizer gates run all twelve CLI cases.',
            'Compile commands completed successfully; exact compile times and compile-time umasks were not captured. Test execution metadata is measured.',
        ],
    },
    'helper_sha256': {'readers-run.py': digest(temporary / 'readers-run.py'),
                      'readers-metadata.py': digest(temporary / 'readers-metadata.py')},
}
(evidence / 'input-readers-metadata.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({'path': str(evidence / 'input-readers-metadata.json'), 'runs': len(runs),
                  'baseline_sources_match': all(item['all_three_source_versions_match'] for item in baseline_sources)}))
