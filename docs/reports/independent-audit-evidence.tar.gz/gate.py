from pathlib import Path
import hashlib,json,os,subprocess,sys,time

root=Path(sys.argv[1]); name=sys.argv[2]; mask=sys.argv[3]; cwd=Path(sys.argv[4]); command=sys.argv[5:]
assert os.getuid()!=0
started=time.time()
environment=dict(os.environ)
environment['ASAN_OPTIONS']='halt_on_error=1:detect_leaks=1'
environment['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
log=root/'logs'/(name+'.log')
with log.open('w') as output:
    result=subprocess.run(command,cwd=cwd,stdout=output,stderr=subprocess.STDOUT,
                          env=environment,umask=int(mask,8))
record={'name':name,'command':command,'cwd':str(cwd),'uid':os.getuid(),'gid':os.getgid(),
        'umask':mask,'started':started,'exit_code':result.returncode,
        'elapsed_seconds':round(time.time()-started,3),
        'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
(root/'logs'/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(result.returncode)
