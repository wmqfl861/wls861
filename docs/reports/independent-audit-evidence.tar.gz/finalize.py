from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, sys, tarfile

root = Path('/tmp/wls861-independent-audit')
evidence = Path('/tmp/wls861-audit-evidence')
reports = root / 'docs/reports'
prefix = 'independent-audit'
base = '72f74d6fd9261fab2fb372370080b93006fc4fdb'
local, remote = sys.argv[1:3]
bt = chr(96)
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=root)
def dump(value): return json.dumps(value, ensure_ascii=False, indent=2) + '\n'

tree = git('rev-parse', local + '^{tree}').decode().strip()
manifest = (evidence / 'final-inputs.sha256').read_bytes()
inputs = []
for line in manifest.decode().splitlines():
    digest, path = line.split('  ', 1)
    assert sha((root / path).read_bytes()) == digest, path
    assert sha(git('show', local + ':' + path)) == digest, path
    inputs.append({'path': path, 'sha256': digest})
assert len(inputs) == 258
(reports / (prefix + '-inputs.sha256')).write_bytes(manifest)
preserved = ['db', 'third_party', 'docs/handoff', '.github/workflows']
for path in preserved:
    assert not git('diff', '--name-only', base, local, '--', path).strip(), path
original_reviews = git('ls-tree', '-r', '--name-only', base, '--', 'docs/reviews').decode().splitlines()
assert all(git('show', base + ':' + path) == (root / path).read_bytes() for path in original_reviews)

def count_groups(path):
    blocks = re.split(r'(?m)^(\d+)/\d+ Testing: (.+)\n', path.read_text())
    groups = []
    for index in range(1, len(blocks), 3):
        number, name, block = int(blocks[index]), blocks[index + 1], blocks[index + 2]
        assert 'Test Passed.' in block, name
        cpp = re.findall(r'^RESULT (\d+) passed, 0 failed$', block, re.M)
        py = re.findall(r'^Ran (\d+) tests? in', block, re.M)
        count = int(cpp[0]) if cpp else (int(py[0]) if py else None)
        groups.append({'ctest_id': number, 'name': name, 'counted_cases': count,
                       'integrity_only': number in (41, 42)})
    counts = {
        'ctest_groups': len(groups),
        'm1_cpp': sum(g['counted_cases'] or 0 for g in groups if g['ctest_id'] < 5),
        's1_cpp': sum(g['counted_cases'] or 0 for g in groups if 5 <= g['ctest_id'] <= 38),
        'cli': sum(g['counted_cases'] or 0 for g in groups if g['ctest_id'] in (39, 40) or g['ctest_id'] >= 45),
        'reference_contracts': sum(g['counted_cases'] or 0 for g in groups if g['ctest_id'] == 43),
        'demo': sum(g['counted_cases'] or 0 for g in groups if g['ctest_id'] == 44),
        'integrity_groups': sum(g['integrity_only'] for g in groups),
    }
    counts['counted_cases'] = sum(counts[k] for k in ('m1_cpp', 's1_cpp', 'cli', 'reference_contracts', 'demo'))
    return counts, groups

formal_names = ['final-release-0002', 'final-release-0022', 'final-focused-asan', 'final-focused-ubsan']
gates = {}
for name in formal_names:
    record = json.loads((evidence / 'logs' / (name + '.json')).read_text())
    log = (evidence / 'logs' / (name + '.log')).read_bytes()
    assert record['exit_code'] == 0 and record['uid'] == 65534
    assert sha(log) == record['log_sha256']
    last = evidence / (name + '-LastTest.log')
    counts, groups = count_groups(last)
    if 'release' in name:
        assert counts == {'ctest_groups': 63, 'm1_cpp': 52, 's1_cpp': 573, 'cli': 188,
                          'reference_contracts': 38, 'demo': 3, 'integrity_groups': 2, 'counted_cases': 854}, counts
    else:
        assert counts['ctest_groups'] == 12 and counts['s1_cpp'] == 171 and counts['cli'] == 47, counts
        assert not re.search(r'ERROR: (?:AddressSanitizer|LeakSanitizer)|SUMMARY: (?:AddressSanitizer|UndefinedBehaviorSanitizer)|runtime error:', last.read_text())
    record.update({'counts': counts, 'groups': groups, 'last_test_log_sha256': sha(last.read_bytes())})
    gates[name] = record
environment = json.loads((evidence / 'environment.json').read_text())
assert environment['source_input_count'] == len(inputs)
assert environment['input_manifest_sha256'] == sha(manifest)
for kind in ('release', 'asan', 'ubsan'):
    started = json.loads((evidence / 'logs' / ('final-build-' + kind + '.json')).read_text())['started']
    assert environment['latest_source_input_mtime_epoch'] <= started

records = []
for path in sorted((evidence / 'logs').glob('*.json')):
    value = json.loads(path.read_text())
    if 'log_sha256' in value:
        log = Path(value['log']) if value.get('log') else path.with_suffix('.log')
        assert log.resolve().is_relative_to(evidence.resolve()), path
        assert log.exists() and sha(log.read_bytes()) == value['log_sha256'], path
    records.append({'metadata_file': str(path.relative_to(evidence)), 'record': value})
raw_items = []
archive = reports / (prefix + '-evidence.tar.gz')
selected = sorted(p for p in evidence.rglob('*') if p.is_file() and p.suffix in
                  ('.log', '.json', '.py', '.cpp', '.sha256'))
with archive.open('wb') as output:
    with gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as bundle:
            for path in selected:
                data = path.read_bytes(); name = str(path.relative_to(evidence))
                info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644; info.mtime = 0
                bundle.addfile(info, io.BytesIO(data))
                raw_items.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(archive, 'r:gz') as bundle:
    assert len(bundle.getmembers()) == len(raw_items)
    for item in raw_items:
        data = bundle.extractfile(item['path']).read()
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
archive_sha = sha(archive.read_bytes())
evidence_manifest = {
    'format': 'wls-validation-evidence-v1', 'archive': archive.name,
    'archive_bytes': archive.stat().st_size, 'archive_sha256': archive_sha,
    'file_count': len(raw_items), 'files': raw_items,
    'excluded': ['build binaries', 'temporary databases', 'core dumps', 'credentials'],
    'all_archive_member_bytes_verified': True,
}
(reports / (prefix + '-evidence.json')).write_text(dump(evidence_manifest))
results = {
    'implementation': '0.8.6-r3.2', 'blueprint': '0.4.1', 'findings': ['A1', 'A2', 'A3', 'A4', 'A5'],
    'source': {'base_commit': base, 'local_code_commit': local, 'remote_code_commit': remote,
               'matching_code_tree': tree, 'input_count': len(inputs),
               'input_manifest': prefix + '-inputs.sha256', 'input_manifest_sha256': sha(manifest),
               'all_manifest_bytes_match_code_commit': True,
               'later_publication_changes': 'documentation and evidence only',
               'input_scope': 'Previous 255 source/build/runtime inputs plus three contract/integrity Python scripts; original archive/review inputs remain independently hash-checked.'},
    'preserved_paths': preserved, 'existing_review_files_unchanged': original_reviews,
    'formal_gates': gates,
    'new_registered_cases': {'doctor_cpp': 2, 'cleanup_cpp': 3, 'sandbox_cpp': 1, 'sse_cpp': 3,
                             'config_loader_cpp': 1, 'offline_runtime_cpp': 1, 'cli': 5, 'total': 16},
    'strengthened_existing_cases': ['all two-chunk SSE splits include obfuscation',
                                     'doctor CLI special-input case observes FIFO IN_OPEN for manifest and config'],
    'effective_umask': {'release_invocations': ['0002', '0022'],
                        'doctor_cpp_and_doctor_protocol_cli': 'preserve and print invoking mask',
                        'cpp_shared_test_support': 'case body sets 0077 and restores the caller afterward',
                        'review_cli': 'existing private-fixture setUp uses 0077',
                        'warning': 'The invoking mask does not describe every fixture body.'},
    'sanitizers': {'local_scope': '12 directly affected groups, not complete repository suite',
                   'ASAN_OPTIONS': 'halt_on_error=1:detect_leaks=1',
                   'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1', 'observed_diagnostics': []},
    'unchanged_timeouts': {'ordinary_groups_seconds': 90, 'cleanup_runtime_seconds': 180,
                           'audit24_capacity_repro_seconds': 300, 'ci_job_minutes': 30},
    'environment': environment, 'process_records': records,
    'development_notes': [
        'Initial shared build read a test being edited and failed on a duplicate diagnostic function. Original failed log retained; assertions/timeouts unchanged.',
        'First Release/two umask and ten-group sanitizer passes bound code 84291e6 before the shared input-reader follow-up; retained as development evidence, not final gates.',
        'Final gates repeat full Release twice and expand focused sanitizers to twelve groups after the shared-reader follow-up.',
        'Cleanup red used 21 cases before two negative guards were added; only accepted-name failure is claimed as baseline red. Uncaptured early compile timestamps remain null.',
        'An initial scratch input-manifest write was denied by directory ownership and repeated as the evidence-directory owner; production permissions unchanged.'
    ],
    'evidence': {'archive': archive.name, 'sha256': archive_sha, 'bytes': archive.stat().st_size,
                 'manifest': prefix + '-evidence.json', 'file_count': len(raw_items)},
    'remote_publication_gate': {'binding': 'the final commit containing this report',
                               'required_jobs': ['strict', 'strict-umask-0002', 'Clang-18', 'UBSan', 'ASan', 'Make-ASan'],
                               'source_snapshot_required': True, 'final_ci_results_embedded': False,
                               'verification_location': 'Final delivery links to exact publication SHA and Actions run; intermediate runs do not substitute.'},
    'limitations': {'new_real_provider_calls': 0, 'paid_attempts': 0, 'credentials_resolved': False,
                    'positive_strong_sandbox_deployment': False, 'independent_second_model_business_review': False,
                    'planned_R3_3_and_R1_4_implemented': False},
}
(reports / (prefix + '-results.json')).write_text(dump(results))
rows = '\n'.join(f"| {name} | {r['counts']['ctest_groups']}/{r['counts']['ctest_groups']}，exit0 | {r['elapsed_seconds']:.3f} 秒 | {bt}{r['log_sha256']}{bt} |" for name, r in gates.items())
report = f'''# 0.8.6-r3.2 独立审核修复验证

问题与修复见[独立报告](../reviews/independent-2026-10-26.md)，设计见
[ADR-079](../adr/079-independent-boundary-review.md)，后继见
[R3.3/R1.4计划](../implementation/R3-controlled-live-plan.md)。本文只登记实际执行，
不把计划或局部通过写成产品验收。蓝图仍为v0.4.1，Store仍408；没有真实模型或付费调用。

## 1. 源码与输入绑定

| 项目 | 核验值 |
| --- | --- |
| 发布基线 | {bt}{base}{bt} |
| 本地最终代码提交 | {bt}{local}{bt} |
| 对应GitHub代码提交 | [{remote}](https://github.com/wmqfl861/wls861/commit/{remote}) |
| 两者完整tree | {bt}{tree}{bt} |
| 构建、测试、运行资产输入 | **258项**，逐项匹配代码提交和工作树 |
| 输入清单SHA256 | {bt}{sha(manifest)}{bt} |

258项包含前一批255项及原有三个contract/integrity Python脚本；原handoff/审核档案另按
其校验器和基线字节核对。最终构建前保存清单，测试后再核Git字节。所有输入修改时间早于
最终三配置构建开始；时间只是辅助观察，身份由SHA256和Git tree确定。之后只追加文档和证据。
本地与GitHub提交元数据不同，源码tree一致。未修改SQL、vendor、原handoff、已有审核文件或workflow。

## 2. 最终普通用户门禁

正式构建和测试均为UID/GID **65534**，保留C++20、严格警告和-Werror。
Release完整63组分别以调用umask0002、0022执行。本地sanitizer覆盖12个直接受影响组，
全量工具链另外核验最终发布SHA的远端矩阵。

| 门禁 | 实际结果 | runner耗时 | 原日志SHA256 |
| --- | --- | ---: | --- |
{rows}

完整Release每次：M1 C++52、S1 C++573、CLI188、Python参考契约38、合成demo3，
共854项计数用例，另有2组原件完整性检查。这些不同层次的测试不能合称854项产品验收；
重复umask/sanitizer不增加独立用例数。

新增**16个注册用例**：doctor2、cleanup3、sandbox1、SSE3、配置读取1、运行输入读取1、CLI5。
原SSE全切分用例增加默认填充，原doctor CLI特殊输入用例增加真实FIFO打开观察，二者未重复计数。
12组sanitizer为config_loader、offline_runtime、sandbox、worker_tools、cleanup、cleanup_runtime、
doctor_diagnostics、sse_replay及doctor/protocol/s12/review四组CLI；每次171项C++、47项CLI。
地址/泄漏与未定义行为检查未报告诊断；不称为本地完整sanitizer套件。

**有效umask：**doctor C++及doctor/protocol CLI保留调用mask；共享C++ test_support和review CLI
按原夹具规则在案例内设置0077，部分sandbox夹具另测子进程0002。不能从调用mask推导全部有效mask。
原超时保持：一般90秒、cleanup_runtime180秒、capacity_repro300秒，CI30分钟。

## 3. 基线失败与开发过程

| 反例 | 原实现实际结果 | 修复验证 |
| --- | --- | --- |
| doctor运行源FIFO与伪空文件 | 30通过/2失败，实际IN_OPEN与非空零声明长度proc文件 | 最终doctor32项及sandbox EOF预算 |
| 合法Workspace名称清理 | 20通过/1失败；另两个守卫当时未加入 | 最终cleanup23项 |
| 默认SSE obfuscation | 最终同源测试27通过/4失败，含加强旧例及3新例 | 最终SSE31项 |
| CLI输入/错误 | 14项中2失败、2错误；非法key原先成功，命令SIGABRT，长消息缺截断事实 | 最终review CLI14项 |
| 共享运行输入读取器 | 9通过/1失败，FIFO产生IN_OPEN | 最终offline_runtime10项 |
| 共享配置读取器 | 18通过/1失败，FIFO产生IN_OPEN | 最终config_loader19项 |
| doctor manifest/config入口 | 原12注册项内两个subtest失败 | 同一12项纳入最终CLI/sanitizer门禁 |

旧库相关源码与发布基线逐字匹配；红测CLI的SHA与上一批保存的二进制证据一致。
初次共享构建在测试文件编辑期间遇到重复函数定义并失败，修正后重建；原日志保留。
第一次两轮Release和十组sanitizer通过在共享reader补齐之前，只作开发阶段证据；
最终四道门禁对补齐后的同一258项输入重跑，不复用旧成绩。新增守卫不都声称在基线失败。
早期文件系统编译的精确时间未记录，metadata保持null；记录运行另实测身份/mask/时间/hash。
一次临时清单写入因目录所有权失败，改由目录所有者保存，生产权限未放宽。

## 4. 命令与原始证据

以下命令须普通用户执行；完整argv、cwd、UID/GID、调用mask、epoch和退出码见机器结果及归档。

{bt*3}sh
cmake -S . -B /tmp/wls861-audit-build-release -G Ninja -DCMAKE_BUILD_TYPE=Release -DPython3_EXECUTABLE=/tmp/wls861-validation-venv/bin/python
cmake --build /tmp/wls861-audit-build-release --parallel 2
ctest --test-dir /tmp/wls861-audit-build-release --output-on-failure
{bt*3}

ASan使用Debug/WLS_ENABLE_ASAN=ON、halt_on_error=1:detect_leaks=1；
UBSan使用Debug/WLS_ENABLE_UBSAN=ON、halt_on_error=1:print_stacktrace=1。
实际工具链GCC13.3.0、GNU ld2.42、CMake3.28.3、Ninja1.11.1、OpenSSL3.0.13，
Python3.12.14/jsonschema4.10.3；二进制摘要与实际版本见environment记录。
原CTest保留主机时区标签，runner时间为epoch，不跨环境比较时钟或速度。

| 文件 | 内容 |
| --- | --- |
| [{prefix}-inputs.sha256]({prefix}-inputs.sha256) | 258项源码/构建/测试/运行输入 |
| [{prefix}-results.json]({prefix}-results.json) | 门禁、计数、环境、过程元数据 |
| [{prefix}-evidence.json]({prefix}-evidence.json) | 每个成员的字节数/SHA256 |
| [{prefix}-evidence.tar.gz]({prefix}-evidence.tar.gz) | {len(raw_items)}份原日志、元数据、测试副本和采集脚本 |

归档{archive.stat().st_size}字节，SHA256 **{bt}{archive_sha}{bt}**。
逐项读回核验全部成员；不含构建二进制、临时DB、核心转储或凭据。

## 5. 最终发布与边界

最终文档提交改变commit SHA但不改变258项输入。发布须核对该最终SHA的strict、
strict-umask-0002、Clang-18、UBSan、ASan、Make-ASan及source-snapshot，
中间代码CI不能替代。交付回复给出最终SHA、实际run链接与结果，此处不预填尚未完成的远端成绩。
没有现场供应商/模型质量费用/强bwrap-cgroup正向/整机掉电/任意同UID对抗或第二模型业务验收。
附加用量核对、管理视图、大树容量、服务化和private-row purge仍为后续工作。
'''
(reports / (prefix + '-validation.md')).write_text(report)
print(dump({'local_code': local, 'remote_code': remote, 'tree': tree, 'inputs': len(inputs),
            'archive_files': len(raw_items), 'archive_bytes': archive.stat().st_size,
            'archive_sha256': archive_sha, 'counts': {k: v['counts'] for k, v in gates.items()}}))
