#!/usr/bin/env python3
"""One functional red probe on the unmodified 0.8.3-r2a.1 binary.

Refusal to adopt an unreceipted partial marker is expected and must remain.
The regression is the missing explicit abandonment exit, which prevents a
new-key allocation for that team. Setup/harness failures use exit code 2.
"""
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import sqlite3
import subprocess
import sys
import tempfile
import time
import traceback

BINARY = Path("/tmp/wls861-validation-r2a1/build-release/wls")
SOURCE = Path("/tmp/wls861-validation-r2a1/source")
EVIDENCE = Path(__file__).resolve().parent
SHIM = EVIDENCE / "red-marker-kill.so"
assert os.geteuid() != 0, "must run as an ordinary user"
os.umask(0o077)
started = time.monotonic()
record = {"classification": "functional missing explicit abandonment after real SIGKILL",
          "functional_cases": 1, "functional_passed": 0, "functional_failed": 0, "harness_errors": 0,
          "uid": os.getuid(), "gid": os.getgid(), "umask": "0077", "commands": [],
          "started_utc": datetime.now(timezone.utc).isoformat(), "real_model_calls": 0,
          "baseline_binary": str(BINARY), "baseline_source": str(SOURCE),
          "baseline_published_commit": "89eb108cac1455dc309a28dab8213195824b3fc4",
          "baseline_execution_manifest_sha256": "f6ebda73b85913cddcba9e735c927ee2d8aeb80b502c7b9ad21c69169ecf39e0"}

def call(*arguments, env=None):
    command = [str(BINARY), *(str(arg) for arg in arguments), "--source-root", str(SOURCE)]
    completed = subprocess.run(command, capture_output=True, text=True, timeout=30, check=False, env=env)
    item = {"arguments": [str(arg) for arg in arguments], "exit_code": completed.returncode,
            "stdout": completed.stdout, "stderr": completed.stderr}
    record["commands"].append(item)
    print(json.dumps(item, ensure_ascii=False), flush=True)
    return completed

def success(*arguments):
    result = call(*arguments)
    assert result.returncode == 0 and not result.stderr, result.stderr
    return json.loads(result.stdout)

def reject(result, code):
    assert result.returncode != 0 and not result.stdout, result.stdout
    value = json.loads(result.stderr)
    assert value["error"] == code, value
    return value

def rows(database, query):
    with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)) as connection:
        connection.row_factory = sqlite3.Row
        return [dict(row) for row in connection.execute(query)]

try:
    assert BINARY.is_file() and SHIM.is_file()
    record["binary_sha256"] = hashlib.sha256(BINARY.read_bytes()).hexdigest()
    assert record["binary_sha256"] == "6d4b1d602df0fc16966871ed6e6d32978680128c4a093c6815607c079a953347"
    manifest = Path("/tmp/wls861-validation-r2a1/logs/executed-inputs.sha256")
    assert hashlib.sha256(manifest.read_bytes()).hexdigest() == record["baseline_execution_manifest_sha256"]
    verified = 0
    for line in manifest.read_text().splitlines():
        digest, relative = line.split("  ", 1)
        assert hashlib.sha256((SOURCE / relative).read_bytes()).hexdigest() == digest, relative
        verified += 1
    assert verified == 233
    record["verified_baseline_inputs"] = verified
    version = success("--version")
    assert version["version"] == "0.8.3-r2a.1"
    record["version"] = version
    with tempfile.TemporaryDirectory(prefix="wls-r2a2-original-red-") as temporary:
        directory = Path(temporary)
        parent = directory / "owned"; parent.mkdir(mode=0o700)
        database = directory / "runtime.sqlite"
        fixture = SOURCE / "tests/fixtures"
        request = success("submit", "--db", database, "--key", "red-request", "--text-file", fixture / "s14_request.txt",
                          "--constraints-file", fixture / "s14_constraints.json")["request"]["request_id"]
        pump = success("pump-fake", "--db", database, "--request", request, "--script", fixture / "s15_fake_complete.json",
                       "--worker-calls", 2, "--max-calls", 1)
        assert pump["real_model_calls"] == 0
        task = success("show", "--db", database, "--request", request)["tasks"][0]["task_id"]
        allocation = ["allocate-workspace", "--db", database, "--request", request,
                      "--task", task, "--parent", parent, "--key", "interrupted"]
        env = dict(os.environ, LD_PRELOAD=str(SHIM), WLS_ALLOCATION_RED_PARENT=str(parent))
        killed = call(*allocation, env=env)
        assert killed.returncode == -signal.SIGKILL and not killed.stdout and not killed.stderr
        resources = rows(database, "SELECT * FROM owned_workspaces")
        assert len(resources) == 1 and resources[0]["status"] == "PREPARED"
        resource = resources[0]
        assert rows(database, "PRAGMA user_version") == [{"user_version": 407}]
        intent = json.loads(resource["intent"])
        final = parent / intent["leaf"]
        marker = final / "owner.json"
        original = marker.read_bytes()
        assert len(original) == 7 and original == json.dumps(intent["marker"], sort_keys=True, separators=(",", ":")).encode()[:7]
        assert not (final / "work").exists()
        same_error = reject(call(*allocation), "conflict")
        assert rows(database, "SELECT * FROM owned_workspaces") == resources
        assert marker.read_bytes() == original
        replacement = [*allocation[:-1], "replacement"]
        new_error = reject(call(*replacement), "conflict")
        assert rows(database, "SELECT * FROM owned_workspaces") == resources
        assert marker.read_bytes() == original
        abandonment = call("abandon-workspace", "--db", database, "--request", request,
                           "--resource", resource["resource_id"], "--expected-state-version", resource["state_version"],
                           "--key", "abandon", "--reason", "retain partial marker and allocate a new workspace")
        missing = reject(abandonment, "invalid_input")
        assert "unknown command: abandon-workspace" in missing["message"], missing
        assert rows(database, "SELECT * FROM owned_workspaces") == resources
        assert marker.read_bytes() == original
        record["observations"] = {"kill_signal": "SIGKILL", "partial_marker_bytes": len(original), "schema_version": 407,
                                  "resource_status": resource["status"], "same_key_error": same_error,
                                  "new_key_error": new_error, "abandon_error": missing,
                                  "original_owned_row_retained": True, "partial_marker_retained": True,
                                  "same_key_fail_closed_is_expected": True,
                                  "missing_capability": "explicitly abandon unregistered PREPARED and allocate with a new key"}
        record["functional_failed"] = 1
        record["result"] = "FAIL_EXPECTED_ON_BASELINE"
        record["exit_code"] = 1
        print("FAIL original 0.8.3 cannot explicitly abandon the interrupted PREPARED allocation; old refusal is preserved", flush=True)
except Exception:
    record["harness_errors"] = 1
    record["result"] = "HARNESS_ERROR"
    record["exit_code"] = 2
    record["error"] = traceback.format_exc()
    print(record["error"], flush=True)
finally:
    record["elapsed_seconds"] = round(time.monotonic() - started, 3)
    record["completed_utc"] = datetime.now(timezone.utc).isoformat()
    record["probe_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    record["injector_source_sha256"] = hashlib.sha256((EVIDENCE / "red-marker-kill.c").read_bytes()).hexdigest()
    (EVIDENCE / "r2a1-allocation-red-details.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({key: record[key] for key in ("result", "functional_cases", "functional_failed", "harness_errors", "exit_code", "elapsed_seconds")}), flush=True)
sys.exit(record["exit_code"])
