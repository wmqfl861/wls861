#define _GNU_SOURCE
#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <unistd.h>

/* Test-only exact private-parent fault. Never linked into the product. */
ssize_t write(int fd, const void *bytes, size_t length) {
    const char *parent = getenv("WLS_ALLOCATION_RED_PARENT");
    if (parent && *parent) {
        char descriptor[64], path[PATH_MAX + 1];
        const int printed = snprintf(descriptor, sizeof(descriptor), "/proc/self/fd/%d", fd);
        if (printed > 0 && (size_t)printed < sizeof(descriptor)) {
            const ssize_t size = readlink(descriptor, path, PATH_MAX);
            if (size > 0 && size <= PATH_MAX) {
                path[size] = '\0';
                const size_t prefix = strlen(parent), suffix = strlen("/owner.json");
                if ((size_t)size > prefix + suffix + 5 && strncmp(path, parent, prefix) == 0 &&
                    path[prefix] == '/' && strncmp(path + prefix + 1, "res_", 4) == 0 &&
                    strcmp(path + size - suffix, "/owner.json") == 0) {
                    const ssize_t wrote = (ssize_t)syscall(SYS_write, fd, bytes, length < 7 ? length : 7);
                    if (wrote > 0) (void)kill(getpid(), SIGKILL);
                    return wrote;
                }
            }
        }
    }
    return (ssize_t)syscall(SYS_write, fd, bytes, length);
}
