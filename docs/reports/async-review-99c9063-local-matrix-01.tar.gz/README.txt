WLS861 final local matrix and first 9764667 remote summary

All archive members are inert UTF-8 text at mode 0644; execute none.
Exact commands, nonzero exits, original complete or failed logs, source and
binary manifests retain their original bytes. A failed test is archivable;
this package does not turn failed, timed-out, skipped or NOT_RUN work green.
Release selected 92 twice; local Clang/UBSan/ASan selected only two each.
The other 90 in each focused local configuration remain NOT_RUN. Overall
LOCAL_VALIDATION_COMPLETE is not promoted by archive completion. Historical
GCC/Clang/live_workflow causes remain OPEN and Windows 11 ordinary-user
acceptance remains NOT_RUN. Bounded engineering audits are not formal
coordinator acceptance or merge authorization.

Only FINAL.md, FINAL.json, FREEZE.json and SHA256SUMS represent the first
9764667 remote CI in this archive. The 57,519,077-byte original asset set
remains external at /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649/evidence/remote-9764667-01.
FINAL records the actual GitHub run/artifact identities. No remote assets
were downloaded, changed or executed by this packager. Its SHA256SUMS
describes external files too; absence from this small archive is explicit.
Final later documentation-SHA CI requires its separate receipt.

MEMBERS.json lists original paths, categories and hashes, excluding its own
self-reference. index.json beside the archive hashes every archive member,
including MEMBERS.json; receipt.json and SHA256SUMS seal the full package.
Completion is proven only by receipt.json status COMPLETE, verified members
and before/after unchanged originals. An archive without that receipt is
an incomplete attempt and must not be described as a completed package.
