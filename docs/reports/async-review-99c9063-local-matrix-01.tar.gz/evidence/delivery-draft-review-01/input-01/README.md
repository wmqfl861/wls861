# 待 root 集成的本批交付草稿

本目录仅为外部交付草稿，不是冻结产品工作树。作者为 `/root/independent_recovery_review`：
本批R-A3修复作者、R-A4非作者复核者及本次文档整理者，不是对自己修复的唯一独立审核者，
也不是主协调者正式批准人。本次没有编译、测试、GitHub评论、提交或推送；没有修改combined。

草稿按9764667产品输入编写；最终文档提交只允许新增报告/证据及最小STATUS/ROADMAP变更。

| 文件 | 用途 |
| --- | --- |
| `async-review-99c9063-remediation-20261031.md` | 建议写入同名 `docs/reports/` 的新报告；T0–T5、实际红绿、失败保留、本机/远端范围及六状态。 |
| `STATUS-prefix.md` | 插在STATUS首行版本标题之后，原A0–A5文字前；附一个明确历史范围标题，保留既有事实。 |
| `ROADMAP-insertion.md` | 插在“2026-10-31 获准执行批次”之后、“初始 P0–P7”之前；只调整整改顺序与后继门禁。 |
| `documentation.patch` | 上述三文件的合并草稿patch，尚含待填字段；基于9764667，禁止未经核对直接提交。 |
| `patch-base.json` | 两个既有文档的基准SHA-256及新报告目标路径；若root已修改文档，应人工整合，不能覆盖。 |
| `pr-title.txt` / `pr-body.md` | 建议最终PR标题和描述；仅为素材，由root决定更新既有Draft PR11。 |
| `required-fields.json` | 机器可读精确待填字段及在Markdown中的出现位置。 |
| `source-evidence.json` | 本次读取的关键证据路径/SHA；不复制57,519,077字节（约54.9MiB）的远端资产，原位置保持可查。 |

root应先按实际完成收据替换所有 `{{...}}`。本稿只预填已有完成记录：原附件与冻结红绿、组件Release、
combined Clang2/2、四类工具24/4/11/6、9764667首轮7workflow/17job、T4三方法单次诊断及T5完整LastTest。
本机Release、顺序UBSan/ASan、最终冻结与文档SHA仍待root填写；没有未运行套件的预写绿色。

## 精确待补项

1. 时间范围终点。若实际跨UTC日期，保留报告文件名的本批开始日期，在正文给出完整起止。
2. Release0022与0002各自的注册总数、pass/fail/timeout/skipped/not-run、exit、秒数、原command/completion/JUnit/LastTest位置。
   目前报告有一句草稿时的“67/92进行中”上下文，最终必须随实际结果改写，不能把过期进度留作结论。
3. 顺序本机UBSan/ASan受影响2/92的各自配置、exit、秒数、原日志和前后身份；其余90本机NOT_RUN保持。
   本机Clang也只有2/92；远端各完整92/92单列。整体LOCAL_VALIDATION_COMPLETE按本轮root决定保持FALSE，不能自动提升。
4. Release全套中Store/恢复/工作流/进程结算/cleanup/计费E2E/单Agent/兼容的实际结果索引；它们是完整92中的成员，不追加算另一套完整门禁。
5. 最终输入/二进制清单、测试终止/残留进程检查、保护路径、完整diff、diff-check、remote main/base核对及必要证据包/成员清单的SHA。
   证据包只保留审核过的文本素材/摘要，57,519,077字节（约54.9MiB）的远端资产仍在原数据盘目录；FINAL已给各CI/artifact链接和digest。
6. 只有报告/证据/STATUS/ROADMAP相对9764667改变的证明。产品验证输入固定9764667；若发现生产/测试/构建/CI字节变化，不能沿用旧矩阵。
7. 最终文档提交的完整SHA、远端分支读回、最终Push/PR checkout与base、最终CI/源码artifact核验在提交后外部回执登记。
   不把最终提交自己的SHA预填进它自身的版本化报告，避免自引用；PR描述和外部回执可以在提交后写准确SHA/链接。
8. 主协调者正式PR审核、MERGED和后继派卡保持独立。原CHANGES_REQUIRED未由同模型工程复核覆盖。
   历史GCC/Clang/live_workflow根因仍OPEN，Windows11普通用户NOT_RUN，无真实/付费/生产/合并授权。

9764667的最终远端事实已固定于 `../remote-9764667-01/FINAL.md`、`FINAL.json`，后者SHA：
`be84af2d9f4168708ec72b99136eb16612e775e5f937a617e76b2c5d4f0ab14c`。
Make准确计数为92调用：57 native/801方法、32 unittest/397方法、demo3场景、另2完整性脚本；
13 unittest只有原7/6通过点号与Ran/OK汇总，不填补逐名输出，也不叫1201套。
