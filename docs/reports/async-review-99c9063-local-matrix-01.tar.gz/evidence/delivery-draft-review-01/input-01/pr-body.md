精确重放旧AMEND/cancel时，协调器现在只返回原Store控制结果，不再误停后来合法的调用；真正的新控制仍停止其废止的原需求/epoch捕获。跨池同资源后继现在先在有界host等待，取得资源头资格后才进入原M1池，避免2/2合法配置下两个普通执行槽互等资源前驱。资源仍持有到原结算与反馈持久化，原Actor/session、CAS、claim、UNKNOWN和预算守卫保持。

直接依赖 `work/next-cycle-integration-20261031` 的 `99c9063f3e29cd6d69c56fb15815715d499a374a`（PR #10），保留现有堆叠关系。本PR继续Draft，主协调者对A3/A4的原CHANGES_REQUIRED尚未被正式复核覆盖。

实际验证与限制：

- 两个原审核附件在未修改99输入均命中目标断言失败，在各自修复输入通过；本地冻结合法业务回归另有同源红绿，资源循环修复后四调用实际accepted4并保留FIFO。
- Async原18+4+7共29子例，仍为一个CTest suite；原Scheduler9例、Linux完整92注册和期限保持。两位非作者分别复核另一项修复；同模型交叉审核不等于第二模型或协调者批准。
- 产品输入9764667的本机Release结果：{{PR_LOCAL_RELEASE_RESULTS}}。本机Clang受影响2/2通过；UBSan/ASan为{{PR_LOCAL_SANITIZER_RESULTS}}，各仅2/92范围，其余90本机NOT_RUN。整体LOCAL_VALIDATION_COMPLETE仍FALSE。
- 产品输入9764667的[Push六路](https://github.com/wmqfl861/wls861/actions/runs/41220729821)、[PR六路](https://github.com/wmqfl861/wls861/actions/runs/41220751664)、公平红绿、原生组件和源码快照共17/17 job成功；[源码快照](https://github.com/wmqfl861/wls861/actions/runs/41220729814)785项重建树一致。最终文档提交的精确SHA/CI/源码回执：{{PR_FINAL_PUBLICATION_RECEIPT}}。
- 工具自检分别24/4/11/6方法通过；本轮另补默认关闭的脱敏阶段观察和Windows完整LastTest采集。历史GCC48/2/39timeout、Clang29/10timeout、旧live_workflow根因仍OPEN；三项原GCC方法诊断通过不关闭历史。
- Windows远端为Server2022/elevated/NTFS组件4注册27方法，Windows11普通用户仍NOT_RUN，完整Store/VFS/进程/强隔离/cleanup不在本卡范围。

原始失败、全部命令/退出码、独立复核范围和最终证据见[本批整改报告](https://github.com/wmqfl861/wls861/blob/fix/async-review-99c9063-20261031/docs/reports/async-review-99c9063-remediation-20261031.md)。首轮typed-ID夹具错误、工具I/O异常及取证解析器失败均保留。没有真实模型、付费请求、生产操作、main写入或合并；后继B0–B6仍待协调者派卡。
