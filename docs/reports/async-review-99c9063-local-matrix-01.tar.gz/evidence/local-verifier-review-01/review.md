本次有界静态审核未发现阻断项，可以在四配置结果和原始记录完整后运行这份对账收集器。审核文件为 `verify_local_final.py`，SHA-256：`859c032cb80e34166912c906509baed57e85b92661c2e67d09994c807efa1425`。结论只适用于这些字节及当前 `validate_candidate.py` / `run_recorded.py` 的固定记录格式，不表示产品测试通过。

审核者 `/root/evidence_audit` 未编写该收集器。本次只读源码和既有 Clang 记录，没有启动收集器、编译或运行产品。主协调 Agent 修改了反馈的问题；本审核未修改 `combined` 或既有 `final-coverage-audit-01`。

| 核对范围 | 静态结果 |
| --- | --- |
| 四配置及步骤 | 固定 Release、Clang、UBSan、ASan affected 四配置；configure/build/预期 CTest 的顺序、轮次必须精确一致；缺少记录会拒绝形成完整矩阵。 |
| 执行绑定 | 每步 command/completion 的 HEAD、argv 一致，cwd 和 UID 1000 固定；CTest argv 精确绑定相应 build、JUnit 路径及完整/两项选择。Release 两种 umask，其余 0002。 |
| 源码身份 | 当前 HEAD、git ls-files 集合、785 个源码 SHA-256 与 mode，以及每一步 source-before/source-after 均与冻结输入比较。 |
| 二进制身份 | 前后清单必须相等，包含必要的两测试、两库及构建身份文件；以原采集规则重建当前集合并逐个比 SHA，空清单或缺项不能静默通过。 |
| 注册及选择 | 全目录恰好 92 个唯一名称，拒绝 DISABLED，与冻结 catalog 逐项比期限；JUnit 恰含选中的 92 项或 2 项，没有重复或缺项。 |
| 实际结果 | 单独记录失败、Timeout、skipped/notrun，未知状态不能进入 passed；总计与条目分类交叉核对。selected_or_reported 与 executed 分开，后者扣除未执行项。 |
| 编译与 sanitizer | 核对实际 compiler/build type；已冻结 compile_commands 中两库和两测试均具严格告警及所需 sanitizer/debug 参数，检查两测试链接参数。ASan 要求 detect_leaks=1/halt_on_error，UBSan 要求 halt_on_error/stacktrace。 |
| 失败与完成 | 原子进程退出码保留；外层超时按 run_recorded 的包装码 124 对账。非零步骤、外层超时、失败或未执行用例使 observed_selected_result 为 FAIL_OR_INCOMPLETE；对账完成不等于产品通过。 |

审查中指出并已修正：步骤/执行对象绑定不足；未知 JUnit 状态可能计为通过；未执行占位项误算 executed；二进制集合及编译参数核验不足；外层超时时包装退出码 124 与子进程真实码不相等的合法情况。真实失败仍可归档并明确标为非通过，没有通过要求所有退出码为 0 来抹掉失败矩阵。

这是针对当前记录格式的静态审核，未运行工具自检或合成负例，也未证明任意格式/恶意篡改兼容性。缺失、损坏或相互矛盾的记录会让收集器拒绝输出完整矩阵；原始记录仍保留。尚未完成的运行不由本审核补成通过，后续工具实际退出和生成矩阵由主协调 Agent 另行记录。本结果不构成产品门禁、全套验证完成、历史失败关闭或正式 PR 验收。
