"""Freeze this bounded audit only; never compile or execute product binaries."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

ROOT = Path('/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649')
OUT = ROOT / 'evidence/final-coverage-audit-01'
REPO = ROOT / 'combined'
TARGET = '976466720e5fb17f6dcc67b0660b74d246996426'
BASE = '99c9063f3e29cd6d69c56fb15815715d499a374a'

def load(path):
    return json.loads(path.read_text())

def sha_file(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def identity(path):
    return {'bytes': path.stat().st_size, 'sha256': sha_file(path)}

def write(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

assert os.getuid() == 1000
assert git('rev-parse', 'HEAD').decode().strip() == TARGET
assert git('status', '--porcelain') == b''
assert load(OUT / 'retained-evidence-check-v2.json')['exit_code'] == 0
assert load(OUT / 'red-green-check-v2-completion.json')['exit_code'] == 0

read_files = set(load(OUT / 'red-green-receipt-verification.json')['read_files'])
read_files.add('attachments/ce518883/unpacked/NEXT_AGENT_PROMPT.md')
material = load(OUT / 'execution-input-identity.json')['material_source_files']
read_files.update('combined/' + path for path in material)
read_files.update('combined/' + path for path in [
    'AGENTS.md', 'docs/implementation/A3-async-coordinator.md',
    'docs/implementation/A4-fair-scheduling.md',
    'docs/adr/092-single-writer-async-coordinator.md',
    'docs/adr/093-request-team-fair-scheduling.md'])
read_files.update('evidence/' + path for path in [
    'final-clang-01/result.json', 'final-clang-01/test-plan.json',
    'final-clang-01/binaries-before.json', 'final-clang-01/binaries-after.json',
    'final-clang-01/junit-0002.xml',
    'final-clang-01/ctest-0002-original-logs/LastTest.log',
    'final-clang-01-ctest-0002/command.json',
    'final-clang-01-ctest-0002/completion.json',
    'final-clang-01-ctest-0002/source-before.json',
    'final-clang-01-ctest-0002/source-after.json',
    'cross-review-a3-by-resource/review.md',
    'cross-review-a3-by-resource/review-candidate-03-addendum.md',
    'cross-review-a4-by-amend/review-01.md',
    'cross-review-a4-by-amend/review-02.md',
    'integrated-cross-review/review.md',
    'amend-candidate-suites-01/original-ctest-logs/LastTest.log',
    'amend-candidate-suites-02/LastTest.log'])
read_files.update('combined/build-review-clang/' + path
                  for path in load(OUT / 'execution-input-identity.json')['binary_identities'])
inputs = {path: identity(ROOT / path) for path in sorted(read_files)}
skill_path = Path('/home/ubuntu/.codex/skills/codebase-memory/SKILL.md')
inputs[str(skill_path)] = identity(skill_path)

blobs = {}
for ref in [BASE, TARGET]:
    for path in material:
        exists = subprocess.run(['git', '-C', str(REPO), 'cat-file', '-e', ref + ':' + path],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if exists.returncode != 0:
            assert ref == BASE and path in ['tests/async_resource_fifo_cases.hpp',
                                           'tests/async_resource_lifecycle_cases.hpp']
            blobs[ref + ':' + path] = {'exists': False}
            continue
        raw = git('show', ref + ':' + path)
        blobs[ref + ':' + path] = {'exists': True, 'bytes': len(raw),
                                  'sha256': hashlib.sha256(raw).hexdigest()}
        if ref == TARGET:
            assert raw == (REPO / path).read_bytes()
            assert blobs[ref + ':' + path]['sha256'] == material[path]['sha256']

archive = ROOT / 'evidence/review-package-01/wls861-review-evidence-01.tar.gz'
assert sha_file(archive) == 'c1431a300cc77537ef86e782d8ea91e945aa853e724f2175b11f09470daa6614'
write('audit-inputs.json', {'task_root': str(ROOT), 'target': TARGET, 'baseline': BASE,
    'files': inputs, 'git_blob_inputs': blobs,
    'binary_inputs': 'Hashes only; audit did not execute binaries or copy them into an archive.',
    'previous_accepted_archive_preservation': {'path': str(archive.relative_to(ROOT)), **identity(archive)}})
artifacts = {str(p.relative_to(OUT)): identity(p) for p in sorted(OUT.iterdir())
             if p.is_file() and p.name not in ['audit-artifacts.json', 'completion-receipt.json']}
write('audit-artifacts.json', {'artifacts': artifacts,
    'excluded_self_and_later_receipt': ['audit-artifacts.json', 'completion-receipt.json']})
assert git('status', '--porcelain') == b''
write('completion-receipt.json', {
    'reviewer': '/root/evidence_audit', 'uid': os.getuid(),
    'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'BOUNDED_EVIDENCE_AUDIT_COMPLETE', 'target': TARGET, 'baseline': BASE,
    'repository_worktree_status': '', 'repository_changes_by_audit': False,
    'build_or_product_execution_by_audit': False,
    'audit_check_exits': {'retained_evidence_v2': 0, 'red_green_receipts_v2': 0},
    'failed_audit_utility_attempts_retained': True,
    'actual_retained_clang_execution': {'async_methods': 29, 'scheduler_methods': 9,
        'ctest_registrations_executed': 2, 'remaining_registrations_not_run_here': 90},
    'original_async_case_preservation': {'original': 18, 'byte_identical': 15,
        'strengthened': 3, 'one_nonnull_check_explicitly_strengthened': True},
    'product_registration_names_and_deadlines': {'count': 92, 'unchanged': True},
    'coverage_rows': 18, 'coverage_rows_are_distinct_suites': False,
    'conclusion': 'No blocking missing execution mapping or weakened original test found within enumerated bounded requirements; not a full combination or interleaving proof.',
    'explicit_combination_not_run': 'Adapter itself throws while a same-resource cross-pool successor is blocked.',
    'full_validation_remote_ci_and_formal_acceptance': 'Outside this audit; use coordinator receipts.',
    'previous_accepted_archive_unchanged': True,
    'manifests': {name: identity(OUT / name) for name in ['audit-inputs.json', 'audit-artifacts.json']},
    'report': {'path': str((OUT / 'review.md').relative_to(ROOT)), **identity(OUT / 'review.md')}
})
for name, expected in load(OUT / 'audit-artifacts.json')['artifacts'].items():
    assert identity(OUT / name) == expected
for name, expected in load(OUT / 'completion-receipt.json')['manifests'].items():
    assert identity(OUT / name) == expected
print(json.dumps({'status': 'BOUNDED_EVIDENCE_AUDIT_COMPLETE', 'target': TARGET,
    'input_file_count': len(inputs), 'artifact_file_count': len(artifacts),
    'report': identity(OUT / 'review.md'),
    'input_manifest': identity(OUT / 'audit-inputs.json'),
    'artifact_manifest': identity(OUT / 'audit-artifacts.json'),
    'completion_receipt': identity(OUT / 'completion-receipt.json'),
    'worktree_clean': True, 'accepted_archive_unchanged': True}, indent=2))
