本次独立覆盖审核针对 `976466720e5fb17f6dcc67b0660b74d246996426`，比较基线为 `99c9063f3e29cd6d69c56fb15815715d499a374a`。审核者为 `/root/evidence_audit`，未编写 T1/T2 的生产修复或相应用例；这是同一模型的独立工程证据审核，不是第二模型评测、协调 Agent 的正式验收或 PR 批准。

在本次限定范围内，未发现 T1/T2 已列出的行为要求缺失实际执行映射，亦未发现原 18 个异步用例被删减或原测试期限被放宽。保留一项明确的组合覆盖限制：适配器抛异常已执行，但没有单独执行“适配器抛异常，同时存在同资源的跨池阻塞后继”这一组合；不能将全部组合矩阵标为通过。本结论也不证明任意线程交错均正确。

审核只读取现有源码、Git 对象、原始执行日志和身份清单；没有编译、运行产品、调用供应商或访问生产服务，没有修改 `combined`、既有文档、旧证据或已接受的 `review-package-01` 归档。所有新增审核产物位于本目录。

已完成的准确提交执行证据是 `evidence/final-clang-01/` 和 `evidence/final-clang-01-ctest-0002/`：UID 1000，外层 umask 0002，Async 29/29、Scheduler 9/9，CTest 两个注册套件通过，进程退出 0；外层采集耗时 16.304403898 秒，未触发外层超时。Async 的 CTest 耗时 15.52 秒，Scheduler 0.02 秒。该配置仅执行这两个套件，其余 90 个注册项未在此 Clang 配置中运行。原有测试夹具仍在内部设置私有 umask 0077，因此这里不声称所有内部文件都按 0002 创建。环境中出现 ASAN_OPTIONS/UBSAN_OPTIONS 不等于这次 Clang 运行是 sanitizer 运行。

`actual-method-execution-and-catalog.json` 将原始 LastTest.log 的 29 个唯一 PASS 名称逐个对应目标源文件的注册顺序，核验 RESULT 29 passed, 0 failed，亦核验 M1 原 9 个方法。`execution-input-identity.json` 核验测试前后 785 个源码输入条目一致，13 个相关源码/构建入口与目标提交及现工作树逐字相符；7 个保留二进制/构建身份在运行前、运行后和当前文件之间一致。二进制身份为 SHA-256，不以文件名或一次构建成功替代。

| 身份 | SHA-256 |
| --- | --- |
| 目标 async_coordinator_tests.cpp | edd07b4ff82ce4b50d30a057f81a40e5ab41337f4a85298d43eaae3b05c743eb |
| 目标 FIFO 回归头文件 | 7007271c489611848f4900f93cd9ffcef373c04443bd9751c7bd5784c6f2a229 |
| 目标生命周期回归头文件 | b60343ddaec10dc118e827af61a2dba5f218da153940e2b6a65bbef43346d2fe |
| 目标 src/async_coordinator.cpp | 5ecf3f22ad5ed27379a77ca73072f031c1fdda1d975d4781af0d9b96646270ae |
| 实际 Clang async_coordinator_tests 二进制 | 9b52f37c4aab12760d5fe533715b21759b09341121c50ab1b0bc9c014c52bcf1 |
| 实际 Clang LastTest.log | 1694273b8c7178406958f634beaba57302f2554967906e82080067dd40d51978 |

下表为已核对的要求—方法—实际执行映射。完整机器记录见 `requirement-method-execution-map.json`，含注册名称、源码行号、原始日志路径和观察到的断言。18 行要求映射存在重叠，不能计为 18 个套件或额外的 18 个独立用例；真实产品计数是一个 Async 套件内 29 个方法，以及一个 Scheduler 套件内 9 个方法。

| 要求 | 目标函数及源码位置 | 已执行的具体断言 |
| --- | --- | --- |
| T1.1：原问题同源红转绿，当前Dispatcher完成并结算 | `amend_replay_preserves_queued_new_dispatcher`（`tests/async_coordinator_tests.cpp:286`）<br>`amend_replay_preserves_inflight_new_dispatcher`（`tests/async_coordinator_tests.cpp:287`） | 两个冻结旧例分别验证queued/inflight。合法AMEND后的新捕获保留requirements2，原command/CAS重放后stop为false；真实plan/task/COMPLETED accepted1及原response/feedback均检查。 |
| T1.2：真正的新AMEND通知旧在途调用并保留迟到原证据 | `amend_retains_late_original_without_business`（`tests/async_coordinator_tests.cpp:374`） | 真实AMEND后observed_stop=true；迟到旧Worker结果为STALE/accepted0，任务与操作计数不变，原envelope/binding/response/feedback及usage保留，旧捕获重放不再进入模型。 |
| T1.3a：首次、重复及迟到重放均无新副作用 | `amend_replay_preserves_queued_new_dispatcher`（`tests/async_coordinator_tests.cpp:286`）<br>`amend_replay_preserves_inflight_new_dispatcher`（`tests/async_coordinator_tests.cpp:287`） | queued/inflight各做两次精确重放；新结果提交后再做late重放。request/budget/attempt/request_texts/events前缀逐项相等；模型仅一次、无stop。 |
| T1.3b：同键异参、旧CAS/Actor/session拒绝 | `amend_replay_preserves_queued_new_dispatcher`（`tests/async_coordinator_tests.cpp:286`）<br>`amend_replay_preserves_inflight_new_dispatcher`（`tests/async_coordinator_tests.cpp:287`）<br>`store_session_and_first_claim_remain_authoritative`（`tests/async_coordinator_tests.cpp:598`） | 同键text/CAS/catalog变化为Conflict，其他owner为Unauthorized，旧writer session为Stale；新command旧CAS也Conflict。原Store会话/claim事务故障同样拒绝且模型零调用。 |
| T1.3c：合法新控制仍实际生效 | `amend_retains_late_original_without_business`（`tests/async_coordinator_tests.cpp:374`）<br>`actual_cancel_stops_old_call_and_keeps_late_original`（`tests/async_coordinator_tests.cpp:421`） | 合法新AMEND及新cancel各自真实改变状态/代次并通知旧在途模型；不是把全部控制改成无操作。 |
| T1.4：取消精确重放不误停合法终态经验收尾 | `control_replays_preserve_current_terminal_experience`（`tests/async_coordinator_tests.cpp:456`） | 真实WorkerTools提交、TeamLead检查、Dispatcher验收创建原experience；实际AMEND/cancel后捕获合法当前TeamLead经验调用。两轮旧AMEND+cancel重放均不stop；原source/job/closeout保持，最后DONE且accepted1。 |
| T1.5：UNKNOWN、预算、历史和终态权限边界 | `actual_cancel_stops_old_call_and_keeps_late_original`（`tests/async_coordinator_tests.cpp:421`）<br>`control_replays_preserve_current_terminal_experience`（`tests/async_coordinator_tests.cpp:456`）<br>`queued_worker_wait_and_unknown_cannot_acquire_permission`（`tests/async_coordinator_tests.cpp:717`） | 真实cancel在迟到结果前保留UNKNOWN/原保留量，之后原证据STALE；终态伪造source/job CAS、普通Dispatcher/Worker业务及新AMEND/cancel均拒绝且无预算/attempt副作用；原文件不删。 |
| T2.1：2/2最小合法资源循环及四次合法完成 | `cross_pool_fifo_resource_heads_progress_before_slot_admission`（`tests/async_resource_fifo_cases.hpp:37`） | manager2/worker2，各默认reserve1。M_A(X),W_B(Y),M_B(Y),W_A(X)原顺序入队；绿分支不cancel/close解锁，四模型各一次、accepted4、原binding/settlement/feedback、claim+4及业务op计数均核验。 |
| T2.2：默认4/8饱和，双预留及资源等待不借槽 | `both_s1_pools_keep_their_review_execution_reserve`（`tests/async_coordinator_tests.cpp:762`） | 3普通manager+7普通Worker及各一Review同时运行，实际4/8；两普通排队加两个跨池同key等待者均不扩大M1队列/运行数。claims仍12；释放后真实调用提交。 |
| T2.3：Normal/Review/Handoff同key FIFO及异key兄弟推进 | `resource_fifo_spans_normal_review_handoff_and_allows_siblings`（`tests/async_resource_lifecycle_cases.hpp:170`） | 2/2下Worker Normal→Dispatcher Review→Worker Handoff；独立Dispatcher兄弟先提交。每个前驱feedback持久后后继才进模型；四claims/四ops及原accepted记录核验。 |
| T2.4a：排队资源等待者取消不释放活动前驱 | `resource_waiter_cancel_preserves_active_predecessor`（`tests/async_resource_lifecycle_cases.hpp:17`） | 非头Worker从未进入模型；原head继续占真实执行资源，新Review不能偷key。取消者保留host_not_dispatched/未知usage及预算；head/第三调用后续完成。 |
| T2.4b：排队资源等待者AMEND不刷新原捕获或扰动前驱 | `resource_waiter_amend_preserves_original_capture_and_predecessor`（`tests/async_resource_lifecycle_cases.hpp:226`） | 同key非头Handoff真实AMEND，原需求1/current2；模型零调用，原host_not_dispatched保留；另一request的前驱request/budget/attempt完全相同并正常完成。 |
| T2.4c：原结算及反馈写入失败保留资源/结果且不重复效果 | `resource_waiter_cannot_bypass_persistence_failure`（`tests/async_resource_lifecycle_cases.hpp:121`）<br>`persistence_failure_retains_result_and_only_retries_evidence`（`tests/async_coordinator_tests.cpp:619`）<br>`failed_feedback_after_committed_effect_fences_without_reexecution`（`tests/async_coordinator_tests.cpp:742`） | 真实SQLite trigger覆盖settlement前与业务效果后feedback两故障点；保留2个结果/原响应、阻止新claim；flush仅收证、op/model调用数不增加，永久halt及UNKNOWN预算保持。两故障点属于一个方法。 |
| T2.4d：Ready前驱直到原结果持久前继续持有key | `same_resource_is_fifo_across_management_and_worker_pools`（`tests/async_coordinator_tests.cpp:900`） | callback已Ready且manager线程槽已释放时，原attempt仍PENDING、feedback为null；另一池等待者仍零outstanding/未进模型。之后原持久完成才启动后继。 |
| T2.4e：close与foreign destruction有界收尾/恢复 | `resource_waiter_close_records_original_unknown`（`tests/async_resource_lifecycle_cases.hpp:57`）<br>`resource_waiter_foreign_destruction_preserves_pending_attempts`（`tests/async_resource_lifecycle_cases.hpp:85`）<br>`shutdown_joins_and_restart_preserves_unknown`（`tests/async_coordinator_tests.cpp:650`）<br>`foreign_thread_destruction_cannot_deadlock_a_claim_waiter`（`tests/async_coordinator_tests.cpp:696`） | 合作stop的head和未入池waiter完成收尾，两个pool归零；foreign析构保留真实PENDING，重开为UNKNOWN且旧Actor不能claim。原5秒观察边界及180秒CTest限额保留。 |
| T2.4f：适配器异常及drain边界 | `adapter_exception_and_unsupported_long_tool_are_bounded`（`tests/async_coordinator_tests.cpp:676`）<br>`resource_waiter_cannot_bypass_persistence_failure`（`tests/async_resource_lifecycle_cases.hpp:121`）<br>`cross_pool_fifo_resource_heads_progress_before_slot_admission`（`tests/async_resource_fifo_cases.hpp:37`） | 原adapter异常方法实际运行并持久化host_adapter_exception/未知预算，drain可返回；资源前驱的持久化异常方法也实际运行并有界停止。没有专门组合“adapter本身抛异常+同key跨池后继”的单一新增方法。 限制：适配器异常与跨池同资源阻塞后继没有单独组合执行。 |
| T2.5：等待者无执行槽/Store权限，真实在途仍占资源 | `both_s1_pools_keep_their_review_execution_reserve`（`tests/async_coordinator_tests.cpp:762`）<br>`resource_waiter_cancel_preserves_active_predecessor`（`tests/async_resource_lifecycle_cases.hpp:17`）<br>`store_session_and_first_claim_remain_authoritative`（`tests/async_coordinator_tests.cpp:598`）<br>`queued_worker_wait_and_unknown_cannot_acquire_permission`（`tests/async_coordinator_tests.cpp:717`） | 等待者M1 outstanding/running为0且模型零调用，真实head仍executing1；原claim事务、session、wait/UNKNOWN仍核验，未把未知账目提前释放。 |
| T2.6：原公平性、18方法及M1兼容保留 | `queued_s1_requests_and_teams_rotate_without_starvation`（`tests/async_coordinator_tests.cpp:832`）<br>`host_limits_are_validated_without_rewriting_frozen_requests`（`tests/async_coordinator_tests.cpp:937`）<br>`full_queue_keeps_control_and_result_reserves`（`tests/async_coordinator_tests.cpp:344`） | 原request→team轮转方法逐字不变并再次实际通过；原18相对顺序保留，15体逐字不变、3增强；M1源/9例/harness/CMake/Make/92名字与期限目录保持原字节。 |

红转绿证据分为原审核附件和另外冻结的合法业务回归输入，两者不能混称为同一套测试。原附件 `attachments/ce518883/unpacked/independent_async_repros.cpp` 的 SHA-256 是 `aec4981953945e2e714564623cb15006bec97d4703ca6d02a4baa3c6595f8f84`。原版和修复候选均使用这份原文件及原基线测试夹具，并链接各自的生产头文件、库和资源；before/after 身份记录和真实退出状态完整保留。

| 实际轮次 | 退出码 | 原始结果 |
| --- | ---: | --- |
| original-baseline-amend-01 | 1 | `new_call_stop_requested=1`，附件第 56 行 `!model->observed_stop.load()` 失败 |
| original-baseline-cycle-01 | 1 | `cycle=1 awaiting=2 queued=2 executing=0 resource_blocked=2`，附件第 120 行 `!cycle` 失败 |
| original-amend-amend-01 | 0 | 同一附件 AMEND 反例，`new_call_stop_requested=0`，1 passed |
| original-resource-cycle-01 | 0 | 同一附件资源反例，`cycle=0`，1 passed |
| amend-red-run-01 | 1 | 冻结的 queued/inflight 新 Dispatcher 两个回归均在目标 stop 断言失败，0 passed / 2 failed |
| resource-red-run-01 | 1 | 冻结的合法业务回归发现结构循环，`new_model_calls=0`，`!structural_cycle` 失败 |
| frozen-amend-green-run-01 | 0 | 相同冻结输入的两方法均通过，真实计划/任务/原反馈检查保留 |
| frozen-resource-green-run-01 | 0 | 相同冻结输入，`cycle=0 new_model_calls=4 accepted=4 resource_fifo=preserved` |

上述基线失败均是目标断言失败而非超时。原附件资源探针使用其自己的合成 Error 响应，不能用它的“循环消失”结果替代四次合法业务成功；后者由冻结的合法业务回归另行证明。该 FIFO 头文件与最终目标文件 SHA 完全相同，绿分支不靠 cancel/close 打破循环；红分支只在已观察循环后执行有界清理，然后仍因目标断言失败退出。最终 9764667 的 Clang 原始日志进一步证明合并后的相关注册方法实际通过。

`red-green-receipt-verification.json` 对原始 `red-green-index-v1.json` 的 11 个轮次逐项核验原日志 SHA、退出码、记录的 HEAD、source-before/source-after 及无外层超时；三个原附件编译回执、各自身份清单和两个冻结绿回执均核验。早期 `baseline-red-receipt.json` 创建时尚未执行原附件，保留了当时的 NOT_RUN；后来原附件实际执行由独立的新回执补充，历史回执未被改写。部分候选运行时工作树尚未提交，回执中的 HEAD 只表示当时父提交，候选输入身份以原清单/补丁为准；这些中间绿例不是最终 9764667 直接运行的替代证据。

最初候选套件失败也保留：`amend-candidate-suites-01` 的 CTest 退出 8、Async 19 passed / 3 failed，原因是新增夹具的 typed ID 含不允许的连字符。`fixture-correction-03.json` 记录仅将 `stale-cas`、`terminal-amend`、`terminal-cancel` 改为 `stalecas`、`termamend`、`termcancel`，没有放宽断言或超时，也没有修改生产守卫来兼容非法夹具。后续 `amend-candidate-suites-02` 与 `resource-candidate-suites-01` 成功，分别记录 Async 22 和 25 方法及 Scheduler 9 方法；这两个历史数量不是最终套件数。

原 18 个 Async 注册方法的相对顺序全部保留。15 个函数体逐字相同，3 个函数增强了原验证：`amend_retains_late_original_without_business` 补充真实停止和原始证据；`both_s1_pools_keep_their_review_execution_reserve` 补充默认 4/8 饱和和资源等待不借槽；`same_resource_is_fifo_across_management_and_worker_pools` 补充 Ready 后、持久化前的资源占有。原 CHECK 表达式全部保留或明确加强，其中仅一处原非空反馈检查被更强检查替代：

```cpp
// 原断言
CHECK(!runtime.store().tool_feedback(old.request.attempt_id).is_null());
// 目标断言
CHECK(runtime.store().tool_feedback(old.request.attempt_id).at("response")
      == model->original_response());
```

读取 `.at("response")` 先要求非空对象并存在该字段，随后还要求它等于原响应。因此可以报告语义加强，但不能声称每一条旧 CHECK 的文本都原封不动。逐方法 SHA 和差异保留在 `original-case-preservation.json`、`three-original-case-differences.patch`。自动比较仅对空白和原响应访问器括号做归一化，三处变更也经过人工读取。

`CMakeLists.txt`、`Makefile`、`tests/gcc_asan_expected_tests.json`、`scripts/run_gcc_asan.py`、`tests/test_support.hpp`、`src/scheduler.cpp`、`include/wls/scheduler.hpp`、`tests/scheduler_tests.cpp` 在基线与目标之间均逐字未变。实际 Clang CTest 计划的全部 92 个名称与期限逐项匹配原 catalog，没有 DISABLED 项。Async 期限仍是 180 秒，局部 `until` 仍是原 5 秒。Gate、Release、Fixture、until 及整个 `tests/fixtures` Git 树身份保持一致。测试计数没有以新数字替代旧名称/期限审核。

遵照 codebase-memory skill 已检查索引覆盖，但现有 `wls861-next-cycle` 索引 generation 为 `2026-10-31T06:55:42Z`，根目录是旧工作树，缺失本次 Async 生产/测试文件；docs/scripts 被排除，Makefile 有部分解析记录。实际 A4 合同路径是 `docs/implementation/A4-fair-scheduling.md`，首次尝试的 `A4-m1-fairness.md` 并不存在。`graph-coverage.json` 保留了这些事实。未完成分页的无关广域 src gaps 没有用来支持完整性或不存在性结论；本次所有实质结论来自准确提交的源码、直接读取和原始日志。

只读审核工具的失败也完整保留。`retained-evidence-check.json` 首次退出 1，是工具错误假设每个旧 CHECK 文本都必须保留；识别上面更强的等值断言后，保留 `check_retained_evidence_attempt_01.py` 和原 stderr，明确列出该替换，再由 v2 退出 0。`red-green-check-completion.json` 首次退出 1，是工具误把“编译后额外包含新 probe 二进制”当作输入清单差异；保留原脚本与日志后，v2 要求所有原输入严格相同、唯一新增项正是该 probe，且核对现存二进制 SHA，最终退出 0。这两次是审核工具假设修正，不是产品失败，也没有据此修改产品测试断言。

剩余边界：本审核未重复产品执行，不承担全 Release 两种 umask、完整 ASan/LSan、UBSan、远端 Actions 或 Windows 11 的完成判定；这些由主协调 Agent 的独立执行/发布回执决定。不会因两个本地 Clang 套件成功而声称全部 92 套件在此配置执行，也不会把历史 Clang/live_workflow 失败改写为关闭。T2.4f 的组合覆盖限制仍保留。目标代码没有因本审核发生变动，正式验收及后续任务仍由主协调 Agent 决定。

本目录的 `audit-inputs.json` 冻结本次实际使用的材料路径、大小和 SHA-256；`audit-artifacts.json` 冻结审核输出；最后的 `completion-receipt.json` 记录两份清单哈希、准确提交、工作树状态及审核结论。清单和完成回执不包含自引用哈希，原已接受归档保持原字节。
