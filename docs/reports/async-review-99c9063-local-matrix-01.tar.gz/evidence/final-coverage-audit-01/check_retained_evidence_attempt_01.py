"""Read retained source/log identities only; no build or product execution."""
from pathlib import Path
import collections
import difflib
import hashlib
import json
import re
import subprocess

TASK = Path('/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649')
REPO = TASK / 'combined'
EVIDENCE = TASK / 'evidence'
OUT = EVIDENCE / 'final-coverage-audit-01'
BASE = '99c9063f3e29cd6d69c56fb15815715d499a374a'
TARGET = '976466720e5fb17f6dcc67b0660b74d246996426'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def source(ref, path):
    return git('show', ref + ':' + path).decode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name, value):
    with (OUT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def span(text, opening, left='{', right='}'):
    # Lexical balance only for these exact C++ fixtures. Strings and comments
    # cannot contribute braces/parentheses to function or CHECK boundaries.
    depth, index, state = 0, opening, 'code'
    while index < len(text):
        ch, pair = text[index], text[index:index + 2]
        if state in ('"', "'"):
            if ch == '\\':
                index += 2
                continue
            if ch == state:
                state = 'code'
        elif state == 'line':
            if ch == '\n':
                state = 'code'
        elif state == 'block':
            if pair == '*/':
                state = 'code'
                index += 2
                continue
        elif pair == '//':
            state = 'line'
            index += 2
            continue
        elif pair == '/*':
            state = 'block'
            index += 2
            continue
        elif ch in ('"', "'"):
            state = ch
        elif ch == left:
            depth += 1
        elif ch == right:
            depth -= 1
            if depth == 0:
                return text[opening:index + 1]
        index += 1
    raise AssertionError('unbalanced retained source')


def body(text, function):
    match = re.search(r'^void\s+' + re.escape(function) + r'\([^)]*\)\s*\{', text, re.M)
    assert match, function
    return span(text, text.index('{', match.start()))


def cases(text):
    tail = text[text.index('return test::run({'):]
    return re.findall(r'\{"([^"]+)",\s*([A-Za-z0-9_]+)\}', tail)


def checks(text):
    result = []
    for match in re.finditer(r'\bCHECK\(', text):
        value = span(text, match.end() - 1, '(', ')')
        value = value.replace('original_response()', 'original_response')
        result.append(re.sub(r'\s+', '', value))
    return collections.Counter(result)


path = 'tests/async_coordinator_tests.cpp'
before, after = source(BASE, path), source(TARGET, path)
old_cases, new_cases = cases(before), cases(after)
assert len(old_cases) == 18 and len(new_cases) == 29
assert len(set(new_cases)) == 29
assert [case for case in new_cases if case in old_cases] == old_cases
preservation, changes = [], []
for label, function in old_cases:
    old, new = body(before, function), body(after, function)
    missing = checks(old) - checks(new)
    assert not missing, (function, missing)
    record = {'case': label, 'function': function,
              'baseline_body_sha256': sha(old.encode()), 'target_body_sha256': sha(new.encode()),
              'byte_identical': old == new,
              'all_original_CHECK_expressions_retained': True,
              'CHECK_comparison_normalization': 'whitespace and original_response accessor parentheses only'}
    preservation.append(record)
    if old != new:
        changes.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                       fromfile=BASE + ':' + function, tofile=TARGET + ':' + function))
assert sum(item['byte_identical'] for item in preservation) == 15
(OUT / 'three-original-case-differences.patch').write_text(''.join(changes))
write('original-case-preservation.json', {'baseline': BASE, 'target': TARGET,
    'original_count': 18, 'current_count': 29, 'original_relative_order_preserved': True,
    'byte_identical_original_cases': 15, 'original_cases': preservation,
    'new_cases': [{'case': label, 'function': function} for label, function in new_cases if (label, function) not in old_cases]})

unchanged = ['CMakeLists.txt', 'Makefile', 'tests/gcc_asan_expected_tests.json', 'scripts/run_gcc_asan.py',
             'tests/test_support.hpp', 'src/scheduler.cpp', 'include/wls/scheduler.hpp', 'tests/scheduler_tests.cpp']
identities = {}
for filename in unchanged:
    original, target = git('show', BASE + ':' + filename), git('show', TARGET + ':' + filename)
    assert original == target, filename
    identities[filename] = {'baseline_sha256': sha(original), 'target_sha256': sha(target), 'byte_identical': True}
for marker in ('struct Gate {', 'struct Release {', 'struct Fixture {', 'void until('):
    old_start, new_start = before.index(marker), after.index(marker)
    old = span(before, before.index('{', old_start))
    new = span(after, after.index('{', new_start))
    assert old == new, marker
    identities[marker] = {'byte_identical': True, 'sha256': sha(old.encode())}
fixture_before = git('rev-parse', BASE + ':tests/fixtures').decode().strip()
fixture_after = git('rev-parse', TARGET + ':tests/fixtures').decode().strip()
assert fixture_before == fixture_after
identities['tests/fixtures'] = {'baseline_tree': fixture_before, 'target_tree': fixture_after, 'unchanged': True}
write('unchanged-guards-harness-and-registration-inputs.json', identities)

clang = EVIDENCE / 'final-clang-01'
run = EVIDENCE / 'final-clang-01-ctest-0002'
plan = json.loads((clang / 'test-plan.json').read_text())['tests']
catalog = json.loads(source(TARGET, 'tests/gcc_asan_expected_tests.json'))['tests']
actual_catalog = []
for test in plan:
    props = {item['name']: item['value'] for item in test['properties']}
    assert not props.get('DISABLED', False)
    actual_catalog.append({'name': test['name'], 'timeout': props['TIMEOUT']})
assert len(actual_catalog) == len(catalog) == 92
assert sorted(actual_catalog, key=lambda row: row['name']) == sorted(catalog, key=lambda row: row['name'])
completion = json.loads((run / 'completion.json').read_text())
assert completion['head'] == TARGET and completion['exit_code'] == 0
assert completion['source_unchanged'] and not completion['outer_timeout']
log = (clang / 'ctest-0002-original-logs/LastTest.log').read_text()
section = log[log.index('51/92 Testing: async_coordinator'):]
passed = re.findall(r'^PASS (.+)$', section, re.M)
assert passed == [label for label, _ in new_cases]
assert 'RESULT 29 passed, 0 failed' in section
assert not re.search(r'^(?:FAIL|SKIP) ', section, re.M)
assert 'RESULT 9 passed, 0 failed' in log[:log.index('51/92 Testing: async_coordinator')]
write('actual-method-execution-and-catalog.json', {'target': TARGET, 'ordinary_user_uid': 1000,
    'outer_umask': '0002', 'test_harness_private_fixture_umask': '0077 (unchanged original test_support.hpp)',
    'product_tests_launched_by_this_audit': False, 'retained_configuration': 'Clang strict focused',
    'executed_registrations': ['scheduler', 'async_coordinator'], 'registration_count': 92,
    'remaining_90_registrations_executed_in_this_configuration': False,
    'all_names_deadlines_match_unchanged_reviewed_catalog': True,
    'async_timeout_seconds': 180, 'async_methods': passed, 'async_method_count': len(passed),
    'scheduler_methods': 9, 'completion': completion,
    'lasttest_sha256': sha(log.encode())})

source_before = json.loads((run / 'source-before.json').read_text())
source_after = json.loads((run / 'source-after.json').read_text())
assert source_before == source_after
material = [path, 'tests/async_resource_fifo_cases.hpp', 'tests/async_resource_lifecycle_cases.hpp',
            'src/async_coordinator.cpp', 'include/wls/async_coordinator.hpp', *unchanged]
source_checks = {}
for filename in material:
    target_bytes = git('show', TARGET + ':' + filename)
    assert sha(target_bytes) == source_before[filename]['sha256']
    assert (REPO / filename).read_bytes() == target_bytes
    source_checks[filename] = source_before[filename]
binaries_before = json.loads((clang / 'binaries-before.json').read_text())
binaries_after = json.loads((clang / 'binaries-after.json').read_text())
assert binaries_before == binaries_after
for filename, expected in binaries_before.items():
    with (REPO / 'build-review-clang' / filename).open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected
write('execution-input-identity.json', {'target': TARGET, 'material_source_files': source_checks,
    'retained_source_inventory_count': len(source_before), 'source_before_equals_after': True,
    'material_sources_match_commit_and_worktree': True, 'binary_identities': binaries_before,
    'binary_before_equals_after_and_current_files': True})
print(json.dumps({'original_async_methods': 18, 'current_async_methods': 29,
    'original_byte_identical': 15, 'original_assertions_retained': True,
    'actual_target_clang_passes': {'async_coordinator': 29, 'scheduler': 9},
    'registered': 92, 'deadline_catalog_unchanged': True,
    'current_and_executed_source_binary_identities_match': True}, indent=2))
