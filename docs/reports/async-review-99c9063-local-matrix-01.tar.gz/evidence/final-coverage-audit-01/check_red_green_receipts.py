"""Verify retained text evidence. Does not compile, launch product, or edit repository."""
from pathlib import Path
import hashlib
import json

ROOT = Path('/mnt/d/codex-workspace/wls861-review-fixes-20261031-153649')
EVIDENCE = ROOT / 'evidence'
OUT = EVIDENCE / 'final-coverage-audit-01'
read_files = set()

def read(path):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    read_files.add(str(path.relative_to(ROOT)))
    return path.read_bytes()

def load(path):
    return json.loads(read(path))

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

index = load('evidence/red-green-index-v1.json')
rows = []
for row in index['rows']:
    directory = Path('evidence') / row['round']
    complete = load(directory / 'completion.json')
    assert complete['exit_code'] == row['exit'], row['round']
    assert complete['head'] == row['head'], row['round']
    assert complete['source_unchanged'] and not complete['outer_timeout'], row['round']
    assert load(directory / 'source-before.json') == load(directory / 'source-after.json')
    assert digest(read(directory / 'stdout.log')) == row['stdout_sha256']
    assert digest(read(directory / 'stderr.log')) == row['stderr_sha256']
    rows.append({'round': row['round'], 'exit': row['exit'], 'head': row['head'],
                 'source_before_after_equal': True, 'original_log_hashes_match': True})

attachment = 'attachments/ce518883/unpacked/independent_async_repros.cpp'
attachment_sha = digest(read(attachment))
assert attachment_sha == 'aec4981953945e2e714564623cb15006bec97d4703ca6d02a4baa3c6595f8f84'
probe_identities = []
for name in ['original-probes-baseline', 'original-probes-amend', 'original-probes-resource']:
    directory = Path('evidence') / name
    before = load(directory / 'identities-before.json')
    assert before == load(directory / 'identities-after.json')
    assert before[str(ROOT / attachment)] == attachment_sha
    receipt = load(directory / 'receipt.json')
    assert receipt['compile_exit'] == 0 and receipt['identities_unchanged']
    probe_identities.append({'name': name, 'before_after_equal': True, 'compile_exit': 0,
                             'runs': receipt['runs'], 'same_original_attachment': True})

frozen = load('evidence/frozen-local-repros/baseline-red-receipt.json')
for filename, expected in frozen['frozen_probe_inputs'].items():
    actual = read(filename)
    assert len(actual) == expected['bytes'] and digest(actual) == expected['sha256']
for name in ['frozen-green-amend', 'frozen-green-resource']:
    directory = Path('evidence') / name
    before = load(directory / 'before.json')
    after = load(directory / 'after.json')
    # These receipts capture inputs before compilation and add only the newly
    # built probe afterwards. Input values must remain exactly equal.
    probe = str(ROOT / directory / 'probe')
    assert set(after) == set(before) | {probe}
    assert {name: after[name] for name in before} == before
    assert digest(read(probe)) == after[probe]
    receipt = load(directory / 'receipt.json')
    assert receipt == {'compile_exit': 0, 'test_exit': 0,
                       'original_inputs_unchanged': True, 'binary_unchanged': True}
    for filename, expected in frozen['frozen_probe_inputs'].items():
        assert before[str(ROOT / filename)] == expected['sha256']
assert read('evidence/frozen-local-repros/async_resource_fifo_cases.hpp') == read('combined/tests/async_resource_fifo_cases.hpp')

correction = load('evidence/amend-replay-20261031/fixture-correction-03.json')
assert correction['previous_async_result']['passed'] == 19
assert correction['previous_async_result']['failed'] == 3
assert correction['previous_execution']['exit_code'] == 8
assert correction['production_source_changed_for_correction'] is False
assert correction['timeouts_or_assertions_relaxed'] is False
assert correction['failed_logs_preserved'] is True
assert correction['corrections'] == {'stale-cas': 'stalecas', 'terminal-amend': 'termamend', 'terminal-cancel': 'termcancel'}

result = {'classification': 'READ_ONLY_RETAINED_EVIDENCE_VERIFICATION',
          'product_executed_by_audit': False, 'rows': rows,
          'original_attachment_sha256': attachment_sha,
          'original_probe_identities': probe_identities,
          'frozen_red_green_source_inputs_match': True,
          'current_fifo_header_matches_frozen_red_green_header': True,
          'fixture_failure_and_correction_preserved': True,
          'historical_receipt_time_scope': 'The early baseline-red receipt predates original attachment execution; later original-probes receipts add execution without rewriting it.',
          'read_files': sorted(read_files)}
with (OUT / 'red-green-receipt-verification.json').open('x') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('rows','read_files','original_probe_identities')}, ensure_ascii=False, indent=2))
