"""Read completed retained text and create a NEW evidence package; execute nothing.

Preparation only: the author has not run this script or assembled any package.
Use --check-only or --assemble only after the root coordinator reviews the code.
No subprocess, imported evidence code, extraction, network or product access.
"""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile
import xml.etree.ElementTree as ET


TASK = Path(__file__).absolute().parents[2]
PREPARATION = "evidence/final-package-preparation-01"
OUTPUT = "evidence/review-final-package-01"
HEAD = "976466720e5fb17f6dcc67b0660b74d246996426"
ARCHIVE = "wls861-review-final-evidence-01.tar.gz"
MAX_FILE_BYTES = 32 * 1024 * 1024
MAX_TOTAL_BYTES = 128 * 1024 * 1024
MAX_FILES = 10000
MAX_DEPTH = 16
CONFIGURATIONS = {
    "release": ("0022", "0002"),
    "clang": ("0002",),
    "ubsan": ("0002",),
    "asan-affected": ("0002",),
}
ROUND_FILES = {
    "command.json", "completion.json", "process.json", "observations.jsonl",
    "source-before.json", "source-after.json", "stdout.log", "stderr.log",
}
SUMMARY_FILES = {
    "binaries-before.json", "binaries-after.json", "steps.json", "result.json",
    "test-plan.json", "junit-0022.xml", "junit-0002.xml",
}
CTEST_LOG_FILES = {
    "LastTest.log", "LastTest.log.tmp", "LastTestsFailed.log", "CTestCostData.txt",
    "CTestCheckpoint.txt",
}
TEXT_SUFFIXES = {
    ".json", ".jsonl", ".xml", ".log", ".txt", ".stdout", ".stderr",
    ".md", ".py", ".patch", ".sha256", ".sha256sums", ".csv", ".exit",
}
TEXT_NAMES = {"SHA256SUMS", "DRAFT-SHA256SUMS", "COMMIT", "TREE", "LastTest.log.tmp"}
BLOCKED_SUFFIXES = {
    ".exe", ".dll", ".so", ".a", ".o", ".obj", ".pyc", ".pyo",
    ".sqlite", ".sqlite3", ".db", ".pem", ".key", ".env", ".pfx", ".p12",
    ".crt", ".cer", ".der", ".zip", ".gz", ".tar", ".7z", ".bin",
}
BLOCKED_NAMES = {".env", ".netrc", "id_rsa", "id_ed25519", "credentials"}
SECRET_RULES = {
    "private-key-block": re.compile(r"-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----"),
    "pgp-private-key": re.compile(r"-----BEGIN PGP " r"PRIVATE KEY BLOCK-----"),
    "github-token": re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})\b"),
    "provider-key": re.compile(r"\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,}\b"),
    "aws-access-key": re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
    "authorization-value": re.compile(
        r"(?i)authorization\s*[:=]\s*[\"']?bearer\s+[A-Za-z0-9._~+/=-]{16,}"
    ),
}


class Refusal(Exception):
    """Only fixed explanations and safe paths/rule names enter public errors."""

    def __init__(self, code, detail, context=None):
        super().__init__(detail)
        self.code = code
        self.detail = detail
        self.context = context or {}


def require(condition, code, detail, **context):
    if not condition:
        raise Refusal(code, detail, context)


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def path_parts(name):
    require(isinstance(name, str), "UNSAFE_PATH", "Path is not a string")
    require(name and not name.startswith("/") and "\\" not in name,
            "UNSAFE_PATH", "Only relative POSIX paths are permitted")
    try:
        encoded = name.encode("utf-8", errors="strict")
    except UnicodeEncodeError:
        raise Refusal("UNSAFE_PATH", "Path is not strict UTF-8") from None
    require(len(encoded) <= 4096 and ":" not in name, "UNSAFE_PATH", "Path exceeds its portable text boundary")
    parts = name.split("/")
    require(all(p and p not in (".", "..") and not any(ord(c) < 32 or ord(c) == 127 for c in p)
                for p in parts), "UNSAFE_PATH", "Unsafe path component")
    require(len(parts) <= MAX_DEPTH, "UNSAFE_PATH", "Path exceeds the bounded depth")
    require(PurePosixPath(name).as_posix() == name, "UNSAFE_PATH", "Path is not canonical")
    return parts


def regular_text_name(name):
    path_parts(name)
    p = PurePosixPath(name)
    require(p.name not in BLOCKED_NAMES and p.suffix.lower() not in BLOCKED_SUFFIXES,
            "FORBIDDEN_FILE", "Binary, credential, database or archive filename is forbidden", path=name)
    require(p.name in TEXT_NAMES or p.suffix.lower() in TEXT_SUFFIXES,
            "UNREVIEWED_FILE_TYPE", "Selected filename has no reviewed text type", path=name)


def identity(st):
    return {"device": st.st_dev, "inode": st.st_ino, "size": st.st_size,
            "mode": stat.S_IMODE(st.st_mode), "links": st.st_nlink,
            "mtime_ns": st.st_mtime_ns, "ctime_ns": st.st_ctime_ns}


def directory_flags():
    return os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC


def open_absolute_directory(path):
    fd = os.open("/", directory_flags())
    try:
        for part in Path(path).parts[1:]:
            child = os.open(part, directory_flags(), dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


class Reader:
    """Anchor every component with no-follow directory handles; never follow links."""

    def __init__(self):
        self.root_fd = open_absolute_directory(TASK)
        self.root_identity = identity(os.fstat(self.root_fd))
        self.device = self.root_identity["device"]
        self.cache = {}
        self.directories = {}
        self.total = 0
        self.findings = []

    def close(self):
        os.close(self.root_fd)

    def directory(self, name):
        fd = os.dup(self.root_fd)
        try:
            for part in path_parts(name):
                child = os.open(part, directory_flags(), dir_fd=fd)
                os.close(fd)
                fd = child
                require(os.fstat(fd).st_dev == self.device, "OTHER_FILESYSTEM",
                        "Nested mounts are not selected", path=name)
            return fd
        except BaseException:
            os.close(fd)
            raise

    def entries(self, name, remember=True):
        fd = self.directory(name)
        try:
            with os.scandir(fd) as entries:
                result = [(e.name, e.stat(follow_symlinks=False).st_mode) for e in entries]
            result.sort()
        finally:
            os.close(fd)
        for child, mode in result:
            path_parts(name + "/" + child)
            require(stat.S_ISDIR(mode) or stat.S_ISREG(mode), "LINK_OR_SPECIAL_FILE",
                    "Selected tree contains a link or special file", path=name + "/" + child)
        if remember:
            if name in self.directories:
                require(self.directories[name] == result, "CHANGED_DIRECTORY",
                        "Directory changed while selecting evidence", path=name)
            else:
                self.directories[name] = result
        return result

    def exists(self, name):
        parts = path_parts(name)
        fd = self.directory("/".join(parts[:-1])) if len(parts) > 1 else os.dup(self.root_fd)
        try:
            try:
                st = os.stat(parts[-1], dir_fd=fd, follow_symlinks=False)
            except FileNotFoundError:
                return False
            require(not stat.S_ISLNK(st.st_mode), "LINK_OR_SPECIAL_FILE",
                    "A selected path is a symbolic link", path=name)
            return True
        finally:
            os.close(fd)

    def read(self, name, fresh=False):
        regular_text_name(name)
        if not fresh and name in self.cache:
            return self.cache[name][0]
        parts = path_parts(name)
        parent = self.directory("/".join(parts[:-1])) if len(parts) > 1 else os.dup(self.root_fd)
        fd = None
        try:
            fd = os.open(parts[-1], os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK,
                         dir_fd=parent)
            before = os.fstat(fd)
            require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1,
                    "LINK_OR_SPECIAL_FILE", "Input must be a regular file with one link", path=name)
            require(before.st_dev == self.device and before.st_size <= MAX_FILE_BYTES,
                    "INPUT_BOUNDARY", "Input exceeds the filesystem or size boundary", path=name)
            chunks, remaining = [], MAX_FILE_BYTES + 1
            while remaining:
                part = os.read(fd, min(1024 * 1024, remaining))
                if not part:
                    break
                chunks.append(part)
                remaining -= len(part)
            raw = b"".join(chunks)
            after = os.fstat(fd)
            require(len(raw) == after.st_size and len(raw) <= MAX_FILE_BYTES and identity(before) == identity(after),
                    "CHANGED_INPUT", "Input changed during bounded read", path=name)
        finally:
            if fd is not None:
                os.close(fd)
            os.close(parent)
        marker = identity(after)
        marker["sha256"] = digest(raw)
        if fresh:
            require(name in self.cache and self.cache[name][1] == marker,
                    "CHANGED_INPUT", "Original evidence identity changed", path=name)
            return raw
        self.check_text(raw, name)
        self.total += len(raw)
        require(self.total <= MAX_TOTAL_BYTES and len(self.cache) < MAX_FILES,
                "PACKAGE_BOUND", "Input text exceeds package limits")
        self.cache[name] = (raw, marker)
        return raw

    def check_text(self, raw, name):
        require(not raw.startswith((b"\x7fELF", b"MZ", b"PK\x03\x04", b"\x1f\x8b", b"SQLite format 3")),
                "BINARY_CONTENT", "Binary magic is forbidden in text evidence", path=name)
        require(not any(b < 32 and b not in (9, 10, 12, 13, 27) for b in raw),
                "BINARY_CONTENT", "Unexpected control bytes in selected text", path=name)
        try:
            text = raw.decode("utf-8", errors="strict")
        except UnicodeDecodeError:
            raise Refusal("NON_UTF8", "Selected file is not strict UTF-8", {"path": name}) from None
        for rule, pattern in SECRET_RULES.items():
            for match in pattern.finditer(text):
                self.findings.append({"path": name, "rule": rule,
                                      "line": text.count("\n", 0, match.start()) + 1})
        return text

    def json(self, name):
        def object_pairs(pairs):
            result = {}
            for key, value in pairs:
                require(key not in result, "AMBIGUOUS_JSON", "Duplicate JSON key", path=name)
                result[key] = value
            return result

        def invalid_constant(_value):
            raise Refusal("AMBIGUOUS_JSON", "Non-finite JSON constant", {"path": name})

        try:
            return json.loads(self.read(name).decode("utf-8"), object_pairs_hook=object_pairs,
                              parse_constant=invalid_constant)
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise Refusal("INVALID_JSON", "Selected JSON receipt is incomplete or invalid", {"path": name}) from None

    def unchanged(self):
        root_fd = open_absolute_directory(TASK)
        try:
            root_now = identity(os.fstat(root_fd))
            require((root_now["device"], root_now["inode"]) ==
                    (self.root_identity["device"], self.root_identity["inode"]),
                    "CHANGED_ROOT", "Task root was replaced")
        finally:
            os.close(root_fd)
        for name, expected in self.directories.items():
            require(self.entries(name, remember=False) == expected, "CHANGED_DIRECTORY",
                    "Selected directory membership changed", path=name)
        for name in sorted(self.cache):
            self.read(name, fresh=True)


def timestamp(value, path):
    require(isinstance(value, str) and bool(value), "PENDING_RECEIPT", "Completion timestamp absent", path=path)
    try:
        parsed = dt.datetime.fromisoformat(value)
    except ValueError:
        raise Refusal("PENDING_RECEIPT", "Invalid completion timestamp", {"path": path}) from None
    require(parsed.tzinfo is not None, "PENDING_RECEIPT", "Completion timestamp lacks a timezone", path=path)
    return parsed


class Selection:
    def __init__(self, reader):
        self.reader = reader
        self.members = {}
        self.runs = []
        self.catalog = None
        self.inputs = None
        self.collector_observed_result = None
        self.collector_consistency = None

    def add(self, name, category):
        raw = self.reader.read(name)
        if name in self.members:
            require(self.members[name]["category"] == category, "DUPLICATE_MEMBER",
                    "Member selected with conflicting categories", path=name)
            return raw
        self.members[name] = {"source": str(TASK / name), "size": len(raw),
                              "sha256": digest(raw), "category": category,
                              "source_identity": self.reader.cache[name][1],
                              "encoding": "UTF-8", "archive_mode": "0644"}
        return raw

    def tree(self, directory, category):
        for name, mode in self.reader.entries(directory):
            relative = directory + "/" + name
            if stat.S_ISDIR(mode):
                self.tree(relative, category)
            else:
                self.add(relative, category)

    def recorded_round(self, name):
        directory = "evidence/" + name
        entries = self.reader.entries(directory)
        require({n for n, _ in entries} == ROUND_FILES and all(stat.S_ISREG(m) for _, m in entries),
                "PENDING_OR_UNREVIEWED_ROUND", "Recorder must have its exact completed file set", path=directory)
        command = self.reader.json(directory + "/command.json")
        completion = self.reader.json(directory + "/completion.json")
        before = self.reader.json(directory + "/source-before.json")
        after = self.reader.json(directory + "/source-after.json")
        require(completion.get("source_unchanged") is True and before == after and len(before) == 785,
                "UNSTABLE_SOURCE", "Recorder source identity is incomplete or changed", path=directory)
        if self.inputs is None:
            self.inputs = before
        require(before == self.inputs, "UNSTABLE_SOURCE", "Configuration source collections differ", path=directory)
        require(command.get("head") == completion.get("head") == HEAD and command.get("uid") == 1000,
                "WRONG_EXECUTION_IDENTITY", "Recorder head or ordinary-user identity differs", path=directory)
        require(command.get("argv") == completion.get("argv") and command.get("argv"),
                "INCONSISTENT_ROUND", "Recorder command and completion differ", path=directory)
        start = timestamp(completion.get("started_at_utc"), directory)
        end = timestamp(completion.get("finished_at_utc"), directory)
        require(end >= start and command.get("started_at_utc") == completion.get("started_at_utc"),
                "INCONSISTENT_ROUND", "Recorder time range differs", path=directory)
        require(type(completion.get("exit_code")) is int and type(completion.get("outer_timeout")) is bool,
                "PENDING_RECEIPT", "Recorder has no final exit/timeout status", path=directory)
        require(type(completion.get("seconds")) in (int, float) and completion["seconds"] >= 0,
                "PENDING_RECEIPT", "Recorder has no final duration", path=directory)
        for child, _mode in entries:
            self.add(directory + "/" + child, "completed-recorder-round")
        return command, completion, before

    def junit(self, path, expected_names, completion):
        exists = self.reader.exists(path)
        if not exists:
            require(completion["exit_code"] != 0 or completion["outer_timeout"],
                    "MISSING_SUCCESS_EVIDENCE", "Successful CTest requires its original JUnit", path=path)
            return {"available": False, "reason": "ABSENT_AFTER_FAILED_OR_TIMED_OUT_COMPLETION",
                    "observed_names": [], "failed_names": [], "skipped_names": []}
        raw = self.reader.read(path)
        require(b"<!DOCTYPE" not in raw.upper() and b"<!ENTITY" not in raw.upper(),
                "UNSAFE_XML", "DTD/entity declarations are not accepted", path=path)
        try:
            root = ET.fromstring(raw)
        except ET.ParseError:
            require(completion["exit_code"] != 0 or completion["outer_timeout"],
                    "INCOMPLETE_SUCCESS_XML", "Successful CTest JUnit cannot be partial", path=path)
            return {"available": True, "reason": "PARTIAL_XML_AFTER_FAILED_OR_TIMED_OUT_COMPLETION",
                    "observed_names": [], "failed_names": [], "skipped_names": []}
        cases = list(root.iter("testcase"))
        names = [c.attrib.get("name") for c in cases]
        failures = [c.attrib.get("name") for c in cases
                    if c.find("failure") is not None or c.find("error") is not None]
        skipped = [c.attrib.get("name") for c in cases
                   if c.find("skipped") is not None or c.attrib.get("status") in ("notrun", "disabled")]
        exact = len(names) == len(expected_names) and set(names) == expected_names
        if completion["exit_code"] == 0 and not completion["outer_timeout"]:
            require(exact and not failures and not skipped, "INCONSISTENT_SUCCESS_RESULT",
                    "Successful CTest requires the exact unskipped selection", path=path)
        return {"available": True, "reason": "COMPLETE_XML", "exact_expected_selection": exact,
                "observed_names": names, "failed_names": failures, "skipped_names": skipped}

    def configuration(self, config, masks):
        prefix = "final-" + config + "-01"
        directory = "evidence/" + prefix
        result = self.reader.json(directory + "/result.json")
        require(result.get("configuration") == config and result.get("head") == HEAD,
                "PENDING_RESULT", "Configuration result is absent, incomplete or from another input", path=directory)
        require(result.get("binary_identity_unchanged") is True and result.get("full_registered_count") == 92,
                "UNSTABLE_BINARY", "Configuration identity/catalog verification is incomplete", path=directory)
        before = self.reader.json(directory + "/binaries-before.json")
        after = self.reader.json(directory + "/binaries-after.json")
        require(before and before == after, "UNSTABLE_BINARY", "Binary identity manifests differ", path=directory)
        steps = result.get("steps")
        require(isinstance(steps, list) and steps == self.reader.json(directory + "/steps.json"),
                "PENDING_RESULT", "Configuration final steps are missing or differ", path=directory)
        required_steps = ["configure", "build"] + ["ctest-" + mask for mask in masks]
        require([s.get("name") for s in steps] == required_steps,
                "PENDING_RESULT", "All required configuration steps must have ended", path=directory)
        plan = self.reader.json(directory + "/test-plan.json")
        tests = plan.get("tests", [])
        catalog = {}
        for item in tests:
            name = item.get("name")
            limits = [p.get("value") for p in item.get("properties", []) if p.get("name") == "TIMEOUT"]
            require(isinstance(name, str) and name not in catalog and len(limits) == 1,
                    "BAD_CATALOG", "Registration names/deadlines are ambiguous", path=directory)
            catalog[name] = limits[0]
        require(len(catalog) == 92 and catalog.get("async_coordinator") == 180,
                "BAD_CATALOG", "Reviewed 92-registration catalog is missing", path=directory)
        if self.catalog is None:
            self.catalog = catalog
        require(catalog == self.catalog, "BAD_CATALOG", "Configuration names/deadlines differ", path=directory)
        expected = set(catalog) if config == "release" else {"scheduler", "async_coordinator"}
        completions = {}
        for step in steps:
            round_name = prefix + "-" + step["name"]
            require(step.get("round") == round_name and type(step.get("exit")) is int,
                    "INCONSISTENT_RESULT", "Configuration step has no final recorded exit", path=directory)
            command, completion, inputs = self.recorded_round(round_name)
            wrapper_exit = 124 if completion["outer_timeout"] else completion["exit_code"] % 256
            require(step["exit"] == wrapper_exit, "INCONSISTENT_RESULT",
                    "Recorder wrapper and original final exit disagree", path=round_name)
            completions[step["name"]] = (command, completion, inputs)
        # Nonzero CTest exits are valid retained evidence. Never require pass to archive.
        for mask in masks:
            command, completion, _inputs = completions["ctest-" + mask]
            require(command.get("umask") == mask, "WRONG_EXECUTION_IDENTITY",
                    "CTest umask differs from its declared round", path=directory)
            observed = self.junit(directory + "/junit-" + mask + ".xml", expected, completion)
            logs = directory + "/ctest-" + mask + "-original-logs"
            if self.reader.exists(logs):
                log_entries = self.reader.entries(logs)
                require(all(stat.S_ISREG(mode) and name in CTEST_LOG_FILES for name, mode in log_entries),
                        "UNREVIEWED_LOG", "Original CTest log tree has unreviewed members", path=logs)
                if completion["exit_code"] == 0 and not completion["outer_timeout"]:
                    require(any(name == "LastTest.log" for name, _mode in log_entries),
                            "MISSING_SUCCESS_EVIDENCE", "Successful CTest requires complete LastTest", path=logs)
            else:
                require(completion["exit_code"] != 0 or completion["outer_timeout"],
                        "MISSING_SUCCESS_EVIDENCE", "Successful CTest requires original logs", path=logs)
            self.runs.append({"configuration": config, "umask": mask, "registered": 92,
                              "selected": len(expected), "outside_selection_notrun": 92 - len(expected),
                              "exit_code": completion["exit_code"], "wrapper_exit": 124 if completion["outer_timeout"] else completion["exit_code"] % 256,
                              "outer_timeout": completion["outer_timeout"], "seconds": completion["seconds"],
                              "junit": observed, "original_logs_present": self.reader.exists(logs)})
        for name, mode in self.reader.entries(directory):
            relative = directory + "/" + name
            if stat.S_ISDIR(mode):
                require(name in {"ctest-" + m + "-original-logs" for m in masks},
                        "UNREVIEWED_SUMMARY", "Unexpected configuration subdirectory", path=relative)
                for log_name, _log_mode in self.reader.entries(relative):
                    self.add(relative + "/" + log_name, "original-complete-or-failed-ctest-logs")
            else:
                require(name in SUMMARY_FILES and not (name.startswith("junit-") and name not in
                        {"junit-" + m + ".xml" for m in masks}),
                        "UNREVIEWED_SUMMARY", "Unexpected configuration summary file", path=relative)
                self.add(relative, "completed-configuration-summary")

    def final_matrix(self):
        name = "evidence/local-final-matrix.json"
        matrix = self.reader.json(name)
        require(matrix.get("product_commit") == HEAD and matrix.get("source_inputs") == 785 and
                matrix.get("tests_launched_by_verifier") == 0 and matrix.get("historical_failures_closed") is False,
                "PENDING_MATRIX", "Root final matrix has no completed identity/limits verification", path=name)
        timestamp(matrix.get("verified_at_utc"), name)
        require(matrix.get("observed_selected_result") in ("PASS", "FAIL_OR_INCOMPLETE") and
                matrix.get("evidence_consistency_check") == "COMPLETE; this is not a product gate runner",
                "PENDING_MATRIX", "Root matrix must distinguish consistency completion from product outcome", path=name)
        require(set(matrix.get("configurations", {})) == set(CONFIGURATIONS),
                "PENDING_MATRIX", "Root final matrix lacks a required configuration", path=name)
        manifest = matrix.get("source_manifest")
        require(manifest == "final-clang-01-ctest-0002/source-before.json" and
                digest(self.reader.read("evidence/" + manifest)) == matrix.get("source_manifest_sha256"),
                "INCONSISTENT_MATRIX", "Root final matrix source manifest differs", path=name)
        for config, masks in CONFIGURATIONS.items():
            entry = matrix["configurations"][config]
            require(entry.get("binary_identity_unchanged") is True,
                    "INCONSISTENT_MATRIX", "Root matrix binary identity is not verified", path=name)
            runs = entry.get("runs", [])
            require([r.get("umask") for r in runs] == list(masks),
                    "INCONSISTENT_MATRIX", "Root matrix run selection differs", path=name)
            for run in runs:
                completion = self.reader.json("evidence/final-" + config + "-01-ctest-" + run["umask"] + "/completion.json")
                require(run.get("completion") == completion,
                        "INCONSISTENT_MATRIX", "Root matrix does not contain the original final completion", path=name)
                observed = next(item for item in self.runs if item["configuration"] == config and item["umask"] == run["umask"])
                junit = observed["junit"]
                passed = (completion["exit_code"] == 0 and not completion["outer_timeout"] and
                          junit.get("exact_expected_selection") is True and not junit["failed_names"] and
                          not junit["skipped_names"])
                require(run.get("observed_selected_result") == ("PASS" if passed else "FAIL_OR_INCOMPLETE"),
                        "INCONSISTENT_MATRIX", "Collector selected outcome contradicts original observations", path=name)
                observed["collector_observed_selected_result"] = run["observed_selected_result"]
                observed["collector_reported_counts"] = {key: run.get(key) for key in
                    ("passed", "failed_names", "timeout_names", "skipped_or_notrun_names", "selected_or_reported", "executed")}
        all_selected_passed = (all(run["collector_observed_selected_result"] == "PASS" for run in self.runs) and
                               all(step["exit"] == 0 for cfg in matrix["configurations"].values() for step in cfg["steps"]))
        require(matrix["observed_selected_result"] == ("PASS" if all_selected_passed else "FAIL_OR_INCOMPLETE"),
                "INCONSISTENT_MATRIX", "Collector aggregate outcome contradicts its completed steps", path=name)
        self.collector_observed_result = matrix["observed_selected_result"]
        self.collector_consistency = matrix["evidence_consistency_check"]
        self.add(name, "root-final-local-matrix-with-true-failures-and-limits")

    def audits(self):
        directory = "evidence/final-coverage-audit-01"
        receipt = self.reader.json(directory + "/completion-receipt.json")
        require(receipt.get("status") == "BOUNDED_EVIDENCE_AUDIT_COMPLETE" and receipt.get("target") == HEAD,
                "PENDING_AUDIT", "Final coverage audit has not completed", path=directory)
        timestamp(receipt.get("completed_at_utc"), directory)
        report = receipt.get("report", {})
        require(report.get("path") == directory + "/review.md" and
                digest(self.reader.read(report["path"])) == report.get("sha256"),
                "INCONSISTENT_AUDIT", "Coverage review report hash differs", path=directory)
        for child, claimed in receipt.get("manifests", {}).items():
            require("/" not in child and digest(self.reader.read(directory + "/" + child)) == claimed.get("sha256"),
                    "INCONSISTENT_AUDIT", "Coverage review manifest hash differs", path=directory)
        self.tree(directory, "bounded-coverage-audit-including-failed-utility-attempts")
        review = "evidence/delivery-draft-review-01"
        if self.reader.exists(review):
            completed = self.reader.json(review + "/review-receipt.json")
            timestamp(completed.get("completed_at"), review)
            require(completed.get("scope") == "NON_AUTHOR_DELIVERY_DOCUMENT_REVIEW" and
                    completed.get("formal_coordinator_approval") is False and
                    digest(self.reader.read(review + "/review.md")) == completed.get("review_sha256"),
                    "PENDING_AUDIT", "Draft review has no complete bounded receipt", path=review)
            self.tree(review, "non-author-draft-document-review-not-formal-approval")
        verifier_review = "evidence/local-verifier-review-01"
        completed = self.reader.json(verifier_review + "/completion-receipt.json")
        timestamp(completed.get("completed_at_utc"), verifier_review)
        require(completed.get("status") == "BOUNDED_STATIC_REVIEW_COMPLETE" and
                digest(self.reader.read("verify_local_final.py")) == completed.get("reviewed_script_sha256") and
                digest(self.reader.read(verifier_review + "/review.md")) == completed.get("report", {}).get("sha256"),
                "PENDING_AUDIT", "Local verifier review or reviewed source identity differs", path=verifier_review)
        self.tree(verifier_review, "non-author-local-verifier-static-review-not-product-execution")

    def remote_summary(self):
        directory = "evidence/remote-9764667-01"
        freeze = self.reader.json(directory + "/FREEZE.json")
        final = self.reader.json(directory + "/FINAL.json")
        for child, key in (("FINAL.json", "final_json_sha256"), ("FINAL.md", "final_md_sha256"),
                           ("SHA256SUMS", "sha256sums_sha256")):
            require(digest(self.reader.read(directory + "/" + child)) == freeze.get(key),
                    "INCONSISTENT_REMOTE_FREEZE", "Frozen remote summary digest differs", path=child)
        require(final.get("source_sha") == HEAD and final.get("completed_workflows") == 7 and
                final.get("completed_jobs") == 17 and final.get("source_files_verified") == 785,
                "INCONSISTENT_REMOTE_FREEZE", "Remote summary is not the frozen 9764667 record")
        require(freeze.get("total_bytes") == 57519077,
                "INCONSISTENT_REMOTE_FREEZE", "Original remote asset boundary differs")
        for child in ("FINAL.md", "FINAL.json", "FREEZE.json", "SHA256SUMS"):
            self.add(directory + "/" + child, "frozen-9764667-ci-summary-original-assets-external")

    def all(self):
        require(not self.reader.exists(OUTPUT), "OUTPUT_EXISTS", "Output must be a new independent directory")
        self.tree("intake", "ordinary-user-data-disk-intake-and-dependency-history")
        for config, masks in CONFIGURATIONS.items():
            self.configuration(config, masks)
        self.final_matrix()
        self.audits()
        self.remote_summary()
        for name in ("run_recorded.py", "validate_candidate.py", "verify_local_final.py"):
            self.add(name, "execution-or-readonly-verifier-source-inert-text")
        for name in ("assemble_final_evidence.py", "README.md", "preparation-receipt.json", "SHA256SUMS"):
            self.add(PREPARATION + "/" + name, "packager-source-and-reviewed-usage-inert-text")
        require(set(self.reader.cache) == set(self.members), "INTERNAL_SELECTION_ERROR",
                "A validated source was not assigned an archive category")
        require(not self.reader.findings, "SECRET_REVIEW_REQUIRED",
                "Credential-like patterns require human review; original files are unchanged",
                findings_without_values=self.reader.findings)
        self.reader.unchanged()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def exclusive_output(fd, name, data):
    require(len(path_parts(name)) == 1, "UNSAFE_OUTPUT", "Output filename is not a simple component")
    raw_fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                     0o600, dir_fd=fd)
    with os.fdopen(raw_fd, "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def write_block_report(reader, refusal):
    """Never print matched values, delete originals, or overwrite a prior refusal."""
    name = "blocked-" + dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ") + "-" + str(os.getpid()) + ".json"
    payload = {"status": "BLOCKED_NO_COMPLETE_PACKAGE", "at": utc(), "code": refusal.code,
               "detail": refusal.detail, "safe_context": refusal.context,
               "original_files_edited_or_deleted": False}
    fd = reader.directory(PREPARATION)
    try:
        exclusive_output(fd, name, json_bytes(payload))
    finally:
        os.close(fd)
    print(json.dumps({"status": "BLOCKED_NO_COMPLETE_PACKAGE", "code": refusal.code,
                      "report": str(TASK / PREPARATION / name)}), file=sys.stderr)


def assemble(selection):
    reader = selection.reader
    readme = (
        "WLS861 final local matrix and first 9764667 remote summary\n\n"
        "All archive members are inert UTF-8 text at mode 0644; execute none.\n"
        "Exact commands, nonzero exits, original complete or failed logs, source and\n"
        "binary manifests retain their original bytes. A failed test is archivable;\n"
        "this package does not turn failed, timed-out, skipped or NOT_RUN work green.\n"
        "Release selected 92 twice; local Clang/UBSan/ASan selected only two each.\n"
        "The other 90 in each focused local configuration remain NOT_RUN. Overall\n"
        "LOCAL_VALIDATION_COMPLETE is not promoted by archive completion. Historical\n"
        "GCC/Clang/live_workflow causes remain OPEN and Windows 11 ordinary-user\n"
        "acceptance remains NOT_RUN. Bounded engineering audits are not formal\n"
        "coordinator acceptance or merge authorization.\n\n"
        "Only FINAL.md, FINAL.json, FREEZE.json and SHA256SUMS represent the first\n"
        "9764667 remote CI in this archive. The 57,519,077-byte original asset set\n"
        "remains external at " + str(TASK / "evidence/remote-9764667-01") + ".\n"
        "FINAL records the actual GitHub run/artifact identities. No remote assets\n"
        "were downloaded, changed or executed by this packager. Its SHA256SUMS\n"
        "describes external files too; absence from this small archive is explicit.\n"
        "Final later documentation-SHA CI requires its separate receipt.\n\n"
        "MEMBERS.json lists original paths, categories and hashes, excluding its own\n"
        "self-reference. index.json beside the archive hashes every archive member,\n"
        "including MEMBERS.json; receipt.json and SHA256SUMS seal the full package.\n"
        "Completion is proven only by receipt.json status COMPLETE, verified members\n"
        "and before/after unchanged originals. An archive without that receipt is\n"
        "an incomplete attempt and must not be described as a completed package.\n"
    ).encode("utf-8")
    members = dict(selection.members)
    payload = {name: reader.cache[name][0] for name in selection.members}
    members["README.txt"] = {"source": None, "size": len(readme), "sha256": digest(readme),
                             "category": "generated-package-scope-and-limits", "encoding": "UTF-8", "archive_mode": "0644"}
    payload["README.txt"] = readme
    manifest = json_bytes({"format": "wls861-final-text-members-v1", "members": members,
                           "self_manifest_excluded_from_this_member_list": True,
                           "complete_member_list_with_manifest_hash": "external index.json"})
    payload["MEMBERS.json"] = manifest
    members["MEMBERS.json"] = {"source": None, "size": len(manifest), "sha256": digest(manifest),
                               "category": "generated-per-member-path-category-hash-manifest", "encoding": "UTF-8", "archive_mode": "0644"}
    for name, data in payload.items():
        path_parts(name)
        require(not name.startswith("/") and len(data) <= MAX_FILE_BYTES,
                "INTERNAL_SELECTION_ERROR", "Generated archive member violates bounds")
        reader.check_text(data, name)
    require(sum(len(data) for data in payload.values()) <= MAX_TOTAL_BYTES,
            "PACKAGE_BOUND", "Generated text payload exceeds the total package bound")
    require(not reader.findings, "SECRET_REVIEW_REQUIRED", "Generated metadata contains a credential-like pattern",
            findings_without_values=reader.findings)
    reader.unchanged()
    evidence_fd = reader.directory("evidence")
    try:
        os.mkdir("review-final-package-01", 0o700, dir_fd=evidence_fd)
        output_fd = os.open("review-final-package-01", directory_flags(), dir_fd=evidence_fd)
    finally:
        os.close(evidence_fd)
    try:
        started_bytes = json_bytes({"at": utc(), "status": "INCOMPLETE_UNTIL_RECEIPT"})
        exclusive_output(output_fd, "ASSEMBLY-STARTED.json", started_bytes)
        archive_fd = os.open(ARCHIVE, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                             0o600, dir_fd=output_fd)
        with os.fdopen(archive_fd, "wb") as stream:
            with gzip.GzipFile(filename="", fileobj=stream, mode="wb", mtime=0, compresslevel=6) as compressed:
                with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                    for name in sorted(members):
                        info = tarfile.TarInfo(name)
                        info.size = len(payload[name])
                        info.mode, info.uid, info.gid, info.mtime = 0o644, 0, 0, 0
                        info.uname = info.gname = ""
                        archive.addfile(info, io.BytesIO(payload[name]))
            stream.flush()
            os.fsync(stream.fileno())
        archive_fd = os.open(ARCHIVE, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=output_fd)
        with os.fdopen(archive_fd, "rb") as stream:
            archive_bytes = stream.read(MAX_TOTAL_BYTES + 1)
        require(len(archive_bytes) <= MAX_TOTAL_BYTES, "PACKAGE_BOUND", "Archive exceeds the output bound")
        verified = set()
        with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as archive:
            for member in archive:
                path_parts(member.name)
                require(member.isfile() and not member.issym() and not member.islnk() and
                        member.name in members and member.name not in verified and member.mode == 0o644 and
                        member.uid == member.gid == member.mtime == 0,
                        "ARCHIVE_MISMATCH", "Archive metadata or membership differs")
                expected = members[member.name]
                require(member.size == expected["size"], "ARCHIVE_MISMATCH", "Archive size differs")
                extracted = archive.extractfile(member)
                require(extracted is not None, "ARCHIVE_MISMATCH", "Regular member has no data")
                with extracted:
                    raw = extracted.read(member.size + 1)
                require(len(raw) == expected["size"] and digest(raw) == expected["sha256"],
                        "ARCHIVE_MISMATCH", "Archive member hash differs")
                reader.check_text(raw, member.name)
                verified.add(member.name)
        require(verified == set(members) and not reader.findings,
                "ARCHIVE_MISMATCH", "Archive verification or secret scan differs")
        reader.unchanged()  # Real post-archive reread, not only a preflight comparison.
        index = {"format": "wls861-final-text-evidence-index-v1", "created_at": utc(), "uid": os.getuid(),
                 "product_input": HEAD, "archive": {"name": ARCHIVE, "bytes": len(archive_bytes), "sha256": digest(archive_bytes)},
                 "member_count": len(members), "members": dict(sorted(members.items())),
                 "categories": dict(sorted(collections.Counter(m["category"] for m in members.values()).items())),
                 "actual_local_runs": selection.runs, "failed_tests_are_preserved_not_rejected": True,
                 "collector_evidence_consistency_check": selection.collector_consistency,
                 "collector_observed_selected_result": selection.collector_observed_result,
                 "local_validation_complete_promoted": False, "historical_failures_closed": False,
                 "windows_11_ordinary_user_acceptance": "NOT_RUN", "formal_coordinator_acceptance": "NOT_GRANTED",
                 "external_remote_original_bytes": 57519077,
                 "external_remote_original_path": str(TASK / "evidence/remote-9764667-01"),
                 "verification": {"strict_utf8": True, "regular_members_only": True, "no_links_or_traversal": True,
                                  "all_member_hashes_verified": True, "original_files_unchanged_before_and_after_archive": True,
                                  "configured_credential_pattern_matches": [], "archived_code_executed": False,
                                  "product_or_compiler_or_network_launched": False}}
        index_bytes = json_bytes(index)
        exclusive_output(output_fd, "index.json", index_bytes)
        receipt_bytes = json_bytes({"status": "COMPLETE", "completed_at": utc(), "product_input": HEAD,
                                    "archive_sha256": digest(archive_bytes), "index_sha256": digest(index_bytes),
                                    "members": len(members), "original_files_unchanged": True,
                                    "collector_observed_selected_result": selection.collector_observed_result,
                                    "scope": "Text evidence freeze; not product validation success or formal acceptance"})
        sums = "".join(value + "  " + name + "\n" for name, value in
                       ((ARCHIVE, digest(archive_bytes)), ("index.json", digest(index_bytes)),
                        ("ASSEMBLY-STARTED.json", digest(started_bytes)), ("receipt.json", digest(receipt_bytes))))
        exclusive_output(output_fd, "SHA256SUMS", sums.encode("utf-8"))
        # Publish the COMPLETE marker last. Interrupted attempts retain their
        # existing partial outputs and cannot be mistaken for a sealed package.
        exclusive_output(output_fd, "receipt.json", receipt_bytes)
        os.fsync(output_fd)
        print(json.dumps({"status": "COMPLETE", "output": str(TASK / OUTPUT), "members": len(members),
                          "archive_sha256": digest(archive_bytes), "index_sha256": digest(index_bytes),
                          "collector_observed_selected_result": selection.collector_observed_result,
                          "failed_or_timed_out_runs": sum(r["exit_code"] != 0 or r["outer_timeout"] for r in selection.runs)}))
    finally:
        os.close(output_fd)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-only", action="store_true", help="Read completed evidence and report readiness; create no package")
    mode.add_argument("--assemble", action="store_true", help="After review, create the new independent text-only package")
    args = parser.parse_args()
    require(os.getuid() == 1000, "ORDINARY_USER_REQUIRED", "Run as the recorded ordinary UID 1000")
    reader = Reader()
    try:
        selection = Selection(reader)
        selection.all()
        if args.check_only:
            print(json.dumps({"status": "READY_NO_PACKAGE_CREATED", "selected_files": len(selection.members),
                              "selected_bytes": reader.total, "local_runs": selection.runs,
                              "collector_evidence_consistency_check": selection.collector_consistency,
                              "collector_observed_selected_result": selection.collector_observed_result,
                              "overall_local_validation_complete_promoted": False}))
        else:
            assemble(selection)
    except Refusal as refusal:
        write_block_report(reader, refusal)
        return 2
    except OSError as error:
        # Never copy OS exception text, which may contain sensitive file values.
        write_block_report(reader, Refusal("FILESYSTEM_NOT_READY_OR_CHANGED",
                           "A required path is missing, unsafe, inaccessible or changed",
                           {"errno": error.errno, "exception_type": type(error).__name__}))
        return 2
    except Exception as error:
        write_block_report(reader, Refusal("INVALID_OR_UNSUPPORTED_RECEIPT",
                           "A required receipt shape or archive invariant is invalid",
                           {"exception_type": type(error).__name__}))
        return 2
    finally:
        reader.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
