# 最终本机矩阵文本包：待 root 审阅执行

脚本 `assemble_final_evidence.py` 目前仅已编写，作者没有运行其 `--check-only` 或 `--assemble`，
也没有创建 `evidence/review-final-package-01/`。它不启动产品、编译、安装或网络，不执行原证据代码，
不修改combined或原文件。只使用Python标准库，目标环境是本机Linux普通UID1000。

## 执行前条件

先由root确认Release两种umask与后续受影响UBSan/ASan均已真实结束，四个配置的 `result.json` 已写完，
然后执行本任务根的只读 `verify_local_final.py` 生成真实 `evidence/local-final-matrix.json`。
工具接受真实非零测试退出码、failed/timeout/skipped/NOT_RUN；不能通过填零、重写日志或删失败来满足条件。
配置结果或recorder completion缺失、source_unchanged不成立、source/binary清单不同才会阻断，不把未完成日志打包成结果。

审阅代码后，在任务根使用现有普通用户和系统Python即可：

```sh
cd /mnt/d/codex-workspace/wls861-review-fixes-20261031-153649
python3 -B evidence/final-package-preparation-01/assemble_final_evidence.py --check-only
python3 -B evidence/final-package-preparation-01/assemble_final_evidence.py --assemble
```

第一条只读核对完成性/身份/文本/秘密规则，不创建归档；失败时会在本准备目录新增一份
`blocked-<UTC>-<pid>.json`，只含安全路径、规则、行号或固定错误原因，不输出匹配值。
第二条重新核对后才创建全新 `evidence/review-final-package-01/`；任何已存在同名输出均拒绝覆盖。
失败尝试的原文件和输出留存，不自动删除、清理、改写或跳过。可疑秘密必须先报告并由root检查原件，
脚本没有绕过秘密检测的开关，也不把合成键形匹配自动当成安全。

## 精确白名单与范围

- `intake/` 的原文本，保留各自当时的真实状态。
- `final-release-01/`，以及configure/build/ctest0022/ctest0002各recorder轮次。
- `final-clang-01/`、`final-ubsan-01/`、`final-asan-affected-01/`，各自configure/build/ctest0002轮次。
- 上述summary内的result、steps、test-plan、JUnit、source和binaries清单，以及原完整LastTest/失败/临时日志。
- 已完成的 `final-coverage-audit-01/` 全部文本，包含首次失败工具尝试；completion及其report/manifest哈希必须对应。
- `delivery-draft-review-01/` 如存在，必须已有完整review-receipt且报告hash匹配；保留冻结输入、原命令及首轮cwd错误，
  不把文档review写成正式批准或审核者自身A4代码的独立审核。
- root生成的 `evidence/local-final-matrix.json`，必须与四配置原completion及固定785输入一致。
- 已完成 `evidence/local-verifier-review-01/`，核对完成收据、report哈希与当前859c032c…版本的验证器字节。
- 远端只选 `remote-9764667-01/FINAL.md`、`FINAL.json`、`FREEZE.json`、`SHA256SUMS`；
  通过FREEZE核四者相关hash及976输入身份，57,519,077字节原始资产继续外置，不再读取/复制整组artifact。
- 任务根 `run_recorded.py`、`validate_candidate.py`、`verify_local_final.py`，以及本准备脚本和本说明；
  全部只作不可执行文本证据，归档统一mode0644。

Recorder目录必须恰有command/completion/process、observations、source-before/after、stdout/stderr八份结束文件。
四配置必须有完整的预期step集合，source前后和跨配置均相同，head9764667、UID1000；
Release两轮完整92，Clang/UBSan/ASan每轮只选2/92，其余90本机NOT_RUN明确留在索引。
成功轮次必须有精确JUnit和完整LastTest；真实非零/timeout轮次允许保留缺失或部分JUnit/日志并在索引明确记录，
但root的最终矩阵本身仍须是已完成、如实描述该失败的核对产物。

## 归档安全与输出

所有路径都从任务根目录句柄逐组件no-follow打开，拒绝符号链接、硬链接、特殊文件、穿越和跨挂载目录。
仅白名单文本后缀可入包；每份必须严格UTF-8，无NUL/二进制魔数或异常控制字节，
数据库、对象/可执行文件、PEM/密钥/证书、环境秘密及嵌套归档文件名均拒绝。
原始合法ANSI转义保留，不改写原日志。每份最大32MiB，总文本最大128MiB，数量/路径深度有界。

扫描规则涵盖私钥块、GitHub/provider/AWS键形及Authorization bearer值。模式扫描不声称证明任意秘密绝不存在；
所有疑似匹配先阻断、给不含匹配值的报告，保留原件供root审阅。

实际取样时记录每份源的路径、类别、SHA-256、大小、权限、inode/device、mtime/ctime与链接数；
归档前再次读取，归档后再次读取，并核白名单目录成员集合不变。没有改模式、重命名或删除原文件。
包内所有成员统一regular、0644、uid/gid/mtime0；脚本也不可执行。
归档后仅从tar流读取字节核对，不向文件系统extract、不执行任何成员。

新输出目录会包含：

- `wls861-review-final-evidence-01.tar.gz`：只有文本成员，含README和逐成员manifest。
- `index.json`：每成员完整SHA、源路径、类别、模式与身份；实际exit、JUnit失败/跳过/缺失及本机未选范围。
- `receipt.json`：最后发布的COMPLETE标记、archive/index hash与原文件前后不变结论。
- `SHA256SUMS`：archive、index、开始标记及最终receipt的精确hash。
- `ASSEMBLY-STARTED.json`：保留尝试开始事实，本身不能证明成功。

成功必须以脚本exit0、最后COMPLETE receipt、完整SHA与成员核对共同确认；有tar但无完整收据仍是未完成尝试。
包内 `MEMBERS.json` 为避免自引用不列它自己，外部index补上该成员hash；外部SHA再封住archive/index/receipt。
collector的 `evidence_consistency_check` 和 `observed_selected_result` 分列保存；后者为FAIL_OR_INCOMPLETE时原样保留，
包仍可完整冻结该真实失败，COMPLETE只表示归档完成。每轮PASS/FAIL、timeout、skip及实际计数均按原收据记录。

归档完成不把测试失败变绿，不提升整体LOCAL_VALIDATION_COMPLETE，不关闭历史GCC/Clang/live_workflow，
不改变Windows11普通用户NOT_RUN，不构成主协调者正式接受、最终文档SHA的CI、推送或合并。

本准备阶段只允许静态语法/源码检查；产品与归档均未执行。具体准备阶段检查范围见同目录 `preparation-receipt.json`。
