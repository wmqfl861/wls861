候选 01 的有界静态核查记录。输入为 `assemble_final_evidence.py` SHA-256 `299d99add0784f6a4437498a635bb62c85cd91abe23e4a733e7075d4ac681651`。没有导入或运行该模块，没有执行 `--check-only`、`--assemble`、模拟测试、产品或编译。原字节保留在 `candidate-01/`。

发现两项收据对应缺口，均已反馈 root 和作者；这是源码分支分析，不是声称实际原始收据已经出错。

1. **配置步骤没有绑定最终矩阵。** `configuration()` 第 412–441 行确实把原 `result.steps`、`steps.json` 与每个 recorder completion 核对，但 `final_matrix()` 第 495–516 行重新采用矩阵自身的 `entry.steps`，没有与前述步骤相等核对。聚合结果却使用它执行 `all(step['exit'] == 0 ...)`。因此独立矩阵里的空步骤或被改写的 configure/build 退出值可能避开已核实步骤的真实非零结果，仍被接受为一致。最小修正是将每配置矩阵 steps 精确绑定到已核实的原步骤，并仅据该绑定结果聚合；真实非零结果继续可归档为失败。

2. **计数和 timeout 分类没有绑定原 JUnit。** 第 513–514 行直接转存矩阵 `passed/failed_names/timeout_names/skipped_or_notrun_names/selected_or_reported/executed`。此前仅验证最终 PASS/FAIL_OR_INCOMPLETE 分类，没有核对这些数值和名字。真实失败虽不会被这一路改成 PASS，但错误的通过数、漏记 timeout 名字或错分 failed/timeout 仍可能跟着“证据一致性完成”入包。最小修正是在已读取的原 JUnit 上按批准的本机验证器分类规则重算并精确比对，或只发布实际重算事实；不能为消除此缺口而要求所有产品通过。

其他已读设计未见当前范围内的新阻断：固定任务目录白名单；逐组件 no-follow 和 regular/单链接/同设备要求；严格文本、文件/总量上限和凭据模式阻断；源身份与目录成员集合前后重读；新输出目录及文件独占创建；归档内容仅从 tar 流读取核验、不 extract 或执行；COMPLETE 收据最后发布；归档完成与测试通过、历史问题关闭、正式采纳分开。

root 补充要求仅最小增加两个已完成证据目录：`local-release-0002-timeout-triage-01` 和 `final-package-review-01`。前者需要如实保留本轮 Release0002 `owned_capacity` 原时限 Timeout；后者只能陈述静态工具核查范围。两个目录应有完成收据和对应报告/输入哈希，不能纳入仍在写入的临时结果。

作者按 root 指示将修正版放在 `final-package-preparation-02`，保持 01 原字节。后续结论以候选 02 的精确身份和静态复核记录为准。
