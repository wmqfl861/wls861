固定源码提交 `976466720e5fb17f6dcc67b0660b74d246996426` 的远端 CI 证据已完整采集和核验。7 个工作流、17 个 job 均成功；本收据只覆盖该提交及 PR #11 的实际 merge checkout。

PR 源头：`976466720e5fb17f6dcc67b0660b74d246996426`。实际 checkout：`cbc4107e0c6984e0acc3d8759ddeff87247b75b9`。两者 tree 均为 `30d6e38091c35a4439cb3b2d13075687b9d0877f`；PR base 为 `99c9063f3e29cd6d69c56fb15815715d499a374a`。

| 事件 | 工作流 | 实际结果 | 原始运行 |
| --- | --- | --- | --- |
| pull_request | Windows native foundation slice | success | [41220751577](https://github.com/wmqfl861/wls861/actions/runs/41220751577) |
| pull_request | A4 same-source fairness counterexample | success | [41220751625](https://github.com/wmqfl861/wls861/actions/runs/41220751625) |
| pull_request | C++20 runtime and specification contracts | success | [41220751664](https://github.com/wmqfl861/wls861/actions/runs/41220751664) |
| push | Verifiable committed source snapshot | success | [41220729814](https://github.com/wmqfl861/wls861/actions/runs/41220729814) |
| push | Windows native foundation slice | success | [41220729868](https://github.com/wmqfl861/wls861/actions/runs/41220729868) |
| push | A4 same-source fairness counterexample | success | [41220729844](https://github.com/wmqfl861/wls861/actions/runs/41220729844) |
| push | C++20 runtime and specification contracts | success | [41220729821](https://github.com/wmqfl861/wls861/actions/runs/41220729821) |

- Linux 的 strict（0022）、strict-umask-0002、UBSan、Clang-18：Push 与 PR 共 8 个 job，各 92/92 CTest 注册组通过，逐名和序号对照清单核验。
- Linux ASan：Push 与 PR 各完整 92 项 JUnit，所有名称和原时限与清单一致；GCC 13.3、Debug、ASan/LSan、普通用户、umask 0002，以及 785 个源码输入和二进制清单前后身份均已核验。
- Linux Make-ASan：每事件按原始 Makefile 的 92 条测试调用逐条比对实际顺序。57 个 native 调用明确通过 801 方法，32 个 unittest 调用通过 397 方法，demo_smoke.py 通过 3 场景，另有 2 项完整性脚本。13 个 unittest 方法仅有原始 7/6 个通过点号及完整 Ran/OK 汇总，没有逐名输出。总 1201 个显式通过项不能计为 1201 个 Suite；该路线没有额外登记成 CTest 套件。
- Windows：每事件完整原始 LastTest 与源码登记逐方法核验，共 4 组、27 方法。实际环境 Server 2022、elevated token、NTFS。每事件另有 6 个工具自检方法；Windows 11 普通用户验收仍 NOT_RUN。
- Fairness：每事件原 A3 版本精确业务顺序断言 exit 1，当前版本 exit 0。是 1 项冻结反例的 2 版执行，不是新增 2 个 CTest 套件；另有 6 个分类工具自检。基线 719 个、当前 785 个源码输入及二进制清单前后身份均一致。
- Source snapshot：785 个 tar 文件成员的 bytes、Git blob、执行位均一致，独立重建 tree 与提交树一致。全部 7 个 artifact ZIP 的 SHA-256 与 GitHub API digest 相符。

完整机器收据：[FINAL.json](FINAL.json)。逐产物核验：[verified/20261031T172420Z/verification.json](verified/20261031T172420Z/verification.json)。逐 Linux job 核验：[verified-jobs/20261031T172845Z/verification.json](verified-jobs/20261031T172845Z/verification.json)。

GitHub CLI 第一次读取含 ANSI 的 job 日志曾被输出保护拒绝；原失败收据已保留，随后仅增加只读 `--allow-escape-sequences` 选项成功下载。未重跑 CI。

本地取证解析器首次因两组原始 unittest 使用 quiet 点号输出而退出 1；第二版按完整点号、Ran 和 OK 三者共同核验通过，并明确保留未逐名输出的限制。后续分类核对将 demo_smoke.py 的 3 场景从 native 计数单列。所有原日志、旧解析器和旧收据均保留；这些是取证器问题，CI 产品结果未改写。12 份独立下载的 Linux job 日志均与最终 workflow ZIP 中的对应原日志逐字节一致。

本收据是同模型工程取证，不是主协调 Agent 的正式采纳。历史 sanitizer/transport 根因仍不能由本次通过推导关闭。
