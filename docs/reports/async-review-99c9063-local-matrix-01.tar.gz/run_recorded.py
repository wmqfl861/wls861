import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def source_identity(directory):
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=directory).split(b'\0')
    result = {}
    for encoded in names:
        if not encoded:
            continue
        name = os.fsdecode(encoded)
        path = directory / name
        if not path.exists():
            result[name] = {'missing': True}
            continue
        data = path.read_bytes()
        result[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                        'mode': path.stat().st_mode & 0o777}
    return result


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


parser = argparse.ArgumentParser()
parser.add_argument('--round', required=True)
parser.add_argument('--cwd', required=True, type=Path)
parser.add_argument('--umask', default='0022')
parser.add_argument('--timeout', type=float, default=10800)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
argv = args.command[1:] if args.command[:1] == ['--'] else args.command
assert argv and os.getuid() != 0
assert args.round and all(c.isalnum() or c in '-_.' for c in args.round)
out = ROOT / 'evidence' / args.round
out.mkdir(mode=0o700, exist_ok=False)
temporary = ROOT / 'tmp' / args.round
temporary.mkdir(mode=0o700, exist_ok=False)
os.umask(int(args.umask, 8))
environment = dict(os.environ)
environment.update(TMPDIR=str(temporary), PYTHONDONTWRITEBYTECODE='1',
                   ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',
                   UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
before = source_identity(args.cwd)
write(out / 'source-before.json', before)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=args.cwd, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=args.cwd, text=True)
command = {'argv': argv, 'cwd': str(args.cwd), 'uid': os.getuid(), 'gid': os.getgid(),
           'head': head, 'worktree_status': status, 'umask': args.umask,
           'environment': {k: environment[k] for k in ['TMPDIR', 'PYTHONDONTWRITEBYTECODE', 'ASAN_OPTIONS', 'UBSAN_OPTIONS']},
           'started_at_utc': utc(), 'outer_timeout_seconds': args.timeout}
write(out / 'command.json', command)
start = time.monotonic()
timed_out = False
with (out / 'stdout.log').open('xb') as stdout, (out / 'stderr.log').open('xb') as stderr, (out / 'observations.jsonl').open('x') as observations:
    process = subprocess.Popen(argv, cwd=args.cwd, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
    write(out / 'process.json', {'pid': process.pid, 'pgid': process.pid, 'recorder_pid': os.getpid()})
    print(json.dumps({'round': args.round, 'pid': process.pid, 'started_at_utc': command['started_at_utc']}), flush=True)
    observed = 0.0
    while process.poll() is None:
        elapsed = time.monotonic() - start
        if elapsed - observed >= 15:
            observation = {'utc': utc(), 'elapsed': elapsed, 'load': os.getloadavg()}
            for path in ['/proc/meminfo', '/sys/fs/cgroup/cpu.stat', '/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/memory.current', '/sys/fs/cgroup/memory.max']:
                try:
                    observation[path] = Path(path).read_text()
                except OSError:
                    observation[path] = None
            observations.write(json.dumps(observation) + '\n')
            observations.flush()
            observed = elapsed
        if elapsed > args.timeout:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
            break
        time.sleep(0.5)
    code = process.wait()
after = source_identity(args.cwd)
write(out / 'source-after.json', after)
receipt = {'argv': argv, 'head': head, 'started_at_utc': command['started_at_utc'], 'finished_at_utc': utc(),
           'seconds': time.monotonic() - start, 'exit_code': code, 'outer_timeout': timed_out,
           'source_unchanged': before == after, 'source_count': len(before), 'pid': process.pid}
write(out / 'completion.json', receipt)
print(json.dumps(receipt), flush=True)
raise SystemExit(124 if timed_out else code)
