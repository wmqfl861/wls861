# External execution recorder for this review task; not a replacement GCC gate.
import argparse,hashlib,importlib.util,json,os,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('configuration',choices=['release','clang','ubsan','asan-affected']);p.add_argument('--tree',default='combined');a=p.parse_args();tree=root/a.tree
python='/mnt/d/codex-workspace/wls861-r2-4-20261029/test-venv/bin/python'
label='final-'+a.configuration+'-01';summary_dir=root/'evidence'/label;summary_dir.mkdir(mode=0o700,exist_ok=False)
b=tree/('build-review-'+a.configuration)
compiler='/usr/bin/clang++-18' if a.configuration=='clang' else '/usr/bin/g++-13'
kind='Debug' if a.configuration in ('ubsan','asan-affected') else 'Release'
steps=[]
def write(name,obj): (summary_dir/name).write_text(json.dumps(obj,indent=2)+'\n')
def execute(name,argv,mask='0022'):
 round_name=label+'-'+name
 command=[sys.executable,str(root/'run_recorded.py'),'--round',round_name,'--cwd',str(tree),'--timeout','18000','--umask',mask,'--',*map(str,argv)]
 code=subprocess.run(command,cwd=root).returncode
 steps.append({'name':name,'round':round_name,'exit':code});write('steps.json',steps)
 return code
configure=['cmake','-S',tree,'-B',b,'-G','Unix Makefiles',f'-DCMAKE_BUILD_TYPE={kind}',f'-DCMAKE_CXX_COMPILER={compiler}','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',f'-DPython3_EXECUTABLE={python}',f'-DWLS_ENABLE_UBSAN={"ON" if a.configuration=="ubsan" else "OFF"}',f'-DWLS_ENABLE_ASAN={"ON" if a.configuration=="asan-affected" else "OFF"}']
assert execute('configure',configure)==0
build=['cmake','--build',b,'--parallel','2']
if a.configuration!='release': build+=['--target','async_coordinator_tests','scheduler_tests']
assert execute('build',build)==0
spec=importlib.util.spec_from_file_location('original_shared_gcc_gate',tree/'scripts/run_gcc_asan.py');gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
plan=subprocess.check_output(['ctest','--test-dir',str(b),'--show-only=json-v1']);(summary_dir/'test-plan.json').write_bytes(plan)
# Validate the unchanged full registration names and deadlines, even for focused runs.
expected=gate.registered_tests(summary_dir/'test-plan.json',92,tree/'tests/gcc_asan_expected_tests.json')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def binary_inputs():return {v.name:digest(v) for v in sorted(b.iterdir()) if v.is_file() and (os.access(v,os.X_OK) or v.suffix=='.a' or v.name in ('CMakeCache.txt','compile_commands.json','CTestTestfile.cmake'))}
before=binary_inputs();write('binaries-before.json',before)
for mask in (['0022','0002'] if a.configuration=='release' else ['0002']):
 junit=summary_dir/('junit-'+mask+'.xml');argv=['ctest','--test-dir',b,'--output-on-failure','--output-junit',junit]
 if a.configuration!='release':argv+=['-R','^(async_coordinator|scheduler)$']
 execute('ctest-'+mask,argv,mask)
 logs=b/'Testing/Temporary'
 if logs.exists():shutil.copytree(logs,summary_dir/('ctest-'+mask+'-original-logs'))
after=binary_inputs();write('binaries-after.json',after)
write('result.json',{'configuration':a.configuration,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip(),'scope':'full 92' if a.configuration=='release' else '2 CTest registrations: async_coordinator/scheduler; full 92 registration manifest checked, remaining 90 NOT_RUN in this local configuration','steps':steps,'binary_identity_unchanged':before==after,'full_registered_count':len(expected),'sanitizer_options':{'ASAN_OPTIONS':'halt_on_error=1:detect_leaks=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}})
print(json.dumps({'result':str(summary_dir/'result.json'),'steps':steps}),flush=True)
