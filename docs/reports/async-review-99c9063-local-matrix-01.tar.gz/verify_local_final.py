"""Read completed records only; never launches or retries a product test."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "combined"
HEAD = "976466720e5fb17f6dcc67b0660b74d246996426"
EVIDENCE = ROOT / "evidence"
OUTPUT = EVIDENCE / "local-final-matrix.json"


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


require(not OUTPUT.exists(), "refuse to overwrite a completed evidence receipt")
require(os.getuid() != 0, "ordinary user required")
catalog_path = TREE / "tests/gcc_asan_expected_tests.json"
catalog = {v["name"]: v["timeout"] for v in read(catalog_path)["tests"]}
require(len(catalog) == 92, "reviewed catalog changed")
inputs = read(EVIDENCE / "final-clang-01-ctest-0002/source-before.json")
require(len(inputs) == 785, "unexpected frozen input collection")
require(subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=TREE, text=True).strip() == HEAD,
        "worktree HEAD differs from tested input")
tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=TREE).decode().strip("\0").split("\0")
require(set(tracked) == set(inputs), "tracked source set differs from frozen inputs")
for name, identity in inputs.items():
    path = TREE / name
    require(sha(path) == identity["sha256"], f"changed tested input: {name}")
    require(path.stat().st_mode & 0o777 == identity["mode"], f"changed input mode: {name}")
configurations = {}
for config in ["release", "clang", "ubsan", "asan-affected"]:
    prefix = "final-" + config + "-01"
    directory = EVIDENCE / prefix
    result = read(directory / "result.json")
    require(result["head"] == HEAD, f"unexpected tested head: {config}")
    step_names = ["configure", "build"] + ["ctest-" + mask for mask in
                  (["0022", "0002"] if config == "release" else ["0002"])]
    require([step["name"] for step in result["steps"]] == step_names,
            f"missing, duplicate or reordered steps: {config}")
    require([step["round"] for step in result["steps"]] ==
            [prefix + "-" + name for name in step_names], "unexpected round binding")
    require(result["binary_identity_unchanged"], f"unstable binaries: {config}")
    before = read(directory / "binaries-before.json")
    after = read(directory / "binaries-after.json")
    require(before == after, f"different binary records: {config}")
    build = TREE / ("build-review-" + config)
    required_binaries = {"CMakeCache.txt", "CTestTestfile.cmake", "compile_commands.json",
                         "async_coordinator_tests", "scheduler_tests", "libwls_s1.a", "libwls_kernel.a"}
    actual_binary_names = {p.name for p in build.iterdir() if p.is_file() and
                           (os.access(p, os.X_OK) or p.suffix == ".a" or p.name in required_binaries)}
    require(required_binaries <= set(after) and set(after) == actual_binary_names,
            f"missing or changed binary collection: {config}")
    for name, digest in after.items():
        require(sha(build / name) == digest, f"post-run binary changed: {config}/{name}")
    plan = read(directory / "test-plan.json")
    require(len(plan["tests"]) == 92 and len({v["name"] for v in plan["tests"]}) == 92,
            "duplicate or missing registered tests")
    require(all(not any(p["name"] == "DISABLED" and p["value"]
                        for p in item["properties"]) for item in plan["tests"]),
            "disabled product registration")
    registered = {
        item["name"]: next(v["value"] for v in item["properties"] if v["name"] == "TIMEOUT")
        for item in plan["tests"]
    }
    require(registered == catalog, f"changed names/deadlines: {config}")
    for step in result["steps"]:
        round_path = EVIDENCE / step["round"]
        completion = read(round_path / "completion.json")
        command = read(round_path / "command.json")
        require(completion["source_unchanged"] and completion["head"] == HEAD,
                f"unstable source: {step['round']}")
        require(command["head"] == HEAD and command["argv"] == completion["argv"]
                and command["cwd"] == str(TREE) and command["uid"] == 1000,
                f"different command identity: {step['round']}")
        require(read(round_path / "source-before.json") == inputs and
                read(round_path / "source-after.json") == inputs,
                f"different source set: {step['round']}")
        expected_wrapper_exit = 124 if completion["outer_timeout"] else completion["exit_code"]
        require(expected_wrapper_exit == step["exit"], "recorder wrapper exit mismatch")
    runs = []
    for mask in (["0022", "0002"] if config == "release" else ["0002"]):
        round_path = EVIDENCE / (prefix + "-ctest-" + mask)
        completion = read(round_path / "completion.json")
        command = read(round_path / "command.json")
        require(command["uid"] == 1000 and command["umask"] == mask, "execution identity mismatch")
        junit = directory / ("junit-" + mask + ".xml")
        expected_ctest = ["ctest", "--test-dir", str(build), "--output-on-failure", "--output-junit", str(junit)]
        if config != "release":
            expected_ctest += ["-R", "^(async_coordinator|scheduler)$"]
        require(command["argv"] == expected_ctest, "CTest invocation scope differs from expected build/selection")
        junit_root = ET.parse(junit).getroot()
        cases = list(junit_root.iter("testcase"))
        names = [case.attrib["name"] for case in cases]
        expected = set(catalog) if config == "release" else {"async_coordinator", "scheduler"}
        require(set(names) == expected and len(names) == len(expected), "JUnit missing/duplicate tests")
        failed_all = [case.attrib["name"] for case in cases
                      if case.find("failure") is not None or case.find("error") is not None]
        timed_out = [case.attrib["name"] for case in cases
                     if case.find("failure") is not None
                     and case.find("failure").attrib.get("message") == "Timeout"]
        failed = [name for name in failed_all if name not in timed_out]
        skipped = [case.attrib["name"] for case in cases if case.find("skipped") is not None
                   or case.attrib.get("status") in ("notrun", "disabled")]
        require(not (set(failed_all) & set(skipped)), "inconsistent JUnit classifications")
        for case in cases:
            if case.attrib["name"] not in failed_all + skipped:
                require(case.attrib.get("status") == "run", "unknown JUnit status cannot pass")
        require(completion["exit_code"] != 0 or not failed_all,
                "successful CTest receipt contradicts failed JUnit cases")
        require(int(junit_root.attrib["tests"]) == len(cases)
                and int(junit_root.attrib["failures"]) == len(failed_all)
                and int(junit_root.attrib["disabled"]) + int(junit_root.attrib["skipped"]) == len(skipped),
                "JUnit aggregate counts contradict cases")
        selected_passed = (completion["exit_code"] == 0 and not completion["outer_timeout"]
                           and not failed_all and not skipped)
        runs.append({"umask": mask, "registered": 92, "selected_or_reported": len(cases),
                     "executed": len(cases) - len(skipped),
                     "observed_selected_result": "PASS" if selected_passed else "FAIL_OR_INCOMPLETE",
                     "passed": len(cases) - len(failed_all) - len(skipped),
                     "failed_names": failed, "timeout_names": timed_out,
                     "skipped_or_notrun_names": skipped,
                     "outside_local_selection_notrun": 92 - len(cases),
                     "completion": completion, "command": command,
                     "junit_sha256": sha(junit),
                     "lasttest_sha256": sha(directory / ("ctest-" + mask + "-original-logs/LastTest.log")),
                     "tests": [{"name": case.attrib["name"], "seconds": case.attrib.get("time"),
                                "status": case.attrib.get("status")} for case in cases]})
    flags = (build / "CMakeFiles/async_coordinator_tests.dir/flags.make").read_text()
    require("-Werror" in flags, "strict warnings absent")
    cache = (build / "CMakeCache.txt").read_text()
    expected_compiler = "/usr/bin/clang++-18" if config == "clang" else "/usr/bin/g++-13"
    expected_kind = "Debug" if config in ("ubsan", "asan-affected") else "Release"
    require(re.search(r"^CMAKE_BUILD_TYPE:[^=]+=" + expected_kind + r"$", cache, re.M), "wrong build type")
    require(re.search(r"^CMAKE_CXX_COMPILER:[^=]+=" + re.escape(expected_compiler) + r"$", cache, re.M),
            "wrong compiler cache")
    compile_checks = {}
    compile_entries = read(build / "compile_commands.json")
    sanitizer_flag = {"ubsan": "-fsanitize=undefined", "asan-affected": "-fsanitize=address"}.get(config)
    for target in ("wls_s1", "wls_kernel", "async_coordinator_tests", "scheduler_tests"):
        selected = [entry for entry in compile_entries if "CMakeFiles/" + target + ".dir/" in entry["command"]]
        require(bool(selected), f"missing compile commands: {target}")
        for entry in selected:
            args = shlex.split(entry["command"])
            require(args[0] == expected_compiler and "-Werror" in args, "unexpected compilation inputs")
            if sanitizer_flag:
                require(sanitizer_flag in args and "-g" in args, "uninstrumented tested library/target")
        compile_checks[target] = len(selected)
    links = {}
    for target in ("async_coordinator_tests", "scheduler_tests"):
        command = (build / "CMakeFiles" / (target + ".dir") / "link.txt").read_text()
        if sanitizer_flag:
            require(sanitizer_flag in shlex.split(command), "sanitizer not linked")
        links[target] = command
    if config == "ubsan":
        require("-fsanitize=undefined" in flags and "-g" in flags, "UBSan missing")
        require(runs[0]["command"]["environment"]["UBSAN_OPTIONS"] == "halt_on_error=1:print_stacktrace=1",
                "UBSan failure options changed")
    if config == "asan-affected":
        require("-fsanitize=address" in flags and "-g" in flags, "ASan missing")
        require(runs[0]["command"]["environment"]["ASAN_OPTIONS"] == "halt_on_error=1:detect_leaks=1",
                "leak detection configuration changed")
    configurations[config] = {"runs": runs, "binary_records": len(after),
                              "binary_identity_unchanged": True,
                              "flags": flags, "steps": result["steps"],
                              "verified_compile_entries": compile_checks, "link_commands": links,
                              "compiler": expected_compiler, "build_type": expected_kind}
receipt = {"verified_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "evidence_consistency_check": "COMPLETE; this is not a product gate runner",
           "observed_selected_result": "PASS" if all(
               run["observed_selected_result"] == "PASS"
               for cfg in configurations.values() for run in cfg["runs"]
           ) and all(step["exit"] == 0 for cfg in configurations.values()
                     for step in cfg["steps"]) else "FAIL_OR_INCOMPLETE",
           "product_commit": HEAD, "source_inputs": len(inputs),
           "source_manifest": "final-clang-01-ctest-0002/source-before.json",
           "source_manifest_sha256": sha(EVIDENCE / "final-clang-01-ctest-0002/source-before.json"),
           "catalog_sha256": sha(catalog_path), "configurations": configurations,
           "tests_launched_by_verifier": 0,
           "historical_failures_closed": False,
           "local_full_clang_sanitizer_and_make": "NOT_RUN; affected subsets are separately counted"}
OUTPUT.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"receipt": str(OUTPUT), "sha256": sha(OUTPUT)}))
