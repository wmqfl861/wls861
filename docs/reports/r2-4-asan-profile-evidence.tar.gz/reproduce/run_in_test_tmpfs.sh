#!/bin/bash
set -euo pipefail
# Invoke only with unshare --mount --propagation private --fork. The mount is
# private to this runner; production and build paths remain on /mnt/d.
test "$(id -u)" -eq 0
mount -t tmpfs -o mode=1777,size=2147483648,nosuid,nodev wls861-test-tmp /tmp
# Test commands run as the original ordinary user, without inherited root caps.
exec setpriv --reuid=1000 --regid=1000 --init-groups --reset-env -- "$@"
