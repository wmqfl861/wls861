"""Freeze a text-only ASan profile supplement without running archived code."""

import datetime
import gzip
import hashlib
import io
import json
import pathlib
import stat
import tarfile


ROOT = pathlib.Path(__file__).resolve().parent
TARGET = ROOT / 'feature/docs/reports/r2-4-asan-profile-evidence.tar.gz'
MANIFEST_SHA256 = '59c8310d64a961d2ebac1159b93e8aa925499be61795b06831a96d79e2fa2050'
IMMUTABLE = {
    'feature/docs/reports/r2-4-evidence.tar.gz':
        '45ac14ee3558dfb8f18054f4d543d0598297c7032a012e457943ed806bea4f6c',
    'feature/docs/reports/r2-4-results.json':
        '78c718189cf951ac6a61352ee8390aa46d17502b91196a6377910abb1f7fb2fc',
    'evidence/final-validation-plan.json':
        '282d031865d920b7cbf97cd1969d2150355cc90a82ad53a50127242d09b12a2b',
}
EVIDENCE_NAMES = (
    'asan-v3-profile-findings.json',
    'asan-performance-static-review.json',
    'feature-asan-v3-perf-wrapper.json',
    'feature-asan-v3-perf-wrapper.log',
    'feature-asan-v3-event-runtime-perf.json',
    'feature-asan-v3-event-runtime-perf.log',
    'feature-asan-v3-event-runtime-perf-detail.log',
    'asan-v3-event-runtime-perf-self.txt',
    'asan-v3-event-runtime-perf-aggregate.txt',
    'asan-v3-event-runtime-perf-callers.txt',
    'asan-v3-event-runtime-perf-relative.txt',
    'source-final-v3.json',
    'source-final-v3.sha256',
)
REPRODUCERS = ('run_validation.py', 'run_in_test_tmpfs.sh', 'archive_asan_profile.py')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_identity(path):
    size = 0
    hasher = hashlib.sha256()
    with path.open('rb') as source:
        while chunk := source.read(1024 * 1024):
            size += len(chunk)
            hasher.update(chunk)
    return {'sha256': hasher.hexdigest(), 'bytes': size}


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def read_text_file(path):
    require(path.is_file() and not path.is_symlink(), str(path))
    require(path.stat().st_size < 16 * 1024 * 1024, 'oversized input: ' + str(path))
    data = path.read_bytes()
    data.decode('utf-8')
    require(b'\0' not in data, 'non-text input: ' + str(path))
    return data


def check_immutable():
    for relative, expected in IMMUTABLE.items():
        require(file_identity(ROOT / relative)['sha256'] == expected,
                'frozen main artifact changed: ' + relative)


def main():
    require(not TARGET.exists(), 'refusing to replace ASan profile supplement')
    check_immutable()
    files = {'evidence/' + name: read_text_file(ROOT / 'evidence' / name)
             for name in EVIDENCE_NAMES}
    for name in REPRODUCERS:
        files['reproduce/' + name] = read_text_file(ROOT / name)
    frozen = json.loads(files['evidence/source-final-v3.json'])
    manifest = files['evidence/source-final-v3.sha256']
    require(digest(manifest) == frozen['manifest_sha256'] == MANIFEST_SHA256,
            'source manifest identity changed')
    source = frozen['inputs']
    require(len(source) == frozen['count'] == 312, 'source input count changed')
    require({line.split('  ', 1)[1]: line.split('  ', 1)[0]
             for line in manifest.decode().splitlines()} == source,
            'source manifest content differs from record')
    for relative, expected in source.items():
        require(file_identity(ROOT / 'feature' / relative)['sha256'] == expected,
                'current source changed: ' + relative)
    findings = json.loads(files['evidence/asan-v3-profile-findings.json'])
    require(findings['local_validation_complete'] is False and
            findings['diagnostic_test_passed'] is False,
            'a failed diagnostic cannot become completed validation')
    require(findings['source_verification']['current_inputs_match_v3'] and
            findings['source_verification']['current_input_count'] == 312,
            'missing source inventory verification')
    require(findings['residual_process_check']['matching_executable_processes'] == [] and
            findings['residual_process_check']['permission_denied_count'] == 0,
            'residual executable check incomplete')
    for name in ('feature-asan-v3-perf-wrapper', 'feature-asan-v3-event-runtime-perf'):
        record = json.loads(files['evidence/' + name + '.json'])
        require(record['exit_code'] == 8 and record['finished_at'],
                'diagnostic completion/exit differs: ' + name)
        require(record['before'] == record['after'] == source,
                'diagnostic source differs: ' + name)
        require(digest(files['evidence/' + name + '.log']) == record['log_sha256'],
                'diagnostic raw log differs: ' + name)
    inner = json.loads(files['evidence/feature-asan-v3-event-runtime-perf.json'])
    require(inner['uid'] == inner['gid'] == 1000 and inner['umask'] == '0002',
            'ordinary test identity differs')
    require(inner['environment']['ASAN_OPTIONS'] == 'halt_on_error=1:detect_leaks=1',
            'sanitizer options differ')
    require(inner['binaries_before'] == inner['binaries_after'] and
            len(inner['binaries_after']) == 57, 'missing concrete binary identities')
    for relative, expected in inner['binaries_after'].items():
        require(file_identity(ROOT / 'feature/build-asan-clang-opt' / relative) == expected,
                'current binary/build input differs: ' + relative)
    for report in findings['perf_report_commands']:
        require(report['exit_code'] == 0 and report['execution_provenance'] ==
                'parent_root_tool_result_confirmed_in_team_message',
                'report exit provenance is missing')
        require(digest(files[report['stdout_relative_path']]) == report['stdout_sha256'],
                'report stdout changed: ' + report['stdout_relative_path'])
    detail = findings['last_test_detail']
    require(digest(files[detail['archived_relative_path']]) == detail['sha256'],
            'LastTest snapshot changed')
    static_review = findings['static_review']
    require(digest(files[static_review['relative_path']]) == static_review['sha256'],
            'static review changed')
    raw_perf = findings['raw_perf_local_only']
    raw_path = ROOT / raw_perf['relative_path']
    raw_stat = raw_path.stat()
    require({'bytes': raw_stat.st_size, 'uid': raw_stat.st_uid, 'gid': raw_stat.st_gid,
             'mode': format(stat.S_IMODE(raw_stat.st_mode), '04o')} == raw_perf['stat'],
            'local raw perf metadata changed')
    require(raw_perf['sha256'] ==
            'a4a8358bcb41dcc3ffa96a60ba76fabbaa74cb033d1e99702c9111b138ae233a',
            'local raw perf registered identity differs')
    require(raw_perf['included_in_archive'] is False and
            raw_perf['relative_path'] not in files, 'raw perf must stay local-only')
    require(sum(map(len, files.values())) < 24 * 1024 * 1024, 'bundle is oversized')
    index = {
        'schema_version': 1,
        'record_kind': 'asan_profile_text_supplement',
        'archived_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'Existing v3 ASan event_runtime diagnostic only; source and frozen main deliverables are unchanged.',
        'diagnostic_test_passed': False,
        'local_validation_complete': False,
        'diagnostic_ctest_exit_code': 8,
        'source_manifest_sha256': MANIFEST_SHA256,
        'frozen_main_artifacts': IMMUTABLE,
        'raw_perf_local_only': raw_perf,
        'command_provenance_note': 'Record/CTest commands retain original runner JSON and raw logs. Four report argv/exit values are explicitly attributed to parent-observed tool results, without invented timestamps or duration.',
        'limitations': findings['limitations'],
        'files': {name: {'bytes': len(data), 'sha256': digest(data)}
                  for name, data in sorted(files.items())},
    }
    files['INDEX.json'] = (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode()
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(files.items()):
            path = pathlib.PurePosixPath(name)
            require(not path.is_absolute() and '..' not in path.parts, 'unsafe member path')
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            entry.uid = entry.gid = 1000
            entry.mtime = 0
            archive.addfile(entry, io.BytesIO(data))
    encoded = gzip.compress(stream.getvalue(), mtime=0)
    check_immutable()
    with TARGET.open('xb') as output:
        output.write(encoded)
    print(json.dumps({'archive': str(TARGET), 'member_count': len(files),
                      'raw_bytes': sum(map(len, files.values())),
                      'archive_bytes': len(encoded), 'sha256': digest(encoded),
                      'diagnostic_test_passed': False, 'local_validation_complete': False},
                     indent=2))


if __name__ == '__main__':
    main()
