import os, sys, subprocess, pathlib, hashlib, json, time, datetime
root = pathlib.Path(__file__).resolve().parent
name, cwd, *cmd = sys.argv[1:]
cwd = pathlib.Path(cwd).resolve()
log = root / 'evidence' / (name + '.log')
meta = root / 'evidence' / (name + '.json')
if log.exists() or meta.exists():
    raise SystemExit('refusing to overwrite validation evidence: ' + name)
def inputs():
    tracked = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'], cwd=cwd).split(b'\0')
    result = {}
    for item in sorted(set(tracked)):
        if not item: continue
        rel = os.fsdecode(item)
        if rel.startswith('docs/') or rel == 'AGENTS.md' or rel in ('README.md','CHANGELOG.md','.gitignore'): continue
        p = cwd / rel
        if p.is_file(): result[rel] = hashlib.sha256(p.read_bytes()).hexdigest()
    return result
def binaries():
    if not cmd or pathlib.Path(cmd[0]).name != 'ctest' or '--test-dir' not in cmd:
        return None
    directory = cwd / cmd[cmd.index('--test-dir') + 1]
    return {p.name: {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes':p.stat().st_size}
            for p in sorted(directory.iterdir())
            if p.is_file() and (os.access(p,os.X_OK) or p.suffix == '.a' or p.name in ('CMakeCache.txt','CTestTestfile.cmake','build.ninja'))}
record = {'command':cmd, 'cwd':str(cwd), 'uid':os.getuid(), 'gid':os.getgid(), 'groups':os.getgroups(),
          'environment':{k:os.environ.get(k) for k in ['TMPDIR','ASAN_OPTIONS','UBSAN_OPTIONS','CC','CXX']},
          'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'before': inputs(), 'binaries_before':binaries()}
record['cpu_affinity']=sorted(os.sched_getaffinity(0))
record['nice']=os.getpriority(os.PRIO_PROCESS,0)
record['capabilities']={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in pathlib.Path('/proc/self/status').read_text().splitlines() if line.startswith(('CapInh:','CapPrm:','CapEff:','CapAmb:'))}
record['mount_namespace']=os.readlink('/proc/self/ns/mnt')
record['tmp_mounts']=[line for line in pathlib.Path('/proc/self/mountinfo').read_text().splitlines() if line.split()[4]=='/tmp']
mask = os.umask(0); os.umask(mask); record['umask'] = format(mask,'04o')
meta.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
start=time.monotonic()
with log.open('wb') as stream:
    try: rc=subprocess.run(cmd,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT).returncode
    except Exception as exc:
        stream.write((repr(exc)+'\n').encode()); rc=125
record.update(exit_code=rc, elapsed_seconds=time.monotonic()-start,
              finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), after=inputs(),
              log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
record['inputs_unchanged']=record['before']==record['after']
record['binaries_after']=binaries()
record['binaries_unchanged']=record['binaries_before']==record['binaries_after']
meta.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['command','exit_code','elapsed_seconds','inputs_unchanged']},ensure_ascii=False),flush=True)
print('log='+str(log),flush=True)
raise SystemExit(rc if 0 <= rc <= 255 else 128-rc)
