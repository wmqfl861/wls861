from pathlib import Path
import importlib.util
import os
import sqlite3
import sys

source, output = map(Path, sys.argv[1:])
spec = importlib.util.spec_from_file_location('evaluation', source / 'scripts/evaluate_r3.py')
evaluation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evaluation)
request_id = (output / 'legacy-408-request.txt').read_text()
database = output / 'legacy-408.sqlite'
with evaluation.database(database) as connection:
    assert connection.execute('PRAGMA user_version').fetchone()[0] == 408
    assert not evaluation.rows(connection, "SELECT name FROM sqlite_master WHERE name='live_attempt_execution'")
    attempt = evaluation.one(connection, 'SELECT * FROM call_attempts WHERE request_id=?', (request_id,))
    envelope = evaluation.strict_json(attempt['request_envelope'])
    assert envelope['format'] == 'wls-model-request-v1'
    assert 'logical_request_sha256' not in envelope
with evaluation.database(output / 'legacy-408-seed.sqlite') as connection:
    plans = [evaluation.make_plan(connection, request_id, decision_evidence=decision)
             for decision in (None, 'model-origin-v1')]
for plan in plans:
    run = dict(task_id='delivery_receipt', condition='multi_agent', database=str(database),
               request_id=request_id, elapsed_ms=1000, plan_sha256=plan['plan_sha256'])
    row = evaluation.build_report(plan, [run])['rows'][8]
    assert row['status'] == 'failed', row
    assert row['source_kinds'] == {'synthetic_fake': 1}, row
    assert row['usage']['cache_read_tokens'] == {'known_total': 0, 'unknown_attempts': 1}, row
    print('PASS valid original Store 408 / Fake / framed-v1 / evaluator v' + str(plan['schema_version']))
print('uid/gid/groups', os.getuid(), os.getgid(), os.getgroups())
