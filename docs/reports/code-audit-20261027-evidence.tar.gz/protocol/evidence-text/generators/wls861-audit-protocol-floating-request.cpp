#include "protocol_test_support.hpp"
#include <fstream>

using namespace wls::s1;
namespace fixture = wls::test::protocol;

int main(int argc, char** argv) {
    if (argc != 2) return 2;
    StructuredContextMessage assistant;
    assistant.role = "assistant";
    assistant.tool_calls = {{"prior-call", "note", fixture::Object{
        {"message", "Synthetic previous input."}, {"ratio", 0.1}, {"integral", 1.0},
        {"small", 1e-7}, {"large", 1e20}, {"negative_zero", -0.0},
        {"logical_request_sha256", "nested original field remains part of the input"}}}};
    StructuredContextMessage result;
    result.role = "tool"; result.tool_call_id = "prior-call";
    result.content = "Literal text: },\"wire_request_sha256\":null, { \\ \n 原文😀";
    const auto request = fixture::request({assistant, result});
    const auto envelope = to_json(request);
    if (to_json(model_request_from_json(envelope)) != envelope) return 3;
    const auto encoded = encode_responses_request(fixture::profile(), request, false);
    if (encoded.logical_request_sha256 != envelope.at("logical_request_sha256").as_string()) return 4;
    std::ofstream output(argv[1]); output << canonical_json(envelope);
}
