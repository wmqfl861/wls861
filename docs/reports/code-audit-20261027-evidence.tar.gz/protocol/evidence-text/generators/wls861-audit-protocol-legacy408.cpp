#include "live_test_support.hpp"

using namespace wls::s1;
namespace fixture = wls::test::live;

int main(int argc, char** argv) {
    if (argc != 3) return 2;
    ::umask(0077);
    const std::filesystem::path output(argv[2]);
    fixture::Assets assets(argv[1]);
    fixture::Fixture f(assets, fixture::settings(), false, 408, true, output / "legacy-408.sqlite");
    auto input = fixture::admission(assets, fixture::settings(), "legacy-evaluation", false, true);
    input.original_text = "Deliver accepted original file bytes and record an exact receipt for the current requirement and plan versions.";
    input.constraint_catalog = fixture::Array{};
    f.request_id = fixture::text(f.store->admit(input), "request_id");
    f.store.reset();
    std::filesystem::copy_file(f.path, output / "legacy-408-seed.sqlite");
    f.store = assets.open(f.path, {}, 408);
    const auto request = f.request("legacy-fake-attempt");
    (void)f.store->reserve_attempt(f.actor(), request.binding, f.reservation(request, true));
    ModelResponse response;
    response.call_id = request.call_id; response.attempt_id = request.attempt_id;
    response.role_call_index = request.role_call_index; response.role = request.role;
    response.binding = request.binding; response.config_snapshot_id = request.config_snapshot_id;
    response.status = ModelResultStatus::Completed;
    response.text = "Synthetic legacy completion.";
    response.usage = fixture::complete_usage(9, 3, 0);
    response.usage.cache_read_tokens.reset(); response.usage.cache_write_tokens.reset();
    (void)f.store->settle_attempt(request.attempt_id, request.binding, request.config_snapshot_id,
        "COMPLETED", to_json(response.usage), to_json(response));
    std::ofstream identity(output / "legacy-408-request.txt"); identity << f.request_id;
    std::cout << "Original Store 408 Fake/framed-v1 evidence created with nullable cache usage.\n";
}
