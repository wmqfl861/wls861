WLS861 audit performance diagnostics: readable evidence export

This export contains existing aggregate timing data, exact build/run metadata, plain-text logs, the actual diagnostic scripts/header, and a unified instrumentation patch. No new build or functional test was run to create it. It introduces no new performance conclusion.

The 12 instrumented C++ translation units and 3 Store include files are represented by diagnostic-instrumentation.patch. Every original file was SHA-256 checked against /tmp/wls861-audit-initial-candidate/source and the original instrumentation manifest before export. The patch uses a/src and b/src labels; audit_profile.hpp is separate at the source root. The actual historical scripts keep their original absolute paths, which identify the inputs and commands used during the run; they were not rewritten into a new execution recipe.

timings/*.json contain per-process aggregate counters only. in_batch distinguishes the pump_workflow call stack from startup/preflight work. Inclusive durations overlap and must not be added together. profile-summary.json and logs/profile-summary.log aggregate the same recorded data. binary.json contains executable metadata and hashes only.

The 223.401-second instrumented case04 run is diagnostic evidence and does not replace the uninstrumented audit failures. build-comparison.json records the same Debug ASan language flags and the instrumentation/include-path/link-layout differences. Original failing gate logs are referenced there and are archived separately by the root audit.

Excluded: evidence/profile-case04, databases and SQLite sidecars, private keys, certificates, request/response contents, executables, object files, and static/shared libraries. The original private evidence directory permissions were not changed.

All exported directories are 0755 and files 0644. manifest.json inventories payload files; SHA256SUMS also covers manifest.json and excludes its own checksum to avoid self-reference.
