#!/usr/bin/env python3
"""Run the unchanged case04 against a specified local diagnostic executable."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import re
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--binary', type=Path, required=True)
parser.add_argument('--label', required=True)
arguments = parser.parse_args()
if not re.fullmatch('[a-z0-9_-]+', arguments.label):
    raise SystemExit('label must be a confined filename component')
if os.getuid() != 65534 or os.getgid() != 65534 or os.getgroups():
    raise SystemExit('tests must use UID/GID 65534 and no supplementary groups')
os.umask(0o002)
root = Path('/tmp/wls861-audit-perf-profile')
source = Path('/tmp/wls861-code-audit-final/source')
binary = arguments.binary.resolve(strict=True)
log = root / 'logs' / (arguments.label + '.log')
evidence = root / 'evidence' / arguments.label
if log.exists() or evidence.exists():
    raise SystemExit('refusing to overwrite prior test evidence')
evidence.parent.mkdir(mode=0o700, exist_ok=True)
environment = dict(os.environ)
environment.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',
    UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',
    WLS_BILLING_BASELINE_EVIDENCE_DIR=str(evidence))
argv = ['/tmp/wls861-audit-venv/bin/python', str(source / 'tests/test_billing_baseline_e2e.py'),
    str(binary), str(source),
    'BillingBaselineIntegration.test_04_exhausted_rework_owner_question_pair', '-v']
record = {'label': arguments.label, 'argv': argv, 'cwd': str(source),
    'identity': {'uid': os.getuid(), 'gid': os.getgid(), 'groups': os.getgroups()},
    'caller_umask': '0002', 'fixture_umask': '0077',
    'limits': {'batch_ms': 60000, 'cli_subprocess_seconds': 150, 'outer_seconds': 900},
    'environment_overrides': {key: environment[key] for key in
        ['ASAN_OPTIONS','UBSAN_OPTIONS','WLS_BILLING_BASELINE_EVIDENCE_DIR']},
    'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
    'test_source_sha256': hashlib.sha256(Path(argv[1]).read_bytes()).hexdigest(),
    'log': str(log), 'returncode': None}
record_path = root / (arguments.label + '-evidence.json')
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'label': arguments.label, 'started_at_utc': record['started_at_utc'], 'log': str(log)}), flush=True)
started = time.monotonic()
with log.open('w') as output:
    try:
        completed = subprocess.run(argv, cwd=source, env=environment,
            stdout=output, stderr=subprocess.STDOUT, timeout=900)
        record['returncode'] = completed.returncode
    except subprocess.TimeoutExpired:
        record['returncode'] = 124
        record['outer_timeout'] = True
record['elapsed_seconds'] = time.monotonic() - started
record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
record['log_sha256'] = hashlib.sha256(log.read_bytes()).hexdigest()
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(record['returncode'])
