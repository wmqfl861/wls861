#!/usr/bin/env python3
"""Aggregate already-recorded timings; never launches code under test."""
from collections import defaultdict
from pathlib import Path
import json

root = Path('/tmp/wls861-audit-perf-profile')
groups = defaultdict(lambda: {'processes': [], 'scopes': defaultdict(lambda: defaultdict(int))})
for path in sorted((root / 'timings').glob('*.json')):
    record = json.loads(path.read_text())
    timings = {(('batch/' if item['in_batch'] else 'outside/') + item['scope']): item
               for item in record['timings']}
    mode = ('single_pump' if any(item['scope'] == 'single_agent_transcript' for item in timings.values())
            else 'multi_pump') if 'batch/pump_workflow' in timings else 'setup_or_other'
    group = groups[mode]
    group['processes'].append({'path': str(path), **{key: record[key] for key in ['pid','uid','gid','wall_ns','cpu_ns']}})
    for label, counters in timings.items():
        for key, value in counters.items():
            if key in ['scope', 'in_batch']:
                continue
            if key == 'max_wall_ns':
                group['scopes'][label][key] = max(group['scopes'][label][key], value)
            else:
                group['scopes'][label][key] += value

output = {mode: {'processes': group['processes'], 'scopes': dict(group['scopes'])}
          for mode, group in groups.items()}
(root / 'profile-summary.json').write_text(json.dumps(output, indent=2) + '\n')
for mode, group in output.items():
    print(mode, 'processes', len(group['processes']))
    for label, item in sorted(group['scopes'].items(), key=lambda pair: pair[1]['wall_ns'], reverse=True):
        print(f"  {label:34s} count={item['count']:6d} units={item['units']:12d} "
              f"inclusive={item['wall_ns']/1e9:9.3f}s self={item['self_wall_ns']/1e9:9.3f}s "
              f"cpu={item['cpu_ns']/1e9:9.3f}s")
