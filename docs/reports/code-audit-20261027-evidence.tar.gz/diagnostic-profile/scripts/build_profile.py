#!/usr/bin/env python3
"""Run only after root explicitly clears the sequential performance comparison."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--execute-after-root-clearance', action='store_true', required=True)
parser.parse_args()
if os.getuid() != 65534 or os.getgid() != 65534 or os.getgroups():
    raise SystemExit('diagnostic builds must use UID/GID 65534 and no supplementary groups')
os.umask(0o002)

root = Path('/tmp/wls861-audit-perf-profile')
frozen = Path('/tmp/wls861-code-audit-final')
source = frozen / 'source'
build = root / 'build'
logs = root / 'logs'
for path in [build, logs, root / 'timings']:
    path.mkdir(mode=0o700, exist_ok=True)
manifest = json.loads((root / 'instrumentation-manifest.json').read_text())
for item in manifest['files']:
    for key in ['original', 'instrumented']:
        actual = hashlib.sha256(Path(item[key]).read_bytes()).hexdigest()
        if actual != item[key + '_sha256']:
            raise SystemExit('source changed after instrumentation: ' + item[key])

records = []
def run(label, argv):
    start = datetime.now(timezone.utc).isoformat()
    then = time.monotonic()
    log = logs / (label + '.log')
    with log.open('w') as output:
        completed = subprocess.run(argv, cwd=source, stdout=output, stderr=subprocess.STDOUT)
    record = {'label': label, 'argv': argv, 'cwd': str(source), 'uid': os.getuid(),
        'gid': os.getgid(), 'groups': os.getgroups(), 'umask': '0002',
        'started_at_utc': start, 'elapsed_seconds': time.monotonic() - then,
        'returncode': completed.returncode, 'log': str(log),
        'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    records.append(record)
    (root / 'build-evidence.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if completed.returncode:
        raise SystemExit(completed.returncode)

flags = ['-g', '-std=c++20', '-Wall', '-Wextra', '-Wpedantic', '-Wconversion', '-Wshadow',
    '-Werror', '-fsanitize=address', '-fno-omit-frame-pointer',
    '-I' + str(source / 'include'), '-I' + str(source / 'src'),
    '-isystem', str(source / 'third_party/valijson/include'),
    '-isystem', str(source / 'third_party/libyaml/include')]
objects = []
for item in manifest['files']:
    path = Path(item['instrumented'])
    if path.suffix != '.cpp':
        continue
    output = build / (path.name + '.o')
    run('compile-' + path.stem, ['/usr/bin/c++', *flags, '-c', str(path), '-o', str(output)])
    objects.append(str(output))
executable = build / 'wls-profile'
run('link', ['/usr/bin/c++', '-g', '-fsanitize=address',
    str(frozen / 'build-asan/CMakeFiles/wls.dir/src/cli.cpp.o'), *objects,
    str(frozen / 'build-asan/libwls_s1.a'), str(frozen / 'build-asan/libwls_kernel.a'),
    '/usr/lib/x86_64-linux-gnu/libsqlite3.so', '/usr/lib/x86_64-linux-gnu/libcrypto.so',
    '/usr/lib/x86_64-linux-gnu/libcurl.so', '/usr/lib/x86_64-linux-gnu/libyaml.so',
    '-o', str(executable)])
(root / 'binary.json').write_text(json.dumps({'executable': str(executable),
    'sha256': hashlib.sha256(executable.read_bytes()).hexdigest(),
    'header_sha256': hashlib.sha256((root / 'audit_profile.hpp').read_bytes()).hexdigest()}, indent=2) + '\n')
