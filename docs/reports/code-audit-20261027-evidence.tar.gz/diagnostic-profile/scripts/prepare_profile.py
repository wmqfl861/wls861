#!/usr/bin/env python3
"""Prepare temporary diagnostics; never builds, executes tests, or edits the repo."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path('/tmp/wls861-audit-perf-profile')
SOURCE = Path('/tmp/wls861-code-audit-final/source')
DESTINATION = ROOT / 'source'
DESTINATION.mkdir(exist_ok=True)

SITES = {
    'runtime_types.cpp': [
        (r'^Json parse_json_strict\([^\n]+\) \{', 'StrictJson', 'text.size()'),
        (r'^std::string canonical_json\(const Json& value\) \{', 'Canonical', None),
        (r'^std::string sha256_hex\(std::string_view bytes\) \{', 'Sha256', 'bytes.size()'),
    ],
    'config_loader.cpp': [
        (r'^Json yaml_value\([^\n]+\) \{', 'YamlValue', 'bytes.size()'),
        (r'^void validate_document\([^\n]+\) \{', 'ConfigValidate', None),
        (r'^FrozenRequestConfig::FrozenRequestConfig\([^\n]+\)\n    : document_\(std::move\(document\)\) \{', 'ConfigConstruct', None),
        (r'^FrozenRequestConfig FrozenRequestConfig::restore\([\s\S]*?\) \{', 'ConfigRestore', 'serialized.size()'),
    ],
    'single_agent.cpp': [
        (r'^Json marker\([\s\S]*?\) \{', 'TranscriptMarker', 'history.size()'),
        (r'^SingleAgentTranscript single_agent_transcript\([\s\S]*?\) \{', 'Transcript', 'history.size()'),
    ],
    'store_single_agent.inc': [
        (r'^std::vector<Json> single_agent_original_history\([\s\S]*?\) \{', 'OriginalHistory', None),
        (r'^std::vector<Json> Store::logical_agent_history\([^\n]+\) const \{', 'StoreHistory', None),
    ],
    'store_capacity.inc': [
        (r'^    Row capacity_state\([^\n]+\) const \{', 'Capacity', None),
    ],
    'store.cpp': [
        (r'^    Json feedback_info\([^\n]+\) const \{', 'Feedback', None),
        (r'^Json Store::reserve_attempt\([\s\S]*?\) \{', 'Reserve', None),
    ],
    'store_live.inc': [
        (r'^Json Store::claim_live_send\([\s\S]*?\) \{', 'SendClaim', None),
    ],
    'offline_runtime.cpp': [
        (r'^CapturedModelCall OfflineRuntime::capture_call\([\s\S]*?\) \{', 'Capture', None),
    ],
    'model.cpp': [
        (r'^void validate_envelope\([^\n]+\) \{', 'EnvelopeValidation', None),
        (r'^ModelRequest model_request_from_json\([^\n]+\) \{', 'ModelDecode', None),
        (r'^Json to_json\(const ModelRequest& [^\n]+\) \{', 'ModelEncode', None),
    ],
    'protocol_codec.cpp': [
        (r'^EncodedResponsesRequest encode_responses_request\([\s\S]*?\) \{', 'ResponsesEncode', None),
    ],
    'structured_history.cpp': [
        (r'^std::vector<StructuredContextMessage> structured_attempt_history\([^\n]+\) \{', 'StructuredHistory', 'history.size()'),
    ],
    'structured_context.cpp': [
        (r'^CompiledContext compile_structured_context\([\s\S]*?\) \{', 'StructuredCompile', 'messages.size()'),
        (r'^CompiledContext structured_context_from_json\([^\n]+\) \{', 'StructuredRestore', None),
        (r'^Json structured_context_to_json\([^\n]+\) \{', 'StructuredEncode', None),
    ],
    'context.cpp': [
        (r'^std::string CompiledContext::prompt\(\) const \{', 'ContextPrompt', None),
    ],
    'live_model.cpp': [
        (r'^ObservedLiveAttempt observe_live_attempt\([\s\S]*?\) \{', 'ObserveLive', None),
    ],
    'event_runtime.cpp': [
        (r'^Json EventRuntime::pump_workflow\([\s\S]*?\) \{', 'Pump', None),
    ],
}

manifest = {'purpose': 'temporary aggregate timing only', 'phase': 'source_preparation_only',
            'source': str(SOURCE), 'files': [], 'timing_directory': str(ROOT / 'timings'),
            'preparation_launched_build_or_tests': False}
for filename, sites in SITES.items():
    original = (SOURCE / 'src' / filename).read_bytes()
    text = original.decode()
    for pattern, tag, units in sites:
        suffix = ', ' + units if units else ''
        insertion = '\n    wls_audit_profile::Scope audit_profile_scope(wls_audit_profile::Tag::' + tag + suffix + ');'
        text, count = re.subn(pattern, lambda match: match[0] + insertion, text, flags=re.MULTILINE)
        if count != 1:
            raise RuntimeError((filename, tag, 'unexpected signature matches', count))
    if filename == 'runtime_types.cpp':
        text = text.replace('    append_canonical(value, result, 0);',
                            '    append_canonical(value, result, 0);\n    audit_profile_scope.units(result.size());', 1)
    if filename == 'store_capacity.inc':
        pattern = r'        const auto pending_calls = (number\(one\([\s\S]*?\{id\}\), "n"\));'
        text, count = re.subn(pattern, lambda match:
            '        const auto pending_calls = [&] {\n'
            '            wls_audit_profile::Scope audit_pending_scope(wls_audit_profile::Tag::CapacityPending);\n'
            '            return ' + match[1] + ';\n        }();', text)
        if count != 1:
            raise RuntimeError((filename, 'pending query matches', count))
    if filename.endswith('.cpp'):
        text = '#include "../audit_profile.hpp"\n' + text
    output = DESTINATION / filename
    output.write_text(text)
    manifest['files'].append({'original': str(SOURCE / 'src' / filename),
        'original_sha256': hashlib.sha256(original).hexdigest(), 'instrumented': str(output),
        'instrumented_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
        'timers': [site[1] for site in sites]})
(ROOT / 'instrumentation-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'prepared_files': len(manifest['files']), 'manifest': str(ROOT / 'instrumentation-manifest.json')}))
