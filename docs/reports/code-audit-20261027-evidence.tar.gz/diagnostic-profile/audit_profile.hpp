#pragma once

// Temporary audit diagnostics only. No request contents or credentials are
// collected; each process writes aggregate counters to its private /tmp file.
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>

namespace wls_audit_profile {
enum class Tag : std::size_t {
    Canonical, StrictJson, Sha256, YamlValue, ConfigValidate, ConfigRestore,
    ConfigConstruct, Transcript, TranscriptMarker, OriginalHistory, StoreHistory,
    Feedback, Capacity, CapacityPending, Capture, Reserve, SendClaim, ObserveLive,
    ModelDecode, ModelEncode, ResponsesEncode, StructuredHistory, Pump,
    StructuredCompile, StructuredRestore, StructuredEncode, ContextPrompt,
    EnvelopeValidation, Count
};
inline constexpr std::array<const char*, static_cast<std::size_t>(Tag::Count)> names{
    "canonical_json", "parse_json_strict", "sha256_hex", "yaml_value",
    "config_validate_document", "config_restore", "config_construct",
    "single_agent_transcript", "single_agent_marker", "single_agent_original_history",
    "store_logical_agent_history", "store_feedback_info", "capacity_state",
    "capacity_pending_query", "capture_call", "reserve_attempt", "claim_live_send",
    "observe_live_attempt", "model_request_from_json", "model_request_to_json",
    "encode_responses_request", "structured_attempt_history", "pump_workflow",
    "compile_structured_context", "structured_context_from_json",
    "structured_context_to_json", "compiled_context_prompt", "validate_model_envelope"
};

inline std::uint64_t clock_ns(clockid_t clock) noexcept {
    timespec value{};
    if (::clock_gettime(clock, &value) != 0) return 0;
    return static_cast<std::uint64_t>(value.tv_sec) * 1000000000ULL +
        static_cast<std::uint64_t>(value.tv_nsec);
}

struct Counters {
    std::atomic<std::uint64_t> count{}, units{}, wall_ns{}, self_wall_ns{},
        cpu_ns{}, self_cpu_ns{}, max_wall_ns{};
};

struct Registry {
    std::array<Counters, names.size() * 2U> counters{};
    pid_t owner{::getpid()};
    std::uint64_t started_wall_ns{clock_ns(CLOCK_MONOTONIC)};
    std::uint64_t started_cpu_ns{clock_ns(CLOCK_PROCESS_CPUTIME_ID)};

    static void write_all(int descriptor, const char* bytes, std::size_t size) noexcept {
        while (size != 0) {
            const auto written = ::write(descriptor, bytes, size);
            if (written <= 0) return;
            bytes += written;
            size -= static_cast<std::size_t>(written);
        }
    }

    ~Registry() noexcept {
        if (::getpid() != owner) return;
        const int directory = ::open("/tmp/wls861-audit-perf-profile/timings",
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        if (directory < 0) return;
        char filename[96]{};
        static_cast<void>(std::snprintf(filename, sizeof(filename), "%ld-%llu.json",
            static_cast<long>(owner), static_cast<unsigned long long>(started_wall_ns)));
        const int descriptor = ::openat(directory, filename,
            O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600);
        ::close(directory);
        if (descriptor < 0) return;
        char buffer[1024]{};
        auto length = std::snprintf(buffer, sizeof(buffer),
            "{\"pid\":%ld,\"uid\":%lu,\"gid\":%lu,\"wall_ns\":%llu,\"cpu_ns\":%llu,\"timings\":[",
            static_cast<long>(owner), static_cast<unsigned long>(::getuid()),
            static_cast<unsigned long>(::getgid()),
            static_cast<unsigned long long>(clock_ns(CLOCK_MONOTONIC) - started_wall_ns),
            static_cast<unsigned long long>(clock_ns(CLOCK_PROCESS_CPUTIME_ID) - started_cpu_ns));
        if (length > 0 && static_cast<std::size_t>(length) < sizeof(buffer))
            write_all(descriptor, buffer, static_cast<std::size_t>(length));
        bool first = true;
        for (std::size_t index = 0; index < counters.size(); ++index) {
            const auto& value = counters[index];
            if (value.count.load(std::memory_order_relaxed) == 0) continue;
            length = std::snprintf(buffer, sizeof(buffer),
                "%s{\"scope\":\"%s\",\"in_batch\":%s,\"count\":%llu,\"units\":%llu,\"wall_ns\":%llu,"
                "\"self_wall_ns\":%llu,\"cpu_ns\":%llu,\"self_cpu_ns\":%llu,\"max_wall_ns\":%llu}",
                first ? "" : ",", names[index % names.size()], index >= names.size() ? "true" : "false",
                static_cast<unsigned long long>(value.count.load(std::memory_order_relaxed)),
                static_cast<unsigned long long>(value.units.load(std::memory_order_relaxed)),
                static_cast<unsigned long long>(value.wall_ns.load(std::memory_order_relaxed)),
                static_cast<unsigned long long>(value.self_wall_ns.load(std::memory_order_relaxed)),
                static_cast<unsigned long long>(value.cpu_ns.load(std::memory_order_relaxed)),
                static_cast<unsigned long long>(value.self_cpu_ns.load(std::memory_order_relaxed)),
                static_cast<unsigned long long>(value.max_wall_ns.load(std::memory_order_relaxed)));
            if (length > 0 && static_cast<std::size_t>(length) < sizeof(buffer))
                write_all(descriptor, buffer, static_cast<std::size_t>(length));
            first = false;
        }
        write_all(descriptor, "]}\n", 3);
        ::close(descriptor);
    }
};

inline Registry& registry() {
    static Registry result;
    return result;
}

class Scope;
inline thread_local Scope* active_scope = nullptr;

class Scope {
public:
    explicit Scope(Tag tag, std::uint64_t units = 0) noexcept
        : counters_(registry().counters[slot(tag)]), parent_(active_scope),
          in_batch_(tag == Tag::Pump || (active_scope && active_scope->in_batch_)),
          units_(units), started_wall_ns_(clock_ns(CLOCK_MONOTONIC)),
          started_cpu_ns_(clock_ns(CLOCK_THREAD_CPUTIME_ID)) { active_scope = this; }
    Scope(const Scope&) = delete;
    Scope& operator=(const Scope&) = delete;
    void units(std::uint64_t value) noexcept { units_ = value; }
    ~Scope() noexcept {
        const auto wall = clock_ns(CLOCK_MONOTONIC) - started_wall_ns_;
        const auto cpu = clock_ns(CLOCK_THREAD_CPUTIME_ID) - started_cpu_ns_;
        active_scope = parent_;
        if (parent_) { parent_->children_wall_ns_ += wall; parent_->children_cpu_ns_ += cpu; }
        counters_.count.fetch_add(1, std::memory_order_relaxed);
        counters_.units.fetch_add(units_, std::memory_order_relaxed);
        counters_.wall_ns.fetch_add(wall, std::memory_order_relaxed);
        counters_.self_wall_ns.fetch_add(wall > children_wall_ns_ ? wall - children_wall_ns_ : 0,
            std::memory_order_relaxed);
        counters_.cpu_ns.fetch_add(cpu, std::memory_order_relaxed);
        counters_.self_cpu_ns.fetch_add(cpu > children_cpu_ns_ ? cpu - children_cpu_ns_ : 0,
            std::memory_order_relaxed);
        auto previous = counters_.max_wall_ns.load(std::memory_order_relaxed);
        while (wall > previous && !counters_.max_wall_ns.compare_exchange_weak(previous, wall,
            std::memory_order_relaxed)) {}
    }
private:
    static std::size_t slot(Tag tag) noexcept {
        return static_cast<std::size_t>(tag) +
            ((tag == Tag::Pump || (active_scope && active_scope->in_batch_)) ? names.size() : 0U);
    }
    Counters& counters_;
    Scope* parent_;
    bool in_batch_;
    std::uint64_t units_, started_wall_ns_, started_cpu_ns_;
    std::uint64_t children_wall_ns_{}, children_cpu_ns_{};
};
} // namespace wls_audit_profile
