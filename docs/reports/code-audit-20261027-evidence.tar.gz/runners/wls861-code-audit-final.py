from pathlib import Path
import datetime
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

repo = Path('/workspace/scratch/8587bb1893aa/wls861')
root = Path('/tmp/wls861-code-audit-final')
source = root/'source'
python = '/tmp/wls861-audit-venv/bin/python'
prefix = ['setpriv', '--reuid=65534', '--regid=65534', '--clear-groups']
input_paths = [line.split('  ', 1)[1] for line in (repo/'docs/reports/billing-baseline-post-ci-inputs.sha256').read_text().splitlines()]
assert len(input_paths) == len(set(input_paths)) == 306
stage = sys.argv[1]
additional = ['tests/fixtures/r3_cpp_logical_request.json']
input_paths = sorted(input_paths + [name for name in additional if (repo/name).exists()])

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs(directory):
    return {name: digest(directory/name) for name in input_paths}

def identity():
    value = json.loads(subprocess.check_output(prefix + [python, '-c',
        'import os,json;print(json.dumps(dict(uid=os.getuid(),gid=os.getgid(),groups=os.getgroups())))'], text=True))
    assert value == {'uid': 65534, 'gid': 65534, 'groups': []}
    return value

if stage == 'prepare':
    assert not root.exists()
    source.mkdir(parents=True)
    files = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=repo).decode().split('\0')
    for name in sorted(set(filter(None, files))):
        path = repo/name
        assert path.is_file() and not path.is_symlink(), name
        target = source/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    (root/'prepared-inputs.json').write_text(json.dumps(inputs(source), indent=2)+'\n')
    (root/'results.json').write_text(json.dumps({'baseline':'d3da700c9c47db86abe941374bcbdac5e31462d4', 'gates':[]}, indent=2)+'\n')
    for path in [root, *root.rglob('*')]:
        os.chown(path, 65534, 65534)
    os.chmod(root, 0o755)
    print(json.dumps({'prepared':str(source), 'files':len(set(filter(None,files))), 'input_count':len(input_paths), 'identity':identity()}))
    sys.exit(0)

record = json.loads((root/'results.json').read_text())
record['identity'] = identity()
if stage == 'freeze':
    prior = json.loads((root/'prepared-inputs.json').read_text())
    current = inputs(repo)
    allowed = {'scripts/evaluate_r3.py', 'tests/test_billing_baseline_e2e.py', 'tests/r3_evaluation_tests.py', *additional}
    changed = {name for name in input_paths if current[name] != prior.get(name)}
    assert changed <= allowed, changed
    for name in sorted(changed):
        shutil.copy2(repo/name, source/name)
        os.chown(source/name,65534,65534)
    assert inputs(source) == current
    manifest = ''.join(current[name]+'  '+name+'\n' for name in input_paths)
    (root/'final-inputs.sha256').write_text(manifest)
    record['final_input_count'] = len(input_paths)
    record['final_inputs_sha256'] = hashlib.sha256(manifest.encode()).hexdigest()
    record['frozen_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record['post_compile_python_updates'] = sorted(changed)
    (root/'results.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({key:record[key] for key in ['final_input_count','final_inputs_sha256','frozen_at_utc','post_compile_python_updates']}))
    sys.exit(0)

release = root/'build-release'
release_layout = source/'build-release'
asan = root/'build-asan'
focus = ['store','live_model_store','process_evidence','cleanup','cleanup_runtime','worker_tools','schema',
         'config_loader','offline_runtime','https_transport','live_model_store_tls','r3_evaluation','billing_baseline_e2e']
core = focus[:9]
commands = {
 'build-release': [
    ('configure-release',['cmake','-S',str(source),'-B',str(release),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DPython3_EXECUTABLE='+python],0o022),
    ('build-release',['cmake','--build',str(release),'--parallel','2'],0o022)],
 'build-asan': [
    ('configure-asan',['cmake','-S',str(source),'-B',str(asan),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DWLS_ENABLE_ASAN=ON','-DPython3_EXECUTABLE='+python],0o002),
    ('build-asan',['cmake','--build',str(asan),'--parallel','2','--target','wls','store_tests','live_model_store_tests',
        'process_evidence_tests','cleanup_tests','cleanup_runtime_tests','worker_tools_tests','schema_tests',
        'config_loader_tests','offline_runtime_tests','https_transport_driver','live_model_store_driver'],0o002)],
 'build-release-layout': [
    ('configure-release-layout',['cmake','-S',str(source),'-B',str(release_layout),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DPython3_EXECUTABLE='+python],0o022),
    ('build-release-layout',['cmake','--build',str(release_layout),'--parallel','2'],0o022)],
 'test-release': [
    ('release-0022',['ctest','--test-dir',str(release),'--output-on-failure'],0o022),
    ('release-0002',['ctest','--test-dir',str(release),'--output-on-failure'],0o002)],
 'test-release-layout': [
    ('release-0022-final',['ctest','--test-dir',str(release_layout),'--output-on-failure','--parallel','2'],0o022),
    ('release-0002-final',['ctest','--test-dir',str(release_layout),'--output-on-failure','--parallel','2'],0o002)],
 'test-asan': [
    ('focused-asan',['ctest','--test-dir',str(asan),'--output-on-failure','-R','^('+'|'.join(focus)+')$'],0o002)],
 'test-asan-core': [
    ('focused-asan-core',['ctest','--test-dir',str(asan),'--output-on-failure','-R','^('+'|'.join(core)+')$'],0o002)],
 'test-asan-integration': [
    ('focused-asan-integration',['ctest','--test-dir',str(asan),'--output-on-failure','-R','^('+'|'.join(focus[9:])+')$'],0o002)],
 'test-asan-billing-isolated': [
    ('asan-billing-isolated',['ctest','--test-dir',str(asan),'--output-on-failure','-R','^billing_baseline_e2e$'],0o002)]
}[stage]
if stage.startswith('test-'):
    if stage == 'test-asan-core':
        # These nine native suites never execute the three evaluator Python
        # files still under review, nor their new numerical fixture. Verify
        # every other prepared input before and after this independent gate.
        unfinished_python = {'scripts/evaluate_r3.py','tests/test_billing_baseline_e2e.py','tests/r3_evaluation_tests.py'}
        expected = {name:sha for name,sha in json.loads((root/'prepared-inputs.json').read_text()).items()
                    if name not in unfinished_python}
    else:
        expected = dict(line.split('  ',1)[::-1] for line in (root/'final-inputs.sha256').read_text().splitlines())
    def gate_inputs(directory):
        return {name:digest(directory/name) for name in expected}
    assert gate_inputs(source) == expected == gate_inputs(repo), 'gate input changed before test'

for name, command, mask in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    environment = os.environ.copy()
    environment.update({'ASAN_OPTIONS':'halt_on_error=1:detect_leaks=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
    log_path = root/(name+'.log')
    with log_path.open('wb') as log:
        process = subprocess.run(prefix+command, cwd=source, env=environment, stdout=log, stderr=subprocess.STDOUT,
            preexec_fn=lambda: os.umask(mask))
    entry = dict(name=name, command=prefix+command, cwd=str(source), umask=format(mask,'04o'), started_at_utc=started,
        elapsed_seconds=round(time.monotonic()-start,3), returncode=process.returncode, log_sha256=digest(log_path))
    if stage.startswith('test-'):
        entry['verified_input_count'] = len(expected)
        entry['verified_input_manifest_sha256'] = hashlib.sha256(''.join(
            expected[name]+'  '+name+'\n' for name in sorted(expected)).encode()).hexdigest()
    if command[0]=='ctest':
        build = Path(command[2])
        last = build/'Testing/Temporary/LastTest.log'
        if last.exists():
            copied=root/(name+'-LastTest.log')
            shutil.copy2(last,copied)
            entry['last_test_log_sha256']=digest(copied)
    # Independent builds can finish together; serialize result updates.
    with (root/'results.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        record = json.loads((root/'results.json').read_text())
        record['identity'] = identity()
        record['gates'].append(entry)
        (root/'results.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(entry),flush=True)
    assert process.returncode==0, log_path
if stage.startswith('test-'):
    assert gate_inputs(source) == expected == gate_inputs(repo), 'gate input changed during test'
