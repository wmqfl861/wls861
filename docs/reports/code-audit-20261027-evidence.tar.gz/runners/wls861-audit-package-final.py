from pathlib import Path
import copy
import datetime
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

repo = Path('/workspace/scratch/8587bb1893aa/wls861')
initial = Path('/tmp/wls861-code-audit-final')
initial_copy = Path('/tmp/wls861-audit-initial-candidate')
final = Path('/tmp/wls861-audit-optimized-final')
performance = Path('/tmp/wls861-audit-performance')
profile = Path('/tmp/wls861-audit-perf-evidence')
output = repo / 'docs/reports'
baseline = 'd3da700c9c47db86abe941374bcbdac5e31462d4'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


record = read_json(final / 'results.json')
expected_gates = {'optimized-build-asan', 'optimized-build-release', 'optimized-case04',
                  'optimized-release-0022', 'optimized-release-0002', 'optimized-focused-asan'}
assert {gate['name'] for gate in record['gates']} == expected_gates
assert len(record['gates']) == len(expected_gates)
assert all(gate['returncode'] == 0 for gate in record['gates'])
assert record['identity'] == {'uid': 65534, 'gid': 65534, 'groups': []}
manifest = (final / 'inputs.sha256').read_bytes()
inputs = dict(line.split('  ', 1)[::-1] for line in manifest.decode().splitlines())
assert len(inputs) == record['final_input_count'] == 307
assert digest(manifest) == record['final_inputs_sha256']
assert record['final_inputs_sha256'] == 'ce3d518aa1ecf50d2d7e84c7c28e949e39e5bd7df559147c8b10219d69a0dbad'
for name, expected in inputs.items():
    assert digest((repo / name).read_bytes()) == expected, name
    assert digest((initial / 'source' / name).read_bytes()) == expected, name
    if name.startswith(('src/', 'include/', 'tests/')):
        assert not any(marker in (repo / name).read_bytes() for marker in
                       [b'wls_audit_profile', b'audit_profile.hpp', b'wls_audit_perf_profile']), name
record['final_inputs_reverified_at_utc'] = now()

diagnostics = ['ERROR: AddressSanitizer', 'LeakSanitizer: detected memory leaks',
               'SUMMARY: UndefinedBehaviorSanitizer']
by_name = {gate['name']: gate for gate in record['gates']}
record['verified_ctest_suites'] = {}
for name, count in [('optimized-release-0022', 78), ('optimized-release-0002', 78),
                    ('optimized-focused-asan', 18)]:
    log = (final / (name + '.log')).read_text()
    passed = re.findall(r'\b\d+/\d+\s+Test\s+#\s*(\d+):\s*(\S+).*?\bPassed\s+([\d.]+) sec', log)
    assert len(passed) == len({item[0] for item in passed}) == count, (name, passed)
    assert f'100% tests passed, 0 tests failed out of {count}' in log
    detail = (final / (name + '-LastTest.log')).read_text()
    assert not any(item in detail for item in diagnostics), name
    assert digest(log.encode()) == by_name[name]['log_sha256']
    assert digest(detail.encode()) == by_name[name]['last_test_log_sha256']
    record['verified_ctest_suites'][name] = [dict(ctest_id=int(number), name=test, seconds=float(seconds))
                                           for number, test, seconds in passed]
assert {item['name'] for item in record['verified_ctest_suites']['optimized-focused-asan']} == set(record['asan_focus'])
for gate in record['gates']:
    assert gate['verified_before_utc'] and gate['verified_after_utc']
    assert gate['input_manifest_sha256'] == record['final_inputs_sha256']
    assert digest((final / (gate['name'] + '.log')).read_bytes()) == gate['log_sha256']

old = read_json(initial_copy / 'results.json')
old_manifest = (initial_copy / 'final-inputs.sha256').read_bytes()
assert digest(old_manifest) == old['final_inputs_sha256'] == record['initial_inputs_sha256']
old_inputs = dict(line.split('  ', 1)[::-1] for line in old_manifest.decode().splitlines())
assert old_inputs.keys() == inputs.keys()
assert sorted(name for name in inputs if inputs[name] != old_inputs[name]) == sorted(record['changed_from_initial_audit'])
for name, expected in old_inputs.items():
    assert digest((initial_copy / 'source' / name).read_bytes()) == expected, name
record['initial_snapshot_reverified_at_utc'] = now()
old_by_name = {gate['name']: gate for gate in old['gates']}
assert {name for name, gate in old_by_name.items() if gate['returncode'] != 0} == {
    'release-0022', 'focused-asan-integration', 'asan-billing-isolated'}
for gate in old['gates']:
    assert digest((initial / (gate['name'] + '.log')).read_bytes()) == gate['log_sha256'], gate['name']
assert '2 tests failed out of 78' in (initial / 'release-0022.log').read_text()
assert '75% tests passed, 1 tests failed out of 4' in (initial / 'focused-asan-integration.log').read_text()
assert "AssertionError: 'deadline' unexpectedly found" in (initial / 'asan-billing-isolated.log').read_text()
old['evidence_limitations'] = {
    'failed_stage_post_checks': 'The original runner asserted success before its final input check. '
                               'Failed stages bind entry inputs only; later checks are explicitly later evidence.',
    'initial_native_suites': 'Nine core ASan suites verified 303 prepared inputs, excluding three Python '
                            'files still under review. Later complete stages bind all 307 initial inputs.',
    'layout_failure': 'First Release used a sibling build directory and failed executable-relative '
                      'resource discovery in doctor_diagnostics_cli and review_cli_smoke (76/78). '
                      'Source-local rebuild then passed both full Release gates, without product/test changes.',
    'asan_failure': 'Both the overlapping four-suite integration gate and the quiet complete 16-method '
                    'billing rerun failed case04 at the original single-Agent 60000ms batch deadline; '
                    'test99 consequently retained one failed paired cell. Quiet failure rules out a claim '
                    'that contention alone explains the failure. No sanitizer diagnostic was found.'}
record['initial_audit_candidate'] = old
record['initial_candidate_capture'] = read_json(initial_copy / 'capture.json')
record['initial_artifacts_verified_before_rebuild'] = read_json(final / 'initial-artifact-post-check.json')
record['later_initial_input_check'] = read_json(performance / 'after-comparison-input-check.json')
record['pristine_and_initial_audit_comparison'] = read_json(performance / 'results.json')
comparison = {run['name']: run for run in record['pristine_and_initial_audit_comparison']['runs']}
assert comparison['baseline-case04']['returncode'] == 0
assert comparison['audit-case04']['returncode'] != 0
record['diagnostic_profile'] = {
    'summary': read_json(profile / 'profile-summary.json'),
    'execution': read_json(profile / 'profile-case04-evidence.json'),
    'build_comparison': read_json(profile / 'build-comparison.json'),
    'export_manifest_sha256': digest((profile / 'manifest.json').read_bytes()),
    'interpretation': 'Diagnostic instrumented binary only, not a production gate. Inclusive nested '
                      'times cannot be summed. Compile flags matched Debug ASan without optimization; '
                      'instrumentation and overlay object layout differ. Original case04 deadlines were retained.'}

original_environment = read_json(initial_copy / 'environment.json')
environment = {key: copy.deepcopy(value) for key, value in original_environment.items() if key != 'build_artifacts'}
environment['build_artifacts'] = {}
for kind, directory, names in [
        ('release', initial / 'source/build-release',
         list(original_environment['build_artifacts']['release_final_source_layout'])),
        ('asan', initial / 'build-asan', ['wls', 'https_transport_driver', 'live_model_store_driver',
                                         *record['native_targets']])]:
    artifacts = {}
    for name in sorted(set(names)):
        data = (directory / name).read_bytes()
        assert data[:4] == b'\x7fELF', (kind, name)
        assert b'wls_audit_profile' not in data and b'audit_profile.hpp' not in data, (kind, name)
        artifacts[name] = {'bytes': len(data), 'sha256': digest(data)}
    environment['build_artifacts'][kind] = artifacts
    for gate in record['gates']:
        if 'cli_binary_sha256' in gate and (('release' in gate['name']) == (kind == 'release')):
            assert gate['cli_binary_sha256'] == artifacts['wls']['sha256'], gate['name']
environment['recorded_at_utc'] = now()
environment['build_method'] = 'Incremental recompilation and relink over the verified initial builds; '
environment['build_method'] += 'not claimed as a clean local rebuild. Final-SHA CI supplies fresh independent builds.'
record['environment'] = environment

protected = read_json(Path('/tmp/wls861-audit-io-delivery-check.json'))
checked = 0
for group in protected['protected_baseline_files'].values():
    for item in group['files']:
        path = repo / item['path']
        assert path.is_file() and not path.is_symlink(), path
        data = path.read_bytes()
        assert len(data) == item['bytes'] and digest(data) == item['sha256'], path
        actual_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert actual_blob == item['baseline_git_blob'], path
        mode = '100755' if path.stat().st_mode & 0o111 else '100644'
        assert mode == item['baseline_mode'], path
        checked += 1
record['preserved_trees_and_coverage'] = protected
record['protected_files_final_verification'] = {'checked_at_utc': now(), 'file_count': checked}
record['scope'] = {
    'release': 'Complete 78 registered CTest suites, separately under caller umasks 0022 and 0002.',
    'local_asan': '18 complete affected suites in original order, plus original case04 quiet confirmation.',
    'remote_ci': 'Exact final published SHA must be checked; no future CI outcome is recorded here.',
    'limits': 'No real provider/paid calls, production data, power-loss test, formal proof, independent '
              'second-model business review, deployment strong-isolation positive acceptance or CVE survey.'}
record['archived_at_utc'] = now()

members = {}


def add(path, name):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
    data = path.read_bytes()
    data.decode('utf-8')
    assert b'\0' not in data, path
    assert not re.search(rb'(?m)^-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----\s*$', data), path
    members[name] = data


for path in sorted(final.glob('*.log')):
    add(path, 'final-optimized/' + path.name)
for name in ['results.json', 'inputs.sha256', 'initial-artifact-post-check.json']:
    add(final / name, 'final-optimized/' + name)
members['final-optimized/environment.json'] = (json.dumps(environment, indent=2) + '\n').encode()
for kind, directory in [('release', initial / 'source/build-release'), ('asan', initial / 'build-asan')]:
    for name in ['CMakeCache.txt', 'build.ninja']:
        assert b'wls861-audit-perf-profile' not in (directory / name).read_bytes(), (kind, name)
        add(directory / name, 'final-optimized/build-metadata/' + kind + '/' + name)
for path in sorted(initial.glob('*.log')):
    add(path, 'initial-audit/' + path.name)
for name in ['results.json', 'environment.json', 'prepared-inputs.json', 'final-inputs.sha256', 'capture.json']:
    add(initial_copy / name, 'initial-audit/' + name)
for name in record['changed_from_initial_audit']:
    add(initial_copy / 'source' / name, 'initial-audit/source/' + name)
for name in ['configure.log', 'build.log', 'build-result.json']:
    add(Path('/tmp/wls861-audit-baseline') / name, 'pristine-release-build/' + name)
for path in sorted(performance.iterdir()):
    if path.is_file() and path.suffix in {'.log', '.json'}:
        add(path, 'performance-comparison/' + path.name)
for path in sorted(profile.rglob('*')):
    if path.is_file():
        add(path, 'diagnostic-profile/' + path.relative_to(profile).as_posix())
for name in ['wls861-code-audit-final.py', 'wls861-audit-baseline-build.py',
             'wls861-audit-schema-check.py', 'wls861-audit-performance-run.py',
             'wls861-audit-optimized-gates.py', 'wls861-audit-package-final.py',
             'wls861-audit-validation-template.md']:
    add(Path('/tmp') / name, 'runners/' + name)
schema = Path('/tmp/wls861-audit-schema')
for pattern in ['*.log', '*-result.json', '*.cpp']:
    for path in sorted(schema.glob(pattern)):
        add(path, 'schema/' + path.name)
io_root = Path('/tmp/wls861-audit-io-regressions')
add(io_root / 'audit-summary.json', 'io/audit-summary.json')
for phase in ['baseline', 'fixed']:
    for path in sorted((io_root / phase).glob('*.log')):
        add(path, 'io/' + phase + '/' + path.name)
    add(io_root / phase / 'results.json', 'io/' + phase + '/results.json')
    for path in sorted((io_root / phase / 'source_capture').rglob('*')):
        if path.is_file():
            add(path, 'io/' + phase + '/source_capture/' + path.relative_to(io_root / phase / 'source_capture').as_posix())
state = Path('/tmp/wls861-audit-state-release')
add(state / 'evidence-summary.json', 'state/evidence-summary.json')
for path in sorted((state / 'logs').iterdir()):
    if path.is_file() and path.suffix in {'.log', '.identity'}:
        add(path, 'state/' + path.name)
protocol = Path('/tmp/wls861-audit-protocol-zrkh7pkp')
add(protocol / 'evidence-summary.json', 'protocol/evidence-summary.json')
for path in sorted((protocol / 'evidence-text').rglob('*')):
    if path.is_file():
        add(path, 'protocol/evidence-text/' + path.relative_to(protocol / 'evidence-text').as_posix())
add(Path('/tmp/wls861-audit-io-delivery-check.json'), 'review/preserved-trees-and-coverage.json')

subprocess.run(['git', 'diff', '--check'], cwd=repo, check=True)
archive = output / 'code-audit-20261027-evidence.tar.gz'
with archive.open('wb') as destination:
    with gzip.GzipFile(filename='', mode='wb', fileobj=destination, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
index = {'archive': archive.name, 'bytes': archive.stat().st_size,
         'sha256': digest(archive.read_bytes()), 'member_count': len(members),
         'members': [{'path': name, 'bytes': len(data), 'sha256': digest(data)}
                     for name, data in sorted(members.items())]}
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(members)
    for member in tar:
        assert member.isfile() and tar.extractfile(member).read() == members[member.name]
record['archive'] = {key: value for key, value in index.items() if key != 'members'}
(output / 'code-audit-20261027-inputs.sha256').write_bytes(manifest)
(output / 'code-audit-20261027-results.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
(output / 'code-audit-20261027-evidence.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')

rows = ['| 最终门禁 | 实际结果 | runner墙钟 | 原日志SHA-256 |', '| --- | --- | ---: | --- |']
for name, label, result in [
        ('optimized-release-0022', 'Release，调用umask0022', '78/78，exit0'),
        ('optimized-release-0002', 'Release，调用umask0002', '78/78，exit0'),
        ('optimized-case04', 'ASan原case04，独占执行', '原multi/single分支及断言通过，exit0'),
        ('optimized-focused-asan', 'ASan/LSan受影响完整套件', '18/18，exit0')]:
    gate = by_name[name]
    rows.append(f"| {label} | {result} | {gate['elapsed_seconds']:.3f}秒 | `{gate['log_sha256']}` |")
archive_summary = (f"归档含 **{index['member_count']}个成员、{index['bytes']}字节**，SHA-256为 "
                   f"**`{index['sha256']}`**。逐成员读回与原始字节比对一致；原日志没有去空白或重排。")
report = Path('/tmp/wls861-audit-validation-template.md').read_text()
assert '{{FINAL_GATE_TABLE}}' in report and '{{ARCHIVE_SUMMARY}}' in report
report = report.replace('{{FINAL_GATE_TABLE}}', '\n'.join(rows)).replace('{{ARCHIVE_SUMMARY}}', archive_summary)
assert not re.search(r'\{\{[A-Z_]+\}\}', report), 'unfilled report placeholder'
report = re.sub(r'<!--.*?-->\n\n', '', report, flags=re.DOTALL)
(output / 'code-audit-20261027-validation.md').write_text(report)
print(json.dumps({'archive': record['archive'], 'input_count': len(inputs),
                  'input_sha256': digest(manifest), 'protected_file_count': checked,
                  'binary_count': sum(len(v) for v in environment['build_artifacts'].values()),
                  'gates': [{key: gate[key] for key in ['name', 'returncode', 'elapsed_seconds']}
                            for gate in record['gates']]}, ensure_ascii=False))
