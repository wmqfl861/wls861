from pathlib import Path
import datetime
import json
import os
import subprocess
import tarfile
import time

repo = Path('/workspace/scratch/8587bb1893aa/wls861')
root = Path('/tmp/wls861-audit-baseline')
source = root / 'source'
root.mkdir(exist_ok=True)
source.mkdir(exist_ok=True)
sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert sha == 'd3da700c9c47db86abe941374bcbdac5e31462d4'
archive = root / 'source.tar'
with archive.open('wb') as target:
    subprocess.run(['git', 'archive', '--format=tar', sha], cwd=repo, stdout=target, check=True)
with tarfile.open(archive) as stream:
    stream.extractall(source, filter='data')
for path in [root, *root.rglob('*')]:
    os.chown(path, 65534, 65534)
os.chmod(root, 0o755)
prefix = ['setpriv', '--reuid=65534', '--regid=65534', '--clear-groups']
python = '/tmp/wls861-audit-venv/bin/python'
result = {'base_commit': sha, 'identity': json.loads(subprocess.check_output(prefix +
    [python, '-c', 'import os,json;print(json.dumps(dict(uid=os.getuid(),gid=os.getgid(),groups=os.getgroups())))'], text=True)), 'gates': []}
assert result['identity'] == {'uid': 65534, 'gid': 65534, 'groups': []}
commands = [
    ('configure', ['cmake', '-S', str(source), '-B', str(root/'build-release'), '-G', 'Ninja',
        '-DCMAKE_BUILD_TYPE=Release', '-DPython3_EXECUTABLE=' + python]),
    ('build', ['cmake', '--build', str(root/'build-release'), '--parallel', '2', '--target', 'wls']),
]
for name, command in commands:
    start = time.monotonic()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (root/(name+'.log')).open('wb') as log:
        process = subprocess.run(prefix + command, cwd=source, stdout=log, stderr=subprocess.STDOUT,
            preexec_fn=lambda: os.umask(0o022))
    entry = {'gate': name, 'command': prefix+command, 'started_at': started,
        'elapsed_seconds': round(time.monotonic()-start,3), 'returncode': process.returncode}
    result['gates'].append(entry)
    (root/'build-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(entry), flush=True)
    assert process.returncode == 0, root/(name+'.log')
