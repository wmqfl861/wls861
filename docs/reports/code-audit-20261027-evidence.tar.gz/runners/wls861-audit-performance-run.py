from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

repo=Path('/workspace/scratch/8587bb1893aa/wls861')
root=Path('/tmp/wls861-audit-performance')
root.mkdir(exist_ok=True)
os.chmod(root,0o755)
baseline=Path('/tmp/wls861-audit-baseline')
final=Path('/tmp/wls861-code-audit-final')
python='/tmp/wls861-audit-venv/bin/python'
prefix=['setpriv','--reuid=65534','--regid=65534','--clear-groups']
stage=sys.argv[1]
environment=os.environ.copy()
environment.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
identity=json.loads(subprocess.check_output(prefix+[python,'-c','import os,json;print(json.dumps(dict(uid=os.getuid(),gid=os.getgid(),groups=os.getgroups())))'],text=True))
assert identity==dict(uid=65534,gid=65534,groups=[])
record_path=root/'results.json'
record=json.loads(record_path.read_text()) if record_path.exists() else {'baseline':'d3da700c9c47db86abe941374bcbdac5e31462d4','identity':identity,'runs':[]}

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

if stage=='build-baseline':
    names=subprocess.check_output(['git','ls-tree','-r','--name-only',record['baseline'],'--','src','include'],cwd=repo,text=True).splitlines()
    for name in names:
        original=subprocess.check_output(['git','show',record['baseline']+':'+name],cwd=repo)
        assert (baseline/'source'/name).read_bytes()==original,name
    record['baseline_source_identity']={name:sha(baseline/'source'/name) for name in names}
    commands=[('baseline-asan-configure',['cmake','-S',str(baseline/'source'),'-B',str(baseline/'build-asan'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DWLS_ENABLE_ASAN=ON','-DPython3_EXECUTABLE='+python]),
              ('baseline-asan-build',['cmake','--build',str(baseline/'build-asan'),'--parallel','2','--target','wls'])]
elif stage=='compare-case04':
    test=final/'source/tests/test_billing_baseline_e2e.py'
    commands=[]
    record['comparison_test_sha256']=sha(test)
    record['comparison_inputs_sha256']=sha(final/'final-inputs.sha256')
    record['case04_limit_policy']={'batch_ms':60000,'cli_subprocess_seconds':150,'original_multi_and_single_branches':True}
    for name,binary in [('baseline-case04',baseline/'build-asan/wls'),('audit-case04',final/'build-asan/wls')]:
        commands.append((name,[python,str(test),str(binary),str(final/'source'),'BillingBaselineIntegration.test_04_exhausted_rework_owner_question_pair','-v']))
        record[name+'_binary_sha256']=sha(binary)
else:raise ValueError(stage)

for name,command in commands:
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    start=time.monotonic()
    path=root/(name+'.log')
    with path.open('wb') as output:
        completed=subprocess.run(prefix+command,cwd=final/'source',env=environment,stdout=output,stderr=subprocess.STDOUT,preexec_fn=lambda:os.umask(0o002))
    entry={'name':name,'command':prefix+command,'cwd':str(final/'source'),'identity':identity,'caller_umask':'0002','started_at_utc':started,
           'elapsed_seconds':round(time.monotonic()-start,3),'returncode':completed.returncode,'log_sha256':sha(path)}
    record['runs'].append(entry)
    record_path.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(entry),flush=True)
    if stage=='build-baseline':assert completed.returncode==0,path
