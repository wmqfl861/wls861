from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

repo=Path('/workspace/scratch/8587bb1893aa/wls861')
prior=Path('/tmp/wls861-code-audit-final')
source=prior/'source'
root=Path('/tmp/wls861-audit-optimized-final')
python='/tmp/wls861-audit-venv/bin/python'
prefix=['setpriv','--reuid=65534','--regid=65534','--clear-groups']
stage=sys.argv[1]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity():
    value=json.loads(subprocess.check_output(prefix+[python,'-c','import os,json;print(json.dumps(dict(uid=os.getuid(),gid=os.getgid(),groups=os.getgroups())))'],text=True))
    assert value=={'uid':65534,'gid':65534,'groups':[]}
    return value

base=dict(line.split('  ',1)[::-1] for line in (prior/'final-inputs.sha256').read_text().splitlines())
if stage=='prepare':
    assert not root.exists()
    root.mkdir()
    prior_environment=json.loads((prior/'environment.json').read_text())
    binaries=0
    for kind,directory in [('asan',prior/'build-asan'),('release_initial_sibling_layout',prior/'build-release'),
                           ('release_final_source_layout',source/'build-release')]:
        for name,expected in prior_environment['build_artifacts'][kind].items():
            path=directory/name
            assert path.stat().st_size==expected['bytes'] and sha(path)==expected['sha256'],(kind,name)
            binaries+=1
    (root/'initial-artifact-post-check.json').write_text(json.dumps({'checked_at_utc':now(),'matched_artifacts':binaries,
        'environment_sha256':sha(prior/'environment.json'),'initial_input_manifest_sha256':sha(prior/'final-inputs.sha256')},indent=2)+'\n')
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=repo).decode().split('\0')
    extra={name for name in names if name and name not in base and name.startswith(('src/','include/','tests/','scripts/'))
           and Path(name).suffix in {'.cpp','.hpp','.inc','.py'}}
    inputs={name:sha(repo/name) for name in sorted(set(base)|extra)}
    changed=[name for name,value in inputs.items() if base.get(name)!=value]
    assert changed, 'no performance correction to validate'
    for name in changed:
        path=repo/name
        assert path.is_file() and not path.is_symlink(),name
        assert b'wls_audit_perf_profile' not in path.read_bytes(),name
        destination=source/name
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path,destination)
        os.chown(destination,65534,65534)
    for name,value in inputs.items():assert sha(source/name)==value,name
    manifest=''.join(value+'  '+name+'\n' for name,value in inputs.items())
    (root/'inputs.sha256').write_text(manifest)
    focus=['store','live_model_store','process_evidence','cleanup','cleanup_runtime','worker_tools','schema',
           'config_loader','offline_runtime','https_transport','live_model_store_tls','r3_evaluation','billing_baseline_e2e']
    native_targets=['store_tests','live_model_store_tests','process_evidence_tests','cleanup_tests','cleanup_runtime_tests',
                    'worker_tools_tests','schema_tests','config_loader_tests','offline_runtime_tests']
    if 'src/single_agent.cpp' in changed:
        focus+=['single_agent','single_agent_runtime']
        native_targets+=['single_agent_tests']
    if any(name in changed for name in ['src/model.cpp','src/context_compiler.cpp',
                                       'src/structured_context.cpp','src/offline_runtime.cpp']):
        focus+=['model','r1_structured','protocol_codec']
        native_targets+=['model_tests','r1_structured_tests','protocol_codec_tests']
    record={'baseline':'d3da700c9c47db86abe941374bcbdac5e31462d4','identity':identity(),
            'initial_input_count':len(base),'initial_inputs_sha256':sha(prior/'final-inputs.sha256'),
            'final_input_count':len(inputs),'final_inputs_sha256':hashlib.sha256(manifest.encode()).hexdigest(),
            'frozen_at_utc':now(),'changed_from_initial_audit':changed,
            'asan_focus':focus,'native_targets':native_targets,'gates':[]}
    (root/'results.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({key:record[key] for key in ['final_input_count','final_inputs_sha256','changed_from_initial_audit','asan_focus']}))
    sys.exit(0)

record=json.loads((root/'results.json').read_text())
expected=dict(line.split('  ',1)[::-1] for line in (root/'inputs.sha256').read_text().splitlines())
def verify():
    for name,value in expected.items():assert sha(source/name)==sha(repo/name)==value,name
    return now()

release=source/'build-release'
asan=prior/'build-asan'
commands={
    'build-release':[('optimized-build-release',['cmake','--build',str(release),'--parallel','2'],0o022)],
    'build-asan':[('optimized-build-asan',['cmake','--build',str(asan),'--parallel','2','--target','wls',
                   *record['native_targets'],'https_transport_driver','live_model_store_driver'],0o002)],
    'test-release':[
        ('optimized-release-0022',['ctest','--test-dir',str(release),'--output-on-failure','--parallel','2'],0o022),
        ('optimized-release-0002',['ctest','--test-dir',str(release),'--output-on-failure','--parallel','2'],0o002)],
    'test-case04':[('optimized-case04',['timeout','--signal=TERM','900',python,
        str(source/'tests/test_billing_baseline_e2e.py'),str(asan/'wls'),str(source),
        'BillingBaselineIntegration.test_04_exhausted_rework_owner_question_pair','-v'],0o002)],
    'test-asan':[('optimized-focused-asan',['ctest','--test-dir',str(asan),'--output-on-failure','-R',
                    '^('+'|'.join(record['asan_focus'])+')$'],0o002)]
}[stage]
environment=os.environ.copy()
environment.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for name,command,mask in commands:
    verified_before=verify()
    binary=None
    if stage.startswith('test-'):
        binary=asan/'wls' if stage in {'test-asan','test-case04'} else release/'wls'
        binary_before=sha(binary)
    started=now(); start=time.monotonic()
    log=root/(name+'.log')
    with log.open('wb') as output:
        completed=subprocess.run(prefix+command,cwd=source,env=environment,stdout=output,stderr=subprocess.STDOUT,
                                 preexec_fn=lambda:os.umask(mask))
    elapsed=round(time.monotonic()-start,3)
    # Record the post-check on failed gates too, before testing their status.
    verified_after=verify()
    entry={'name':name,'command':prefix+command,'cwd':str(source),'identity':identity(),'caller_umask':format(mask,'04o'),
           'started_at_utc':started,'elapsed_seconds':elapsed,'returncode':completed.returncode,
           'verified_before_utc':verified_before,'verified_after_utc':verified_after,
           'input_count':len(expected),'input_manifest_sha256':record['final_inputs_sha256'],'log_sha256':sha(log)}
    if binary is not None:
        assert sha(binary)==binary_before
        entry['cli_binary_sha256']=binary_before
    if command[0]=='ctest':
        last=Path(command[2])/'Testing/Temporary/LastTest.log'
        copied=root/(name+'-LastTest.log')
        shutil.copy2(last,copied)
        entry['last_test_log_sha256']=sha(copied)
    record['gates'].append(entry)
    (root/'results.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(entry),flush=True)
    assert completed.returncode==0,log
