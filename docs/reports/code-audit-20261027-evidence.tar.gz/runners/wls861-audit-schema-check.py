from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import time

repo = Path('/workspace/scratch/8587bb1893aa/wls861')
base = Path('/tmp/wls861-audit-baseline')
root = Path('/tmp/wls861-audit-schema')
root.mkdir(exist_ok=True)
phase = sys.argv[1]
assert phase in {'red', 'green'}
for name in ['schema_tests.cpp', 'schema.cpp']:
    shutil.copyfile(repo / ('tests' if name.endswith('_tests.cpp') else 'src') / name, root / name)
for path in [root, *root.rglob('*')]:
    os.chown(path, 65534, 65534)
prefix = ['setpriv', '--reuid=65534', '--regid=65534', '--clear-groups']
identity = json.loads(subprocess.check_output(prefix + ['/tmp/wls861-audit-venv/bin/python', '-c',
    'import os,json;print(json.dumps(dict(uid=os.getuid(),gid=os.getgid(),groups=os.getgroups())))'], text=True))
assert identity == {'uid': 65534, 'gid': 65534, 'groups': []}
flags = ['-O3', '-DNDEBUG', '-std=c++20', '-Wall', '-Wextra', '-Wpedantic', '-Wconversion', '-Wshadow', '-Werror',
    '-I' + str(base/'source/include'), '-I' + str(base/'source/tests'),
    '-isystem', str(base/'source/third_party/valijson/include'),
    '-isystem', str(base/'source/third_party/libyaml/include'),
    '-DWLS_SOURCE_DIR="' + str(base/'source') + '"']
commands = []
extra = []
if phase == 'green':
    commands.append(('compile-production', ['/usr/bin/c++', *flags, '-c', str(root/'schema.cpp'), '-o', str(root/'schema.o')]))
    extra.append(str(root/'schema.o'))
commands.extend([
    ('compile-test', ['/usr/bin/c++', *flags, str(root/'schema_tests.cpp'), *extra,
        str(base/'build-release/libwls_s1.a'), str(base/'build-release/libwls_kernel.a'),
        '-lsqlite3', '-lcrypto', '-lcurl', '-lyaml', '-pthread', '-o', str(root/('schema-tests-'+phase))]),
    ('test', [str(root/('schema-tests-'+phase))])])
results = []
for name, command in commands:
    start = time.monotonic()
    with (root/(phase+'-'+name+'.log')).open('wb') as log:
        result = subprocess.run(prefix + command, cwd=base/'source', stdout=log, stderr=subprocess.STDOUT,
            preexec_fn=lambda: os.umask(0o022))
    entry = dict(name=name, returncode=result.returncode, elapsed_seconds=round(time.monotonic()-start,3), command=command)
    results.append(entry)
    print(json.dumps(entry), flush=True)
    if name != 'test':
        assert result.returncode == 0
(root/(phase+'-result.json')).write_text(json.dumps(dict(identity=identity, results=results), indent=2)+'\n')
