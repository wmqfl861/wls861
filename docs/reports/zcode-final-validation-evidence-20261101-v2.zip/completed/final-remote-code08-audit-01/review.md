精确 code08 的远端 CI 与既有产物完成独立收尾复核：**7 个 workflow、17 个 job 全部 completed/success，17 份原始 job 日志的实际 checkout 已逐一绑定；7 份原字节 archive 均重新哈希并匹配本轮 API digest。REMOTE_CI_COMPLETE_FOR_CODE08=true。** 这不是 PR 批准，也不关闭本机或历史失败。

本轮 GitHub 读取窗口为 2026-11-01T06:33:33.244950+00:00 至 2026-11-01T06:37:54.302925+00:00；核验器于 2026-11-01T06:42:41.036853+00:00 完成。共36次GET命令，全部exit0，没有发表评论、review、修改PR、触发workflow/rerun、push或merge。这里只证明各次查询截点的状态，不声称审核整个远端事件历史。

工作树仍为 `fix/zcode-local-validation-20261101`，HEAD `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`，最后Git status干净。远端开发分支仍指向该HEAD，main仍为 `a6b8559018a599d7a806b05942857a56d69a00ce`。PR #12实际base为PR #11的 `7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a`；合并验证提交为 `47534906df0402b20651b1971ac642c98aa1af9a`。本轮Git API返回该merge与head具有相同tree `149bca333bce2460ba940ace3c76cc1111dfdd83`，merge的两个parents分别为base和head。

| PR | 实际head | 实际base | 当前状态 |
| --- | --- | --- | --- |
| [#10](https://github.com/wmqfl861/wls861/pull/10) | `99c9063f3e29cd6d69c56fb15815715d499a374a` | `86b82f8f63a3c60c7659c9cd8f9b8e7d7252870b` | open / Draft / 未合并 |
| [#11](https://github.com/wmqfl861/wls861/pull/11) | `7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a` | `99c9063f3e29cd6d69c56fb15815715d499a374a` | open / Draft / 未合并 |
| [#12](https://github.com/wmqfl861/wls861/pull/12) | `08dad7e815b9c3c84d3bd2393818b2030a6e0cde` | `7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a` | open / Draft / 未合并 |

与 `latest-pr-comments-01` 的2026-11-01T05:04:41.567997+00:00快照相比，三张PR的issue comments/reviews均无新增、删除或既有正文编辑。PR #10仍只有原issue comment 6545609429和review 5723348769；review的GitHub状态为COMMENTED，正文明确CHANGES_REQUIRED/不批准合并，不能改称APPROVED。PR #11/#12无issue comment或review。三张PR的inline review comments本轮均为0；旧快照没有这一类，故只记录本轮观察，不宣称其历史未变化。

PR #12标题、head、base、merge、draft/state/merged与audit04相同；正文和updated_at确实变化，updated_at由04:02:35Z变为05:05:56Z。保存了完整 `pr12-body-change.diff`：正文更新Release两种umask已完成、当前本机ASan运行中且已有原始Timeout、UBSan/Clang待执行，以及精确08远端CI已完成。正文继续明确LOCAL_VALIDATION_COMPLETE=false、PR_REVIEW_COMPLETE=false、MERGED=false。本审核不把它误报成PR内容完全未变，也不将正文进度声明替代本机独立证据。

| workflow | event | job数 | 实际checkout | artifact |
| --- | --- | ---: | --- | --- |
| [41271462756](https://github.com/wmqfl861/wls861/actions/runs/41271462756) Windows native foundation slice | pull_request | 1 | 47534906…（PR合并验证） | 13069323249 |
| [41271462726](https://github.com/wmqfl861/wls861/actions/runs/41271462726) A4 same-source fairness counterexample | pull_request | 1 | 47534906…（PR合并验证） | 13070010643 |
| [41271462706](https://github.com/wmqfl861/wls861/actions/runs/41271462706) C++20 runtime and specification contracts | pull_request | 6 | 47534906…（PR合并验证） | 13069509584 |
| [41271460295](https://github.com/wmqfl861/wls861/actions/runs/41271460295) Verifiable committed source snapshot | push | 1 | 08dad7e…（分支HEAD） | 13069810810 |
| [41271460257](https://github.com/wmqfl861/wls861/actions/runs/41271460257) Windows native foundation slice | push | 1 | 08dad7e…（分支HEAD） | 13068994449 |
| [41271460270](https://github.com/wmqfl861/wls861/actions/runs/41271460270) A4 same-source fairness counterexample | push | 1 | 08dad7e…（分支HEAD） | 13069985633 |
| [41271460248](https://github.com/wmqfl861/wls861/actions/runs/41271460248) C++20 runtime and specification contracts | push | 6 | 08dad7e…（分支HEAD） | 13071100488 |

所有run均为attempt1；run/job集合与audit04相同，没有借用旧579绿色结果。17份原job日志分别确认Git checkout之后的 `git log -1 --format=%H` 输出，原路径、原哈希和证明行在verification.json中逐项列出。已有12份Linux原日志、两份Windows原日志均复用冻结物；本轮仅新收原fairness两份和source job一份日志，没有触发任何作业。

冻结物完整性复核为：`ci-08dad7e-audit-04` 93/93文件、`windows-code08-ci-audit-01` 174/174文件匹配原SHA256SUMS；review/verification及receipt所绑定的hash也一致。audit04引用的外部原件均重新核对，包括audit02/audit03原日志、canonical源码输入清单和原source ZIP。没有改写任何旧证据。

7份archive均检查安全成员路径、重复/大小/加密/符号链接边界，并与本轮API的大小、digest、run/head关联核对。五份已存在的Linux/Windows/source archive没有重新下载；只新下载两份此前未缓存的fairness文本archive（248438与248447字节）。原ZIP路径、所有检查的文本成员CRC/大小/SHA均在archive-identity-recheck.json中；没有盲目extractall或执行归档程序。

两份共享GCC ASan archive分别为PR `13069509584` 与Push `13071100488`。本轮直接重新解析两份原JUnit、注册plan、CTest摘要和9项step receipts：各92个唯一CTest全部run/pass，0 failure/error/skipped/notrun，精确原测试名和期限匹配Git08 catalog；所有step及log hash绑定一致、exit0。原ctest耗时分别1991.662654724s与2317.010153091s。每份794项source-before/after完全相同，61项binary/control before/after相同，三项实际归档CMake/CTest/compile控制文件重新哈希匹配。ASan/LSan选项、UID1001、build0022/test0002保持原值。Make-ASan与其余Linux矩阵的既有日志核验范围保留，不把Make target另计为92项注册CTest。

本轮对canonical源码清单794项的Git blob/mode逐项核对精确Git08 ls-tree，并把Linux两份、Windows两份及fairness两份候选运行的source hash/size/executable-bit映射与该已绑定清单核对。原source artifact `13069810810` 的24,083,543字节ZIP SHA仍为 `6cfa4b87e40f01c5ec89d40d8db40134395de67ffb217a37d248204139a1a419`，匹配本轮API；其中COMMIT/TREE/原tar SHA256SUMS也逐项匹配。完整794份源码原字节/blob验证复用audit03已冻结结果及本轮重新绑定的同一ZIP；本轮没有重新读取所有实现，也没有读取或重哈希src/runtime_types.cpp。不能把清单元数据核对扩大称为本轮重新验证全部源码原字节。

Windows两次执行的原始完整LastTest均在本轮重新解析：每次native_modules 3、native_platform 4、native_cli 14、native_bundle_capture 6，共4个CTest/27个不同方法，每个方法成功行、RESULT或Ran/OK、Test Passed和suite end齐全；原JUnit四项均run/pass、十项command receipts全部exit0。两轮是同样27个方法的两次执行，不是54个不同方法。native_cli的JUnit只有7条完整成功行，27/27结论仍来自完整LastTest，不以源码或另一轮输出补齐。

Windows事实继续限定Windows Server2022/build20348、elevated、NTFS、原生Release/MSVC x64组件和格式slice。两份原runner日志的image Version均为 `20261025.346.1`，artifact environment.image_version均为 `20261026.347.1`；本轮从原记录再次读取两值并保留冲突，**exact_windows_runner_image_identity=UNRESOLVED**，没有豁免或归因。**Windows11普通用户验收仍NOT_RUN，full_native_runtime仍NOT_IMPLEMENTED**。Store/Workspace/process/sandbox/cleanup完整安全不在此slice的通过范围。两份Windows archive没有PE本体，Linux证据archive没有ELF本体，因此本轮不能独立重哈希这些远端二进制或验证其签名。

新增的fairness两份小archive也做了原字节和收据核验：Push候选实际为head08，PR候选实际为merge475349，同tree；候选各794项source映射匹配Git08 canonical输入。基线为a2dfb463…，各719项source-before/after不变；同一Git08 probe `tests/repros/a4_fairness_same_source.cpp` 的SHA为48ae8f4db3d29835403bc41daba2554d51a2c05d5a7c3901ee901193fd25aad6。原baseline-probe两轮均exit1并有精确顺序断言失败，未达外期限；candidate-probe均exit0、RESULT 1 passed/0 failed。原source/binary before-after和step log绑定均保持。它是一项同源诊断在两个版本上的执行，不另算两套CTest；本轮没有重新核验全部基线719份原字节/blob。

审核器首轮因错误要求PR fairness候选也必须等于head08而exit1。该错误属于本轮检查器，原artifact实际正常使用merge475349。首轮源码、完整stderr/stdout、receipt和只读Git输出均移存metadata-verifier-attempt-01，没有覆盖；metadata-verifier-correction.json记录修正。v2按event检查实际candidate SHA，仍强制794项source映射与同一Git08 tree一致；v2于06:42:41.146387UTC结束，exit0、stderr为空、耗时2.300621s。这两次都是元数据/归档检查，不是产品或CI重跑。

交付状态只对应已推code08：REMOTE_CI_COMPLETE_FOR_CODE08=true；本地完整矩阵由root及其独立收据判断，本审核LOCAL_VALIDATION_COMPLETE=NOT_ATTESTED；PR_REVIEW_COMPLETE=false；MERGED=false。CI成功不能覆盖本机/历史失败或成为正式批准。审核执行UID/GID1000，仅在本新目录写入文件，没有运行产品、构建、测试、归档代码、模型、生产操作或图索引。HTTPS后继诊断与本轮无依赖，未执行。
