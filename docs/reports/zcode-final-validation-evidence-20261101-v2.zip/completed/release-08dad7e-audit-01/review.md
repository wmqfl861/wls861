精确提交 08dad7e 的 Release / umask 0022 独立证据核验完成：**VERIFIED_RELEASE_0022_92_OF_92**。完整提交为 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`，tree `149bca333bce2460ba940ace3c76cc1111dfdd83`。本结论只覆盖已经结束的 `event-full-release-0022-01` 一轮，不代替其余串行矩阵、历史失败审核或主协调者接受。

审核者 `/root/evidence_audit`；只读原始证据、精确 Git 对象及当前构建输入并计算哈希，没有编译、执行测试/模型、修改源码、停止进程或发布。所有新文件位于本目录；旧证据保持原字节。

| 执行事实 | 已验证结果 |
|---|---|
| 运行身份 | UID/GID 1000；外层 umask 0022；数据盘 TMPDIR；原命令为完整 CTest、parallel 1、no-tests=error，无筛选/改期限/仅重跑失败参数 |
| 输入提交 | command/completion 均为完整 08dad7e；开始时工作区 clean |
| 开始 / 结束 | 2026-11-01T03:52:43.809294+00:00 / 2026-11-01T04:07:37.786883+00:00 |
| 外层时间 / 退出 | 893.9771241920535 秒；exit 0；outer_timeout=false |
| 源码输入 | before=after，共 794 文件；路径、原字节 SHA、Git blob/可执行模式逐项等于精确提交树 |
| 构建清单 | 61 项 before=after，当前逐项重哈希仍匹配：56 ELF、2 静态库、3 构建元数据；不能称为 61 个可执行文件 |
| 构建配置 | 原 CMakeCache 为 Release、ASan OFF、UBSan OFF；compile_commands 含 GCC13、O3、严格警告/Werror 的 Store 编译项 |
| 产品目录 | 92 个唯一登记名和各自 TIMEOUT 与精确提交的原目录全部相符，没有 disabled 项 |
| 完整结果 | 原 stdout、JUnit、该轮独立保存 LastTest 均 92/92 PASS；0 fail、timeout、skipped、notrun，stderr 为空 |
| 进程结束 | 04:15:23 UTC 左右只读 /proc/stat 检查：CTest PID 2337175、recorder PID 2337169 不存在；PGID 2337175 无成员 |

`method-and-catalog-verification.json` 保存全部 92 项的名称、原期限、时间、原输出摘要、方法及证据级别。57 个 C++ 登记的原方法表（含按实际 argv 选择的 single-agent / R2.4 groups）与完整 PASS/RESULT 一一对齐；除原 doctor 自有 runner 不打印 START 外，其余原 START 顺序也逐项匹配。30 个 unittest 登记的原 Python AST 方法集合与具名 `... ok` 行及 Ran/OK 完整对应。另有 2 个独立完整性脚本和 1 个具有三项明确检查的 demo。

两项原 quiet unittest 输出只保留点号、Ran 和 OK：`r1_history_cli_smoke` 为 7 项，`r2_recovery_cli_smoke` 为 6 项。这些数量与原源码登记匹配、没有跳过或失败；日志没有逐方法名称，本审核没有重建或声称持有这些方法的具名运行输出。该限制不影响两项 CTest 登记实际 PASS 的判定。

本轮 Async 的 29 方法、owned-capacity 的 11 方法均完整 PASS；计费 E2E、请求恢复/Store/工作流/结算/清理和单 Agent 等仍按各自原登记与期限计数，没有把方法数换算成额外 CTest 套件。原 JUnit 成功输出发生 1024 字节截断的地方，只核原前缀与 LastTest 一致，方法级证据来自完整独立 LastTest。其 Start/End 时间为 03:52 / 04:07，未读取后续 0002 运行覆盖的共享临时日志。

LastTest SHA-256：`6681e87194b4fb9520930e62fe250984da94d9a06e3614a4f2287503c8de8404`。对原输入的完整文件/哈希记录见 `audited-original-inputs.json`；Git 源码清单见 `git-source-inputs.json`；构建重哈希见 `binary-current-rehash.json`；进程观察见 `process-exit-observation.json`。进程观察只证明所记录 PID/组在观察时不存在，不替代产品进程结算或 owned cleanup 的业务证据。

核验命令 `python3 -B verify_release_v1.py` 实际 exit 0、stderr 为空；绝对 argv、起止与输出哈希见 `verification-v1.command.json`。审核期间 root 的后续串行矩阵未被干预。

`LOCAL_VALIDATION_COMPLETE=false`：本收据仅确认完整 Release 0022 一轮。其余 Release0002、共享 GCC ASan/LSan、UBSan、Clang 由后续实际结束记录判断；本次没有关闭任何历史失败或正式批准 PR。远端提交身份及分提交 CI 记录单独保存在 `../ci-08dad7e-and-579e3c7-audit-01/`。
