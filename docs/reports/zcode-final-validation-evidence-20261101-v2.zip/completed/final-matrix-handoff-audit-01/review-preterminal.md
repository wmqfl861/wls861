两种umask的完整Release已独立核验通过，plan03已有307份可直接按映射复用的文本实体。本机ASan、后续UBSan和Clang的正式终态仍等待root通知；本文件是终态前的交接审计，**没有声明完整本地矩阵通过或最终补包审核完成**。

审核者为 `/root/delivery_report`，两轮原执行者为 `/root`。本轮只运行自编证据核验器、Git只读身份命令和文本检查，没有运行CMake/CTest、编译器或产品。code08为 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`，源码工作树核验前后干净。所有新材料只写入本目录，没有读取活动ASan/UBSan/Clang日志来认定终态，也没有读取tmp运行数据库、配置或凭据。

| 原执行 | 原结束时间UTC | 真正结果 | 时长口径 |
| --- | --- | --- | --- |
| Release0022，UID/GID1000、parallel1 | 04:07:37.786883 | 92个原注册CTest全部PASS，0失败/超时/skipped/notrun；exit0、outer_timeout=false。 | recorder893.977124192秒；CTest893.47秒。 |
| Release0002，UID/GID1000、parallel1 | 04:20:56.417195 | 同一92注册目录全部PASS，0失败/超时/skipped/notrun；exit0、outer_timeout=false。 | recorder776.829678117秒；CTest776.49秒。 |
| GCC runner工具自检 | 04:20:59.435900 | 原stderr有24条方法ok、Ran24/OK，exit0、outer_timeout=false。 | recorder1.236782866秒；这是工具方法，不是产品sanitizer通过。 |

`release-verification.json` 从两轮各自原command/completion、source-before/after、JUnit、test-plan、binary-before/after、LastTest及stdout/stderr核对结果。每轮JUnit恰好92个status=run，无failure/error/skipped；名称和顺序与各自原plan一致。每份完整LastTest分别包含92个Testing块、92个Test Passed、92个suite end及最终End testing，原stdout也为100%/0 failed out of92。补充的 `release-command-crosscheck.json` 将每个LastTest实际command与cwd逐项对照对应plan，两轮各92项均无差异。JUnit成功输出的截断不能被当作所有内部方法原始输出已逐项审核；本轮通过结论是注册CTest层面。

注册集合直接取自Git08的 `tests/gcc_asan_expected_tests.json`，92个唯一名称及每项原期限与两轮plan相同，没有只核数量。既有手动Store探针不是第93项CTest；同一92项在两种umask下执行两次，不称为184个不同套件。后续每种编译配置同样要独立核名称、期限、实际选中和结局，不能移用Release或远端结果。

两轮各自794项source-before与after完全一致，两轮间相同。核验器将全部794个路径和记录字节/SHA与Git08真实blob对照，并重哈希当前tracked源文件，均匹配；这是输入身份核验，不是794文件实现语义审计。Git条目模式为100644，原记录及当前文件系统权限为0664，两种模式分别保留，不能把文件系统权限误报为0644；可执行位一致。

两轮61项binary/control-before与after一致，两轮间也相同。本次另外重哈希已结束Release目录的这61个实体，全部匹配原清单；这份当前观察与原执行前后清单分开登记。CMakeCache记录Release、compiler `/usr/bin/g++-13`、ASan=OFF、UBSan=OFF；92条编译命令均有-O3、-DNDEBUG、-Werror且没有-fsanitize参数。command环境中的ASAN_OPTIONS/UBSAN_OPTIONS不能把Release改计为sanitizer运行。没有执行这些二进制或宣称可重复构建证明。

核验器实际在06:36:01–06:36:15 UTC运行，exit0、stderr为空、13.899488329秒；准确argv和输出身份见 `release-audit-command-receipt.json`。原材料来源/哈希在 `original-input-identities.json`，Git命令结果在 `git-command-receipts.json`，794条映射在 `git08-source-crosscheck.json`，当前61项实体在 `release-current-binary-identity.json`。

plan03的复用判断已有实体证据。06:38:28 UTC逐份读取其 `prepared-text/` 中307份文件，全部字节/SHA与冻结whitelist/index一致，均为普通0644，共4827093字节；其中270份original、37份projection。来源/projection算法已经在原独立准备审核中核验，本轮没有重新执行该整个来源审核。可以在新的final目录中按archive_path显式复制这些精确字节、沿用原来源映射，再加入真正终态的新成员及新控制文件，不必重做整套。

角色边界需明确：本审核者也是plan03作者，因此此处只是作者对复用性的检查，不冒称第二次非作者批准。独立准备结论仍来自 `/root/evidence_audit` 的 `late-evidence-preparation-review-03`：06:01:29完成，completion SHA `43eec6eb8263dd4d01dcf4dda97ec73e95cfde13185c332849dc2ea57647612b`，范围为已准备307份文本，59条pending未读；FINAL_ARCHIVE_REVIEW_COMPLETE和PUBLICATION_APPROVED均为false。真正最终ZIP由root或另一个独立reviewer按精确字节复核，组装者不能自行批准。

最终还需要补齐的实际证据已逐项写入 `outstanding-evidence-preterminal.json`：

- 共享GCC门禁的外层completion、官方最终summary及各step实际命令/时间/退出、完整或明确缺失的ctest/JUnit/自有LastTest、source与binary/control-after、实际进程收尾观察。已经结束的失败叶子与活动前缀不能替代门禁最终退出。
- UBSan和Clang的真实configure/build/CTest收据及来源路径、原92项名称/期限、每种真实失败/超时/skipped/notrun、各自before/after身份与进程结束。现在的round/build名称只是计划locator，不能从计划或目录出现推导执行成功。
- 串行driver本身的最终事件/完成记录，明确每一阶段是否真的执行、失败后是否继续，以及任何未执行或中断。若最后没有某个after/JUnit/LastTest，应登记缺失与原因，不重建成并不存在的原件。
- 新最终包的逐成员映射和实际控制文件、全部成员扫描、CRC/模式/路径/哈希、外部精确ZIP身份及非作者审核、实际发布读回、未来docs commit/tree/差异和该SHA自己的CI。code08和PR merge475349的原成功范围保持，不延伸到未来报告SHA。

当前pending59条实际分为GCC45、UBSan7、Clang7；其中包括条件日志和未解析的收据集合，不能称为59个缺失文件或59个未执行测试。本轮没有打开或哈希这些路径。`test-plan.log`在plan03中已经明确NEVER_GENERATED并移出pending，实际stdout为test-plan.json；旧plan01原字节保留，不能重新沿用那个错误路径。

公开投影有一个已经观察到的内容风险，不能只靠路径分类处理：T4的live_workflow断言曾打印完整raw result。最终ASan的ctest/LastTest/JUnit若包含这段或其他原始结果，必须按实际字节重新审阅，不能自动沿用草案中的original分类。原件继续私有留存；需要投影时，保留原SHA、完整失败状态/trace和允许的error/report字段，明确投影算法和省略范围，不隐藏失败。T4原段和CLI99份私有原日志都没有因本交接获准自动公开。

其余路径和身份风险写在 `path-and-projection-risks.json`：使用每轮自己的LastTest以免复用被覆盖的共享输出；按明确最终成员集合复制，禁止目录glob扩大来源；archive path必须相对规范且无drive/backslash/父级/大小写或归一化碰撞，provenance内绝对源路径不是解压目的地；plan03控制文件不能直接当成final控制文件；checksum与引用ZIP哈希的审查/上传收据保持自引用排除；源码mode、CTest、内部方法、工具自检、Make、workflow/job、归档成员各自计数。

实施计划是等待root正式终态通知，然后对新增终态原件做一次完整身份与结果复核，记录所有失败；随后在新final目录复用已审307份payload并按明确白名单添加终态/诊断投影，生成新控制文件和ZIP，交root或独立reviewer验精确字节。当前没有创建final目录、生成ZIP、改报告或发布，也没有并行重测。历史失败、Windows精确image差异及Windows11普通用户NOT_RUN均保持原范围。

一次工具编排使用未定义的workdir变量T导致ReferenceError，随后改为显式taskroot重试只读readiness检查；没有因此执行产品或修改旧材料。原Release审计进程独立正常结束，其真实exit0从已写入的原命令收据和stdout/stderr核验，未把编排错误算作产品失败或伪造测试完成。

本阶段状态：**RELEASE_EVIDENCE_AUDIT_COMPLETE=true；PREPARED_PAYLOAD_REUSABLE=true；MATRIX_TERMINAL_AUDIT_COMPLETE=false；LOCAL_VALIDATION_COMPLETE=false；FINAL_PACKAGE_ASSEMBLED=false；FINAL_ARCHIVE_REVIEW_COMPLETE=false。** 这份终态前审计保留原字节，收到真正结束材料后另增版本，不能回填成当前已完成。
