# UBSan async 已结束注册项的只读复核（2026-11-01）

已独立确认冻结块的原CTest行是 `51/92 Test #51: async_coordinator ... ***Timeout 180.02 sec`。08源码按固定顺序注册29个内部方法；本块START恰好为前28个、PASS恰好为前27个，FAIL、UNTIL-DEADLINE和RESULT均为0。第28个方法只有START，第29个AMEND方法没有START。**这是一个CTest注册项的Timeout及其方法输出，不是28或29个独立CTest；没有确认新的生产缺陷或根因。**

本审核仅读取root已抽取、冻结的3881字节私有块、安全投影及三个精确08源码文件，没有打开正在增长的UBSan stdout、JUnit、完整LastTest或其他活动日志。原块SHA256为 `8f77f654077e804732a4bf2dcb5f504156a1dc628b7b6f0494f0c3b000e8ec04`，大小、摘要和全部安全投影标记逐字相符。原块本身含终态Timeout行；root观察其后已有Start52来自父任务通知，本次未另读活动日志以验证该后继行。整个UBSan阶段、其最终JUnit和执行前后完整输入/二进制身份仍须等root终态取证，不能从本块推断全部完成或总体通过。

当前三个源码文件逐字匹配Git `08dad7e815b9c3c84d3bd2393818b2030a6e0cde` 自身blob，路径、大小、SHA256及实际只读Git命令列在input-manifest.json。它们证明此次静态阅读对应08，不代替未来整阶段source/binary-after核验。原始片段只在来源目录私有保留，本目录不复制它或任何运行数据库/配置。

**已观察结果与范围。**

| 观察 | 能确定 | 不能推出 |
| --- | --- | --- |
| 前27个START/PASS与main前27项逐名、逐序相同 | test_support在调用返回后输出并flush PASS，因此这些调用已经正常返回到runner。 | 不能据此批准整个套件、全部安全边界或整个UBSan门禁，也没有新读其最终二进制身份。 |
| 第28 START：resource FIFO spans all classes while independent siblings progress | runner已发出并flush该方法名，随后未见对应PASS/FAIL。 | 不能把缺结束标记称为方法已失败、死锁、五秒等待断言命中、或纯性能问题。 |
| 第29 AMEND of a resource waiter preserves original capture and predecessor无START | 本冻结块没有观察到进入该项的start标记，分类NO_START_MARKER_OBSERVED。 | 不补造其失败、成功、持续时间或独立测试退出。 |
| CROSS_POOL_FIFO cycle=0 new_model_calls=4 accepted=4 resource_fifo=preserved | 它位于此前第23项cross-pool resource heads的START/PASS之间；该行保留原四调用进展观察。 | 不是第28项计数，不能用它证明第28项的四调用已完成。 |
| 无UNTIL-DEADLINE、无FAIL、无RESULT | 本块未出现这些即时输出。 | 不能证明原五秒条件未超时、无异常、或已完成析构。 |

**当前源码提供的有界定位。** `tests/async_coordinator_tests.cpp:1095` 的main初始化schemas/SQL后按固定向量调用 `test::run`，最后两项在1131/1132行；`async_resource_lifecycle_cases.hpp` 在1092行真实包含。`tests/test_support.hpp:48` 在调用前输出START并std::endl，49行仅在function()返回后输出PASS，50–51行捕获std::exception后才输出FAIL。若异常在函数内抛出，局部对象析构必须先完成才到runner catch；因此没有FAIL也不排除正在异常展开或收尾。缺少RESULT说明没有观察到整组末尾总结，不给每个未结束方法补造结果。

最后方法名映射到 `tests/async_resource_lifecycle_cases.hpp:170` 的 `resource_fifo_spans_normal_review_handoff_and_allows_siblings`。START之后的范围包含下列真实步骤；日志没有阶段时间标记，无法从本次输出选定其中某一步：

| 源码范围 | 真实业务/夹具路径 | 证据限制 |
| --- | --- | --- |
| 171–178 | Fixture配置构造、Store打开、四个请求admit、对normal和handoff分别ready；ready实际运行OfflineRuntime链路。 | 第28 START发生在这些操作之前；不能直接假定已到资源队列或首次until。 |
| 179–191 | 三个Gate及Release、四个真实捕获/submit；Normal Worker、Review Dispatcher、Handoff Worker共享资源，另有独立Dispatcher sibling。池固定2/2。 | 无本项calls/claim/快照输出，不能从前项CROSS_POOL_FIFO替补这些事实。 |
| 192–199 | until等待normal已入Gate且sibling ready，get sibling并检查计划、排队/阻塞/槽位和两条claim。 | 不知是否到达或通过；不能仅据无deadline日志判定poll、predicate或Store调用均有界。 |
| 200–212 | 释放Normal后等Review入Gate、检查原反馈/状态；释放Review后等Handoff入Gate并核容量。 | 三次until的具体阶段未知，未观察到任何一处阶段完成或失败。 |
| 213–223及退出 | 释放Handoff、drain/get，核三原attempt/response/feedback、四claim/ops和outstanding=0，然后局部对象销毁。 | 这些断言是否执行、哪个对象的收尾完成均未知；不能把Timeout全部归给drain或析构。 |

主文件155–174行的until只在入口取一次五秒deadline；每圈先predicate，再runtime.poll，poll返回后取clock并打印UNTIL-DEADLINE及CHECK。若前置准备、predicate、poll或后续同步动作尚未返回，局部五秒不是硬抢占；无UNTIL-DEADLINE也不缩小为“未超时”。当前CTest180.02秒是整29方法及setup/cleanup的累计期限，没有方法起止时间，不能算出第28独占180秒，亦不能由全组累计时间证明死锁或资源调度正确。

GatedModel在主文件88–108行执行实际FakeModel；有Gate时先等待。Gate在64–76行用condition_variable等待release或可选stop；本方法f.model默认respect_stop=false。Release对象析构调用gate->release，声明在runtime之后，正常/异常离开函数时这些局部释放先于runtime析构。以上只说明静态释放设计，未捕获到本次释放是否发生，不能据此证明无阻塞或推断具体生产调用栈。本审核没有读取生产AsyncCoordinator/Store实现或采集线程栈，因此不提交它们的完整调用链结论。

图依据只引用父任务已做的Verify检查：wls861-next-cycle generation2026-10-31T06:55:42Z属于旧worktree，async图搜索零结果，相关源/头/cases缺coverage，test_support的metadata_match也不是当前checkout。该检查由root执行，本审核未重复图查询或建索引；当前事实来自精确08源码fallback。零图结果不是无调用证明，图不提供本次完整覆盖。

**只提出一个后继诊断，不执行。** 若root在整正式driver与编译全部结束后需要定位，可在独立诊断工作树对原async单注册做一次有界test-only阶段观测：保留29方法顺序、原180秒与每次五秒期限、全部断言和真实Store/FakeModel输入；在第28方法的Fixture/Store、admit/ready、submit、三次until的poll进入/返回、Gate release、drain以及退出收尾前后写私有有界monotonic阶段号/计数并flush。禁止打印请求/完整配置、取消正常调用或预造业务状态解锁。此建议尚未实现、没有运行；所得结果分类DIAGNOSTIC_NOT_GATE，不能改写本次原日志，也不直接解释历史GCC/Clang/live_workflow失败。只有新阶段证据实际到位后，再由主协调者决定是否采栈或建立最小生产反例。

本次结论为 READ_ONLY_COMPLETED_CTEST_REVIEW_COMPLETE / ROOT_CAUSE_OPEN；不改变code08 LOCAL_VALIDATION_COMPLETE=false，历史失败和主协调者CHANGES_REQUIRED保持。没有产品/诊断/测试/编译/模型调用、进程干预、网络请求或源码/原报告修改；整个UBSan矩阵仍待精确终态核验。
