08dad7e 的一次有界 CI 更新审核完成：**8 个 Linux 作业成功并已核原日志，4 个 Linux 作业仍运行。REMOTE_CI_COMPLETE=false。**

目标完整提交 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`。workflow 查询截止 2026-11-01T04:28:53.661962+00:00，7条中5条success、Push/PR Linux两条in_progress。随后各Linux矩阵只查询一次jobs/artifacts，job截止2026-11-01T04:30:40.838427+00:00。没有再次轮询或索取pending日志。

审核者 `/root/evidence_audit`；只读API/原日志/Git目录，不执行构建、测试、模型或源码修改。八份完整原始日志已下载，所有请求exit0；未打印原日志中的终端控制序列。verify_logs_v1.py实际exit0、stderr空。

| 事件 | 配置 | Job | 结果 | CTest秒数 |
|---|---|---|---|---:|
| pull_request | Linux C++20 (ASan) | [124744917757](https://github.com/wmqfl861/wls861/actions/runs/41271462706/job/124744917757) | in_progress | — |
| pull_request | Linux C++20 (Clang-18) | [124744917858](https://github.com/wmqfl861/wls861/actions/runs/41271462706/job/124744917858) | 92/92原CTest通过 | 300.65 |
| pull_request | Linux C++20 (Make-ASan) | [124744917912](https://github.com/wmqfl861/wls861/actions/runs/41271462706/job/124744917912) | in_progress | — |
| pull_request | Linux C++20 (strict) | [124744917993](https://github.com/wmqfl861/wls861/actions/runs/41271462706/job/124744917993) | 92/92原CTest通过 | 201.67 |
| pull_request | Linux C++20 (strict-umask-0002) | [124744918026](https://github.com/wmqfl861/wls861/actions/runs/41271462706/job/124744918026) | 92/92原CTest通过 | 211.90 |
| pull_request | Linux C++20 (UBSan) | [124744918039](https://github.com/wmqfl861/wls861/actions/runs/41271462706/job/124744918039) | 92/92原CTest通过 | 1286.24 |
| push | Linux C++20 (ASan) | [124744910414](https://github.com/wmqfl861/wls861/actions/runs/41271460248/job/124744910414) | in_progress | — |
| push | Linux C++20 (UBSan) | [124744910493](https://github.com/wmqfl861/wls861/actions/runs/41271460248/job/124744910493) | 92/92原CTest通过 | 1297.49 |
| push | Linux C++20 (Clang-18) | [124744910530](https://github.com/wmqfl861/wls861/actions/runs/41271460248/job/124744910530) | 92/92原CTest通过 | 240.36 |
| push | Linux C++20 (strict-umask-0002) | [124744910542](https://github.com/wmqfl861/wls861/actions/runs/41271460248/job/124744910542) | 92/92原CTest通过 | 302.05 |
| push | Linux C++20 (Make-ASan) | [124744910575](https://github.com/wmqfl861/wls861/actions/runs/41271460248/job/124744910575) | in_progress | — |
| push | Linux C++20 (strict) | [124744910654](https://github.com/wmqfl861/wls861/actions/runs/41271460248/job/124744910654) | 92/92原CTest通过 | 309.05 |

八份日志的实际Git checkout均核验：Push为完整08，PR为合并验证提交47534906df0402b20651b1971ac642c98aa1af9a。此前独立查询已确认该merge的父对象为base7dc/head08、tree与head同为149bca333bce2460ba940ace3c76cc1111dfdd83。八次各含原92个唯一测试名、完整通过摘要和结束时间，普通用户guard及umask命令保留；UBSan的ON标志只出现在UBSan配置，ASan均为OFF，未把这些结果冒充ASan验证。

两端ASan与Make-ASan四项仍in_progress，两个Linuxartifact列表在本次查询中均为空，没有可收取的sanitizer产物。其余五个非Linuxworkflow只记录已完成success的元数据，本轮未重新查询它们的job级状态、Windows/fairness产物。此前794文件源码artifact核验继续保留于ci-08dad7e-and-579e3c7-audit-01，不以本轮成功日志代替完整源码/二进制产物审核。

这是精确08的当前已结束日志证据，不继承旧579的17个绿色作业。仍须保留REMOTE_CI_COMPLETE=false、本地余下矩阵待结束和协调者正式审核待办。后续完成需新收据，不修改本次截止记录。
