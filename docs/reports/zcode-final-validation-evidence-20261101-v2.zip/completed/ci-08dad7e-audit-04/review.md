精确提交 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde` 的远端 CI 已核验完成：**7 条 workflow、17 个 job 全部 success，其中 12 个 Linux job 的原始日志已在连续冻结审核中核验。REMOTE_CI_COMPLETE=true；LOCAL_VALIDATION_COMPLETE=false。**

审核者 `/root/evidence_audit`。本轮只查询一次各状态：workflow 截点为 `2026-11-01T04:56:37.340689+00:00`，两个 Linux 矩阵 job 截点为 `04:56:38.943402+00:00`，其余五个 job 的一次查询最后结束于 `04:57:54.607495+00:00`。没有追加远端运行或再次轮询。

分支 `fix/zcode-local-validation-20261101` 仍指向精确 08，[Draft PR #12](https://github.com/wmqfl861/wls861/pull/12) 的 head/base/merge 和 ref 均未变。base 为 `7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a`；PR 合并验证提交为 `47534906df0402b20651b1971ac642c98aa1af9a`，其树与 head 同为 `149bca333bce2460ba940ace3c76cc1111dfdd83`。PR 的 title/body/state/draft/merged/merge_commit_sha/updated_at 与 audit03 原件逐项相同，updated_at 仍为 `04:02:35Z`。这证明查询截点的引用与所比字段未变，不声称审计了整个远端操作历史。PR 尚未合并。

| 已完成 workflow | 实际结论 |
| --- | --- |
| [PR Linux 41271462706](https://github.com/wmqfl861/wls861/actions/runs/41271462706) | 6 个 job success |
| [Push Linux 41271460248](https://github.com/wmqfl861/wls861/actions/runs/41271460248) | 6 个 job success |
| [PR Windows 41271462756](https://github.com/wmqfl861/wls861/actions/runs/41271462756) | 1 个 job success |
| [Push Windows 41271460257](https://github.com/wmqfl861/wls861/actions/runs/41271460257) | 1 个 job success |
| [PR A4 fairness 41271462726](https://github.com/wmqfl861/wls861/actions/runs/41271462726) | 1 个 job success |
| [Push A4 fairness 41271460270](https://github.com/wmqfl861/wls861/actions/runs/41271460270) | 1 个 job success |
| [Source snapshot 41271460295](https://github.com/wmqfl861/wls861/actions/runs/41271460295) | 1 个 job success |

本轮新增收取三份完整原始 job 日志和一份 artifact。Push GCC ASan job `124744910414` 的 API 完成时间为 `04:43:59Z`，PR Make-ASan `124744917912` 为 `04:44:47Z`，Push Make-ASan `124744910575` 为 `04:43:24Z`。三份原日志的实际 checkout 分别是完整 head08、merge475349、head08，均与期望相同。

两份共享 GCC ASan artifact 均重新核验：GCC 13.3.0、Debug、UID/GID 1001、build umask 0022、test umask 0002、`ASAN_OPTIONS=halt_on_error=1:detect_leaks=1`。原始 92 个唯一测试名、原始期限、JUnit 状态和完整 CTest 摘要全部匹配精确 Git08 的 catalog，均为 **92 PASS、0 failure/error/skipped/notrun**。summary 内每个 step 与各自原 receipt 相同、全部 exit 0，日志哈希匹配。

| 共享 gate | 原 ctest 实际退出与耗时 | 源码及构建证据 |
| --- | --- | --- |
| PR artifact `13069509584` | exit 0；1991.662654724 秒；`04:38:01.209297+00:00` 结束 | 794 项源码前后相同并匹配 Git08；61 项 binary/control 清单前后相同。 |
| Push artifact `13071100488` | exit 0；2317.010153091 秒；`04:43:55.542140+00:00` 结束 | 同样核实 794 项源码与 61 项 binary/control。 |

新 Push ZIP 为 134235 字节，SHA-256 `4945da652f7f45f7747fcd7bea461303add19e9cc30d69156e562bdd3603ffd7`，匹配 API digest。两份归档中的 CMakeCache、CTestTestfile、compile_commands 三项 control 文件已重哈希；归档没有 ELF 载荷或完整 LastTest，因此未宣称远端 ELF 重哈希或全部内部方法输出完整。

两份 Make-ASan 原日志保留实际 `make -j2 asan BUILD_DIR=build-make CPPFLAGS=-DWLS_CI_USER_CPPFLAGS=1` 调用、umask 0002、普通用户 UID 1001 的观察、ASan/泄漏检测 flags、用户 CPPFLAGS，以及完整退出收尾。GitHub 原 Make step 和 job 均 success；原日志包含 async 29/29、owned 11/11 和最后 16 项 unittest 的 OK 结果。没有将 Make 执行计成另一次 92 项注册 CTest，也未捏造没有提供的 Make before/after inventory 或独立数值 exit receipt。

此前八份 strict/strict-umask-0002/Clang-18/UBSan 原日志，以及 PR GCC ASan 原日志/ZIP 均从原冻结目录读取并重哈希。源码 artifact `13069810810` 的原始 ZIP 在本轮再次重哈希，保持 SHA-256 `6cfa4b87e40f01c5ec89d40d8db40134395de67ffb217a37d248204139a1a419`；其完整 794 文件路径/原字节/blob/mode 验证保留在 audit03。本轮再将输入清单的 blob/mode 与精确 Git08 `ls-tree` 对照。旧 579 的绿色结果没有转移到 08。

本机对照仅使用 **04:57:49.739025 UTC** 读取的活动日志副本：`build-gcc-asan-20261101T042059Z-b7698edb/evidence/ctest.log`。当时共有 16 条已结束测试记录，下一条为正在启动的 `event_runtime`。summary 的 NOT_COMPLETE、steps=[] 为预写状态，不能作为最终退出或失败类别。下表远端为原 JUnit 秒数，本机为原 CTest 已输出秒数；超时值是达到期限的观察，不能当作完成耗时。

| 测试 | 原期限（秒） | 远端 PR（PASS，秒） | 远端 Push（PASS，秒） | 本机截点观察 |
| --- | ---: | ---: | ---: | --- |
| r3_offline_acceptance_cli | 600 | 79.1387 | 92.1821 | Timeout 600.12 秒 |
| store | 90 | 9.54418 | 10.2695 | Timeout 90.39 秒 |
| workflow_store | 90 | 9.90404 | 11.409 | Timeout 90.31 秒 |
| acceptance_store | 90 | 12.5814 | 14.782 | Timeout 90.40 秒 |
| offline_runtime | 90 | 6.44749 | 5.84409 | PASS 61.91 秒 |

三端均 GCC 13.3.0、Debug，CMAKE_CXX_FLAGS 为空、DEBUG flags 为 `-g`、ASAN=ON、UBSAN=OFF；测试 umask 和 sanitizer environment 相同。每端 92 条 compile_commands，在仅将各自源码/构建路径替换为占位符后逐 token 比较，全部相同，没有删除任何编译 flags。其警告和 sanitizer flags 包含 `-Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror -fsanitize=address -fno-omit-frame-pointer`。本机 source-before 794 项与 Git08 相符，binary-before 有 61 项，但未把活动运行当作已有 after 或最终退出证据。

三端原 configure 日志均找到 Boost 1.83.0，Boost_INCLUDE_DIR 为 `/usr/include`，Boost_DIR 为 `/usr/lib/x86_64-linux-gnu/cmake/Boost-1.83.0`。Boost_FOUND、Boost_VERSION、Boost_VERSION_STRING 未单独写入 cache，报告没有虚构这些键；版本证据来自原 configure 和 FIND_PACKAGE_MESSAGE_DETAILS_Boost。`src/boost_json.cpp` 三端均是实际编译输入，原字节哈希及归一化编译命令相同。

本机补充只读观测于 **05:03:04 UTC** 完成：store_tests 当前哈希仍匹配 before，`readelf -d` 显示 NEEDED `libasan.so.8`；编译器的 libasan 链接解析到 `/usr/lib/x86_64-linux-gnu/libasan.so.8.0.0`，已安装 libasan8 版本为 `14.2.0-4ubuntu2~24.04.1`。libboost1.83-dev 为 `1.83.0-2.1ubuntu3.2`。联合 dpkg 查询因 `libboost-dev` 元包不存在而 **exit 1**，原 stdout/stderr 已保留；这是包元数据查询结果，没有改写成测试通过或隐藏失败，也没有否认已安装的实际 Boost 开发包。

本机 uname 为 6.8.0-147-generic，lscpu 报告 4 个逻辑 CPU、Intel Xeon E5-2696 v4、KVM；当前观察进程的 affinity 为 0–3。远端 summary 平台为 7.0.0-1017-azure、x86_64、glibc2.39；本机 summary 同为 x86_64/glibc2.39。现有远端日志/归档未记录精确 libasan 包版本、ELF SONAME 证据或 CPU 型号/数量，故这些远端字段明确为未取得，没有追加远端命令。本机已安装库的路径也不等于证明每个进程实际加载了该路径。

root 的 `asan-resource-interval-01` 原始两份记录已只读复制并核对原件哈希。其约 30.289 秒区间记录 cpu.max=max、nr_throttled=0、未见 OOM 事件、host CPU steal 占前八项增量的 25.6917%。这些事实只属于该区间，不解释此前超时，不形成硬件、内核、编译器、库或存储的因果归因。

16 次 GitHub API/日志/产物获取全部 exit 0，原命令、时间、退出和哈希齐全。主证据验证器 **exit 0、stderr 空**，耗时 3.075461 秒。额外四个本机只读元数据命令 exit 0；上述 dpkg 联合查询保留 exit 1。机器核验见 `verification.json`、`local-remote-comparison.json`、`environment-comparison.json`，外部输入身份见 `external-inputs.json`。活动文件仅保存读取截点的副本，副本哈希不被声明为活动源文件的最终哈希。

本审核确认精确 08 的所有 workflow/job 已成功结束。Windows/fairness 的新 08 作业只核对本次 API 成功元数据，其产物内容没有另做独立方法级复核；这一范围限制保留。远端结果不能关闭本机超时或历史 Clang ASan 失败，不能替代主协调者接受，也不授权合并。本轮未执行产品、构建、测试、模型、图索引、源码或旧证据修改、进程干预、提交、推送或合并。
