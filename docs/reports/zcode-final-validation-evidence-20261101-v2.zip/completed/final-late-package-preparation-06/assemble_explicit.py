"""Preparation-only until root supplies the actual final matrix receipt.

Never run product code, discover members by glob, or rewrite prepared plan03.
--check-preparation reads only the frozen control metadata, not pending sources.
--assemble is deliberately gated and creates new paths exclusively.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from package_privacy_guard import scan_payload

HERE = Path(__file__).resolve().parent
TASK = HERE.parent.parent
PLAN = TASK / 'evidence/public-event-late-results-plan-03'
CODE = '08dad7e815b9c3c84d3bd2393818b2030a6e0cde'
PINS = {
    'whitelist-v3.json':'d6c20b3ce31cd213f9863b6d351dc9edeeb97e2688556dbc9f33c4020b16ee13',
    'index-v3.json':'9458b23ab82fe1c36814cdb6cc5d3aa2329b5ec0f61ec40bc91c083a75abc95a',
    'freeze-receipt-v3.json':'9f345d7e0c8cfb16a1296c1ee58647af52d3245a44e7a65554c8425a4dc981b3',
    'projection-spec-v3.json':'2bad6e5415d3a15732e9f74bb5d136d0321739dbb1e969e1a5cfa9c0e8bae67f',
}
GROUPS = {'terminal_outer','local_gcc_asan','local_ubsan','local_clang_release',
          'code08_latest_ci_audit','t4_safe_analysis','root_final_report','completed_phase_audits',
          'billing_ci_audit','partial_upload_diagnostic'}
BASE_REPLACEMENTS = {
    'completed/event-full-release-0002-01-identity/ctest-logs/LastTest.log': '7069fbf9744d796c148164466c0146bc27701c1d43a2281ad01bd1ceb46cb00f',
    'completed/ci-08dad7e-audit-04/job-124744910575.log.projection.txt': '6eb57125cf0440d4b69916988c8abcde52755613ff5eb6bd37512fb1360b7436',
    'completed/ci-08dad7e-audit-04/job-124744917912.log.projection.txt': 'fd1dd4d3171e3fc8410ddd2970ce711477eafacdc60726befd6b692346bd6fac',
}
PATTERNS = {
    'private_key':r'-----BEGIN (?:RSA |DSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----',
    'github_token':r'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b',
    'aws_access_key':r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
    'bearer':r'(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{12,}',
}

def ident(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def encoded(value):
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')

def regular(path):
    path=Path(path)
    assert path.is_absolute() and path.is_relative_to(TASK), 'source outside task root'
    assert path.resolve()==path, 'symlink or noncanonical source'
    assert stat.S_ISREG(path.lstat().st_mode), 'source is not regular'
    return path.read_bytes()

def refread(ref):
    raw=regular(ref['path'])
    assert ident(raw)=={'bytes':ref['bytes'],'sha256':ref['sha256']}, 'source identity changed'
    return raw

def safe_name(name):
    p=PurePosixPath(name)
    assert name and not p.is_absolute() and p.as_posix()==name
    assert all(x not in ('','.','..') for x in p.parts)
    assert '\\' not in name and ':' not in name and '\x00' not in name
    assert unicodedata.normalize('NFC',name)==name
    return name.casefold()

def textcheck(raw):
    text=raw.decode('utf-8',errors='strict')
    assert '\x00' not in text
    assert not any(ord(c)<32 and c not in '\t\n\r' for c in text), 'C0 needs explicit projection'
    return text

def pointer(value,path):
    assert path.startswith('/')
    for part in path[1:].split('/'):
        part=part.replace('~1','/').replace('~0','~')
        value=value[int(part)] if isinstance(value,list) else value[part]
    return value

def controls():
    frozen={}
    for name,sha in PINS.items():
        raw=regular(PLAN/name);assert ident(raw)['sha256']==sha
        frozen[name]=json.loads(raw)
    members=frozen['whitelist-v3.json']['members'];index=frozen['index-v3.json']['entries']
    assert len(members)==len(index)==307
    assert frozen['whitelist-v3.json']['validated_code_commit']==CODE
    for ordinal,(member,row) in enumerate(zip(members,index)):
        assert row['whitelist_member_ordinal']==ordinal
        assert all(row[k]==member[k] for k in ('archive_path','prepared_path','bytes','sha256','source_path','source_bytes','source_sha256','treatment'))
    assert len({safe_name(m['archive_path']) for m in members})==307
    return members

def project(source,row):
    recipe=row['projection_fields_or_algorithm_if_any']
    if row['treatment']=='original':
        assert recipe is None
        return source
    assert row['treatment']=='projection' and isinstance(recipe,dict)
    algorithm=recipe['algorithm']
    if algorithm=='C0_THEN_BYTE_RANGE_REPLACE_V1':
        assert row['archive_path'] in BASE_REPLACEMENTS
        first=dict(row,projection_fields_or_algorithm_if_any={'algorithm':'LOG_C0_ESCAPE_V1'})
        intermediate=project(source,first)
        assert ident(intermediate)==recipe['intermediate_identity']
        second=dict(row,projection_fields_or_algorithm_if_any={
            'algorithm':'BYTE_RANGE_REPLACE_V1','replacements':recipe['replacements']})
        return project(intermediate,second)
    if algorithm=='BYTE_RANGE_REPLACE_V1':
        cursor=0;chunks=[]
        for span in recipe['replacements']:
            start,end=span['byte_start'],span['byte_end']
            assert cursor<=start<end<=len(source)
            assert ident(source[start:end])['sha256']==span['original_range_sha256']
            replacement=span['replacement_utf8'].encode('utf-8')
            assert replacement and ident(replacement)==span['replacement_identity']
            chunks.extend([source[cursor:start],replacement]);cursor=end
        assert recipe['replacements'], 'empty projection'
        chunks.append(source[cursor:]);result=b''.join(chunks)
        if row.get('format')=='junit_xml':
            before=ET.fromstring(source);after=ET.fromstring(result)
            assert before.attrib==after.attrib
            def statuses(root):
                return [(c.attrib,[(x.tag,x.attrib,x.text) for x in c if x.tag in {'failure','error','skipped'}]) for c in root.findall('.//testcase')]
            assert statuses(before)==statuses(after), 'JUnit outcome changed'
        return result
    if algorithm=='JSON_FIELDS_V1':
        original=json.loads(source);selected={}
        for field in recipe['fields']:
            assert field['output_key'] not in selected
            selected[field['output_key']]=pointer(original,field['source_json_pointer'])
        return encoded(selected)
    if algorithm=='LOG_C0_ESCAPE_V1':
        text=source.decode('utf-8',errors='strict')
        return ''.join('\\u%04x'%ord(c) if ord(c)<32 and c not in '\t\n\r' else c for c in text).encode('utf-8')
    raise ValueError('Unsupported projection; supply a new reviewed explicit recipe')

def assemble(manifest_path,output,zip_path):
    # All gate checks happen before reading any new/pending source.
    selection_raw=regular(manifest_path);selection=json.loads(selection_raw)
    assert selection['state']=='FINAL_SOURCE_SELECTION_FROZEN'
    assert selection['validated_code_commit']==CODE
    assert selection['root_formal_terminal_notice_received'] is True
    assert set(selection['phases'])=={'gcc_asan','ubsan','clang_release'}
    assert all(p['state'] in {'COMPLETED','INTERRUPTED','NOT_RUN','MISSING_FINAL_EVIDENCE'}
               and p['reason_or_evidence'] for p in selection['phases'].values())
    terminal=json.loads(refread(selection['driver_completion']))
    assert isinstance(pointer(terminal,selection['driver_exit_code_pointer']),int)
    assert pointer(terminal,selection['driver_ended_at_pointer'])
    assert selection['readme_text'] and selection['members']
    output=Path(output);zip_path=Path(zip_path)
    assert output.is_absolute() and output.is_relative_to(TASK/'evidence')
    assert zip_path.is_absolute() and zip_path.is_relative_to(TASK/'evidence')
    assert output.resolve()==output and zip_path.resolve()==zip_path
    assert output.parent==zip_path.parent==TASK/'evidence'
    assert not output.exists() and not zip_path.exists()
    receipt_path=zip_path.with_name(zip_path.name+'.assembly-receipt.json')
    assert not receipt_path.exists()
    members=controls();payload={};folded=set();provenance=[]
    replacements={m['archive_path']:m for m in selection['frozen_member_replacements']}
    assert len(replacements)==len(selection['frozen_member_replacements'])==3
    assert set(replacements)==set(BASE_REPLACEMENTS)
    def add(name,raw,record):
        key=safe_name(name);assert key not in folded
        folded.add(key);textcheck(raw);payload[name]=raw;provenance.append(record)
    def add_selected(m):
        assert m['group'] in GROUPS and m['source_cutoff']
        assert m['type']=='regular_utf8_text' and m['mode']=='0644'
        assert m['privacy_review']['preserves_failure_evidence'] is True
        assert m['privacy_review']['public_payload_has_private_raw'] is False
        refread(m['privacy_review']['receipt'])
        source=refread({'path':m['source_path'],'bytes':m['source_bytes'],'sha256':m['source_sha256']})
        raw=regular(m['prepared_path'])
        assert ident(raw)=={'bytes':m['bytes'],'sha256':m['sha256']}
        assert project(source,m)==raw
        add(m['archive_path'],raw,dict(m))
    for m in members:
        path=Path(m['prepared_path'])
        assert path==PLAN/'prepared-text'/m['archive_path']
        raw=regular(path)
        assert ident(raw)=={'bytes':m['bytes'],'sha256':m['sha256']}
        assert stat.S_IMODE(path.stat().st_mode)==0o644
        if m['archive_path'] in replacements:
            revised=replacements[m['archive_path']]
            assert m['sha256']==BASE_REPLACEMENTS[m['archive_path']]
            assert revised['supersedes_frozen_mapping']==m
            assert all(revised[k]==m[k] for k in ('source_path','source_bytes','source_sha256'))
            assert revised['treatment']=='projection'
            expected_algorithm=('BYTE_RANGE_REPLACE_V1' if m['treatment']=='original'
                                else 'C0_THEN_BYTE_RANGE_REPLACE_V1')
            assert revised['projection_fields_or_algorithm_if_any']['algorithm']==expected_algorithm
            add_selected(revised)
        else:
            add(m['archive_path'],raw,dict(m))  # Remaining304 exact frozen mappings.
    for m in selection['members']:
        add_selected(m)
    reserved=['_PACKAGE/README.md','_PACKAGE/PROJECTION-SPEC-V3.json','_PACKAGE/PROVENANCE.json','_PACKAGE/MEMBERS.json','SHA256SUMS']
    assert not {safe_name(n) for n in reserved}&folded
    payload[reserved[0]]=selection['readme_text'].encode('utf-8')
    payload[reserved[1]]=regular(PLAN/'projection-spec-v3.json')
    payload[reserved[2]]=encoded({'validated_code_commit':CODE,'frozen_plan03_pins':PINS,
        'selection_identity':ident(selection_raw),'driver_completion':selection['driver_completion'],
        'phases':selection['phases'],'members':provenance,
        'plan03_sources':307,'exact_plan03_members_reused':304,
        'explicit_frozen_member_replacements':selection['frozen_member_replacements'],
        'control_exclusions':'MEMBERS excludes itself and SHA256SUMS; SHA256SUMS excludes itself; ZIP identity and review receipt stay external.',
        'final_archive_review_complete':False,'publication_confirmed':False,'coordinator_acceptance':False})
    payload[reserved[3]]=encoded({'members':[{'archive_path':p,**ident(b)} for p,b in sorted(payload.items())],
        'excludes':[reserved[3],'SHA256SUMS'],'actual_payload_count':len(provenance),
        'member_counts_are_not_test_counts':True})
    payload['SHA256SUMS']=''.join(ident(b)['sha256']+'  '+n+'\n' for n,b in sorted(payload.items())).encode('utf-8')
    whitelist=selection.get('reviewed_scan_false_positives',[]);seen=[]
    for name,raw in payload.items():
        text=textcheck(raw)
        for rule,pattern in PATTERNS.items():
            for match in re.finditer(pattern,text):
                item={'archive_path':name,'rule':rule,'offset':match.start(),
                      'matched_text_sha256':hashlib.sha256(match.group().encode()).hexdigest(),
                      'member_sha256':ident(raw)['sha256']}
                allowed=[row for row in whitelist if all(row.get(k)==v for k,v in item.items()) and row.get('reason')]
                assert len(allowed)==1, 'Unreviewed scan candidate: '+json.dumps(item)
                seen.append(item)
    private_objects=[]
    for m in provenance:
        recipe=m.get('projection_fields_or_algorithm_if_any')
        if not isinstance(recipe,dict) or recipe.get('algorithm') not in {
                'BYTE_RANGE_REPLACE_V1','C0_THEN_BYTE_RANGE_REPLACE_V1'}:
            continue
        source=refread({'path':m['source_path'],'bytes':m['source_bytes'],'sha256':m['source_sha256']})
        if recipe['algorithm']=='C0_THEN_BYTE_RANGE_REPLACE_V1':
            source=project(source,dict(m,projection_fields_or_algorithm_if_any={'algorithm':'LOG_C0_ESCAPE_V1'}))
            assert ident(source)==recipe['intermediate_identity']
        private_objects.extend(source[r['byte_start']:r['byte_end']] for r in recipe['replacements'])
    structural_scan=scan_payload(payload,private_objects)
    assert structural_scan['blocking_count']==0, 'Structured private evidence remains: '+json.dumps(structural_scan)
    output.mkdir(mode=0o700)
    for name,raw in sorted(payload.items()):
        path=output/name;path.parent.mkdir(mode=0o755,parents=True,exist_ok=True)
        with path.open('xb') as f:f.write(raw)
        path.chmod(0o644)
        assert path.read_bytes()==raw
    # No source discovery here: write only the exact already validated mapping.
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,raw in sorted(payload.items()):
            info=zipfile.ZipInfo(name,(2026,11,1,0,0,0));info.create_system=3
            info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,raw)
    zip_path.chmod(0o644)
    with zipfile.ZipFile(zip_path,'r') as archive:
        assert archive.namelist()==sorted(payload) and archive.testzip() is None
        for info in archive.infolist():
            assert info.flag_bits&1==0 and stat.S_IFMT(info.external_attr>>16)==stat.S_IFREG
            assert stat.S_IMODE(info.external_attr>>16)==0o644
            assert archive.read(info)==payload[info.filename]
    receipt={'zip_path':str(zip_path),**ident(zip_path.read_bytes()),'members':len(payload),
        'plan03_source_mappings':307,'reused_plan03_members':304,'replaced_plan03_members':3,
        'terminal_additions':len(selection['members']),
        'all_crc_hash_bytes_modes_paths_checked':True,'reviewed_scan_candidates':seen,
        'structural_privacy_guard':structural_scan,
        'final_archive_review_complete':False,'publication_confirmed':False,'coordinator_acceptance':False}
    with receipt_path.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
    receipt_path.chmod(0o600)
    print(json.dumps(receipt))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--check-preparation',action='store_true')
    parser.add_argument('--assemble',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--zip',type=Path)
    args=parser.parse_args()
    if args.check_preparation:
        assert args.assemble is None and args.output is None and args.zip is None
        members=controls()
        print(json.dumps({'frozen_mapping_members':len(members),'pending_sources_opened':0,
            'prepared_payload_files_opened':0,'final_directory_created':False,'final_zip_created':False}))
    else:
        assert args.assemble and args.output and args.zip
        assemble(args.assemble,args.output,args.zip)

if __name__=='__main__':main()
