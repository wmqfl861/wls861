"""Bounded cross-member structural privacy guard. Never prints matched values."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import re
import zipfile


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def scan_payload(payload, known_private_objects=()):
    needles = {identity(raw)['sha256']: raw for raw in known_private_objects if len(raw) >= 512}
    findings = []
    for name, raw in payload.items():
        for digest, needle in needles.items():
            start = 0
            while True:
                offset = raw.find(needle, start)
                if offset < 0:
                    break
                findings.append({'member': name, 'kind': 'EXACT_REMOVED_PRIVATE_OBJECT_REMAINS',
                                 'byte_start': offset, 'byte_end': offset + len(needle),
                                 'matched_identity': identity(needle), 'known_private_sha256': digest})
                start = offset + len(needle)
            # A truncated or JSON-string-escaped prefix is still private evidence.
            prefix = needle[:128]
            for label, probe in [('RAW_PREFIX', prefix),
                                 ('JSON_STRING_ESCAPED_PREFIX', json.dumps(prefix.decode('utf-8'), ensure_ascii=False)[1:-1].encode())]:
                offset = raw.find(probe)
                if offset >= 0:
                    findings.append({'member': name, 'kind': 'REMOVED_PRIVATE_' + label,
                                     'byte_start': offset, 'byte_end': offset + len(probe),
                                     'matched_identity': identity(probe), 'known_private_sha256': digest})
        position = 0
        for line in raw.splitlines(keepends=True):
            # Fragmented construction avoids matching this guard's own source text.
            patterns = [('HOST_DOCTOR_STRUCTURED_OBJECT', rb'\[' + b'OBSERVED' + rb'\]\s*(\{)'),
                        ('ASSERTION_STRUCTURED_RESULT', b'Assertion' + rb'Error:[^\r\n]*?(\{)')]
            for kind, pattern in patterns:
                match = re.search(pattern, line)
                if not match:
                    continue
                begin = match.start(1)
                tail = line[begin:].rstrip(b'\r\n')
                complete = False
                body = tail
                syntax = 'UNPARSED_OR_TRUNCATED_PREFIX'
                try:
                    text = tail.decode('utf-8')
                    _, end = json.JSONDecoder().raw_decode(text)
                    body = text[:end].encode('utf-8')
                    complete = True
                    syntax = 'COMPLETE_JSON'
                except (UnicodeDecodeError, json.JSONDecodeError):
                    try:
                        parsed = ast.literal_eval(tail.decode('utf-8'))
                        complete = isinstance(parsed, (dict, list))
                        if complete:
                            syntax = 'COMPLETE_PYTHON_LITERAL'
                    except (UnicodeDecodeError, SyntaxError, ValueError):
                        pass
                findings.append({'member': name, 'kind': kind, 'byte_start': position + begin,
                                 'byte_end': position + begin + len(body), 'matched_identity': identity(body),
                                 'syntax': syntax, 'complete_structure': complete,
                                 'truncated_prefix_is_not_accepted_as_safe': True})
            position += len(line)
    return {'members_scanned': len(payload), 'known_private_objects': len(needles),
            'findings': findings, 'blocking_count': len(findings),
            'matched_values_emitted': False,
            'scope': 'All payload and control members; exact removed objects, raw/escaped prefixes, host-observation and assertion structure starts. Finite guard, not absolute privacy proof.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--zip', type=Path, required=True)
    parser.add_argument('--private-ranges', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    needles = []
    for ref in json.loads(args.private_ranges.read_bytes())['ranges']:
        raw = Path(ref['source_path']).read_bytes()
        assert identity(raw) == ref['source_identity']
        body = raw[ref['byte_start']:ref['byte_end']]
        assert identity(body) == ref['range_identity']
        needles.append(body)
    original = args.zip.read_bytes()
    with zipfile.ZipFile(args.zip) as archive:
        payload = {item.filename: archive.read(item) for item in archive.infolist() if not item.is_dir()}
    result = {'archive': {'path': str(args.zip), **identity(original)},
              'guard': scan_payload(payload, needles), 'archived_code_executed': False}
    assert args.zip.read_bytes() == original
    with args.output.open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    args.output.chmod(0o600)
    print(json.dumps({'archive_identity': identity(original),
                      'members_scanned': len(payload), 'blocking_count': result['guard']['blocking_count'],
                      'matched_values_emitted': False}))
    raise SystemExit(1 if result['guard']['blocking_count'] else 0)


if __name__ == '__main__':
    main()
