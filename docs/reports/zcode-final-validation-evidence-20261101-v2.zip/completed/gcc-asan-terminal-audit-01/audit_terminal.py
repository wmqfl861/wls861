"""Read-only audit of the completed GCC ASan phase; never runs project code."""
from pathlib import Path
import collections
import datetime
import hashlib
import json
import os
import re
import shlex
import stat
import subprocess
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
TASK = OUT.parent.parent
SOURCE = TASK / 'zcode'
BUILD = SOURCE / 'build-gcc-asan-20261101T042059Z-b7698edb'
EV = BUILD / 'evidence'
OUTER = TASK / 'evidence/event-shared-gcc-asan-gate-01'
HEAD = '08dad7e815b9c3c84d3bd2393818b2030a6e0cde'
inputs = {}

def identity(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def read(path):
    st=path.lstat()
    assert stat.S_ISREG(st.st_mode) and not path.is_symlink(), str(path)
    raw=path.read_bytes()
    inputs[str(path.relative_to(TASK))]=identity(raw)
    return raw

def obj(path):
    return json.loads(read(path))

def save(name, value):
    path=OUT/name
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    with path.open('x',encoding='utf-8') as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    path.chmod(0o600)

def rawsave(name, raw):
    path=OUT/name
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    with path.open('xb') as f:f.write(raw)
    path.chmod(0o600)

started=datetime.datetime.now(datetime.timezone.utc).isoformat()
outer=obj(OUTER/'completion.json')
summary=obj(EV/'summary.json')
step=obj(EV/'ctest.step.json')
assert outer['head']==summary['head']==HEAD
assert outer['exit_code']==1 and outer['outer_timeout'] is False
assert summary['status']=='NOT_COMPLETE' and summary['identities_unchanged']
assert summary['uid']==summary['gid']==1000
assert summary['ended_at'] < outer['finished_at_utc']
assert step['exit_code']==8 and step['ended_at'] < summary['ended_at']
assert len(summary['steps'])==9 and summary['steps'][-1]==step
assert all(s['exit_code']==0 for s in summary['steps'][:-1])
assert step['argv'][step['argv'].index('--parallel')+1]=='1' and '-R' not in step['argv']
for s in summary['steps']:
    assert obj(EV/(s['name']+'.step.json'))==s
    for name,sha in s['logs'].items():
        assert identity(read(EV/name))['sha256']==sha
save('terminal-receipts.json',{'outer_completion_original':outer,'runner_status_original':summary['status'],
    'runner_ended_at_original':summary['ended_at'],'runner_error_original':summary['error'],
    'runner_identities_unchanged_original':summary['identities_unchanged'],
    'steps_count':9,'step_results':[{'name':s['name'],'exit_code':s['exit_code'],
        'started_at':s['started_at'],'ended_at':s['ended_at'],'seconds':s['seconds']} for s in summary['steps']],
    'interpretation':'GCC phase terminal with failing CTest; original NOT_COMPLETE status preserved. Whole matrix still active, outside this audit.',
    'no_synthesized_runner_FAILED_or_PASSED_status':True})

before=obj(EV/'source-before.json');after=obj(EV/'source-after.json')
assert before==after and len(before)==794
assert outer['source_unchanged'] and outer['source_count']==794
prior=obj(TASK/'evidence/final-matrix-handoff-audit-01/git08-source-crosscheck.json')
assert prior['head']==HEAD and set(before)==set(prior['entries'])
sources={}
for rel,recorded in before.items():
    current=read(SOURCE/rel)
    assert identity(current)['sha256']==recorded['sha256']==prior['entries'][rel]['sha256']
    assert len(current)==prior['entries'][rel]['bytes']
    mode=stat.S_IMODE((SOURCE/rel).stat().st_mode)
    assert mode==recorded['mode']==prior['entries'][rel]['recorded_and_current_filesystem_mode']
    sources[rel]={**identity(current),'mode':mode,'matches_before_after_and_prior_Git08_blob_audit':True}
save('source-crosscheck.json',{'paths':794,'current_files_rehashed':True,
    'source_before_equals_after':True,'reuse':'Prior frozen Git08 blob audit supplies blob/hash correspondence; source bytes rehashed now, no repeated semantic audit.',
    'entries':sources})
binary_before=obj(EV/'binaries-before.json');binary_after=obj(EV/'binaries-after.json')
assert binary_before==binary_after and len(binary_before)==61
binaries={}
for rel,sha in binary_before.items():
    path=BUILD/rel
    st=path.lstat();assert stat.S_ISREG(st.st_mode) and not path.is_symlink()
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    assert h.hexdigest()==sha
    binaries[rel]={'bytes':st.st_size,'sha256':sha,'matches_before_and_after':True}
cache=read(EV/'CMakeCache.txt').decode('utf-8')
cache_fields={}
for key in ['CMAKE_BUILD_TYPE','CMAKE_CXX_COMPILER','WLS_ENABLE_ASAN','WLS_ENABLE_UBSAN','Python3_EXECUTABLE']:
    cache_fields[key]=re.search('^'+key+r':[^=]+=(.*)$',cache,re.M).group(1)
assert cache_fields['CMAKE_BUILD_TYPE']=='Debug' and cache_fields['WLS_ENABLE_ASAN']=='ON'
assert cache_fields['WLS_ENABLE_UBSAN']=='OFF' and cache_fields['CMAKE_CXX_COMPILER']=='/usr/bin/g++-13'
commands=obj(EV/'compile_commands.json')
assert len(commands)==92
for c in commands:
    tokens=shlex.split(c['command'])
    assert '-fsanitize=address' in tokens and '-Werror' in tokens and '-g' in tokens
save('binary-control-crosscheck.json',{'entries':binaries,'count':61,'current_actual_files_rehashed':True,
    'before_equals_after':True,'cache_fields':cache_fields,'compile_command_count':92,
    'all_commands_address_sanitizer_g_Werror':True,'sanitizer_environment_original':summary['sanitizer_environment'],
    'build_umask_original':summary['build_umask'],'test_umask_original':summary['test_umask']})

catalog_raw=read(SOURCE/'tests/gcc_asan_expected_tests.json')
catalog=obj(EV/'expected-tests.json')
assert json.loads(catalog_raw)==catalog
assert identity(catalog_raw)['sha256']==summary['expected_tests_sha256']
expected={t['name']:t['timeout'] for t in catalog['tests']}
plan=obj(EV/'test-plan.json');names=[t['name'] for t in plan['tests']]
actual={t['name']:next(p['value'] for p in t['properties'] if p['name']=='TIMEOUT') for t in plan['tests']}
assert len(names)==len(set(names))==92 and actual==expected
raws={
 'ctest.log':read(EV/'ctest.log'),
 'ctest.xml':read(EV/'ctest.xml'),
 'LastTest.log':read(BUILD/'Testing/Temporary/LastTest.log'),
 'LastTestsFailed.log':read(BUILD/'Testing/Temporary/LastTestsFailed.log')}
for name,raw in raws.items():rawsave('private-originals/'+name,raw)
root=ET.fromstring(raws['ctest.xml']);cases=root.findall('testcase')
assert [c.get('name') for c in cases]==names and root.get('tests')=='92'
assert root.get('failures')=='44' and root.get('skipped')==root.get('disabled')=='0'
last=raws['LastTest.log'].decode('utf-8');ctest=raws['ctest.log'].decode('utf-8')
blocks=re.split(r'(?m)^(\d+)/92 Testing: (.+)\n',last)
assert len(blocks)==1+92*3
console=re.findall(r'^\s*(\d+)/92 Test\s+#(\d+): (\S+)\s+\.*\s*(Passed|\*\*\*Timeout|\*\*\*Failed)\s+([0-9.]+) sec$',ctest,re.M)
assert len(console)==92
outcomes=[]
for i,(test,case,line) in enumerate(zip(plan['tests'],cases,console),1):
    idx,name,block=blocks[1+(i-1)*3:1+i*3]
    assert int(idx)==i and name==test['name']==line[2]
    command=shlex.split(re.search(r'^Command: (.*)$',block,re.M).group(1))
    directory=re.search(r'^Directory: (.*)$',block,re.M).group(1)
    assert command==test['command']
    assert directory==next(p['value'] for p in test['properties'] if p['name']=='WORKING_DIRECTORY')
    assert len(re.findall(r'^"'+re.escape(name)+r'" end time:',block,re.M))==1
    message='Passed' if case.find('failure') is None else case.find('failure').get('message')
    assert message in ['Passed','Timeout','Failed']
    assert line[3].replace('***','')==message
    assert ('Test Passed.' in block)==(message=='Passed')
    assert ('Test Failed.' in block)==(message!='Passed')
    assert case.get('status')==('run' if message=='Passed' else 'fail')
    output=case.findtext('system-out') or ''
    methods=[]
    if name in ['https_transport','live_model_store_tls','live_workflow','billing_baseline_e2e']:
        methods=re.findall(r'^((?:test_[A-Za-z0-9_]+|FAIL: test_[A-Za-z0-9_]+|ERROR: test_[A-Za-z0-9_]+))',output,re.M)
    outcomes.append({'ordinal':i,'name':name,'outcome':message,'junit_status':case.get('status'),
        'seconds':float(case.get('time')),'original_deadline_seconds':expected[name],
        'LastTest_command_and_cwd_match_plan':True,'LastTest_own_end_marker':True,
        'printed_method_markers_selected_suites_only':methods,
        'printed_unittest_summaries':re.findall(r'^Ran \d+ tests? in [0-9.]+s$',output,re.M),
        'printed_unittest_result_lines':re.findall(r'^(?:FAILED \([^\n]+\)|OK(?: \([^\n]+\))?)$',output,re.M)})
assert len(re.findall(r'^End testing:',last,re.M))==1
counts=dict(collections.Counter(r['outcome'] for r in outcomes))
assert counts=={'Passed':48,'Timeout':42,'Failed':2}
fail_lines=raws['LastTestsFailed.log'].decode().splitlines()
assert fail_lines==[str(r['ordinal'])+':'+r['name'] for r in outcomes if r['outcome']!='Passed']
save('test-results.json',{'registered':92,'selected':92,'completed_CTest_outcomes':92,'counts':counts,
    'skipped':0,'not_run':0,'missing_outcomes':0,'ctest_exit':8,'runner_outer_exit':1,
    'ctest_seconds':step['seconds'],'original_runner_status':'NOT_COMPLETE',
    'same_original_names_and_deadlines':True,'all_LastTest_commands_cwds_end_markers_verified':True,
    'JUnit_LastTest_console_LastTestsFailed_agree':True,'tests':outcomes})

# Preserve every original byte except the already diagnosed raw dictionary line.
# This line occurs identically in console, own LastTest and JUnit system-out.
old_trace=read(TASK/'evidence/live-workflow-diagnosis-08-01/safe-trace-projection.txt')
sentinels=[line for line in old_trace.splitlines(keepends=True) if b'FULL_RESULT_OMITTED' in line]
assert len(sentinels)==1
replacement=sentinels[0]
original_line_sha='f2dd1c2ed75c4e84e36d9575c957ee1507679cd5309fd1d3e4737081d5bee9ac'
projections=[]
for name in ['ctest.log','LastTest.log','ctest.xml']:
    raw=raws[name];position=0;matches=[]
    for line in raw.splitlines(keepends=True):
        if identity(line)['sha256']==original_line_sha:matches.append((position,position+len(line)))
        position+=len(line)
    assert len(matches)==1
    begin,end=matches[0]
    assert end-begin==7424
    projected=raw[:begin]+replacement+raw[end:]
    assert projected[:begin]==raw[:begin] and projected[begin+len(replacement):]==raw[end:]
    projected.decode('utf-8',errors='strict');assert b'\x00' not in projected
    if name=='ctest.xml':
        safe_root=ET.fromstring(projected)
        assert safe_root.attrib==root.attrib
        assert [(x.attrib,[(f.tag,f.attrib,f.text) for f in x if f.tag in ['failure','error','skipped']]) for x in safe_root.findall('testcase')]==[(x.attrib,[(f.tag,f.attrib,f.text) for f in x if f.tag in ['failure','error','skipped']]) for x in cases]
    target='safe-projections/'+name+'.projection.txt'
    rawsave(target,projected)
    projections.append({'source_path':str((EV/name) if name!='LastTest.log' else (BUILD/'Testing/Temporary/LastTest.log')),
        'source_identity':identity(raw),'private_snapshot':'private-originals/'+name,
        'prepared_path':str(OUT/target),'projection_identity':identity(projected),
        'algorithm':'BYTE_RANGE_REPLACE_V1; all original bytes outside the single listed range retained',
        'replacements':[{'byte_start':begin,'byte_end':end,'original_range_sha256':original_line_sha,
            'replacement_utf8':replacement.decode(),'replacement_identity':identity(replacement)}],
        'first_failure_safe_fields_reference':'evidence/live-workflow-diagnosis-08-01/first-failure-safe-projection-v2.json',
        'trace_failure_timeout_and_all_other_lines_preserved':True,'original_publication_approved':False,
        'projection_still_requires_final_explicit_member_and_archive_review':True})
save('terminal-log-projection-recipes.json',{'projections':projections,'no_directory_copy_authorized':True})
patterns={'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    'github_token':r'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b',
    'aws_key':r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b','bearer_material':r'(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{12,}'}
scan=[]
for row in projections:
    text=Path(row['prepared_path']).read_text()
    for key,pattern in patterns.items():
        for m in re.finditer(pattern,text):scan.append({'file':row['prepared_path'],'rule':key,'character_offset':m.start()})
save('bounded-projection-scan.json',{'scope':'Three exact terminal projections only; not a proof of all possible private data absence.',
    'patterns':patterns,'candidate_locations_without_values':scan,'candidate_count':len(scan),
    'raw_dictionary_line_not_published':True,'all_other_bytes_retained':True})
save('input-identities.json',inputs)
save('completion-receipt.json',{'reviewer':'/root/delivery_report','started_at':started,
    'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uid':os.getuid(),'gid':os.getgid(),
    'GCC_PHASE_TERMINAL_AUDIT_COMPLETE':True,'GCC_ASAN_TESTS_PASS':False,
    'LOCAL_VALIDATION_COMPLETE':False,'FULL_MATRIX_TERMINAL':False,
    'product_executions_or_builds':0,'source_changes':0,'active_UBSan_Clang_logs_read':0,
    'private_CLI99_logs_read':0,'source_paths_verified':794,'binary_control_files_verified':61,
    'registered_and_classified_CTest':92,'counts':counts,
    'original_runner_status':'NOT_COMPLETE','root_cause':'OPEN',
    'final_zip_created':False,'projection_scan_candidate_count':len(scan)})
print(json.dumps({'audit_complete':True,'counts':counts,'source_paths':794,'binary_controls':61,
    'scan_candidate_count':len(scan),'whole_matrix_terminal':False,'product_runs':0}))
