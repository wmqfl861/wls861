The completed local GCC ASan phase has **48 Passed, 42 Timeout and 2 Failed**
out of the original 92 CTest registrations. The two Failed outcomes are
`https_transport` and `live_model_store_tls`; timeout outcomes remain separately
classified in test-results.json. All 92 names and original deadlines match the
frozen code08 catalog, with zero skipped, not-run or missing CTest outcomes.
This is a terminal evidence audit, not a passing sanitizer result or closure of
the underlying failures.

The outer phase receipt records exit 1, outer_timeout=false, from
04:20:59.760968 to 06:57:25.231283 UTC on 2026-11-01, taking
9385.47000153712 seconds. Its CTest step records exit 8 from 04:39:17.463919
to 06:56:53.463162, taking 8255.999285957078 seconds. The runner summary
retains its actual **status NOT_COMPLETE**, error “ctest failed with exit 8”,
ended_at 06:57:23.431379 and identities_unchanged=true. This reviewer did not
replace that original status with PASSED or synthesize a FAILED runner record.
All nine recorded steps have genuine end timestamps; the first eight exit 0.
Each individual step receipt and its referenced stdout/stderr hashes matches
the summary. Completion of this GCC phase does not imply the entire sequential
driver is complete: UBSan and Clang remain outside this audit.

JUnit contains 92 cases in the plan's order: 48 status=run and 44 status=fail,
with the original failure messages distinguishing 42 Timeout and 2 Failed.
Its tests/failures/skipped/disabled counters agree with all 92 terminal console
result lines. This build's own LastTest has 92 Testing blocks, 48 Test Passed,
44 Test Failed, 92 named end markers and a final End testing marker. Every
actual LastTest command and working directory matches that test's plan.
LastTestsFailed lists exactly those 44 failing registrations. These are CTest
outcomes; a timeout does not establish completion of every internal unittest
method, and the separately printed method markers are not new CTest suites.

All **794 source paths** have equal before/after manifests and were rehashed
against current code08 source. Their SHA, bytes and filesystem modes match the
previous frozen Git08 blob audit. That prior audit supplies the blob-to-hash
correspondence; this audit does not claim a new semantic reading of all 794
implementations. All **61 actual binary/control files** were independently
rehashed and match both before/after maps. CMake reports Debug, g++-13,
ASan=ON and UBSan=OFF; all 92 compile entries contain -g, -Werror and
-fsanitize=address. The original sanitizer environment is
ASAN_OPTIONS=halt_on_error=1:detect_leaks=1 and
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1, with LSAN_OPTIONS null.
The runner used UID/GID 1000, build umask 0022, test umask 0002 and CTest
parallel 1. UBSAN_OPTIONS does not turn this into an independently instrumented
UBSan run.

The three raw terminal outputs are retained privately with these identities:

| Original | Bytes | SHA-256 |
| --- | ---: | --- |
| ctest.log | 67311 | 4b3402799b8445d05197d578f0f2e69e54e80079f76095d8d3827a264e42a630 |
| own LastTest.log | 213533 | 07db752638c7a9e329bd9c9138f78f67799e19f44b7658482461e9b463ba01e9 |
| ctest.xml | 112929 | f7467e993fff97318751020741f56bb03c0b0a14d4c68f1bb53474d8870c3f88 |

Each includes the same 7424-byte full result-dictionary line previously frozen
in the T4 diagnosis, SHA
`f2dd1c2ed75c4e84e36d9575c957ee1507679cd5309fd1d3e4737081d5bee9ac`.
Explicit public-candidate projections replace only that exact line with the
existing FULL_RESULT_OMITTED sentinel and its safe-field reference. The byte
ranges are [44518,51942) in ctest.log, [151632,159056) in LastTest.log, and
[80212,87636) in JUnit. Every byte outside that range remains unchanged.
The projected JUnit parses and retains the exact original suite/case attributes
and failure/error/skipped elements. Tracebacks, assertion classification,
timeouts, all other errors and result lines remain present. The raw originals
are not approved public members. The exact recipes, source/projection SHA,
replacement text and source ranges are in terminal-log-projection-recipes.json.
Final selection must also explicitly include the referenced T4 safe fields.

The bounded pattern scan of these three projections found zero candidates for
the recorded private-key, GitHub token, AWS key and Bearer patterns. It is not a
proof against every possible kind of private data. All private snapshots and
new audit files use 0600 under this 0700 directory; final public members require
explicit selection and independent review of the exact final archive.

The metadata-only command audit_terminal.py ran as UID/GID 1000, exited **0**
with empty stderr, and took 35.10849760216661 seconds from 07:06:15.748622 to
07:06:50.856882 UTC. No product test, compiler, diagnostic execution, network
call, source edit or process intervention was performed. No private 99 CLI raw
logs, temporary runtime databases/configuration or active UBSan/Clang logs were
read. Root-cause work remains OPEN. GCC_PHASE_TERMINAL_AUDIT_COMPLETE=true;
GCC_ASAN_TESTS_PASS=false; LOCAL_VALIDATION_COMPLETE=false;
FULL_MATRIX_TERMINAL=false; no final ZIP exists.
