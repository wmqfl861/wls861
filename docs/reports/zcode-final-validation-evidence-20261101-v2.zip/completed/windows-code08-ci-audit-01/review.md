提交 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde` 的两次 Windows 原生 foundation CI 内容审核已完成：两次均有 **4/4 CTest、27/27 原始方法成功结束**的完整证据。结论限定为 **Windows Server 2022、elevated、NTFS 上的 native build/format slice**。精确 runner image 身份为 **UNRESOLVED**；**Windows 11 普通用户验收保持 NOT_RUN**。

这是新增的内容审核 `windows-code08-ci-audit-01`。它补充 `ci-08dad7e-audit-04` 对 Windows 元数据的核验，不把两者混称为一次审核，不重新裁定 Linux CI 或整体 REMOTE_CI_COMPLETE。Linux code08 的结论仍由独立 audit04 自身证据确定。

| Run | 实际执行的 job | API 状态 | artifact |
| --- | --- | --- | --- |
| [PR 41271462756](https://github.com/wmqfl861/wls861/actions/runs/41271462756) | [124744917981](https://github.com/wmqfl861/wls861/actions/runs/41271462756/job/124744917981) | attempt 1，completed / success；全部 step success | 13069323249，105399 字节 |
| [Push 41271460257](https://github.com/wmqfl861/wls861/actions/runs/41271460257) | [124744910374](https://github.com/wmqfl861/wls861/actions/runs/41271460257/job/124744910374) | attempt 1，completed / success；全部 step success | 13068994449，105384 字节 |

原始 run/jobs/artifacts API JSON、每次命令的开始/结束时间、退出码、原始 job 日志、ZIP 和下载哈希均在本目录保留。API 请求全为 GET，没有触发 workflow、重新运行 CI、发布或执行归档内的代码/EXE。审核器只使用标准库解析文本、AST、XML 和 Git 只读身份。

两份 ZIP 先全部检查成员路径、大小、压缩边界、类型、加密标志和名称碰撞，再读取文本；没有盲目 `extractall`。两份各有 44 个成员，全部为文本，无可执行载荷。读取时重新验证每份文本的 CRC、大小和 SHA-256；成员和原 ZIP 身份见 `archive-index.json`。

| ZIP | 原始 ZIP SHA-256；与 API digest 相同 |
| --- | --- |
| PR `artifact-13069323249.zip` | `34d4cfdccd249a26a764f90c4dcc56b5dffedefa2d601b6b4e7862fe3d6e7670` |
| Push `artifact-13068994449.zip` | `eb7e8d3ea86a8ebf4a3a66c8229f24b35a617a781f40d7da7cfcb66e13d104a9` |

checkout 身份通过三类原始记录交叉核实：job 原日志中的 checkout、artifact 的 `git-head.stdout`/`environment.github_sha`，以及本轮 Git API 读取结果。PR 实际执行合并验证提交 `47534906df0402b20651b1971ac642c98aa1af9a`；Push 实际执行分支提交 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`。本轮 Git API 对这两个 commit 返回相同 tree：`149bca333bce2460ba940ace3c76cc1111dfdd83`。合并提交的 parents 中含精确 08。

上述 Git API 身份结论绑定本轮查询时间，不表示未来的 branch/ref 状态：head 查询为 **2026-11-01 05:22:00.030121–05:22:01.588030 UTC**，merge 查询为 **05:22:00.033578–05:22:01.593261 UTC**；身份查询截点为 **05:22:01.593261 UTC**。原 API 响应和 request receipt 分别保存；对应响应 SHA-256 为 `f331e84d6cd24c965ae337b6b4998a5de5505d84537c1c27197ae2f264acf38e` 与 `42ed4705bddf9453eb347db399e7efc1512beea3cc4d62ea468ec718d6d7c7ed`。

两次 Windows 各记录 794 份源码输入，before/after 完全一致，两次 run 的映射也逐项一致，路径集合匹配精确 08 的 tracked 文件集合。本轮另外对 28 份与 native 构建、方法、证据收集和资源清单有关的输入直接核对 Git08 blob 及 SHA-256，并保存精确源码快照。范围包括 native-foundation 整个子树、Windows workflow、原 config/scheduler 源码与头、资源 manifest/catalog。本轮没有重新读取全部 794 份实现或重新执行全部 Git blob 校验；也没有读取或重新哈希 `src/runtime_types.cpp`。不要把 28 份直接核验扩大成全树重新核验。

本次是外部 CI 证据审核，无结构图检索需要。方法名与收集语义对照直接读取上述精确源文件；root 已说明现有旧图不能覆盖新 native scope。本轮没有重建索引，也没有用旧图证明当前源码身份。

审核没有把 artifact 自报 `PASSED` 当成最终依据。自编的 `verify_windows_evidence.py` 从精确源码 AST/原 C++ 注册表取预期名称，并独立检查原 `LastTest.log` 每个块的序号、方法成功行、数量、原生 RESULT 或 unittest Ran/OK、`Test Passed.`、suite end 和总 `End testing`；没有执行或导入归档内的 `ctest_evidence.py` 或测试代码，也没有从源码补造缺失输出。

| 原始 CTest suite | 每次 run 的实际方法数 | 原始结束证据 |
| --- | ---: | --- |
| native_modules | 3 | 3 条 PASS，RESULT 3 passed / 0 failed，Test Passed/end |
| native_platform | 4 | 4 条 PASS，RESULT 4 passed / 0 failed，Test Passed/end |
| native_cli | 14 | 14 条原始 `... ok`，Ran 14 tests，OK，Test Passed/end |
| native_bundle_capture | 6 | 6 条原始 `... ok`，Ran 6 tests，OK，Test Passed/end |
| 合计 | 27 | 四个 suite 块齐全，无重复、未知、失败、跳过或未结束的方法 |

这是相同四个 suite、相同 27 个方法的两次独立 CI 执行；不是 54 个不同方法，也不是 27 个独立套件。job 内另有证据收集 helper 的 6 个合成自检，原 job 日志均有 Ran 6 tests / OK；它们单独登记，未混入 native 的四个 CTest 或 27 个方法。

每份完整 LastTest 都为 6323 字节。PR SHA-256 为 `583f25b575380676857fa165fca24a9a6edd7b42f515db95be30a0d3fc20ccbe`；Push 为 `96e80a7f3137a3cc61ff4499c023cebc14064dd3477216af9c9199f0ddaea1c6`。两者都与其 `ctest-log-files.json`、`ctest-methods.json` 的原哈希相符，存在完整 LastTest，不是 `.tmp`。JUnit 恰好四个 testcase，全部 status run，无 failure/error/skipped；`ctest.stdout` 和原 job 日志另有 100% / 0 failed out of 4，命令 exit 0。ctest 命令记录耗时 PR 为 1.3135957718 秒，Push 为 1.4077744484 秒。

JUnit 的成功输出会截断：两份 JUnit 的 native_cli 均只保留 7 条完整方法成功行，不足以证明全部 14 项。本轮 14/14 的依据是完整原 LastTest，未用源码或另一轮测试补齐。本包保留两种原始输出，详见 `verification.json` 的逐 suite 结果。

两次 runner 各有十份命令结束收据：vswhere、git-head、git-status、cmake-version、configure、build、ctest、install、host-capabilities、detached，均 exit 0，并有开始/结束时间。构建为 Release、原生 MSVC x64。工具链原始记录互相吻合：

- Visual Studio generator：Visual Studio 17 2022；vswhere installationVersion `17.14.37824.6`。
- 请求 toolset：`v143,host=x64,version=14.44.35207`；实际 compiler 路径位于 `VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/cl.exe`。
- `native-toolchain.txt` 与 `CMakeCXXCompiler.cmake` 实际 compiler version：`19.44.35229.0`，architecture x64，pointer bytes 8。
- Windows SDK `10.0.26100.0`；CMake `3.31.6`；Python `3.12.10`，64 bit AMD64。两次 pinned compiler/Windows.h 的原始哈希记录相同。本轮没有重取微软安装文件或验证供应商签名。

系统和权限事实应保持分开。job 开头 Operating System 为 Microsoft Windows Server 2022 / 10.0.20348；artifact 的 Python platform 为 `Windows-2022Server-10.0.20348-SP0`、windows_version 为 `[10,0,20348,2,""]`。实际迁移后的原生 executable capabilities 和 detached 输出都记录 token `elevated`、其所在卷 `NTFS`。这不能用来证明 Windows 11、普通用户 ACL、Workspace 权限或 sandbox 安全。

精确 runner image 身份有未解决差异，两次 run 均如此：

| 原字段来源 | 原值 |
| --- | --- |
| 原始 job 日志 `##[group]Runner Image` 下的 Image | windows-2022 |
| 同一 Runner Image group 的 Version | `20261025.346.1` |
| artifact `environment.json` 的 image_os | win22 |
| artifact `environment.json` 的 image_version，来自环境变量 ImageVersion | `20261026.347.1` |

这两个版本值没有被合并或改写，原因没有证据，**exact_runner_image_identity=UNRESOLVED**。它阻止本轮宣称确认了精确镜像 release；不消除另有原始记录支撑的 Server2022/build20348、elevated/NTFS 与逐方法结束事实。本轮不为消除差异新跑 CI，也不归因于 GitHub、脚本、环境或 artifact 篡改。

artifact 中 `result.json` 继续明确 `windows_11_machine_acceptance=NOT_RUN`、`ordinary_user_security_acceptance=NOT_RUN`、`full_native_runtime=NOT_IMPLEMENTED`。capabilities 中 Store、Workspace、process、sandbox、cleanup 均 unsupported，model_calls denied，ordinary_user_security/network_isolation not_checked。本次通过的 public resource/format/module slice 不能关闭 W-FS/W-PROC/W-SBX/W-CLEAN，也不能替代 Linux 完整运行时或 R2.4 的恢复安全验证。

detached 收据和输出证明本次既定流程完成安装、迁移到含中文/emoji 的路径、原 source 路径不存在时读取 35 份 / 160549 字节公共资源、运行原 config 模块并拒绝业务执行。它是该离线 slice 的记录，不是生产 Store/Workspace 权限。两份 artifact 各有三项 EXE SHA-256 清单，但没有 PE 本体；因此不能在本包中独立重新哈希 PE、核验其签名或证明可重复构建。ELF 也不在本次 Windows 审核范围内。

下载过程的异常如实保留：`gh 2.101.0` 初次获取两个 job 日志时拒绝输出终端控制序列，各 exit 1，输出为空，stderr/request receipt 原样保存。随后仅对原字节下载加入 `--allow-escape-sequences` 并直接保存到私有文件，成功 exit 0；没有把原控制序列渲染到终端。`.sanitized.txt` 是去 ANSI 后的派生文本，审核器重新验证了它与原日志的转换关系。一次只读查看命令误将 commit request receipt 匹配为 commit JSON，产生 KeyError，已用两个精确 commit 文件读取修正；这不是 CI/test 失败，原证据没有改写。

本轮 API JSON/ZIP/log 的最终有效下载均有 exit 0 收据，ZIP SHA 与 API digest、job 上传摘要相同。独立审核器在 **2026-11-01 05:29:43.043172 UTC** 完成，实际命令 `python3 .../windows-code08-ci-audit-01/verify_windows_evidence.py` exit 0，stderr 为空。源码前后仍为精确 08、工作树干净。审核执行 UID/GID 1000，只在本新目录写证据，没有运行产品、构建、测试、付费模型、生产服务或归档程序；没有新触发 workflow、提交或推送。

本轮交付状态为 **WINDOWS_SERVER_NATIVE_SLICE_EVIDENCE_VERIFIED_EXACT_IMAGE_UNRESOLVED**。后续协调事项是精确 image 差异如何解释，以及独立安排 Windows 11 普通用户验收；两者均未由本轮关闭。整体本地矩阵和 Linux CI 状态由各自负责人及独立证据判断。
