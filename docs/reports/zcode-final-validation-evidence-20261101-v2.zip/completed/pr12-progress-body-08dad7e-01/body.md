本 PR 保留 native C++ 测试失败的即时诊断，并让 Store event 只完整编码同一 command 一次。原本套件被中止时缺少方法位置；现在 START/PASS/FAIL/RESULT 及时 flush，原五秒 until 失败打印调用位置。Store 原先为 SHA 和 payload 分别 canonical 同一 command，现复用原 `json_text(command,payload_limit)` 返回的完整校验字节。

依赖：本 Draft 的 base 是 PR #11 `fix/async-review-99c9063-20261031@7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a`，再依赖 PR #10 的原审核对象。未 retarget 或合并原 PR，不写 main。当前代码提交 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`；原工具提交 `579e3c7675bc2abb336dde6a95bfddf2139f47cd`。

实际作者为本机 ZCode（既有 Coding Plan、GLM-5.3），Codex/root 与非作者 Agent 审阅差异、要求纠正并执行验证。作者退出0只证明工具调用结束，不能替代验证。限定工程审核不等于主协调 Agent 正式采纳。

变更和安全边界：

- 测试 support 立即输出；until 同一次 clock 采样用于原断言与位置输出，原顺序/异常/计数/umask/期限不变。
- 增加独立 native 观测自检；fairness gate 精确兼容一条同名 START 前缀，并拒绝乱序/多余输出。
- Store 仅 `Impl::event` 五行新增、一行替换。scope/key/type/capacity guard、event_id 相对生成位置、完整 canonical+SAX/DOM/byte/depth/UTF-8 检查和1/4/16MiB限额、result、SQL、路由、CAS/Actor/session、事务均保留。无新API或缓存。
- 新同源 probe 用测试链接 `--wrap` 计数并始终调用真实库，检查完整原 command/Actor/CAS、SQLite payload/hash/result、原文/预算/epoch、精确重放及 foreign-session 拒绝。它是一个显式回归探针，不是第93项 CTest；原92名称/期限保持。

已实际完成的验证（完整矩阵进行中，不能作为全门禁通过）：

| 范围 | 结果 |
| --- | --- |
| native 观测有效旧反例 | 原 support 下已收到独立marker，预期8行/实际3行，目标FAIL、child -9且reaped |
| native 新版 GCC13 / Clang18 | 各一套工具自检的3合成场景通过，child -9/1/0且回收 |
| fairness classifier | 原8PASS/1目标FAIL；新9/9PASS |
| 既有 runner / immediate / transport 自检 | 24/24、4/4、11/11PASS，均是工具方法数 |
| Store 同源原579红例 | 编译0；真实运行1，初次count2/replay1，唯一FAIL为最后的 `published_count == 1` |
| Store 候选绿例 | 相同冻结probe，编译0/运行0，初次count1/replay1，全部持久化和拒绝断言通过 |
| 定向已有 CTest | runtime_types/store/event_store/audit24_capacity/r24_recovery：5/5PASS、无跳过、原90s各不变 |
| 完整 Release0022 / 0002 | 各92/92PASS，0失败/超时/skipped/notrun；893.977s / 776.830s，源码794项和构建61项前后身份均已核验 |
| 本机共享GCC Debug ASan/LSan | RUNNING；已见离线CLI600s及多项原90s Timeout，原始失败保留，不能登记通过 |
| 本机完整 UBSan / Clang18 | 前述共享门禁结束后依次新建构建并执行原92；当前NOT_RUN |
| 精确08远端CI | Push和PR各六配置12个Linux作业，以及另五个workflow作业，合计7workflow/17job均success；两份共享GCC产物92/92、原期限及源码/构建身份已独立核实 |

历史失败继续OPEN：新旧 ASan Async180s Timeout、旧 owned90s Timeout、旧资源探针5s断言，以及更早 GCC/Clang/live_workflow问题。新增失败位置和JSON CPU profile只提供可观测性/优化依据；少一次序列化不是总体提速或历史根因闭合证明。`historical_clang_asan_failures_closed=false` 保持。未放宽断言/期限、关闭sanitizer、删SQL/第三方/历史证据。

Windows hosted Server/elevated native组件结果与Windows11普通用户实机分开；后者仍NOT_RUN，完整Windows runtime未实现。全部产品测试使用FakeModel/私有SQLite/loopback合成凭据，没有真实供应商或付费API测试。编码工具授权不扩展为产品调用授权。

`IMPLEMENTATION_COMPLETE=LIMITED_SCOPES`；`LOCAL_VALIDATION_COMPLETE=false`；`PUSH_COMPLETE=true`和`REMOTE_CI_COMPLETE=true`均仅对应已发布代码08；尚未发布的报告/补包及其最终SHA另行登记；`PR_REVIEW_COMPLETE=false`；`MERGED=false`。完整原日志留数据盘，公开文本证据/版本化报告随后随本分支交付；不把远端绿色当作协调者批准。

进度证据截点：2026-11-01约05:06UTC。远端 [Push CI](https://github.com/wmqfl861/wls861/actions/runs/41271460248) / [PR CI](https://github.com/wmqfl861/wls861/actions/runs/41271462706) 已成功；当前本机门禁真实失败与远端成功分开，不用后者覆盖前者。报告和公开文本收据将在冻结运行全部结束后补齐。
