# 唯一一次partial-upload诊断的终态复核（2026-11-01）

这次单方法诊断真实结束为ERROR：原invoke的driver子进程在15秒内没有返回，Python抛出TimeoutExpired，Ran 1 test in 15.410s、FAILED(errors=1)，method及wrapper均exit1，outer_timeout=false。**它没有到达原prefix断言，没有复现原GCC/UBSan的同一assertion，不建立新的权限或重试漏洞。分类始终DIAGNOSTIC_NOT_GATE，根因OPEN。**

root先观察整个正式driver真实exit1及全部阶段结束，再按已审launcher/spec和新SHA固定notice执行唯一一次。root终态receipt SHA为630e3061ff982f87825733c6c27e454367d9c2d3098d4e986fa57d23130a9b4f，notice为1d82a1d6678000d447c273545cb282452dabe954c0092bbf45bf04dc33e769ce；终态观察时间早于诊断started/launched。一个O_EXCL attempt claim绑定本run，没有重跑。本审核不新运行launcher、driver、测试、编译器、模型或诊断。

原launcher18,939字节SHA8e7b50869f3bf0ad2665f19b84a54f1afa77068dfe2f898088736fccd03657ba；spec4,358字节SHAacf1951cf0e51b5f2e43ea265ab666ccfc6b88e9864b73838cc7e250cb5f47cc。实际argv/cwd与spec逐项相等，selector只选择原HttpsTransport.test_partial_request_upload_deadline_is_not_free_retry_authority，无测试overlay。794份tracked原字节/mode匹配Git08及原gate清单；原15秒子进程、12秒invoke elapsed断言、3500ms配置、900000 padding、4096 prefix、2048 receive buffer全部保留。ASan/LSan halt_on_error/detect_leaks与原UBSan环境值保留，不因UBSAN_OPTIONS就将该GCC ASan二进制计为UBSan构建。

**时间与实际到达阶段。**

| 原记录 | 值 | 准确范围 |
| --- | --- | --- |
| wrapper started / launched / finished UTC | 09:56:29.719869 / 09:56:55.151365 / 09:57:24.697291 | wrapper54.976837秒包含前后完整身份/依赖取证，不能当方法耗时。 |
| unittest原尾总结 | Ran1 in15.410s；errors1 | 一次方法执行；不是整个CTest、更不是新增第93项。 |
| observer subprocess_start → timeout | 0.298001 → 15.385845秒，即15.087844秒 | observer起点相对本次导入；是子进程调用/超时路径，并非已返回transport elapsed。 |
| peer_closed / observation_finished | 15.406669 / 15.411038秒 | collector按序结束，无I/O warning/limit；不证明业务成功。 |
| 配置3500ms | 保留原输入 | 没有driver_result，不能宣称观察到了3.5秒transport deadline、确定它何时开始或在哪里耗尽。 |

10行observation sequence0–9连续，依次certificates_start/ready、fixture_start、peer_listening、configuration_ready、subprocess_start/timeout、peer_close_start/closed、observation_finished。没有subprocess_return、driver_result、peer_accepted、tls_start或prefix marker。peer_closed显示accepted/prefixes/requests/errors/live_threads均0；这是受控fixture记录的计数。Peer源码在listener.accept返回之后增加accepted，prefix仅handler收满4096字节后加入；不能从这些0推出完整网络事实、安全漏洞或具体卡点，亦不替代driver栈。

当前tests/test_https_transport.py:741调用invoke，异常来自286–288行subprocess.run(timeout=15)。因此290起的returncode/stderr/JSON/12秒elapsed与原tuple检查未到达，742–753行的deadline、prefix==1、上传量、upload_may_have_occurred、accepted==1及部分正文断言也均未执行。测试函数名中的retry authority不是本次取得的重试权限证据，没有返回结果可判断UNKNOWN/预算/重试授权。observer捕获TimeoutExpired只记录允许计数并原样重抛，stdout_bytes/stderr_bytes为null表示exception未提供缓冲内容，不冒称driver已正常返回空输出。

**输入与ELF闭包独立核验。** inputs-before/after各363,232字节，原字节完全相同，SHA为d66feaeb98256c7cea238a976a0051c39b27ae0e24e7a1a9267ea49a84b17bda。审核重新读取全部794源码34,883,112字节，重算SHA、Git blob及mode对照精确08 tree；这是身份核验，不是794份实现的语义审核。61项实际binary/control共1,479,120,702字节重新流式哈希，与before/after及原gate清单相同。driver SHA仍52204f0c0be513ea800958321950ae80ada3020b69a023f9a5f55e2cc935e244。

原前后各组driver/Python/OpenSSL ldd输出与对应exit0 metadata命令核验，无not found；解析38/5/4个库槽，加三主体后去重为42个实际resolved文件。它们、git/ldd工具与四项launcher/selection/notice/driver终态控制文件均重新哈希，当前bytes/mode/device/inode/mtime与前后相符。这里只绑定这次已解析ELF依赖；不是历史系统库重建，也不包含运行时dlopen、Python全stdlib、OpenSSL动态provider或所有配置依赖的完备证明。本审核没有再次运行ldd或任何被审ELF。

**清理。** launcher记录finally即使leader已退出仍检查专属PGID；原观察为GROUP_ALREADY_ABSENT、leader_reaped=true、group_exists_after_cleanup=false。当前独立只读/proc stat检查同PID不存在、同pgrp无成员；没有发送任何信号。fixture peer_closed的live_threads0与正常观察尾标记相符。当前Python3.12 subprocess.run源码显示POSIX TimeoutExpired路径kill/wait直接子进程后重抛；这解释标准路径，不伪造未单独保存的driver最终信号退出码。以上是本次测试收尾证据，不是任意逃逸后代完全不存在的证明，也不授予Store资源/Workspace业务清理权限。

**公开候选。** 原stdout0字节、stderr2,253字节及完整completion/身份原件继续在root run目录私有保留。public-candidate仅选择：本报告、显式允许字段的diagnostic-summary.json、原安全observation.jsonl及stderr精确路径投影。projection-recipes.json列每个替换的原字节区间/跨度SHA/替换文本，区间之外字节不变；argv保留顺序/selector正文，仅将确切解释器路径、task根投影为占位。投影不是原日志/原receipt，不能把私有fixture随机路径或整个completion直接扩展公开。没有读取临时call配置、证书/私钥、运行DB、请求/响应正文或用户配置凭据。有界模式检查不保证覆盖全部秘密；最终公开ZIP仍需root按精确成员/字节独立审核。

本审核者此前编写launcher，root已对精确launcher做非作者静态审核；本次由root实际执行，本审核独立核对终态执行/证据，不把自己作者身份改称另一轮非作者launcher审核或主协调者批准。

最小下一步仅供主协调者决定：如果继续定位，应在driver入口到发起transport之前的明确前置阶段取有界采样/剖析，再决定生产修改；目前没有phase trace或调用栈，不归因JSON、编译器、磁盘、ASan或Store锁。当前不重跑、不延长15/12/3.5秒条件、不修改生产或测试。正式GCC/UBSan失败、历史Clang/live_workflow根因继续OPEN，code08 LOCAL_VALIDATION_COMPLETE=false不变，PR审阅/合并状态不变。
