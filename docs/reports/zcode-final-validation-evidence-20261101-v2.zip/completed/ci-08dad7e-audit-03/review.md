精确提交 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde` 的第三次有界 CI 审核完成：**新增 PR GCC ASan 作业已核实 92/92 通过，Linux 累计 9 个作业成功、3 个仍运行；REMOTE_CI_COMPLETE=false。**

审核者 `/root/evidence_audit`。本轮仅进行一次元数据查询，并下载当时新增完成的一个作业原始日志和一份 GCC ASan ZIP。workflow 查询截点为 `2026-11-01T04:43:18.287151+00:00`，Linux job 查询截点为 `2026-11-01T04:43:19.980406+00:00`。没有继续轮询，也没有索取仍运行作业的日志。7 条 workflow 中 5 条 success、Push/PR Linux 两条 in_progress；这些状态只代表查询截点。

分支 `fix/zcode-local-validation-20261101` 和 [Draft PR #12](https://github.com/wmqfl861/wls861/pull/12) 的 head 均为精确 08；base 为 `7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a`，PR 合并验证提交为 `47534906df0402b20651b1971ac642c98aa1af9a`。PR 尚未合并。当前 head 的本地 Git commit/tree 对象和此前保存的不可变 merge API 对象核实：head 与 merge 的 tree 均为 `149bca333bce2460ba940ace3c76cc1111dfdd83`，merge 父对象依次为 base/head。

| 本轮对象 | 结果与证据 |
| --- | --- |
| [PR GCC ASan job 124744917757](https://github.com/wmqfl861/wls861/actions/runs/41271462706/job/124744917757) | success，API 完成时间 `04:38:04Z`；原始日志实际 checkout 为完整 merge 475349。 |
| 共享 GCC ASan gate | GCC 13.3.0、Debug、UID/GID 1001、build umask 0022、test umask 0002；`ASAN_OPTIONS=halt_on_error=1:detect_leaks=1`。 |
| 完整 CTest | 原 92 项唯一注册名及其原始期限全部匹配精确 Git08 的 catalog；JUnit 和 CTest 原日志均为 92 PASS，0 failure/error/skipped/notrun；实际 ctest exit 0，耗时 `1991.662654724` 秒。 |
| 执行时间 | ctest 从 `04:04:49.546643+00:00` 到 `04:38:01.209297+00:00`；共享 runner 总结于 `04:38:02.215084+00:00`，状态 PASSED。 |
| 原始 artifact 13069509584 | 134233 字节、37 个成员；ZIP SHA-256 `81ed97aa1762816b462c907555504abb8456bd2ebad0ee4cd83a747a7e1f7407`，匹配 API digest，CRC/成员路径检查通过。 |
| 日志和退出收据 | summary 的 9 个 step 与各原始 step receipt 相同，全部 exit 0；每个日志哈希与 receipt 匹配。所有 compile command 都含 `-fsanitize=address`。 |
| 源码身份 | 794 项 source-before/source-after 相等，逐项 SHA-256/可执行位与精确 Git08 相符；未将 merge checkout 错写为直接 checkout head。 |
| binary/control 身份 | 61 项前后清单相等；归档实际包含的 CMakeCache、CTestTestfile、compile_commands 三项已重哈希。归档没有可执行载荷，未声称重哈希远端 ELF。 |

本轮读取并重哈希 `ci-08dad7e-audit-02` 的八份原始日志，哈希仍与该冻结审核相同。它们分别覆盖 Push/PR 的 strict、strict-umask-0002、Clang-18 和 UBSan，各自 92/92 通过。这里沿用其已有独立验证结论，没有重新下载或重跑这些作业，也没有将同一测试的子例计成额外套件。

以下三项在本次截点仍未结束：

| Job | 配置 | 截点状态 |
| --- | --- | --- |
| [124744917912](https://github.com/wmqfl861/wls861/actions/runs/41271462706/job/124744917912) | PR Make-ASan | in_progress，conclusion=null |
| [124744910414](https://github.com/wmqfl861/wls861/actions/runs/41271460248/job/124744910414) | Push GCC ASan | in_progress，conclusion=null |
| [124744910575](https://github.com/wmqfl861/wls861/actions/runs/41271460248/job/124744910575) | Push Make-ASan | in_progress，conclusion=null |

最终源码产物 `13069810810` 沿用此前保留的原始 ZIP，本轮重新校验其 API size/digest、内层 COMMIT/TREE/SHA256SUMS 以及 794 个文件。所有路径、原字节、Git blob SHA-1 和归一化后的 Git 可执行 mode 均匹配本地精确 Git08 的 `ls-tree`。ZIP 为 24083543 字节，SHA-256 `6cfa4b87e40f01c5ec89d40d8db40134395de67ffb217a37d248204139a1a419`；内层 `source.tar.gz` SHA-256 为 `bed6d667e74067c8e4107962f9852c62eef1d646ed2a9f050b3f9d0ddf1f0f78`。未解压到工作树，也未执行归档内容。

9 次 API/日志/产物请求均 exit 0、stderr 空，原命令、起止时间、退出码、字节数和 SHA-256 已保存。`verify_ci_v1.py` 的实际执行 exit 0、stderr 空，用时 6.000702 秒；其命令和脚本哈希在 `verify-receipt.json`。`external-inputs.json` 冻结本轮读取的旧审核输入，脚本结束时再次确认它们的原字节未变。`git-command-receipts.json` 保存三个成功 Git 只读命令。初步查看本地 merge 对象的 `git cat-file -p 475349...` 返回 128（该对象未下载到本地）；此查询限制记录于 `inspection-note.json`，merge 的父对象/tree 取自先前保存的精确 GitHub commit API 原件，没有创建或移动 Git 对象/引用。

五条非 Linux workflow 的 success 仅为这次 API 元数据观察；本轮未重新审核精确 08 的 Windows/fairness job 原始产物。共享 GCC ASan artifact 没有完整 LastTest，JUnit 成功输出可能截断，因此只确认原 92 项结果及完整 CTest 摘要，不宣称取得所有内部方法的完整输出。历史 Clang ASan 失败未关闭，旧 579 的绿色结果没有转移到 08。

本轮没有构建、运行产品测试、调用模型、索引图、修改源码/旧证据、终止进程或发布。报告状态保持 `LOCAL_VALIDATION_COMPLETE=false`、`REMOTE_CI_COMPLETE=false`；远端本次绿色项不替代本地尚在执行的门禁，也不代表主协调者接受或授权合并。后续结果应进入新审核目录，保留本截点。
