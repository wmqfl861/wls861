本次只读T4分析确认了两条当场断言失败和随后整项CTest超时的不同事实。第一条driver返回 `threw=true`，错误为 `openat2 workspace path: No such file or directory`，但没有返回reports；第二条只输出 `False is not true`，不能确定实际blocked内容或停止原因。**缺失路径、首份pump报告和整体变慢根因均未定位；没有实施修复、改变期限或重跑。**

审核对象为精确 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`，当前root源码干净且冻结。原证据来自 `build-gcc-asan-20261101T042059Z-b7698edb/evidence/ctest.log` 的已结束 `Start64: live_workflow` 到 `Start65` 之前，范围 `[43703,53415)`，9712字节，SHA-256 `0468e01f8e17581f88d5a246d672ce2dd61874962544f76f311317b1c9c8be8b`。06:05:39.929759 UTC读取后重读同一范围逐字匹配；正在增长的整份ctest.log没有冻结为最终门禁日志。原段含断言打印的完整字典，保存在本目录0600私有文件，未授权自动公开。

安全投影明确省略原请求/尝试身份、完整预算/账本行及正文。`first-failure-safe-projection-v2.json` 由第一条断言内的Python字面量通过 `ast.literal_eval` 解析，未执行日志代码；`safe-trace-projection.txt` 只替换包含该完整字典的一行，其余行保持原样。原段、被投影字面量和投影各有SHA；投影不是原日志。这里没有读取运行中的数据库、配置、账单文件、私钥或凭据。

| 此次原段事实 | 能够确定 | 仍未知或没有执行到的断言 |
| --- | --- | --- |
| `test_cross_task_host_submission_cannot_complete_model_roundtrip_witness`，当前Python第261行 | `assertNotIn('threw', result, result)`失败。原结果有threw=true、上述openat2错误、credential_reads=6、evidence_reads=6、task_count=2；ledger.consistent=true；accounting.ready=true，accounting.blocked_attempts为空。 | 没有reports字段，因此pump的stop_reason、report.blocked、calls和elapsed无法从此结果恢复。accounting的空blocked列表不等于workflow报告没有阻挡。之后的原始roundtrip、模型提交归属和跨任务证据负例断言没有执行到，不能报告这些安全边界通过。 |
| `test_model_exhaustion_escalates_original_rejected_submission`，当前Python第324行 | `any(item['code']=='manager_limit' for item in result['reports'][0]['blocked'])`确实返回False并形成AssertionError。 | 原断言没有message参数，日志没有打印result；不能知道blocked为空还是含其他code，也不知道stop_reason、manager_calls、elapsed或后续phase结果。其后的quiescent、最后escalate_task、原历史验证与用户question断言没有执行到。 |
| 正式注册64 `live_workflow` | CTest输出 `***Timeout 300.10 sec`，随后出现Start65。 | 没有完整unittest Ran/OK/FAILED尾总结，也没有整组ASan门禁最终退出/after身份或整个进程树退出证明。不能用这一个段替代root最终矩阵审计。 |

当前源码静态注册了18个 `LiveWorkflow.test_*` 方法，默认unittest按方法名顺序加载。已结束段有6条ok和2条FAIL；余下10个方法没有start标记，准确分类为 `NO_START_MARKER_OBSERVED`。这是一个CTest内部的方法记录，既不是18个独立CTest，也不能把两个方法失败再当作两次独立CTest超时。不能宣称后十个方法通过或替它们补造退出。第八个失败后没有第九个方法名，不能仅凭此定位清理阻塞或说明之后没有任何Python活动。

当前源码说明了失败和日志的顺序：

1. `tests/test_live_workflow.py:160` 为每个方法创建临时目录，注册临时目录清理和umask恢复；运行数据为离线合成loopback TLS。`invoke:172–191` 捕获driver的stdout/stderr，要求returncode=0、stderr为空，解析stdout JSON；存在ledger时还要求consistent=true，然后才返回result。因此这两个方法到达第261/324行时，已经通过这组invoke检查，不能将它们称为driver非零退出或Python的240秒TimeoutExpired。
2. 两个断言都在 `with tls.Peer(...)` 退出之后。`tests/test_https_transport.py:172–199` 的退出逻辑关闭listener/socket，有限join并检查残留线程和peer.errors；到达这两个断言意味着该上下文退出没有先抛出错误。这只证明相关fixture上下文的检查路径，没有证明整项CTest或任意后代进程已经收尾。
3. `tests/immediate_unittest.py:21–23` 先调用标准 `addFailure` 登记失败，再输出原存储traceback并flush。它没有添加局部变量、配置或诊断字典；第一条完整result来自原测试的assert message，第二条原断言没有message，故只有False信息。这个机制解释了为何后来的套件超时仍保留两条已发生的断言，而没有改变failfast、测试顺序或断言。
4. Python3.12的TextTestResult.startTest在打印方法名前缀后flush；TestCase.run在方法失败被登记后仍有tearDown/doCleanups/stopTest等步骤。本段没有这些步骤的单独时间或完成收据，不能认定第八个方法的cleanup已完成，也不能反过来认定cleanup就是超时原因。正常临时目录清理还可能删除运行数据；本轮不依赖临时目录留存，也不读取它。

`tests/live_workflow_driver.cpp:96–247` 区分了两层异常。内部执行try中的 `wls::s1::Error` 在239–240行被捕获为result.threw/error，之后仍附上accounting/budget/ledger并以stdout JSON、exit0返回。外层std::exception则写stderr并exit1。第一条正是前一种可见形态；这不是把业务错误当作测试成功，Python第261行仍拒绝了它。

driver在197行创建局部reports数组，每个phase先执行pump_live并push结果；`host_submit_alpha`分支随后使用当前Actor/binding读取alpha的result.txt，再进行真实Store提交/检查。直到233行、整个phase循环结束之后，才把局部reports移入最终result；异常发生在赋值前会留下只有threw/error等字段的结果。当前缺失reports不能证明之前没有执行pump，也不能证明已有pump全部成功或全部失败，不能区分在哪次phase停止。源码中216行的host诊断读取是一个直接可检查的候选位置，但没有C++调用栈或phase标记，不能确定此次缺失的就是result.txt，更不能证明它为什么尚未存在。

跨任务夹具的文件前置条件可以从当前源码明确核查。Python第254–255行只创建alpha目录和seed.txt；ModelPeer的cross_task主任务序列在第103–107行依次安排fs_read(seed.txt)、fs_write(result.txt)、fs_read(result.txt)、submit。该方法指定worker_calls=3，所以它依赖首批的真实模型工具执行完成文件写入和读取，再由host完成alpha提交。其他任务走other.txt路径；primary_task由第一次带task_id的模型输入确定，原结果没有保留其值或每次action，本轮不能从task_count=2还原实际调度顺序。driver第204–216行在pump返回后仅检查host_submit_alpha开关，未根据该份report的stop_reason另作host读取前置判断；它直接执行受原Store/Workspace守卫约束的fs_read。源码因此展示一个需要诊断的夹具进度假设，不证明此次就是60秒到期造成ENOENT，也不能通过预造result.txt或放宽守卫让它通过。

`EventRuntime`第742–764行允许先记录原结算/独立usage evidence，再通过live_continue检查后才应用响应；批次停止不授予迟到业务写权限。所以原结果的6次credential/evidence读取、budget.attempts=6和accounting.ready=true不能证明发生了6次业务效果，更不能证明result.txt已经生成。原结果中有request_id但无request_status，有task_count但无tasks/ops/operations明细，也无error_code、errno或host_submission_id；逐键检查没有找到其他嵌套status/error_code/errno字段。后一个ID直到submit与check都结束后才写入，缺失它也不能当作没有进入这些动作的证明。这些字段的存在/缺失均写入安全投影，实际请求、任务、op状态保持未知。

`src/workspace_posix.cpp:117–127` 的open_resolved使用openat2、O_NOFOLLOW及RESOLVE_BENEATH/NO_SYMLINKS/NO_MAGICLINKS/NO_XDEV，非允许的失败转为Error；ENOENT在静态errno映射中对应InvalidInput。原driver结果没有序列化ErrorCode或系统调用参数，因此本报告保留原错误字符串，不把静态映射升级成已捕获的原始errno/路径/C++栈。`WorkerTools::diagnostic:383–389` 在读文件前仍执行参数、工具类型、Store授权、限速和workspace核验。这些守卫没有被修改；本轮没有证明所有安全断言通过或全程没有业务副作用。

期限是三个不同层次：

| 层次 | 当前源码事实 | 不能推出的结论 |
| --- | --- | --- |
| 每次live pump | driver第131行默认max_batch_duration=60000ms；目标两例均显式传两个phase。EventRuntime::pump_live第411–426行设置deadline及stop watcher，并把本机deadline导致的cancelled投影为deadline。 | 不是同步Store/文件操作的硬抢占期限；更不是该次原报告已返回deadline的证据。 |
| 一次Python invoke | subprocess.run在第185行timeout=240，覆盖driver全进程的多个phase、启动和收尾；POSIX stdlib超时会kill/wait直接子进程然后重新抛TimeoutExpired。 | 不等于整个CTest给每个方法另有240秒；也不是任意后代进程组收尾证明。此次两条trace均不是TimeoutExpired。 |
| 一个CTest注册 | CMakeLists.txt第199–202行原TIMEOUT=300；实际段300.10秒Timeout，含整个Python套件的setup、多个方法与cleanup。 | 不能从300.10秒反推某个方法耗时，也不能将多个内部phase的预算相加成新的允许期限。 |

对第二条断言，当前 `EventRuntime::pump_workflow` 第568–586行先检查live_continue、accounting、capacity和总call上限，随后才在非Worker调用达到冻结manager cap时添加manager_limit。live_continue的取消/deadline与其他守卫可以先停止执行；report还可能有其他阻挡。这说明“未见manager_limit”并不足以定位一个管理上限实现缺陷。此次原result没有输出，不能选择deadline、accounting、其他错误或调度作为已确认原因。manager_cap来自原冻结配置，本轮没有读取该配置，也没有扩大限额。

本次图检索遵循codebase-memory的Verify范围。list_projects/index_status确认图仍指向旧 `wls861-next-cycle` integration、generation `2026-10-31T06:55:42Z`；精确方法的图行号315–327与当前317–329不同。trace只给出旧方法的invoke/origin/rows/ModelPeer候选，不作为完整调用链证明。coverage的no_recorded_issue属于旧树，immediate_unittest为missing，live_test_support.hpp第128行partial；相关当前源码均补读，包括128附近范围。没有重建索引，也没有把零caller当作不存在动态调用的证明。

实际辅助模块是 `tests/immediate_unittest.py`，不是初始提供的 `tests/immediate_failure_reporting.py`。首次rg因不存在路径exit2，首次身份探针因同一路径FileNotFoundError exit1；随后按当前import修正并核Git08。它们是只读发现工具错误，不是新的产品失败。十份实际仓库源码逐字匹配Git08 blob，三份Python3.12 stdlib输入另存SHA；共13份输入及原调用身份见input-manifest.json。本轮没有读取src/runtime_types.cpp实现。

下一次最小定向诊断应等待root正式矩阵结束、使用新独立诊断工作树/证据目录，由协调者安排原 `live_workflow` 单注册的离线运行。保持300/240/60秒、原18方法顺序、所有断言、完整evidence与workspace守卫，不添加重试、不提前制造result.txt，也不直接调整管理/Worker配额：

- Python侧在方法开始/结束、invoke开始/完成、peer退出和cleanup开始/结束输出短小monotonic时间标记并flush；结果摘要只投影error code、threw、report是否存在、每phase stop_reason/blocked codes/calls计数/manager_calls/elapsed，保留未知。尤其在第324行断言之前输出明确允许字段，不能再次打印整个rawresult。
- driver的stderr目前必须为空；直接往它写阶段日志会改变测试结果。应使用显式私有诊断sidecar，在每个pump前后、host诊断读取前后、submit/check前后与捕获Error时写有界phase编号/阶段/计数/错误码并及时flush；不输出完整argv、配置、响应、预算行或任何凭据。每个已返回pump的安全摘要应在host后续动作前保留，避免又被局部reports延迟赋值丢失。
- 将有界诊断状态/哈希在正常临时目录清理前转存到明确私有证据目录；只打印稍后会被删除的路径不构成证据。记录这次实际exit/Timeout/未执行事实，不将旧缺失trace补造成当时已存在。
- 只有新phase证据明确之后，才由协调者决定进一步函数/SQL/I/O分析或最小修复。本轮不建立硬件、ASan、Store锁、序列化优化或历史故障的因果关系。

本任务状态为 **READ_ONLY_T4_DIAGNOSIS_COMPLETE / ROOT_CAUSE_OPEN**。原正式live_workflow失败保持，历史失败保持OPEN；没有生产修改、测试/编译/模型执行、数据库/配置/凭据读取、进程干预或网络写入。root仍负责正式矩阵终态；本分析不改变code08已完成远端CI的独立结论，也不代表新的CI核验、协调者接受或合并。
