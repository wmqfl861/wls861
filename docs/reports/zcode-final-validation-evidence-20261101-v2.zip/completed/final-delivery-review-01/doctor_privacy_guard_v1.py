"""Read-only structural privacy guard, shared unchanged by red and green runs.

Inputs are an explicit archive identity manifest. No archive or product code is
imported or executed. Output contains member locations, schemas, and identities;
observed object values and truncated strings are never emitted.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import re
import zipfile


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


DOCTOR_KEYS = (
    "bwrap_available", "delegated_root_ready", "path_display_transformed",
    "destination_display_transformed", "runtime_read_budget_remaining",
    "required_for_prerequisites",
)
DOCTOR_START = re.compile(r'\{\s*"bwrap_available"\s*:')
OBSERVED_START = re.compile(r'\[OBSERVED\]\s*\{')
PRIVATE_RESULT_START = re.compile(r"AssertionError:\s*['\"]threw['\"] unexpectedly found in\s*\{")


def identity(raw):
    return {"bytes": len(raw), "sha256": sha(raw)}


def find_objects(text):
    objects = []
    for match in DOCTOR_START.finditer(text):
        try:
            obj, end = json.JSONDecoder().raw_decode(text, match.start())
        except json.JSONDecodeError:
            continue
        if not isinstance(obj, dict) or not {"checks", "evidence", "inputs"} <= obj.keys():
            continue
        objects.append((match.start(), end, obj))
    return objects


def analyze_member(name, raw):
    text = raw.decode("utf-8")
    objects = find_objects(text)
    findings = []
    for start, end, obj in objects:
        a, b = len(text[:start].encode()), len(text[:end].encode())
        findings.append({"archive_path": name, "type": "COMPLETE_STRUCTURED_HOST_DOCTOR_OBJECT",
            "byte_start": a, "byte_end": b, "line": text.count("\n", 0, start) + 1,
            "object_identity": identity(raw[a:b]),
            "schema": {"top_level_fields": len(obj), "checks": len(obj["checks"]),
                "has_path_or_destination_fields": any(isinstance(c, dict) and ("path" in c or "destination" in c) for c in obj["checks"]),
                "programs_executed": obj["evidence"].get("programs_executed"),
                "strong_prerequisites": obj.get("strong_prerequisites")}})
    covered = lambda offset: any(a <= offset < b for a, b, _ in objects)
    for match in OBSERVED_START.finditer(text):
        brace = text.find("{", match.start(), match.end())
        if any(a == brace for a, _, _ in objects):
            continue
        findings.append({"archive_path": name, "type": "OBSERVED_STRUCTURED_OBJECT_OR_TRUNCATED_PREFIX",
            "byte_start": len(text[:match.start()].encode()), "line": text.count("\n", 0, match.start()) + 1})
    for match in PRIVATE_RESULT_START.finditer(text):
        findings.append({"archive_path": name, "type": "PRIVATE_RESULT_ASSERTION_DICTIONARY_OR_TRUNCATED_PREFIX",
            "byte_start": len(text[:match.start()].encode()), "line": text.count("\n", 0, match.start()) + 1})
    # The key pattern allows escaped quotes. It detects doctor data in an encoded
    # JSON string and incomplete prefixes as well as complete original objects.
    for key in DOCTOR_KEYS:
        pattern = re.compile(r"(?:\\*[\"'])" + key + r"(?:\\*[\"'])\s*:")
        for match in pattern.finditer(text):
            if covered(match.start()):
                continue
            findings.append({"archive_path": name, "type": "HOST_DOCTOR_STRUCTURAL_FIELD_OUTSIDE_COMPLETE_OBJECT",
                "field": key, "byte_start": len(text[:match.start()].encode()),
                "line": text.count("\n", 0, match.start()) + 1})
    decoded_string_checks = []
    if name.endswith(".json"):
        doc = json.loads(text)

        def walk(value, pointer):
            if isinstance(value, dict):
                for key, item in value.items():
                    walk(item, pointer + "/" + str(key).replace("~", "~0").replace("/", "~1"))
            elif isinstance(value, list):
                for ordinal, item in enumerate(value):
                    walk(item, pointer + "/" + str(ordinal))
            elif isinstance(value, str):
                structural = any(re.search(r"[\"']" + k + r"[\"']\s*:", value) for k in DOCTOR_KEYS)
                result_dict = bool(PRIVATE_RESULT_START.search(value))
                observed = bool(OBSERVED_START.search(value))
                if structural or result_dict or observed:
                    findings.append({"archive_path": name, "type": "STRUCTURED_JSON_STRING_CONTAINS_PRIVATE_OBJECT_OR_PREFIX",
                        "json_pointer": pointer, "decoded_string_identity": identity(value.encode()),
                        "doctor_structural_fields": structural, "private_result_dictionary": result_dict,
                        "observed_object": observed})
                # Count all output/prefix strings, including short or incomplete
                # strings, so a zero whole-object match is never the sole test.
                field = pointer.rsplit("/", 1)[-1].lower()
                if any(word in field for word in ("stdout", "stderr", "prefix", "excerpt")):
                    decoded_string_checks.append({"json_pointer": pointer, "identity": identity(value.encode()),
                        "contains_doctor_or_observed_or_private_result_structure": structural or result_dict or observed})

        walk(doc, "")
    return findings, decoded_string_checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    manifest_path = Path(args.inputs).resolve()
    output_path = Path(args.output).resolve()
    review_root = Path(__file__).resolve().parent
    if not output_path.is_relative_to(review_root):
        raise RuntimeError("review output must stay in own review directory")
    manifest_raw = manifest_path.read_bytes()
    manifest = json.loads(manifest_raw)
    archives = []
    all_findings = []
    for entry in manifest["archives"]:
        path = Path(entry["path"])
        raw = path.read_bytes()
        if identity(raw) != {"bytes": entry["bytes"], "sha256": entry["sha256"]}:
            raise RuntimeError("archive identity differs from explicit input manifest")
        result = {"archive": {"path": str(path), **identity(raw)}, "findings": [],
            "structured_output_prefix_string_checks": [], "all_members_read_CRC_UTF8": 0}
        with zipfile.ZipFile(path) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                member = z.read(info)
                findings, strings = analyze_member(info.filename, member)
                result["findings"].extend(findings)
                if strings:
                    result["structured_output_prefix_string_checks"].append({"archive_path": info.filename, "strings": strings})
                result["all_members_read_CRC_UTF8"] += 1
        if path.read_bytes() != raw:
            raise RuntimeError("archive changed during guard")
        result["verdict"] = "BLOCKED_PRIVATE_OBJECT_OR_PREFIX" if result["findings"] else "NO_TARGETED_PRIVATE_OBJECT_OR_PREFIX_FOUND"
        archives.append(result)
        all_findings.extend(result["findings"])
    result = {"schema": "wls861-nonauthor-doctor-privacy-guard-v1", "reviewer": "/root/independent_recovery_review",
        "started_at": started, "finished_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "input_manifest": {"path": str(manifest_path), **identity(manifest_raw)},
        "guard_script": {"path": str(Path(__file__).resolve()), **identity(Path(__file__).read_bytes())},
        "archives": archives, "blocking_findings": len(all_findings),
        "verdict": "BLOCKED_PRIVATE_OBJECT_OR_PREFIX" if all_findings else "NO_TARGETED_PRIVATE_OBJECT_OR_PREFIX_FOUND",
        "bounded_guard_is_not_absolute_privacy_proof": True, "private_values_output": False,
        "archived_code_or_product_executed": False, "original_archives_modified": False}
    with output_path.open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"verdict": result["verdict"], "blocking_findings": len(all_findings),
        "archives": [{"archive": a["archive"], "verdict": a["verdict"],
            "members_checked": a["all_members_read_CRC_UTF8"], "findings": a["findings"],
            "output_prefix_string_members_checked": len(a["structured_output_prefix_string_checks"])} for a in archives]}, ensure_ascii=False, indent=2))
    raise SystemExit(1 if all_findings else 0)


if __name__ == "__main__":
    main()
