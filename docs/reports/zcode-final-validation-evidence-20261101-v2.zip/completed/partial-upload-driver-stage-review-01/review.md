# partial-upload：driver前置阶段的窄范围只读定位（2026-11-01）

当前唯一诊断是invoke的15秒TimeoutExpired，尚无driver结果、阶段标记或调用栈，不能定位耗时函数。这里仅以精确08源码列出可区分的下一步观察点，**没有发现可定性的生产漏洞，也没有证据认定JSON、curl、ASan、编译器或磁盘是根因**。本次只读，不重跑、不改源码，也不重置或重复one-shot claim。

已完成终态审计见同任务 evidence/partial-upload-current-run-review-01，其completion-receipt SHA为01a61ab254de61d363ca3348b94b67f7895b0e68312125c344848aef69acf1b2。该次peer accepted/prefix/requests均0是fixture观察，不提供driver内部PC；下面各阶段都仍是候选，而非已观察卡点。

**实际源码边界及可观测位置。**

| 顺序 | 当前08真实路径 | 若后续另获授权，最小观察点 |
| --- | --- | --- |
| 0 | ELF/动态加载、ASan启动在C++main之前；已有运行记录没有main-entry标记。 | 主入口第一条test-only阶段号；若这个标记都没有，不从C++函数热点倒推原因。 |
| 1 | tests/https_transport_driver.cpp:121读取上限16384的call配置并parse_json_strict；125查询curl_version_info；128–131验证loopback host/port。 | config_read_before/after、config_parse_after、curl_version_after，均只写阶段号和monotonic，不写配置路径/值。 |
| 2 | 133–144构造fixture profile并设限；146调用fixture::request；tests/protocol_test_support.hpp:51–66实际先compile_structured_context小初始材料。 | fixture_request_before/after；这一步早于大padding，不能把所有材料工作视为同一次大编译。 |
| 3 | driver148–153对context.task_contract追加900000字节，再compile_structured_context。src/structured_context.cpp:108–142复用ContextCompiler验证、构造规范投影、边界及hash。 | padded_context_compile_before/after；记录允许的输入字节计数，不输出材料内容。源码证明存在工作，不证明它耗尽了15秒。 |
| 4 | driver155首次encode_responses_request；src/protocol_codec.cpp:274–338包含validate_request、构造/规范编码body、边界、证据和hash。 | encode_first_before/after；保留原验证，不能仅因静态出现多次编码就删除或绕过它。 |
| 5 | driver162–212读取受界CA并配置transport options、synthetic credential及取消控制；214才调用perform_responses_https。 | options_ready、perform_entry_before，区分尚未进transport与已进入。 |
| 6 | src/https_transport.cpp:637先记录started；638重编码原profile/request，639–640对两个EncodedResponsesRequest的to_json完整核对；641–672还验证选项/凭据、解析端点、创建原响应及hash。protocol_codec.cpp:429–440的to_json会验证body及record指纹。 | perform_entry、encode_expected_before/after、encoded_integrity_after、pre_transfer_ready。需要实际持续时间/采样后才判断热点；原完整性守卫不可减少。 |
| 7 | https_transport673把deadline设为started + request.timeout；675首次interrupted检查。Transfer197–206只在调用时检查stop/clock。 | transfer_deadline_check_before/after，允许输出“已过deadline”的布尔/相对计数；不要输出完整请求身份。 |
| 8 | 681 initialize_curl；CurlGlobal35–54含一次curl_global_init/version能力检查；685构造Handles，其58–59调用curl_easy_init/curl_multi_init。 | global_init_before/after、handles_before/after；无阶段/栈证据时不把它们叫阻塞点。 |
| 9 | https_transport688–748设置header/CA/回调及socket控制；750再次检查deadline；755–762设剩余timeout并add_handle；772第一次curl_multi_perform。 | options_done、pre_attach_deadline_check、multi_add_before/after、first_perform_before/after；只首轮采样，禁止打开curl verbose或输出Authorization/body。 |
| 10 | 没有peer accept也可能走早期deadline/错误返回及finalize/清理；driver238–264还构造报告并canonical_json输出。 | perform_return、report_before/after和退出标记，避免仅查“发送前”而遗漏未发送后的返回/清理工作。 |

**三个期限的关系必须保持准确。** request.timeout=3500ms在driver147行写入；实际transport计时起点在perform的637行，故driver首次材料编译/编码发生在这段transport时钟之前。perform内部638起的重编码/完整性验证仍计入此时钟，675处可以在未调用curl前发现deadline；这种“deadline先耗尽”不自动授予重试、没有网络也不证明无费用。检查是合作式，不能硬抢占其中任意同步工作。

但本次15秒ERROR没有返回transport结果：现在不能认定它在675处走了早期deadline，也不能认定它一定尚未到curl或就是大编码慢。invoke的12秒elapsed断言同样未执行；15秒是Python对子进程启动/运行/返回的原界限，不等于已测到的3.5秒transport处理时间。后续必须保留三者及900000/4096/2048原条件，不用增大期限掩盖问题。

**一个可执行的后继假设，而非修复结论。** 主协调者若决定再授权独立诊断，先用有界test-only sidecar阶段号对上表0–10边界取一次monotonic分段；只保留阶段、时间、有限计数，按原stderr/stdout协议不改变产品结果。若无法在原二进制获得阶段信息，则对原driver进程作明确有界的采样/剖析，再与精确ELF/符号/参数身份相连。只有阶段或采样定位后才选择最小生产修复；不建立跨事务陈旧缓存、不删除编码/身份/限额校验、不预造prefix或取消正常请求解锁。新诊断须独立安排和授权；现有launcher及one-shot claim保持原样，不能作为重跑入口。

**图与源码依据。** 已按codebase-memory Verify检查list_projects/index_status：当前项目图仍是wls861-next-cycle旧worktree，generation2026-10-31T06:55:42Z。search_graph找到perform_responses_https，双向depth1的候选包含driver.main和encode_responses_request，但图还含命名解析误连候选，不能直接当动态调用栈。check_index_coverage一次覆盖七条实际路径：protocol_test_support.hpp第52行partial已读，transport_test_observation.py freshness missing已读，其余metadata_match也仅针对旧根。此处实际边界均回读精确08源码并逐字对Git08 blob；没有重建图、声称完整调用链、全仓语义审核或当前执行采样。

首次文件发现命令把协议文件名写作不存在的src/responses_protocol.cpp，rg实际exit2；随后rg --files确认实际为src/protocol_codec.cpp并读取。该发现错误保留在输入收据，不是产品红例。本任务无编译、测试、产品/模型/ZCode调用或进程干预，未改任何源码/原报告/ZIP/已冻结诊断审计。根因OPEN，DIAGNOSTIC_NOT_GATE，主协调者决定是否需要下一轮。
