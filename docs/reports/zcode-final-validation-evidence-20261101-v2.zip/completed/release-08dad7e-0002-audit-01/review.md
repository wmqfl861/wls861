Release / umask 0002 独立核验结论：**VERIFIED_RELEASE_0002_92_OF_92**。精确提交 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`，tree `149bca333bce2460ba940ace3c76cc1111dfdd83`。原始运行 `event-full-release-0002-01` 完整 92/92 PASS，0 fail、timeout、skipped、notrun。此为单轮结果，不直接授予 LOCAL_VALIDATION_COMPLETE 或历史缺陷闭环。

审核者 `/root/evidence_audit`。只读 Git 对象、原始执行证据、当前构建输入和 /proc/stat；没有编译、测试、模型调用、graph indexing、源码编辑、进程终止、提交或推送。后续共享 GCC gate 位于另一个构建目录，本审核未干预。

| 项目 | 独立核验事实 |
|---|---|
| 原命令 | 完整 CTest，parallel 1，no-tests=error，无 -R/-E/-I、改期限或仅重跑失败参数 |
| 身份与权限 | UID/GID 1000、外层 umask0002、数据盘 TMPDIR、初始工作区 clean |
| 开始 / 结束 | 2026-11-01T04:07:59.587111+00:00 / 2026-11-01T04:20:56.417195+00:00 |
| 退出 / 时间 | exit0，outer_timeout=false；recorder 776.8296781170648 秒 |
| 源码 | 794 项 before=after；路径、原 bytes/SHA、Git blob 与可执行模式逐项等于 Git08 |
| 构建输入 | 61 项 before=after，当前重哈希仍同：56 ELF、2 static archives、3 build metadata；也与前轮0022清单完全一致 |
| 构建配置 | Release，ASan/UBSan OFF；原 Store 编译项为 GCC13、O3、严格警告/Werror |
| 产品目录 | 92 名称唯一、全部匹配原目录，逐项 TIMEOUT 保持，没有 disabled 项 |
| 原始结果 | stdout/JUnit/该轮独立 LastTest 全92 PASS，stderr空；无缺项、重复项、失败/跳过/未运行标签 |
| 进程结束 | 04:30:12 UTC 左右观察：CTest PID2348230、recorder PID2348225不存在，PGID2348230无成员 |

方法层面逐项对照精确提交源码：57 个 C++ 登记（含 argv 选择的 R2.4 与 single-agent groups）完整方法表与原 PASS/RESULT 对齐；除原 doctor 自有 runner 不输出 START 外，其余 START 顺序也匹配。30 个 unittest 登记的具名 ok 行与 AST 方法集合、Ran/OK 对应。Async 29/29、owned-capacity 11/11。另有两个完整性脚本以及一个三项显式检查的 demo。它们仍是原 92 个 CTest 登记，没有按方法数扩大套件数。

两项原 quiet unittest 只有点号、Ran 和 OK：r1_history_cli_smoke 7 项、r2_recovery_cli_smoke 6 项，数量匹配源码且无失败/跳过；未补造逐方法具名日志。所有 JUnit 成功输出的截断前缀与完整 LastTest 一致，方法证据使用该轮 own LastTest，未读取后续运行覆盖的共享日志。该原日志的 Start/End 为04:07/04:20，SHA-256 `7069fbf9744d796c148164466c0146bc27701c1d43a2281ad01bd1ceb46cb00f`。

外层统计修正的独立检查见 wrapper-statistics-review.json。ctest-receipt-parser-correction-01 的 before/after SHA 匹配声明，差异只在统计分类块；运行命令、输入/二进制快照、日志复制和真实退出码路径未变。旧逻辑会在检查 failure 标签前把 status=fail 计成 notrun；修正后的逻辑能依据 failure/error 识别 Timeout。原 timeout XML 的真实分类是1 Timeout、0 notrun；原0022 XML为92 PASS，两份冻结测试输入均与原件逐字相同。

本轮0002启动早于该修正，记录说明已经加载旧 helper。本审核直接检查原0002 XML：92项全部 status=run、无failure/error/skipped，因此新旧helper走相同的all-success计数分支，原receipt的92 PASS/其余0准确。没有运行任何归档helper或重跑产品，也没有把分类修正当成产品修复。该外部helper不在Git08的794项产品输入内。

verify_release_v1.py 复用前一0022审核逻辑，仅改变run/identity路径、必需umask/标签及LastTest时段；来源及两版SHA见 verifier-provenance.json。本轮实际exit0、stderr空，绝对命令与起止/日志哈希在 verification-v1.command.json。原输入清单、方法证据、构建重哈希、进程观察均单独保存，旧冻结审核目录未改。

本次确认精确Git08的完整Release两种umask均已有独立通过证据，但 LOCAL_VALIDATION_COMPLETE 仍为false；共享GCC ASan/LSan、UBSan和Clang本地矩阵由后续实际结束记录判断。历史失败和设计接受由主协调者独立决定。新远端状态另存 ../ci-08dad7e-audit-02，仍未完成全部CI。
