本次独立只读审计已完成。原始 UBSan 全量 CTest 的真实终态是 **64 Passed / 26 Timeout / 2 Failed，exit 8**；配置及编译均为 exit 0。原 92 个注册名称与期限、JUnit、此轮完整 LastTest、终态 console、LastTestsFailed 相互一致，没有 skipped、not-run 或缺失的 CTest 结果。审计完成不等于 UBSan 通过，也不等于完整矩阵完成。

审计人 `/root/delivery_report` 只读取 root 已通知结束的 UBSan 阶段，新增输出均位于本目录。未启动产品、诊断、编译或 sanitizer，未读取活动 Clang 日志，未修改源码、原报告、runner 状态、期限或原证据，也未生成最终 ZIP。主审计程序和补充隐私分类程序实际均以 UID/GID 1000 运行并 exit 0；执行命令、时间和日志摘要分别保存在 `audit-command-receipt.json`、`marker-classification-command-receipt.json`。主审计时段为 2026-11-01 09:38:16.738533 至 09:38:32.626770 UTC。

受审源码身份是 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`，对应既有冻结 Git08 blob 审计。此次重新计算全部 **794 个当前源码文件**的 SHA-256、长度及模式，确认 configure/build/test 各自 before/after 共六份清单完全一致，并匹配该 Git08 对照。此处复用的是已有 Git blob 与 SHA-256 的对应关系，未将本次身份核验描述为重新逐文件语义审计，也未把文件系统 0664 与 Git 100644 混为一谈。

此次也重新读取并计算 **61 个实际 UBSan 二进制及构建控制文件**的 SHA-256，全部匹配本轮 binary-before/binary-after。构建自身的 `CMakeFiles/3.28.3/CMakeCXXCompiler.cmake` 确认 GNU 13.3.0、`/usr/bin/g++-13`；没有为了取版本号再执行编译器。缓存明确为 Debug、全局 CXX_FLAGS 为空、DEBUG flags 为 `-g`、ASAN OFF、UBSAN ON。92 条实际编译命令全部包含 `-g -Werror -fsanitize=undefined`，没有 `-O3`、`-DNDEBUG` 或 address sanitizer 标志。清单和核验详见 `source-crosscheck.json` 与 `binary-control-crosscheck.json`。

三个阶段的命令均在 `zcode` 工作目录以 UID/GID 1000、umask **0002** 执行，原工作区状态为空。配置命令显式指定 Debug、GNU13、`-DCMAKE_CXX_FLAGS_DEBUG=-g` 和 UBSan ON；构建命令为 `cmake --build build-zcode-event-ubsan --parallel 2`。全量测试命令为：

```text
ctest --test-dir /mnt/d/codex-workspace/wls861-zcode-followup-20261101-wvm7aclp/zcode/build-zcode-event-ubsan --output-on-failure --parallel 1 --no-tests=error --output-junit /mnt/d/codex-workspace/wls861-zcode-followup-20261101-wvm7aclp/evidence/event-full-ubsan-01-identity/ctest.xml
```

测试开始于 **07:35:50.955124 UTC**，结束于 **09:22:25.230238 UTC**；记录器耗时 6394.274522619089 秒，CTest 自报 6392.81 秒，outer_timeout=false。UBSAN_OPTIONS 原值为 `halt_on_error=1:print_stacktrace=1`，同时存在 ASAN_OPTIONS=`halt_on_error=1:detect_leaks=1`；后一环境变量不改变本构建实际仅启用 UBSan 的事实。每个 CTest 的命令、cwd、独立 end marker、状态和原期限均已核对，完整逐项结果在 `test-results.json`。部分已通过用例的 JUnit system-out 存在 CTest 原有截断，不能据此宣称每个内部方法输出完整；本轮完整 LastTest 保留了更完整的原始记录。

两个 Failed 的安全摘要如下，均不推断根因：

- `https_transport`：CTest 19.7906 秒，unittest `Ran 42 tests in 19.229s`、`FAILED (failures=1)`。失败方法为 `test_partial_request_upload_deadline_is_not_free_retry_authority`，源 `tests/test_https_transport.py:743` 为 `self.assertEqual(len(peer.prefixes), 1)`，实际异常是 **AssertionError: 0 != 1**。此前 invoke/assert_failed 已返回；后续 uploaded-body 和 retry-authority 等断言未执行。此结果不证明后续计数值、重试权限正确性或具体停顿原因。
- `r1_structured_cli_smoke`：CTest 101.111 秒，unittest `Ran 6 tests in 100.602s`、`FAILED (errors=1)`。`test_capacity_still_blocks_without_silent_truncation` 经第186行、pump第92行、call第58行，在 `pump-fake` 的 subprocess.run 内触发 **subprocess.TimeoutExpired，50 秒**。该异常是一个 CTest Failed 的内部原因，不是第27个 CTest Timeout。安全解析确认参数为 worker-calls=16、max-calls=64；没有据此宣称容量行为正确或错误。临时路径及运行时 request ID 未公开。

42 和 6 是这两个既有 CTest 内部 unittest 计数，不是额外独立测试套件。`two-failures-safe-facts.json` 保存完整 traceback 的安全 basename/line/function、异常行 SHA、原始 system-out 身份和上述边界。

Async 的终态绑定已验证：此前冻结的 **3881 字节**原块 SHA-256 `8f77f654077e804732a4bf2dcb5f504156a1dc628b7b6f0494f0c3b000e8ec04` 精确等于最终 console 的 **[17151,21032)**；此前 22237 字节 console 前缀 SHA `3fee0de5d271c84648977f0558df7322441be3ff5e826589f5baf1a8f5c44dd3` 也精确匹配最终前缀。历史 observation 的 `whole_UBSan_phase_ended=false` 和既有独立 review 的 `whole_phase_terminal_attested=false` 保持原样，本次另行记录全阶段已结束。

原 `async_coordinator` CTest 为 Timeout，原期限 180 秒，JUnit 180.019 秒，console 舍入为 180.02 秒。既有独立审查的 **29 个注册内部方法、28 START、27 PASS、0 FAIL、0 RESULT、0 UNTIL-DEADLINE** 得到保持和绑定。第28项 `resource FIFO spans all classes while independent siblings progress` 只有 START，无法定位其内部停顿阶段；第29项 `AMEND of a resource waiter preserves original capture and predecessor` 未观察到 START。`CROSS_POOL_FIFO ... new_model_calls=4 accepted=4` 属于较早第23项，不能用于证明第28项调用已完成。没有每方法耗时；没有 UNTIL-DEADLINE 也不证明五秒 predicate loop 曾经返回。既有 reviewer 的 **ROOT_CAUSE_OPEN** 保留，没有据此认定死锁、单一方法占用全部180秒或可复现的新产品缺陷。详见 `async-frozen-block-terminal-binding.json`。

隐私处理采用逐文件精确投影，没有套用 GCC 的7424字节规则，没有修改任何原件。原始终态日志在原位置保留，并在本目录 `private-originals/` 留有0600快照；目录为0700。具体处理为：

- console [45521,46218)、LastTest [210531,211228)、JUnit [104835,105532) 各替换相同 **697 字节**的 TimeoutExpired argv repr，原范围 SHA `7fa8bcd676beedefa4549b17355ecf337b264a96626de2c514db43351a5ed467`。该结构包含五个绝对路径和一个运行时 request ID；异常类型、50秒、其余 traceback 和全部外部字节保留。安全的 executable/subcommand/flags/worker-calls/max-calls 单独记录。
- 仅 LastTest 的 [54783,69676) 替换 **14893 字节**实际主机 doctor 观察对象，原范围 SHA `af668fb897237175d76f438f56abceca34033a4b4d12e7ff1f21d08bc47dbc23`。该对象含17个顶层字段、8个绝对路径及机器环境信息；其性质是主机环境观察，并未误报为请求/结果字典。已安全保留 `programs_executed=0`、`strong_prerequisites=false`，以及原 `[OBSERVED] ` 前缀和换行。console/JUnit 均无此对象。
- 逐段验证所有范围之外字节精确不变；JUnit 根属性、92个 testcase 属性及 failure/error/skipped outcome 元素完全保留。三份投影中匹配结构语法的其他行均是冻结源码 `tests/test_live_workflow.py:324` 的 traceback 源行。凭据相关词出现的5/24/22行均已绑定到源码测试标题；其中一个 JUnit 标题是本轮完整 LastTest 标题前缀加原有省略号。没有输出原始请求、结果字典或 argv 值。

`terminal-log-projection-recipes.json` 给出原件长度/SHA、精确区间、被替换范围身份、替代文本和每段保留字节身份。公开候选仅为列明的三份投影及已审查元数据，原始 console/LastTest/JUnit、原始 host observations、Async 私有冻结块保持私有。`public-candidate-policy.json` 不授权目录复制、通配收集或发布，最终仍须显式成员及完整成品的精确哈希复核。

受限扫描在三份投影中未发现所列凭据字面模式、`runtime error:` 或 `UndefinedBehaviorSanitizer`；这些零匹配不构成全隐私保证，也不能将有26个超时和2个失败的 sanitizer 阶段改称通过。原 `observations.jsonl` 安全摘要记录 build149条、CTest423条采样；配置阶段0条。CTest load三值范围分别约0.726–3.376、1.257–2.473、1.424–2.839。所有对应 cgroup cpu.max/memory.current/memory.max 记录均为缺失/null；此处不能推断无资源限制、无争用或超时由资源造成。原始主机采样不列入公开候选。

状态保持：`UBSAN_PHASE_TERMINAL_AUDIT_COMPLETE=true`，`UBSAN_PHASE_TESTS_PASS=false`，`LOCAL_VALIDATION_COMPLETE=false`，`FULL_MATRIX_TERMINAL=false`，`ROOT_CAUSE_OPEN=true`。后两项反映本审计时点的范围，后续阶段完成后应由 root 另行生成真实矩阵收据，不覆盖本审计历史记录。
