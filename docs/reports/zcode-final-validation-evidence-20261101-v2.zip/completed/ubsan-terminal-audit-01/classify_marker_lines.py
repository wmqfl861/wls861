"""Read-only classification of credential-word test markers, never their runtime values."""
from pathlib import Path
import ast
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / 'zcode'
pattern = re.compile(rb'(?i)(?:authorization|api[_ -]?key|token|bearer|credential|password|secret)')
inputs = {}


def ident(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    raw = path.read_bytes()
    inputs[str(path)] = ident(raw)
    return raw


source_manifest = json.loads(read(OUT / 'source-crosscheck.json'))['entries']
python_functions = {}
cpp_sources = {}
for relative in source_manifest:
    if relative.startswith('tests/') and relative.endswith(('.py', '.cpp')):
        raw = read(ROOT / relative)
        assert ident(raw) == {key: source_manifest[relative][key] for key in ['bytes', 'sha256']}
        text = raw.decode('utf-8')
        if relative.endswith('.py'):
            tree = ast.parse(text)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    python_functions.setdefault(node.name, []).append({'source': relative, 'line': node.lineno})
        else:
            cpp_sources[relative] = text

last_raw = read(OUT / 'safe-projections/LastTest.log.projection.txt')
last_lines = last_raw.splitlines()
full_marker = re.compile(rb'^(test_[A-Za-z0-9_]+) \([A-Za-z0-9_. ]+\) \.\.\. (?:ok|FAIL|ERROR)$')
rows = []
for filename in ['stdout.log', 'LastTest.log', 'ctest.xml']:
    path = OUT / 'safe-projections' / (filename + '.projection.txt')
    raw = read(path)
    classifications = []
    position = 0
    for line in raw.splitlines(keepends=True):
        if pattern.search(line):
            normalized = line.strip().removeprefix(b'<system-out>').removesuffix(b'</system-out>')
            method = full_marker.match(normalized)
            row = {'byte_range': [position, position + len(line)], 'identity': ident(line)}
            if method:
                name = method.group(1).decode()
                assert name in python_functions
                row.update({'classification': 'unittest_method_and_result_marker',
                            'source_declarations': python_functions[name]})
            else:
                marker = re.match(rb'^(?:START|PASS|FAIL|\[PASS\]) (.+)$', normalized)
                if marker:
                    label = marker.group(1).decode()
                    literal = '"' + label + '"'
                    matches = [relative for relative, content in cpp_sources.items() if literal in content]
                    assert matches, 'C++ marker must match frozen source literal'
                    row.update({'classification': 'cpp_framework_marker_source_literal', 'source_files': matches})
                else:
                    # CTest truncates some passed system-out text at its existing limit.
                    assert filename == 'ctest.xml' and normalized.endswith(b'...')
                    prefix = normalized[:-3]
                    matches = [full for full in last_lines if full.startswith(prefix) and full_marker.match(full)]
                    assert len(matches) == 1
                    name = full_marker.match(matches[0]).group(1).decode()
                    assert name in python_functions
                    row.update({'classification': 'truncated_unittest_marker_prefix_plus_literal_ellipsis',
                                'full_LastTest_marker_identity': ident(matches[0]),
                                'source_declarations': python_functions[name],
                                'internal_output_completeness_inferred_from_truncation': False})
            classifications.append(row)
        position += len(line)
    rows.append({'file': str(path), 'identity': ident(raw), 'credential_word_marker_count': len(classifications),
                 'classifications': classifications,
                 'runtime_error_line_count': len(re.findall(rb'(?m)^.*runtime error:.*$', raw)),
                 'UndefinedBehaviorSanitizer_occurrences': raw.count(b'UndefinedBehaviorSanitizer')})
assert [row['credential_word_marker_count'] for row in rows] == [5, 24, 22]
result = {'scope': 'Only credential/auth/token-word lines in three exact safe projections. Full matches are frozen-source test titles; one truncated JUnit title is bound to full own LastTest marker.',
          'unresolved_lines': 0, 'raw_request_result_or_secret_values_emitted': False,
          'files': rows, 'inputs': inputs,
          'limits': 'Zero literal UBSan diagnostic patterns does not establish sanitizer success; CTest exit8 with26 timeouts and2 failures remains. JUnit output truncation must not be reported as complete per-method evidence.'}
target = OUT / 'marker-line-classification.json'
with target.open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
target.chmod(0o600)
print(json.dumps({'unresolved': 0, 'credential_word_test_marker_counts': [5, 24, 22],
                  'source_backed_marker_classification_complete': True,
                  'ubsan_diagnostic_pattern_occurrences': [row['UndefinedBehaviorSanitizer_occurrences'] for row in rows]}))
