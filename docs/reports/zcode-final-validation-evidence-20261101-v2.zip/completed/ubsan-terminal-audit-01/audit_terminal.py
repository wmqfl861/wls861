"""Metadata-only audit of terminal UBSan evidence; never executes project code."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import collections
import hashlib
import json
import os
import re
import shlex
import stat
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
TASK = OUT.parent.parent
SOURCE = TASK / 'zcode'
BUILD = SOURCE / 'build-zcode-event-ubsan'
EVIDENCE = TASK / 'evidence'
RUN = EVIDENCE / 'event-full-ubsan-01'
IDENTITY = EVIDENCE / 'event-full-ubsan-01-identity'
HEAD = '08dad7e815b9c3c84d3bd2393818b2030a6e0cde'
inputs = {}
started = datetime.now(timezone.utc).isoformat()


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and not path.is_symlink(), 'regular file required'
    raw = path.read_bytes()
    key = str(path.relative_to(TASK))
    item = identity(raw)
    if key in inputs:
        assert inputs[key] == item, 'input changed during audit'
    inputs[key] = item
    return raw


def obj(path):
    return json.loads(read(path))


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    path.chmod(0o600)


def rawsave(name, raw):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open('xb') as stream:
        stream.write(raw)
    path.chmod(0o600)


def stage(name):
    print(json.dumps({'stage_verified': name}), flush=True)


phases = []
source_manifests = []
safe_observations = []
for phase, expected_exit in [('event-ubsan-configure-01', 0),
                             ('event-ubsan-build-01', 0),
                             ('event-full-ubsan-01', 8)]:
    path = EVIDENCE / phase
    command = obj(path / 'command.json')
    completion = obj(path / 'completion.json')
    assert command['head'] == completion['head'] == HEAD
    assert command['cwd'] == str(SOURCE)
    assert command['uid'] == command['gid'] == 1000
    assert command['umask'] == '0002' and command['worktree_status'] == ''
    assert command['argv'] == completion['argv']
    assert command['started_at_utc'] == completion['started_at_utc']
    assert completion['exit_code'] == expected_exit and completion['outer_timeout'] is False
    span = (datetime.fromisoformat(completion['finished_at_utc']) -
            datetime.fromisoformat(completion['started_at_utc'])).total_seconds()
    assert abs(span - completion['seconds']) < 0.01
    assert completion['source_unchanged'] and completion['source_count'] == 794
    expected_environment = {
        'TMPDIR': str(TASK / 'tmp' / phase), 'PYTHONDONTWRITEBYTECODE': '1',
        'ASAN_OPTIONS': 'halt_on_error=1:detect_leaks=1',
        'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'}
    assert command['environment'] == expected_environment
    before = obj(path / 'source-before.json')
    after = obj(path / 'source-after.json')
    assert before == after and len(before) == 794
    source_manifests.append(before)
    phases.append({'phase': phase, 'command_original': command, 'completion_original': completion})
    for leaf in ['stdout.log', 'stderr.log']:
        read(path / leaf)
    observations = read(path / 'observations.jsonl')
    rows = [json.loads(line) for line in observations.splitlines()]
    safe = {'phase': phase, 'original': inputs[str((path / 'observations.jsonl').relative_to(TASK))],
            'records': len(rows), 'raw_observation_publication_approved': False}
    if rows:
        expected_keys = {'utc', 'elapsed', 'load', '/proc/meminfo', '/sys/fs/cgroup/cpu.stat',
                         '/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/memory.current',
                         '/sys/fs/cgroup/memory.max'}
        assert all(set(row) == expected_keys for row in rows)
        assert all(datetime.fromisoformat(command['started_at_utc']) <= datetime.fromisoformat(row['utc']) <=
                   datetime.fromisoformat(completion['finished_at_utc']) for row in rows)
        assert all(a['elapsed'] < b['elapsed'] for a, b in zip(rows, rows[1:]))
        assert all(len(row['load']) == 3 and all(isinstance(x, (int, float)) for x in row['load']) for row in rows)
        stats = []
        for row in rows:
            cpu = {}
            for line in row['/sys/fs/cgroup/cpu.stat'].splitlines():
                key, value = line.split()
                assert key in {'usage_usec', 'user_usec', 'system_usec', 'core_sched.force_idle_usec',
                               'nr_periods', 'nr_throttled', 'throttled_usec', 'nr_bursts', 'burst_usec'}
                cpu[key] = int(value)
            stats.append(cpu)
        safe.update({'first_utc': rows[0]['utc'], 'last_utc': rows[-1]['utc'],
                     'first_elapsed': rows[0]['elapsed'], 'last_elapsed': rows[-1]['elapsed'],
                     'load_min': [min(row['load'][i] for row in rows) for i in range(3)],
                     'load_max': [max(row['load'][i] for row in rows) for i in range(3)],
                     'cgroup_cpu_stat_first': stats[0], 'cgroup_cpu_stat_last': stats[-1],
                     'cgroup_cpu_stat_delta': {key: stats[-1][key] - stats[0][key] for key in stats[0]},
                     'missing_limit_records': {key: sum(row[key] is None for row in rows) for key in
                                              ['/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/memory.current',
                                               '/sys/fs/cgroup/memory.max']}})
    safe_observations.append(safe)
assert all(manifest == source_manifests[0] for manifest in source_manifests)
assert phases[0]['completion_original']['finished_at_utc'] < phases[1]['command_original']['started_at_utc']
assert phases[1]['completion_original']['finished_at_utc'] < phases[2]['command_original']['started_at_utc']
assert '-DCMAKE_CXX_FLAGS_DEBUG=-g' in phases[0]['command_original']['argv']
assert phases[1]['command_original']['argv'] == ['cmake', '--build', 'build-zcode-event-ubsan', '--parallel', '2']
argv = phases[2]['command_original']['argv']
assert argv == ['ctest', '--test-dir', str(BUILD), '--output-on-failure', '--parallel', '1',
                '--no-tests=error', '--output-junit', str(IDENTITY / 'ctest.xml')]
receipt = obj(IDENTITY / 'receipt.json')
assert receipt['exit_code'] == 8 and receipt['binary_unchanged']
assert receipt['stats'] == {'registered': 92, 'cases': 92, 'passed': 64, 'failed': 2,
                            'timeout': 26, 'skipped': 0, 'notrun': 0}
save('terminal-receipts.json', {'phases': phases, 'identity_receipt_original': receipt,
     'UBSAN_PHASE_TERMINAL': True, 'UBSAN_PHASE_TESTS_PASS': False,
     'FULL_MATRIX_TERMINAL': False, 'LOCAL_VALIDATION_COMPLETE': False,
     'ASAN_OPTIONS_does_not_make_this_an_ASan_build': True,
     'interpretation': 'Completed UBSan CTest exit8; other matrix stages are outside this audit.'})
save('environment-observation-safe-summary.json', {
     'observations': safe_observations,
     'scope': 'Only recorded numeric load and cpu.stat counters, timestamps and missing-limit counts. Raw host observations remain private.',
     'limits': 'Missing cgroup limit files do not prove unlimited resources. These samples establish neither timeout causation nor absence of contention.'})
stage('terminal_receipts_and_observation_metadata')

prior = obj(EVIDENCE / 'final-matrix-handoff-audit-01/git08-source-crosscheck.json')
assert prior['head'] == HEAD and prior['tracked_paths'] == 794
assert set(source_manifests[0]) == set(prior['entries'])
sources = {}
for relative, recorded in source_manifests[0].items():
    raw = read(SOURCE / relative)
    actual = identity(raw)
    mode = stat.S_IMODE((SOURCE / relative).stat().st_mode)
    assert actual == {'bytes': recorded['bytes'], 'sha256': recorded['sha256']}
    assert actual == {key: prior['entries'][relative][key] for key in ['bytes', 'sha256']}
    assert mode == recorded['mode'] == prior['entries'][relative]['recorded_and_current_filesystem_mode']
    sources[relative] = dict(actual, mode=mode, matches_all_six_source_manifests_and_Git08_correspondence=True)
save('source-crosscheck.json', {'paths': 794, 'current_files_rehashed': True,
     'six_configure_build_test_source_manifests_identical': True,
     'reuse': 'Frozen prior Git08 blob audit supplies blob/hash correspondence; all current source bytes rehashed here. This is identity checking, not repeated semantic review.',
     'head': HEAD, 'entries': sources})
binary_before = obj(IDENTITY / 'binary-before.json')
binary_after = obj(IDENTITY / 'binary-after.json')
assert binary_before == binary_after and len(binary_before) == 61
binaries = {}
for relative, expected in binary_before.items():
    path = BUILD / relative
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and not path.is_symlink()
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    assert h.hexdigest() == expected
    item = {'bytes': st.st_size, 'sha256': h.hexdigest()}
    inputs[str(path.relative_to(TASK))] = item
    binaries[relative] = dict(item, matches_before_and_after=True)
cache = read(BUILD / 'CMakeCache.txt').decode('utf-8')
cache_fields = {}
for key in ['CMAKE_BUILD_TYPE', 'CMAKE_CXX_COMPILER', 'CMAKE_CXX_FLAGS', 'CMAKE_CXX_FLAGS_DEBUG',
            'WLS_ENABLE_ASAN', 'WLS_ENABLE_UBSAN', 'Python3_EXECUTABLE']:
    match = re.search('^' + key + r':[^=]+=(.*)$', cache, re.M)
    assert match
    cache_fields[key] = match.group(1)
assert cache_fields['CMAKE_BUILD_TYPE'] == 'Debug'
assert cache_fields['CMAKE_CXX_FLAGS'] == '' and cache_fields['CMAKE_CXX_FLAGS_DEBUG'] == '-g'
assert cache_fields['WLS_ENABLE_ASAN'] == 'OFF' and cache_fields['WLS_ENABLE_UBSAN'] == 'ON'
assert cache_fields['CMAKE_CXX_COMPILER'] == '/usr/bin/g++-13'
compiler_path = BUILD / 'CMakeFiles/3.28.3/CMakeCXXCompiler.cmake'
compiler_text = read(compiler_path).decode('utf-8')
compiler_fields = {}
for key in ['CMAKE_CXX_COMPILER', 'CMAKE_CXX_COMPILER_ID', 'CMAKE_CXX_COMPILER_VERSION']:
    match = re.search(r'set\(' + key + r' "([^"]*)"\)', compiler_text)
    assert match
    compiler_fields[key] = match.group(1)
assert compiler_fields == {'CMAKE_CXX_COMPILER': '/usr/bin/g++-13',
                          'CMAKE_CXX_COMPILER_ID': 'GNU', 'CMAKE_CXX_COMPILER_VERSION': '13.3.0'}
commands = obj(BUILD / 'compile_commands.json')
assert len(commands) == 92
for command in commands:
    tokens = shlex.split(command['command'])
    assert all(flag in tokens for flag in ['-g', '-Werror', '-fsanitize=undefined'])
    assert '-O3' not in tokens and '-DNDEBUG' not in tokens and '-fsanitize=address' not in tokens
save('binary-control-crosscheck.json', {'entries': binaries, 'count': 61,
     'actual_current_files_rehashed': True, 'before_equals_after': True,
     'cache_fields': cache_fields, 'compiler_fields': compiler_fields,
     'compiler_metadata_identity': inputs[str(compiler_path.relative_to(TASK))],
     'compiler_version_source': 'Completed UBSan build own CMake compiler metadata, not an executed compiler probe.',
     'compile_command_count': 92, 'all_commands_undefined_sanitizer_g_Werror': True,
     'no_O3_NDEBUG_or_address_sanitizer_in_any_command': True})
stage('source794_and_actual_binary_control61_identity')

catalog = obj(EVIDENCE / 'final-matrix-handoff-audit-01/expected-catalog-from-git08.json')
assert json.loads(read(SOURCE / 'tests/gcc_asan_expected_tests.json')) == catalog
expected = {row['name']: row['timeout'] for row in catalog['tests']}
plan = obj(IDENTITY / 'test-plan.json')
names = [row['name'] for row in plan['tests']]
actual_deadlines = {row['name']: next(p['value'] for p in row['properties'] if p['name'] == 'TIMEOUT')
                    for row in plan['tests']}
assert len(names) == len(set(names)) == 92 and actual_deadlines == expected
raws = {'stdout.log': read(RUN / 'stdout.log'), 'stderr.log': read(RUN / 'stderr.log'),
        'LastTest.log': read(IDENTITY / 'ctest-logs/LastTest.log'),
        'LastTestsFailed.log': read(IDENTITY / 'ctest-logs/LastTestsFailed.log'),
        'CTestCostData.txt': read(IDENTITY / 'ctest-logs/CTestCostData.txt'),
        'ctest.xml': read(IDENTITY / 'ctest.xml')}
for name, raw in raws.items():
    rawsave('private-originals/' + name, raw)
junit = ET.fromstring(raws['ctest.xml'])
cases = junit.findall('testcase')
assert [case.get('name') for case in cases] == names and junit.get('tests') == '92'
assert junit.get('failures') == '28' and junit.get('skipped') == junit.get('disabled') == '0'
last = raws['LastTest.log'].decode('utf-8')
console = raws['stdout.log'].decode('utf-8')
blocks = re.split(r'(?m)^(\d+)/92 Testing: (.+)\n', last)
assert len(blocks) == 1 + 92 * 3
console_lines = re.findall(r'^\s*(\d+)/92 Test\s+#(\d+): (\S+)\s+\.*\s*(Passed|\*\*\*Timeout|\*\*\*Failed)\s+([0-9.]+) sec$', console, re.M)
assert len(console_lines) == 92
outcomes = []
outputs = {}
for i, (test, case, line) in enumerate(zip(plan['tests'], cases, console_lines), 1):
    ordinal, name, block = blocks[1 + (i - 1) * 3: 1 + i * 3]
    assert int(ordinal) == i == int(line[0]) == int(line[1])
    assert name == test['name'] == case.get('name') == line[2]
    command = shlex.split(re.search(r'^Command: (.*)$', block, re.M).group(1))
    directory = re.search(r'^Directory: (.*)$', block, re.M).group(1)
    assert command == test['command']
    assert directory == next(p['value'] for p in test['properties'] if p['name'] == 'WORKING_DIRECTORY')
    assert len(re.findall(r'^"' + re.escape(name) + r'" end time:', block, re.M)) == 1
    message = 'Passed' if case.find('failure') is None else case.find('failure').get('message')
    assert message in ['Passed', 'Timeout', 'Failed']
    assert line[3].replace('***', '') == message
    assert ('Test Passed.' in block) == (message == 'Passed')
    assert ('Test Failed.' in block) == (message != 'Passed')
    assert case.get('status') == ('run' if message == 'Passed' else 'fail')
    assert abs(float(case.get('time')) - float(line[4])) < 0.011
    outputs[name] = case.findtext('system-out') or ''
    outcomes.append({'ordinal': i, 'name': name, 'outcome': message, 'junit_status': case.get('status'),
                     'seconds': float(case.get('time')), 'original_deadline_seconds': expected[name],
                     'LastTest_command_and_cwd_match_plan': True, 'LastTest_own_end_marker': True})
assert len(re.findall(r'^End testing:', last, re.M)) == 1
counts = dict(collections.Counter(row['outcome'] for row in outcomes))
assert counts == {'Passed': 64, 'Timeout': 26, 'Failed': 2}
assert raws['LastTestsFailed.log'].decode().splitlines() == [str(row['ordinal']) + ':' + row['name']
                                                           for row in outcomes if row['outcome'] != 'Passed']
assert '70% tests passed, 28 tests failed out of 92' in console
ctest_seconds = float(re.search(r'Total Test time \(real\) =\s+([0-9.]+) sec', console).group(1))
save('test-results.json', {'registered': 92, 'selected': 92, 'completed_CTest_outcomes': 92,
     'counts': counts, 'skipped': 0, 'not_run': 0, 'missing_outcomes': 0, 'ctest_exit': 8,
     'recorder_seconds': phases[2]['completion_original']['seconds'], 'ctest_seconds': ctest_seconds,
     'same_original_names_and_deadlines': True, 'all_LastTest_commands_cwds_end_markers_verified': True,
     'JUnit_LastTest_console_LastTestsFailed_agree': True,
     'inner_TimeoutExpired_is_part_of_one_Failed_case_not_an_extra_CTest_Timeout': True, 'tests': outcomes})
stage('original92_names_deadlines_terminal_outcome_agreement')

failure_facts = []
for name in ['https_transport', 'r1_structured_cli_smoke']:
    output = outputs[name]
    row = next(row for row in outcomes if row['name'] == name)
    assert row['outcome'] == 'Failed'
    methods = re.findall(r'^(FAIL|ERROR): (test_[A-Za-z0-9_]+)', output, re.M)
    summaries = re.findall(r'^Ran \d+ tests? in [0-9.]+s$', output, re.M)
    result_lines = re.findall(r'^FAILED \((?:failures|errors)=\d+\)$', output, re.M)
    frames = []
    for filename, lineno, function in re.findall(r'^  File "([^"]+)", line (\d+), in ([A-Za-z0-9_<>]+)$', output, re.M):
        frames.append({'file_basename': Path(filename).name, 'line': int(lineno), 'function': function})
    fact = {'CTest': row, 'failure_method_markers': methods, 'unittest_summaries': summaries,
            'unittest_result_lines': result_lines, 'traceback_frames_safe': frames,
            'system_out_identity': identity(output.encode()),
            'raw_request_response_result_dictionaries_printed_by_auditor': False}
    if name == 'https_transport':
        assert methods == [('FAIL', 'test_partial_request_upload_deadline_is_not_free_retry_authority')]
        match = re.search(r'^AssertionError: ([0-9]+ != [0-9]+)$', output, re.M)
        assert match and match.group(1) == '0 != 1'
        fact.update({'exception': 'AssertionError', 'safe_message': match.group(1),
                     'exception_line_without_newline_identity': identity(match.group(0).encode()),
                     'bounded_interpretation': 'Line743 expected len(peer.prefixes)==1 and observed0 after invoke/assert_failed returned. Later upload/retry assertions were not reached; root cause remains open.'})
        source_lines = (SOURCE / 'tests/test_https_transport.py').read_text().splitlines()
        assert source_lines[742].strip() == 'self.assertEqual(len(peer.prefixes), 1)'
    else:
        assert methods == [('ERROR', 'test_capacity_still_blocks_without_silent_truncation')]
        matches = re.findall(r'^subprocess.TimeoutExpired: Command .* timed out after (\d+) seconds$', output, re.M)
        assert matches == ['50']
        exception = next(line for line in output.splitlines() if line.startswith('subprocess.TimeoutExpired:'))
        fact.update({'exception': 'subprocess.TimeoutExpired', 'inner_timeout_seconds': 50,
                     'exception_line_without_newline_identity': identity(exception.encode()),
                     'bounded_interpretation': 'Inner subprocess.run timeout50 during pump-fake in capacity test. CTest recorded Failed at101.111s; not another CTest Timeout. No capacity correctness or timeout cause established.'})
    failure_facts.append(fact)
save('two-failures-safe-facts.json', {'failures': failure_facts, 'ROOT_CAUSE_OPEN': True})

observation_path = EVIDENCE / 'ubsan-async-completed-observation-01/safe-observation.json'
observation = obj(observation_path)
block_meta = observation['completed_block']
frozen_block = read(Path(block_meta['private_path']))
assert identity(frozen_block) == {key: block_meta[key] for key in ['bytes', 'sha256']}
assert len(frozen_block) == 3881 and block_meta['byte_start'] == 17151 and block_meta['byte_end'] == 21032
assert raws['stdout.log'][17151:21032] == frozen_block
prefix_meta = observation['stdout_snapshot']
assert identity(raws['stdout.log'][:prefix_meta['bytes_observed']]) == {
       'bytes': 22237, 'sha256': prefix_meta['sha256_of_observed_bytes']}
review = obj(EVIDENCE / 'ubsan-async-completed-review-01/verification.json')
review_receipt = obj(EVIDENCE / 'ubsan-async-completed-review-01/completion-receipt.json')
read(EVIDENCE / 'ubsan-async-completed-review-01/review.md')
read(EVIDENCE / 'ubsan-async-completed-review-01/input-manifest.json')
assert review['head'] == observation['head'] == HEAD
assert review['counts'] == observation['selected_counts'] == {
       'START': 28, 'PASS': 27, 'FAIL': 0, 'RESULT': 0, 'UNTIL-DEADLINE': 0}
assert review['registered_internal_methods'] == observation['source']['declared_current_methods'] == 29
assert observation['whole_UBSan_phase_ended'] is False and review['whole_phase_terminal_attested'] is False
assert review['root_cause'] == 'OPEN'
assert identity(read(Path(observation['source']['path']))) == {
       key: observation['source'][key] for key in ['bytes', 'sha256']}
lines = frozen_block.decode().splitlines()
selected = [line for line in lines if any(line.startswith(prefix) for prefix in
            ['START ', 'PASS ', 'FAIL ', 'RESULT ', 'UNTIL-DEADLINE '])]
assert selected == observation['selected_observed_lines']
async_row = next(row for row in outcomes if row['name'] == 'async_coordinator')
assert async_row['outcome'] == 'Timeout' and async_row['original_deadline_seconds'] == 180
save('async-frozen-block-terminal-binding.json', {
     'terminal_console_identity': identity(raws['stdout.log']), 'frozen_block_original': block_meta,
     'terminal_range_exactly_equals_frozen_block': True, 'terminal_prefix_exactly_equals_earlier22237_bytes': True,
     'original_observation_identity': inputs[str(observation_path.relative_to(TASK))],
     'historical_observation_whole_phase_ended_false_preserved': True,
     'historical_review_whole_phase_terminal_attested_false_preserved': True,
     'current_terminal_CTest': async_row, 'registered_internal_methods': 29, 'counts': review['counts'],
     'internal_method28': review['internal_method28'], 'internal_method29': review['internal_method29'],
     'cross_pool_fifo_line_belongs_to_earlier_method23_not_method28': True,
     'limits': 'No per-method timing. A START without end does not locate a stop within the method. No UNTIL-DEADLINE does not prove the five-second predicate loop returned. No deadlock/root-cause or complete four-call inference.',
     'ROOT_CAUSE_OPEN': True, 'prior_non_author_review_reused_without_changing_its_scope': True})
stage('two_failures_safe_facts_and_async_frozen_block_binding')

# Privacy review uses file-specific exact byte ranges; no GCC recipe is reused.
argv_sha = '7fa8bcd676beedefa4549b17355ecf337b264a96626de2c514db43351a5ed467'
doctor_sha = 'af668fb897237175d76f438f56abceca34033a4b4d12e7ff1f21d08bc47dbc23'
argv_positions = {'stdout.log': (45521, 46218), 'LastTest.log': (210531, 211228),
                  'ctest.xml': (104835, 105532)}
argv_source = raws['stdout.log'][45521:46218]
assert identity(argv_source) == {'bytes': 697, 'sha256': argv_sha}
assert argv_source[:1] == argv_source[-1:] == b"'"
private_argv = ast.literal_eval(argv_source[1:-1].decode())
assert isinstance(private_argv, list) and len(private_argv) == 16 and all(isinstance(v, str) for v in private_argv)
allowed_flags = ['--db', '--request', '--script', '--workspaces-file', '--worker-calls', '--max-calls', '--source-root']
assert [v for v in private_argv if v.startswith('--')] == allowed_flags
assert Path(private_argv[0]).name == 'wls' and private_argv[1] == 'pump-fake'
assert private_argv[private_argv.index('--worker-calls') + 1] == '16'
assert private_argv[private_argv.index('--max-calls') + 1] == '64'
request_identifier = private_argv[private_argv.index('--request') + 1]
argv_replacement = ("'[PRIVATE_ARGV_OMITTED bytes=697 sha256=" + argv_sha +
                    "; executable=wls subcommand=pump-fake worker_calls=16 max_calls=64]'").encode()
doctor_raw = raws['LastTest.log'][54783:69676]
assert identity(doctor_raw) == {'bytes': 14893, 'sha256': doctor_sha}
doctor = json.loads(doctor_raw)
known_doctor = {}
doctor_paths = []
def visit_doctor(value, key=''):
    if key in ['programs_executed', 'strong_prerequisites'] and isinstance(value, (bool, int)):
        known_doctor[key] = value
    if isinstance(value, dict):
        for child_key, child in value.items():
            visit_doctor(child, child_key)
    elif isinstance(value, list):
        for child in value:
            visit_doctor(child, key)
    elif isinstance(value, str) and value.startswith('/'):
        doctor_paths.append(value)
visit_doctor(doctor)
assert len(doctor) == 17 and len(doctor_paths) == 8
assert known_doctor == {'programs_executed': 0, 'strong_prerequisites': False}
doctor_replacement = ('[PRIVATE_HOST_OBSERVATION_OBJECT_OMITTED bytes=14893 sha256=' + doctor_sha +
                      '; programs_executed=0 strong_prerequisites=false]').encode()
assert b'[OBSERVED] ' not in raws['stdout.log'] and b'[OBSERVED] ' not in raws['ctest.xml']
assert raws['LastTest.log'].count(b'[OBSERVED] ') == 1
recipes = []
for name in ['stdout.log', 'LastTest.log', 'ctest.xml']:
    raw = raws[name]
    begin, end = argv_positions[name]
    assert raw[begin:end] == argv_source
    replacements = [{'byte_start': begin, 'byte_end': end, 'original_range_identity': identity(argv_source),
                     'reason': 'Structured command repr contains five absolute paths and a runtime request identifier. Safe executable, subcommand, flags and numeric capacities are retained separately.',
                     'replacement_utf8': argv_replacement.decode(), 'replacement_identity': identity(argv_replacement)}]
    if name == 'LastTest.log':
        replacements.append({'byte_start': 54783, 'byte_end': 69676, 'original_range_identity': identity(doctor_raw),
                             'reason': 'Actual host doctor observation:17 top-level fields,8 absolute-path values and machine topology. Omitted as environment metadata, not classified as a request/result dictionary; safe observation-only fields retained.',
                             'replacement_utf8': doctor_replacement.decode(), 'replacement_identity': identity(doctor_replacement)})
    replacements.sort(key=lambda item: item['byte_start'])
    pieces = []
    preserved = []
    pos = 0
    for replacement in replacements:
        begin, end = replacement['byte_start'], replacement['byte_end']
        assert pos <= begin < end <= len(raw)
        segment = raw[pos:begin]
        pieces.append(segment)
        preserved.append({'original_start': pos, 'original_end': begin, **identity(segment)})
        pieces.append(replacement['replacement_utf8'].encode())
        pos = end
    pieces.append(raw[pos:])
    preserved.append({'original_start': pos, 'original_end': len(raw), **identity(raw[pos:])})
    projected = b''.join(pieces)
    projected.decode('utf-8', errors='strict')
    assert b'\x00' not in projected
    # Check every retained interval against its resulting shifted location.
    current = 0
    for i, segment in enumerate(preserved):
        size = segment['bytes']
        assert projected[current:current + size] == raw[segment['original_start']:segment['original_end']]
        current += size
        if i < len(replacements):
            current += replacements[i]['replacement_identity']['bytes']
    assert current == len(projected)
    junit_outcomes_preserved = None
    if name == 'ctest.xml':
        safe_junit = ET.fromstring(projected)
        assert safe_junit.attrib == junit.attrib
        def outcome_signature(root):
            return [(case.attrib, [(child.tag, child.attrib, child.text)
                     for child in case if child.tag in ['failure', 'error', 'skipped']])
                    for case in root.findall('testcase')]
        assert outcome_signature(safe_junit) == outcome_signature(junit)
        junit_outcomes_preserved = True
    relative_target = 'safe-projections/' + name + '.projection.txt'
    rawsave(relative_target, projected)
    source_path = (IDENTITY / 'ctest-logs/LastTest.log') if name == 'LastTest.log' else (
                  IDENTITY / 'ctest.xml' if name == 'ctest.xml' else RUN / 'stdout.log')
    recipes.append({'source_path': str(source_path), 'source_identity': identity(raw),
                    'private_snapshot': 'private-originals/' + name,
                    'prepared_path': str(OUT / relative_target), 'projection_identity': identity(projected),
                    'algorithm': 'BYTE_RANGE_REPLACE_V1; every byte outside sorted exact intervals retained unchanged',
                    'replacements': replacements, 'preserved_intervals': preserved,
                    'JUnit_outcome_elements_preserved': junit_outcomes_preserved,
                    'original_publication_approved': False, 'final_explicit_member_and_archive_review_required': True})
save('terminal-log-projection-recipes.json', {'projections': recipes, 'no_GCC_recipe_reused': True,
     'no_directory_copy_authorized': True, 'safe_argv_fields': {
         'executable_basename': 'wls', 'subcommand': 'pump-fake', 'flags': allowed_flags,
         'worker_calls': 16, 'max_calls': 64, 'arguments': 16, 'absolute_path_arguments': 5,
         'request_identifier_identity_only': identity(request_identifier.encode())},
     'doctor_known_safe_fields': known_doctor, 'doctor_fields': 17, 'doctor_absolute_path_values': 8})

patterns = {'private_key': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
            'github_token': rb'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b',
            'aws_key': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
            'bearer_material': rb'(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{12,}'}
scan = []
retained_source_lines = []
for recipe in recipes:
    raw = Path(recipe['prepared_path']).read_bytes()
    for rule, pattern in patterns.items():
        for match in re.finditer(pattern, raw):
            scan.append({'file': recipe['prepared_path'], 'rule': rule,
                         'byte_range': [match.start(), match.end()], **identity(match.group())})
    pos = 0
    for line in raw.splitlines(keepends=True):
        if re.search(rb'[\{\[]\s*["\']', line):
            assert identity(line) == {'bytes': 102, 'sha256': 'fb6a1c0362296ad72710df5c842118321a84d2c8916c42e1cfa22a420dcd24e9'}
            source_line = (SOURCE / 'tests/test_live_workflow.py').read_text().splitlines()[323]
            assert source_line.strip() == line.decode().strip()
            retained_source_lines.append({'file': recipe['prepared_path'], 'byte_range': [pos, pos + len(line)],
                                          'identity': identity(line), 'classification': 'Traceback source line; exact Git08 test_live_workflow.py line324, not runtime data.'})
        pos += len(line)
assert not scan and len(retained_source_lines) == 3
save('bounded-projection-scan.json', {'scope': 'Three exact terminal projections; credential patterns and structured-literal candidates. Not a proof against every possible private value.',
     'patterns': {key: value.decode() for key, value in patterns.items()}, 'unresolved_candidates': scan,
     'retained_structured_syntax_classification': retained_source_lines,
     'all_raw_data_ranges_reviewed_privately': True, 'raw_data_values_emitted_by_scan': False})
stage('file_specific_privacy_projections_and_unchanged_outside_bytes')

# Classify explicit original candidates; do not authorize directory globs.
original_candidates = []
for phase in ['event-ubsan-configure-01', 'event-ubsan-build-01', 'event-full-ubsan-01']:
    for leaf in ['command.json', 'completion.json', 'source-before.json', 'source-after.json']:
        path = EVIDENCE / phase / leaf
        original_candidates.append({'path': str(path), **inputs[str(path.relative_to(TASK))],
                                    'classification': 'candidate_original_metadata'})
for relative in ['receipt.json', 'binary-before.json', 'binary-after.json', 'test-plan.json',
                 'ctest-logs/LastTestsFailed.log', 'ctest-logs/CTestCostData.txt']:
    path = IDENTITY / relative
    original_candidates.append({'path': str(path), **inputs[str(path.relative_to(TASK))],
                                'classification': 'candidate_original_metadata'})
assert raws['stderr.log'] == b'Errors while running CTest\n'
original_candidates.append({'path': str(RUN / 'stderr.log'), **identity(raws['stderr.log']),
                            'classification': 'candidate_original_generic_CTest_error_line'})
save('public-candidate-policy.json', {
     'status': 'EXPLICIT_CANDIDATES_ONLY_NOT_PUBLICATION_OR_FINAL_ZIP_APPROVAL',
     'original_candidates': original_candidates,
     'terminal_log_candidates': [{'path': row['prepared_path'], **row['projection_identity'],
                                  'classification': 'candidate_file_specific_projection'} for row in recipes],
     'private_originals': [row['source_path'] for row in recipes],
     'all_private_snapshot_files_remain_private_even_if_original_metadata_is_separately_eligible': True,
     'other_private_inputs': [str(EVIDENCE / phase / 'observations.jsonl') for phase in
                              ['event-ubsan-configure-01', 'event-ubsan-build-01', 'event-full-ubsan-01']] +
                             [str(EVIDENCE / 'ubsan-async-completed-observation-01/private-completed-block.log')],
     'configure_build_logs_not_selected_in_this_audit': True,
     'audit_json_reports_are_candidates_after_final_exact_hash_review': True,
     'no_directory_glob_or_recursive_copy_authorized': True})
save('input-identities.json', inputs)
save('completion-receipt.json', {'reviewer': '/root/delivery_report', 'started_at': started,
     'finished_at': datetime.now(timezone.utc).isoformat(), 'uid': os.getuid(), 'gid': os.getgid(),
     'UBSAN_PHASE_TERMINAL_AUDIT_COMPLETE': True, 'UBSAN_PHASE_TESTS_PASS': False,
     'LOCAL_VALIDATION_COMPLETE': False, 'FULL_MATRIX_TERMINAL': False,
     'product_executions_or_builds': 0, 'source_changes': 0, 'active_Clang_logs_read': 0,
     'private_CLI99_logs_read': 0, 'source_paths_verified': 794, 'binary_control_files_verified': 61,
     'registered_and_classified_CTest': 92, 'counts': counts, 'CTest_exit': 8,
     'ROOT_CAUSE_OPEN': True, 'async_frozen_block_bound_to_terminal': True,
     'final_zip_created': False, 'projection_scan_unresolved_candidates': len(scan)})
print(json.dumps({'audit_complete': True, 'counts': counts, 'source_paths': 794, 'binary_controls': 61,
                  'privacy_projections': 3, 'whole_matrix_terminal': False, 'product_runs': 0}), flush=True)
