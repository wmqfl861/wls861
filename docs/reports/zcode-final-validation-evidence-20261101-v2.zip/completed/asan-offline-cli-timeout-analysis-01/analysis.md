本次只读复核已把本机 GCC Debug ASan 的 `r3_offline_acceptance_cli` 超时定位到类初始化中的 Fake CLI 执行循环。三个 `pump-single-fake` 子进程已有内部 60 秒超时收据；最后留下的命令是多 Agent `exhausted_rework` 的 `correction` 阶段，尚无结束收据。C++ 内部耗时点和本机变慢的根因仍为 **OPEN**。

审核对象是提交 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`、分支 `fix/zcode-local-validation-20261101`。本轮由 UID/GID 1000 执行，源码工作树前后均干净。源码和原日志保持原样；仅在本证据目录创建文件。没有编译、执行产品或测试、打开/哈希数据库、调用模型、读凭据、提交或推送。正式矩阵仍由 root 运行，本报告不宣称该门禁或整体任务完成。

正式构建目录为 `/mnt/d/codex-workspace/wls861-zcode-followup-20261101-wvm7aclp/zcode/build-gcc-asan-20261101T042059Z-b7698edb`。由其实际 `test-plan.json` 核实，CTest 使用 `/mnt/d/codex-workspace/wls861-r2-4-20261029/test-venv/bin/python` 执行精确源码中的 Python 测试，传入该次构建的 `wls` 与源码根目录，原期限为 600 秒。CMakeCache 记录 Python 3.12.3、stdlib `/usr/lib/python3.12`。本报告阅读的是这一版本的 `unittest`、`subprocess` 和 `tempfile` 源码。

正式 `ctest.log` 的已结束前缀记录 `***Timeout 600.12 sec`，CLI 条目后到下一项开始前没有内部阶段、方法名或错误输出。这里只冻结该已结束前缀，没有把仍在增长的完整日志视为最终证据。观察到的门禁 `summary.json` 为 `NOT_COMPLETE`；它是运行中观察值，不是结束结果。

实际源码依赖是测试文件直接导入 `scripts/r3_offline_acceptance.py`，后者导入 `scripts/evaluate_r3.py`。除此之外，本调用链使用标准库；没有其他本地 Python helper 导入。七份版本化素材位于 `scripts/offline_acceptance/v1/`：`system.yaml`、`function.yaml`、`env.yaml`、`model-arguments.json`、`dispatcher.md`、`team_lead.md`、`worker.md`。按 root 最新要求，这些素材只冻结源文件 SHA-256 和 Git blob 身份，不复制配置/素材内容。运行配置和数据库均不在本包中。

图检索遵循已安装 codebase-memory 技能。`index_status` 显示图根目录仍是旧 integration，generation 为 `2026-10-31T06:55:42Z`；精确覆盖检查显示 Python 测试 freshness missing，两个 helper 位于 excluded 的 `scripts` 子树，不能证明当前 08 的源码身份。故使用精确源码和 `rg` fallback，没有重建索引。原响应见 `graph-coverage.json`。

测试静默有直接的源码依据：

- `tests/r3_offline_acceptance_cli_tests.py:30` 的 `setUpClass` 先创建临时包、`prepare`、完整 `run_fake`、读取 plan/index 并哈希数据库，完成后才开始十个测试方法。这里没有阶段打印。
- Python 3.12 `unittest/suite.py:114` 先调用 `_handleClassSetUp`，后续才调用 `test(result)`；`case.py:609` 的 `startTest` 和 `runner.py:56` 的方法名输出发生在后者。verbosity=2 的方法名会 flush，默认写 stderr，但它无法显示尚未结束的类初始化。
- `FakeRunner.invoke` 在 `scripts/r3_offline_acceptance.py:384` 使用 `capture_output=True`。子进程 stdout/stderr 不向 CTest 转发；完成或内部超时后才写私有文件。`progress` 只原子更新临时目录内的 JSON，没有控制台输出。
- 测试是直接调用 helper 函数，未经过 `r3_offline_acceptance.py:507` 的 CLI `main`。其中结束时写 JSON、错误时向 stderr 打印的分支不会为这些直接函数调用提供阶段输出。evaluator 的 `main` 同理。
- cell 内的 `PackageError`、`OSError`、`ValueError` 在 helper 第 467 行被写成 `FAILED`，然后继续下一个 cell。内部 60 秒超时因此不会立即终止类初始化，也不会立即向 CTest 打印失败摘要。

这不应被简化为 Python 缓冲问题。即使启用 unbuffered，当前路径也没有可刷新的阶段标记；helper 还显式捕获了子进程输出。

静态正常路径共有五个固定任务、两种执行条件。每个 cell 都真实启动 Store/Fake CLI；以下数量只描述全部成功且没有提前失败的路径，不是本轮已完成数：

| 任务 | 每个条件内的 CLI 次数 | 两个条件合计 |
| --- | ---: | ---: |
| tool_roundtrip | submit + initial = 2 | 4 |
| partial_amend | submit + initial + amend + update + keep + acceptances = 6 | 12 |
| rejected_rework | submit + initial + correction = 3 | 6 |
| exhausted_rework | submit + initial + correction + escalation = 4 | 8 |
| delivery_receipt | submit + initial + publish-delivery + ack-delivery = 4 | 8 |
| 单独的 plan seed | 1 | 1 |
| 合计 | | 39 |

这些子进程串行执行，每次内部期限 60 秒。这个期限不是全部 39 次的合计保证。准备、版本化素材逐字节校验、seed 计划构造、报告评估、证据和二进制哈希也计入 CTest 的 600 秒；测试方法 09/10 之后还会启动额外 CLI。这些是静态工作阶段，不是本轮性能归因。

`evaluate_r3.py` 的实际报告路径逐 cell 开只读事务、验证原材料/配置指纹/预算账本、重建 logical Agent 历史、核实原始模型响应→反馈→业务事件，以及检查提交/交付字节和恢复见证。`database:166` 使用 SQLite `mode=ro`、`query_only`、2 秒 busy timeout、10 秒 deadline 的 VM progress handler、`quick_check`，并有 JSON/行数/字节边界。该 VM handler 在每 10000 步回调，不能把纯 Python 的 JSON/历史重建或文件哈希变成硬 10 秒总期限；最后的 `file_hash` 也没有单独总时限。保留这些证据守卫。本轮保留的日志表明最终报告/全量证据哈希尚未开始，因此它们不能解释此次已记录的三个子进程内部超时。

root 进一步授权检查该 runner 的专属 TMPDIR。`scripts/run_gcc_asan.py:199` 为本次创建 build，205 行把 `TMPDIR` 设为 `build/tmp`。只检查其 `wls-a2-cli-*` 目录，找到 `wls-a2-cli-0b9q6r_g`；没有读取其他 Agent 或生产目录。root 已报告原 Python/wls 进程退出、未见遗留，本审核没有独立采样这些进程。

保留的原始收据给出以下真实进度：

| 记录 | cell / phase | 原始结果 |
| --- | --- | --- |
| 005 | tool_roundtrip-single_agent / initial | `TIMEOUT`, `exit_code:null`, 60371 ms；stdout/stderr 均 0 字节 |
| 016 | partial_amend-single_agent / keep | `TIMEOUT`, `exit_code:null`, 60300 ms；stdout/stderr 均 0 字节 |
| 022 | rejected_rework-single_agent / correction | `TIMEOUT`, `exit_code:null`, 60289 ms；stdout/stderr 均 0 字节 |
| 024 | exhausted_rework-multi_agent / initial | exit 0，30125 ms |
| 025 | exhausted_rework-multi_agent / correction | 只有 `.command.json`，没有 `.exit.json`、`.stdout` 或 `.stderr` |

001–024 共 24 份结束收据，其中 21 份 exit 0、3 份内部 TIMEOUT，原 `elapsed_ms` 合计 572931。这个合计使用截断到毫秒的各自记录，不等同于 Python 总 wall time。025 的命令文件在启动子进程前写入；其存在本身不能证明子进程成功启动，也不能证明 C++ 具体停在哪一行。

`outcomes.json` 留有六项结果：tool_roundtrip、partial_amend、rejected_rework 的 multi 均为 `COMPLETED`，single 均为 `FAILED`，失败原因是内部命令超时。`COMPLETED` 是 runner 的执行标志，最终 evaluator 还未运行，不能把它报成三个验收通过。`runs.json` 已登记第七个 cell exhausted_rework-multi_agent，`elapsed_ms:0` 是未收尾的初始值，不能理解为零耗时。其余三个 cell 尚未创建；`report.json` 和 `evidence-sha256.json` 均不存在。结合控制流，可以确定类初始化停留在 `run_fake` 循环，没有进入十个 test 方法，也没有生成最终评估报告。

本轮共冻结 99 份原样日志：25 份 command JSON、24 份 exit JSON、24 份 stdout、24 份 stderr，以及 runs/outcomes 两份索引。复制时逐份检查原字节/元数据没有变化。实际命令指向的配置只有路径，没有复制任何配置文件。stdout 是固定 Fake 流程的原始业务输出，不含配置快照正文或凭据字段；24 份 stderr 均为空。完整时间线见 `command-timeline.json`，逐份身份见 `frozen-cli-log-manifest.json`。原输出可能含合成业务材料，本目录权限为私有；这不是自动获准公开发布的文本包。

超时与清理有三层不同的边界：

- helper 的内部超时：Python 3.12 `subprocess.run` 在 timeout 后 kill 并 wait 直接子进程，在 POSIX 使用已捕获的部分输出填充异常；helper 随后保存 stdout/stderr/`TIMEOUT` 收据并抛出 `PackageError`。这里没有显式 `start_new_session`、进程组或后代收尾机制。stdlib `kill` 调用 `os.kill(self.pid, SIGKILL)`，不能将其当作整个进程树的保证。本轮没有据此宣称发生了孤儿进程。
- 测试的临时目录清理：类创建时注册 `addClassCleanup(TemporaryDirectory.cleanup)`，标准 unittest 会在类正常收尾以及捕获的 class-setup 失败后调用它。因而 helper 的“original logs retained”只说明 run 目录内留样；整个测试的正常失败收尾仍会删除临时根。外层终止 Python 时，不能保证 Python 异常路径、finally、class cleanup 或 tempfile finalizer 运行。本轮目录实际保留，是观察事实，不是依赖推测构造的阶段。
- 正式 runner：`Recorder.run` 为 CTest 使用新 session，在自身捕获异常/中断时对其进程组 SIGTERM、必要时 SIGKILL 并等待，最后落 step receipt。它与某个 CTest 项目的内部 600 秒超时不同；不能把 runner 的中断处理当作每个测试已经执行了 Python cleanup 的证明。runner 源码没有删除专属 `tmp` 的路径。

确认的缺口是诊断可观测性和普通失败后的取证保留：setup 开始/结束、cell/phase/command 起止没有实时标记；已捕获的 cell 超时不会即时显示；正常 class cleanup 会删除其私有取证文件。当前实现没有把这些超时当作成功：有完整运行结果时 evaluator/测试仍检查失败事实；本轮外层 CTest 明确报 Timeout。不过本次未执行十个 test 方法，不能宣称其原字节、预算、历史兼容负例或权限边界均已通过。

下一次最小诊断应保持原 60/600 秒期限、执行顺序、continue 策略、断言和全部安全守卫，在同样离线 Fake 条件下只增加观测：

1. 在测试入口、helper 导入前后、`setUpClass` 开始/结束，以及 prepare/run_fake/report/hash 各阶段，向 stderr 写带 monotonic 时间的简短标记并立即 flush。入口与导入前标记可区分尚未开始 setup 的情况。
2. `invoke` 输出序号、允许的 verb、task/condition/phase、开始/结束、耗时与退出/超时状态；cell 捕获失败时即时写一行有界摘要。不要输出完整 argv、配置、原响应或正文。开始标记不能等到 child 完成才写。
3. 在正常临时目录清理之前，输出或导出有界命令状态索引及其哈希；只给出将被删除的临时路径无法保留证据。原字节日志若需另行导出，应使用明确的私有 evidence 目录，仍排除数据库、配置和凭据。本轮已冻结的样本应保持原样，不重跑覆盖。
4. 首先从相同期限的定向重现取得命令级阶段；只有在该证据基础上，再按协调 Agent 指定的方法做函数/SQL/I/O profile。本轮不新增竞争的构建或测试，不提出未经 profile 验证的生产修改。

这些是后续方案，本轮没有实施。root 提供的 host steal、CPU/cgroup 观察和远端较短耗时仅作为上下文登记在 `root-provided-context.json`；本审核未独立核其原始样本，不能将其或 event JSON 路径、sanitizer、Store 锁或磁盘宣布为根因。

本轮实际执行了精确源码/stdlib 的 `rg`、`sed`、元数据读取、Git 只读身份核验和本目录 `collect_evidence.py`，没有执行项目的 prepare/run_fake/report 或任何测试。采集命令 `python3 .../asan-offline-cli-timeout-analysis-01/collect_evidence.py` exit 0。一次发现命令因 `scripts/*validation*` 未匹配使 `rg` exit 2，随后用精确 `scripts/run_gcc_asan.py` 读取修正；它不是产品或测试失败。各工具返回记录见 `inspection-tool-receipts.json`。17 份精确源码输入的 SHA-256、其中 12 份仓库输入的 Git08 blob 校验见 `input-manifest.json`；10 份代码/stdlib 快照位于 `input-snapshots/`。没有读取或重新哈希 `src/runtime_types.cpp`。

本轮结论是 **READ_ONLY_STAGE_LOCALIZATION_COMPLETE / PERFORMANCE_ROOT_CAUSE_OPEN**。没有新增产品功能缺陷的确定证据，也没有完成业务安全边界验证。`LOCAL_VALIDATION_COMPLETE=false` 与 `REMOTE_CI_COMPLETE=false` 的整体状态应继续由 root 根据真实门禁记录维护。
