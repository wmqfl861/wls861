# ceaa9b3 远端 CI 与源码身份独立审核

结论时间：2026-11-01T07:45:37.927645+00:00。本提交自己的 7 个 workflow、17 个 job 全部自然终态 success；17 份原始 job 日志与 7 份产物已分别取证。`REMOTE_CI_COMPLETE=true`。本审核未运行本机产品构建或测试，未触发重跑、发送评论、修改 PR/分支或合并；本结论不授予合并批准。

审核提交 `ceaa9b3e18618c592345001dfc597bdaf579cf81`；直接父提交 `08dad7e815b9c3c84d3bd2393818b2030a6e0cde`；源码树 `a068734b3c44c3cdef428b7dd5f6376b6be8bf32`。分支 `fix/billing-subtest-diagnostics-20261101`，Draft [PR #13](https://github.com/wmqfl861/wls861/pull/13) 的 base 仍为 PR #12 分支 `fix/zcode-local-validation-20261101`，保持 open、未合并。最终只读快照记录的 main 为 `a6b8559018a599d7a806b05942857a56d69a00ce`。

Push 实际 checkout 为 `ceaa9b3e18618c592345001dfc597bdaf579cf81`；PR 实际 checkout 为合并测试提交 `e50c7f70b97d3c91a74d484e0c8d02f4e41c015b`，后者与 head 的 tree 同为 `a068734b3c44c3cdef428b7dd5f6376b6be8bf32`。原始日志的 `git log -1 --format=%H` 输出逐 job 核实，不能仅凭 API 的 head_sha 代替实际 checkout。

## 本提交输入与完整源码归档

基线 794 份 tracked files，本提交 796 份。四项实际变动如下；四个 workflow、产品测试期望表和 `tests/immediate_unittest.py` 的 Git blob 与 base 相同。四项发布输入的 SHA-256 均匹配独立发布收据；没有借用 08dad7e 的 CI 成功结果。

- `docs/reports/billing-subtest-diagnostics-20261101-evidence.json`
- `docs/reports/billing-subtest-diagnostics-20261101.md`
- `tests/test_billing_baseline_e2e.py`
- `tests/test_immediate_unittest.py`

本提交 source artifact `13073741687` 的 ZIP 为 24,094,891 字节，SHA-256 `9f68330bdd7e993bead8aba4b5a5ed8dc8f51d33ec39e77e7dc384939f796b4f`；内部 `source.tar.gz` 的 SHA-256 为 `f40b4301cb06cc45aa9ab4fd8962e07cb803f070dcc6e44458bb3fdae996c9aa`。

实际读取全部 796 份文件、34,930,778 原字节，逐项重算 Git blob、执行位及 SHA-256，并独立递归重建完整 Git tree，精确得到 `a068734b3c44c3cdef428b7dd5f6376b6be8bf32`。路径集合与 Git tree 相等；不是只校验四个变动文件或引用上一次 source 结果。`source-archive-verification.json` 保存全部 796 份清单，`source-verify.receipt.json` 记录核验器实际 exit 0。

读取的归档内容是已提交的公共源码；没有读取实际运行设置、凭据或数据库，也没有执行归档中的产品程序。

## Push 与 PR 六路 Linux 作业

| Event | Job | 原作业链接 | 结果 |
|---|---|---|---|
| push | Linux C++20 (ASan) | [124777581023](https://github.com/wmqfl861/wls861/actions/runs/41282664727/job/124777581023) | success |
| push | Linux C++20 (Clang-18) | [124777580896](https://github.com/wmqfl861/wls861/actions/runs/41282664727/job/124777580896) | success |
| push | Linux C++20 (Make-ASan) | [124777580811](https://github.com/wmqfl861/wls861/actions/runs/41282664727/job/124777580811) | success |
| push | Linux C++20 (UBSan) | [124777580913](https://github.com/wmqfl861/wls861/actions/runs/41282664727/job/124777580913) | success |
| push | Linux C++20 (strict) | [124777581038](https://github.com/wmqfl861/wls861/actions/runs/41282664727/job/124777581038) | success |
| push | Linux C++20 (strict-umask-0002) | [124777580937](https://github.com/wmqfl861/wls861/actions/runs/41282664727/job/124777580937) | success |
| pull_request | Linux C++20 (ASan) | [124777595668](https://github.com/wmqfl861/wls861/actions/runs/41282669494/job/124777595668) | success |
| pull_request | Linux C++20 (Clang-18) | [124777595476](https://github.com/wmqfl861/wls861/actions/runs/41282669494/job/124777595476) | success |
| pull_request | Linux C++20 (Make-ASan) | [124777595657](https://github.com/wmqfl861/wls861/actions/runs/41282669494/job/124777595657) | success |
| pull_request | Linux C++20 (UBSan) | [124777595743](https://github.com/wmqfl861/wls861/actions/runs/41282669494/job/124777595743) | success |
| pull_request | Linux C++20 (strict) | [124777595632](https://github.com/wmqfl861/wls861/actions/runs/41282669494/job/124777595632) | success |
| pull_request | Linux C++20 (strict-umask-0002) | [124777595645](https://github.com/wmqfl861/wls861/actions/runs/41282669494/job/124777595645) | success |

每边 strict、strict-umask-0002、Clang-18、UBSan 共 8 次原 CTest 日志，各自具有完整 92 个唯一测试的 Passed 行、`100% tests passed, 0 tests failed out of 92` 和成功步骤结尾。共享 ASan 两次由各自最终 JUnit、原 CTest 日志和步骤收据核实 92 项全部 run/pass、0 failure/error/skip/notrun、原 TIMEOUT 未改；合计是同一组 92 个产品 CTest 的 10 次完整执行。

共享 ASan 的两份归档均记录 GCC 13.3.0、UID/GID 1001、Debug、warnings-as-errors、`-fsanitize=address -fno-omit-frame-pointer`、无优化/NDEBUG/关闭 sanitizer 的覆盖参数；build umask 0022、test umask 0002，`ASAN_OPTIONS=halt_on_error=1:detect_leaks=1`，未设置 LSAN_OPTIONS。92 条 compile commands、test-plan、3 份原构建控制文件及全部 step/log 摘要分别核验。

| Event | 共享 ASan artifact | CTest 秒数 | billing 秒数 | billing JUnit 完整 ok 方法行 |
|---|---|---:|---:|---:|
| pull_request | 13074684734 | 2454.495 | 427.971 | 7/16 |
| push | 13074770969 | 1569.298 | 263.9 | 7/16 |

两边原 Make-ASan 均从原命令 `make -j2 asan BUILD_DIR=build-make CPPFLAGS=-DWLS_CI_USER_CPPFLAGS=1` 核实用户 CPPFLAGS 与 ASan/LSan 参数，计费产品类完整 16 个方法、`Ran 16 tests` 和 `OK` 均有原日志。计费后继 runtime_resources_cli、最终 review_cli 原 recipe 命令及原步骤 success 也存在。它们是两次原 Make 目标执行，不能另计为两套 92 项 CTest；没有额外单独提供 Make 数字退出码收据，依据是原成功 step/job 与完整 recipe。

共享 ASan JUnit 对成功 billing case 的 system-out 存在截断；上表只计实际完整方法行。原 case 已终态 run/pass，原 ctest exit 0，但不从源代码或其他执行补造缺失方法输出。

## 诊断工具自检单独计数

精确 head 的 AST 提取 5 个顶层工具测试方法；Push/PR 的 strict 和 ASan 共 4 次执行，各自原日志的全部 5 个同名方法、`Ran 5 tests`、`OK` 及 API 成功步骤均核实。它们不加入 92 个产品 CTest；也不把四次执行称作 20 个不同测试。

- `test_billing_script_main_entrypoint_emits_subtest_failure_before_termination`
- `test_expected_failure_and_skip_are_not_reported_as_immediate_failures`
- `test_failure_traceback_survives_termination_after_next_test_starts`
- `test_original_accounting_order_tracebacks_and_failfast_are_preserved`
- `test_subtest_header_excludes_parameters_and_preserves_both_errors`

## 其余 workflow 与能力边界

| Event | Workflow | Run | 结果 |
|---|---|---|---|
| pull_request | A4 same-source fairness counterexample | [41282669560](https://github.com/wmqfl861/wls861/actions/runs/41282669560) | success |
| pull_request | Windows native foundation slice | [41282669512](https://github.com/wmqfl861/wls861/actions/runs/41282669512) | success |
| push | Windows native foundation slice | [41282664647](https://github.com/wmqfl861/wls861/actions/runs/41282664647) | success |
| push | A4 same-source fairness counterexample | [41282664744](https://github.com/wmqfl861/wls861/actions/runs/41282664744) | success |
| push | Verifiable committed source snapshot | [41282664700](https://github.com/wmqfl861/wls861/actions/runs/41282664700) | success |

Windows 两边各自完整 LastTest 与 JUnit 均核实 4 套件、27 方法（3/4/14/6），各 10 条 command 收据 exit 0；预期名取自精确 ceaa 的四份 native 测试源码。796 份源码 before/after 均匹配本提交全量清单。范围是 Windows Server 2022、elevated token、NTFS；`windows_11_machine_acceptance=NOT_RUN`、`ordinary_user_security_acceptance=NOT_RUN`、`full_native_runtime=NOT_IMPLEMENTED`。

两次新 run 仍存在镜像记录差异：runner header 为 `20261025.346.1`，artifact environment 为 `20261026.347.1`；精确镜像身份保留 `UNRESOLVED`，未把旧 run 的结果当作解决证据。

Fairness 两边各自 candidate 源码 796 份均匹配 ceaa tree，Push candidate 为 head，PR candidate 为 merge；原 baseline exit 1、candidate exit 0，保留 red/green 原收据。它们单列，不加入 92 项产品 CTest。没有另外重算公平性历史 baseline 全部原字节 blob。

共享 ASan 的 796 份源码及 61 项二进制/控制身份 before/after 相同，3 份控制文件可从归档原字节独立重算；归档未携带 ELF 或 PE 载荷，不能独立重算远端可执行文件本身的摘要。

## 采集失败与可复现证据

保留历史 6 次失败 GET：首轮 3 次 60 秒 TimeoutExpired、3 次 TLS handshake timeout；原 collector v1 随后解析空失败响应产生 JSONDecodeError，实际 exit 1。`api-0001/` 的原响应、stderr、request 收据、collector stderr/tool-result/failure 描述均保留。只补读失败 GET 到 `api-0002-recovery/` 后成功；v2 collector 保留失败、跳过失败响应解析并降低并发至 2。不能声称所有历史 GET 都 exit 0；这些网络/采集失败也不是产品或 CI 失败。

最后 full 快照：`api-0011-final/collection.json`；最终证据核验：`checks-0005-final/verification.json`、`checks-0005-final.receipt.json`，核验器实际 exit 0，stderr 摘要 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`。顶层 `verification.json` 为最终核验原字节副本。所有新增 GET 均有 argv、时间、真实 returncode、原 stdout/stderr 和 SHA-256；job logs、ZIP 仅对新终态/新产物下载，不重复 source 取证。

`SHA256SUMS` 冻结审核目录的证据文件；为避免递归，排除该清单自身、随后生成的 `SHA256SUMS.check.stdout`、`.stderr`、`.receipt.json` 以及 Python 缓存。最终实际 `sha256sum -c SHA256SUMS` 的退出码、清单摘要及结果总数由 `SHA256SUMS.check.receipt.json` 单独记录。

## 交还主协调 Agent 的状态

- `REMOTE_CI_COMPLETE=true`：仅指本提交自己的上述远端作业与证据已完成审核。
- `IMPLEMENTATION_COMPLETE`、`LOCAL_VALIDATION_COMPLETE`：本审核不出具结论，由主协调 Agent 的代码和本机验证结果决定。
- 发布分支已只读观察为 ceaa9b3，与独立发布收据相符；本审核没有 push。
- `PR_REVIEW_COMPLETE=false`，`MERGED=false`：PR 仍为 Draft，审核/合并决定交还主协调 Agent。
