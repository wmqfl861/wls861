"""Metadata-only terminal Clang audit; does not execute project code or tools."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import collections
import hashlib
import json
import os
import re
import shlex
import stat
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
TASK = OUT.parent.parent
SOURCE = TASK / 'zcode'
BUILD = SOURCE / 'build-zcode-event-clang'
EVIDENCE = TASK / 'evidence'
RUN = EVIDENCE / 'event-full-clang-01'
IDENTITY = EVIDENCE / 'event-full-clang-01-identity'
HEAD = '08dad7e815b9c3c84d3bd2393818b2030a6e0cde'
inputs = {}
started = datetime.now(timezone.utc).isoformat()


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and not path.is_symlink(), 'regular file required'
    raw = path.read_bytes()
    key = str(path.relative_to(TASK))
    item = identity(raw)
    if key in inputs:
        assert inputs[key] == item, 'input changed during audit'
    inputs[key] = item
    return raw


def obj(path):
    return json.loads(read(path))


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    path.chmod(0o600)


def rawsave(name, raw):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open('xb') as stream:
        stream.write(raw)
    path.chmod(0o600)


def stage(name):
    print(json.dumps({'stage_verified': name}), flush=True)


phases = []
source_manifests = []
observations_safe = []
for phase in ['event-clang-configure-01', 'event-clang-build-01', 'event-full-clang-01']:
    path = EVIDENCE / phase
    command = obj(path / 'command.json')
    completion = obj(path / 'completion.json')
    assert command['head'] == completion['head'] == HEAD
    assert command['cwd'] == str(SOURCE)
    assert command['uid'] == command['gid'] == 1000
    assert command['umask'] == '0002' and command['worktree_status'] == ''
    assert command['argv'] == completion['argv']
    assert command['started_at_utc'] == completion['started_at_utc']
    assert completion['exit_code'] == 0 and completion['outer_timeout'] is False
    span = (datetime.fromisoformat(completion['finished_at_utc']) -
            datetime.fromisoformat(completion['started_at_utc'])).total_seconds()
    assert abs(span - completion['seconds']) < 0.01
    assert completion['source_unchanged'] and completion['source_count'] == 794
    assert command['environment'] == {
        'TMPDIR': str(TASK / 'tmp' / phase), 'PYTHONDONTWRITEBYTECODE': '1',
        'ASAN_OPTIONS': 'halt_on_error=1:detect_leaks=1',
        'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'}
    before = obj(path / 'source-before.json')
    after = obj(path / 'source-after.json')
    assert before == after and len(before) == 794
    source_manifests.append(before)
    phases.append({'phase': phase, 'command_original': command, 'completion_original': completion})
    for leaf in ['stdout.log', 'stderr.log']:
        read(path / leaf)
    raw_observations = read(path / 'observations.jsonl')
    records = [json.loads(line) for line in raw_observations.splitlines()]
    safe = {'phase': phase, 'original_identity': identity(raw_observations), 'records': len(records),
            'raw_observation_publication_approved': False}
    if records:
        expected_keys = {'utc', 'elapsed', 'load', '/proc/meminfo', '/sys/fs/cgroup/cpu.stat',
                         '/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/memory.current', '/sys/fs/cgroup/memory.max'}
        assert all(set(row) == expected_keys for row in records)
        assert all(datetime.fromisoformat(command['started_at_utc']) <= datetime.fromisoformat(row['utc']) <=
                   datetime.fromisoformat(completion['finished_at_utc']) for row in records)
        assert all(a['elapsed'] < b['elapsed'] for a, b in zip(records, records[1:]))
        assert all(len(row['load']) == 3 and all(isinstance(x, (int, float)) for x in row['load']) for row in records)
        stats = []
        for row in records:
            cpu = {}
            for line in row['/sys/fs/cgroup/cpu.stat'].splitlines():
                key, value = line.split()
                assert key in {'usage_usec', 'user_usec', 'system_usec', 'core_sched.force_idle_usec',
                               'nr_periods', 'nr_throttled', 'throttled_usec', 'nr_bursts', 'burst_usec'}
                cpu[key] = int(value)
            stats.append(cpu)
        safe.update({'first_utc': records[0]['utc'], 'last_utc': records[-1]['utc'],
                     'load_min': [min(row['load'][i] for row in records) for i in range(3)],
                     'load_max': [max(row['load'][i] for row in records) for i in range(3)],
                     'cgroup_cpu_stat_first': stats[0], 'cgroup_cpu_stat_last': stats[-1],
                     'missing_limit_records': {key: sum(row[key] is None for row in records) for key in
                                              ['/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/memory.current',
                                               '/sys/fs/cgroup/memory.max']}})
    observations_safe.append(safe)
assert all(manifest == source_manifests[0] for manifest in source_manifests)
assert phases[0]['completion_original']['finished_at_utc'] < phases[1]['command_original']['started_at_utc']
assert phases[1]['completion_original']['finished_at_utc'] < phases[2]['command_original']['started_at_utc']
assert '-DCMAKE_BUILD_TYPE=Release' in phases[0]['command_original']['argv']
assert '-DCMAKE_CXX_COMPILER=/usr/bin/clang++-18' in phases[0]['command_original']['argv']
assert phases[1]['command_original']['argv'] == ['cmake', '--build', 'build-zcode-event-clang', '--parallel', '2']
assert phases[2]['command_original']['argv'] == [
    'ctest', '--test-dir', str(BUILD), '--output-on-failure', '--parallel', '1',
    '--no-tests=error', '--output-junit', str(IDENTITY / 'ctest.xml')]
receipt = obj(IDENTITY / 'receipt.json')
assert receipt['exit_code'] == 0 and receipt['binary_unchanged']
assert receipt['stats'] == {'registered': 92, 'cases': 92, 'passed': 92, 'failed': 0,
                            'timeout': 0, 'skipped': 0, 'notrun': 0}
assert receipt['utc'] > phases[2]['completion_original']['finished_at_utc']
save('terminal-receipts.json', {'phases': phases, 'identity_receipt_original': receipt,
     'CLANG_PHASE_TERMINAL': True, 'CLANG_PHASE_TESTS_PASS': True,
     'FULL_MATRIX_TERMINAL_ATTESTED_BY_THIS_PHASE_AUDIT': False, 'LOCAL_VALIDATION_COMPLETE': False,
     'sanitizer_environment_variables_do_not_enable_instrumentation': True,
     'interpretation': 'Completed Clang phase only. Root separately owns actual driver exit observation; sanitizer failures remain unaffected.'})
save('environment-observation-safe-summary.json', {'observations': observations_safe,
     'scope': 'Only recorded numeric load/cpu.stat, timestamps and missing-limit counts. Host raw observations remain private.',
     'limits': 'Absent cgroup limit files do not establish unlimited resources. Observations do not prove or disprove contention or explain another compiler/sanitizer outcome.'})
stage('terminal_receipts_and_observation_metadata')

prior = obj(EVIDENCE / 'final-matrix-handoff-audit-01/git08-source-crosscheck.json')
assert prior['head'] == HEAD and prior['tracked_paths'] == 794
assert set(source_manifests[0]) == set(prior['entries'])
sources = {}
source_bytes = {}
for relative, recorded in source_manifests[0].items():
    raw = read(SOURCE / relative)
    actual = identity(raw)
    mode = stat.S_IMODE((SOURCE / relative).stat().st_mode)
    assert actual == {'bytes': recorded['bytes'], 'sha256': recorded['sha256']}
    assert actual == {key: prior['entries'][relative][key] for key in ['bytes', 'sha256']}
    assert mode == recorded['mode'] == prior['entries'][relative]['recorded_and_current_filesystem_mode']
    sources[relative] = dict(actual, mode=mode, matches_all_six_source_manifests_and_Git08_correspondence=True)
    source_bytes[relative] = raw
save('source-crosscheck.json', {'paths': 794, 'current_files_rehashed': True,
     'six_configure_build_test_source_manifests_identical': True, 'head': HEAD,
     'reuse': 'Frozen prior Git08 blob audit supplies blob/hash correspondence; current source bytes rehashed. Identity verification is not repeated semantic review.',
     'entries': sources})
binary_before = obj(IDENTITY / 'binary-before.json')
binary_after = obj(IDENTITY / 'binary-after.json')
assert binary_before == binary_after and len(binary_before) == 61
binaries = {}
for relative, expected in binary_before.items():
    path = BUILD / relative
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and not path.is_symlink()
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    assert h.hexdigest() == expected
    item = {'bytes': st.st_size, 'sha256': h.hexdigest()}
    inputs[str(path.relative_to(TASK))] = item
    binaries[relative] = dict(item, matches_before_and_after=True)
cache = read(BUILD / 'CMakeCache.txt').decode()
cache_fields = {}
for key in ['CMAKE_BUILD_TYPE', 'CMAKE_CXX_COMPILER', 'CMAKE_CXX_FLAGS', 'CMAKE_CXX_FLAGS_RELEASE',
            'WLS_ENABLE_ASAN', 'WLS_ENABLE_UBSAN', 'Python3_EXECUTABLE']:
    match = re.search('^' + key + r':[^=]+=(.*)$', cache, re.M)
    assert match
    cache_fields[key] = match.group(1)
assert cache_fields['CMAKE_BUILD_TYPE'] == 'Release'
assert cache_fields['CMAKE_CXX_FLAGS'] == '' and cache_fields['CMAKE_CXX_FLAGS_RELEASE'] == '-O3 -DNDEBUG'
assert cache_fields['WLS_ENABLE_ASAN'] == cache_fields['WLS_ENABLE_UBSAN'] == 'OFF'
assert cache_fields['CMAKE_CXX_COMPILER'] == '/usr/bin/clang++-18'
compiler_path = BUILD / 'CMakeFiles/3.28.3/CMakeCXXCompiler.cmake'
compiler_text = read(compiler_path).decode()
compiler_fields = {}
for key in ['CMAKE_CXX_COMPILER', 'CMAKE_CXX_COMPILER_ID', 'CMAKE_CXX_COMPILER_VERSION']:
    match = re.search(r'set\(' + key + r' "([^"]*)"\)', compiler_text)
    assert match
    compiler_fields[key] = match.group(1)
assert compiler_fields == {'CMAKE_CXX_COMPILER': '/usr/bin/clang++-18',
                          'CMAKE_CXX_COMPILER_ID': 'Clang', 'CMAKE_CXX_COMPILER_VERSION': '18.1.3'}
commands = obj(BUILD / 'compile_commands.json')
assert len(commands) == 92
strict_flags = ['-Wall', '-Wextra', '-Wpedantic', '-Werror', '-O3', '-DNDEBUG', '-std=c++20']
for command in commands:
    tokens = shlex.split(command['command'])
    assert tokens[0] == '/usr/bin/clang++-18' and all(flag in tokens for flag in strict_flags)
    assert not any(flag.startswith('-fsanitize=') for flag in tokens)
save('binary-control-crosscheck.json', {'entries': binaries, 'count': 61,
     'actual_current_files_rehashed': True, 'before_equals_after': True,
     'cache_fields': cache_fields, 'compiler_fields': compiler_fields,
     'compiler_metadata_identity': inputs[str(compiler_path.relative_to(TASK))],
     'compiler_version_source': 'Completed Clang build own CMake metadata; no compiler probe executed.',
     'compile_command_count': 92, 'required_flags_in_all_commands': strict_flags,
     'sanitizer_flags_in_any_command': False})
stage('source794_and_actual_binary_control61_identity')

catalog = obj(EVIDENCE / 'final-matrix-handoff-audit-01/expected-catalog-from-git08.json')
assert json.loads(source_bytes['tests/gcc_asan_expected_tests.json']) == catalog
expected = {row['name']: row['timeout'] for row in catalog['tests']}
plan = obj(IDENTITY / 'test-plan.json')
names = [row['name'] for row in plan['tests']]
deadlines = {row['name']: next(prop['value'] for prop in row['properties'] if prop['name'] == 'TIMEOUT')
             for row in plan['tests']}
assert len(names) == len(set(names)) == 92 and deadlines == expected
raws = {'stdout.log': read(RUN / 'stdout.log'), 'stderr.log': read(RUN / 'stderr.log'),
        'LastTest.log': read(IDENTITY / 'ctest-logs/LastTest.log'),
        'CTestCostData.txt': read(IDENTITY / 'ctest-logs/CTestCostData.txt'),
        'ctest.xml': read(IDENTITY / 'ctest.xml')}
assert raws['stderr.log'] == b''
failed_path = IDENTITY / 'ctest-logs/LastTestsFailed.log'
assert not failed_path.exists()
assert not (BUILD / 'Testing/Temporary/LastTestsFailed.log').exists()
for name, raw in raws.items():
    rawsave('private-originals/' + name, raw)
junit = ET.fromstring(raws['ctest.xml'])
cases = junit.findall('testcase')
assert [case.get('name') for case in cases] == names and junit.get('tests') == '92'
assert junit.get('failures') == junit.get('skipped') == junit.get('disabled') == '0'
assert not junit.findall('.//failure') and not junit.findall('.//error') and not junit.findall('.//skipped')
last = raws['LastTest.log'].decode()
console = raws['stdout.log'].decode()
blocks = re.split(r'(?m)^(\d+)/92 Testing: (.+)\n', last)
assert len(blocks) == 1 + 92 * 3
console_lines = re.findall(r'^\s*(\d+)/92 Test\s+#(\d+): (\S+)\s+\.*\s*(Passed|\*\*\*Timeout|\*\*\*Failed)\s+([0-9.]+) sec$', console, re.M)
assert len(console_lines) == 92
outcomes = []
last_blocks = {}
for i, (test, case, line) in enumerate(zip(plan['tests'], cases, console_lines), 1):
    ordinal, name, block = blocks[1 + (i - 1) * 3:1 + i * 3]
    assert int(ordinal) == i == int(line[0]) == int(line[1])
    assert name == test['name'] == case.get('name') == line[2]
    command = shlex.split(re.search(r'^Command: (.*)$', block, re.M).group(1))
    directory = re.search(r'^Directory: (.*)$', block, re.M).group(1)
    assert command == test['command']
    assert directory == next(p['value'] for p in test['properties'] if p['name'] == 'WORKING_DIRECTORY')
    assert len(re.findall(r'^"' + re.escape(name) + r'" end time:', block, re.M)) == 1
    assert line[3] == 'Passed' and case.get('status') == 'run'
    assert block.count('Test Passed.') == 1 and 'Test Failed.' not in block
    assert abs(float(case.get('time')) - float(line[4])) < 0.011
    last_blocks[name] = block
    outcomes.append({'ordinal': i, 'name': name, 'outcome': 'Passed', 'junit_status': 'run',
                     'seconds': float(case.get('time')), 'original_deadline_seconds': expected[name],
                     'LastTest_command_and_cwd_match_plan': True, 'LastTest_own_end_marker': True})
assert len(re.findall(r'^End testing:', last, re.M)) == 1
assert '100% tests passed, 0 tests failed out of 92' in console
ctest_seconds = float(re.search(r'Total Test time \(real\) =\s+([0-9.]+) sec', console).group(1))
save('test-results.json', {'registered': 92, 'selected': 92, 'completed_CTest_outcomes': 92,
     'counts': {'Passed': 92, 'Timeout': 0, 'Failed': 0}, 'skipped': 0, 'not_run': 0,
     'missing_outcomes': 0, 'ctest_exit': 0, 'recorder_seconds': phases[2]['completion_original']['seconds'],
     'ctest_seconds': ctest_seconds, 'same_original_names_and_deadlines': True,
     'all_LastTest_commands_cwds_end_markers_verified': True, 'JUnit_LastTest_console_agree': True,
     'LastTestsFailed_absent_in_archived_and_actual_build_log_directories': True,
     'per_method_output_completeness_claimed_from_JUnit': False, 'tests': outcomes})
stage('original92_names_deadlines_all_passed_terminal_agreement')

# The only host-observation object is classified privately and projected exactly.
doctor_start, doctor_end = 57744, 72637
doctor_raw = raws['LastTest.log'][doctor_start:doctor_end]
assert identity(doctor_raw) == {'bytes': 14893, 'sha256': 'af668fb897237175d76f438f56abceca34033a4b4d12e7ff1f21d08bc47dbc23'}
doctor = json.loads(doctor_raw)
known_doctor = {}
doctor_paths = []
def visit_doctor(value, key=''):
    if key in ['programs_executed', 'strong_prerequisites'] and isinstance(value, (bool, int)):
        known_doctor[key] = value
    if isinstance(value, dict):
        for child_key, child in value.items():
            visit_doctor(child, child_key)
    elif isinstance(value, list):
        for child in value:
            visit_doctor(child, key)
    elif isinstance(value, str) and value.startswith('/'):
        doctor_paths.append(value)
visit_doctor(doctor)
assert len(doctor) == 17 and len(doctor_paths) == 8
assert known_doctor == {'programs_executed': 0, 'strong_prerequisites': False}
assert raws['LastTest.log'].count(b'[OBSERVED] ') == 1
assert b'[OBSERVED] ' not in raws['stdout.log'] and b'[OBSERVED] ' not in raws['ctest.xml']
replacement = ('[PRIVATE_HOST_OBSERVATION_OBJECT_OMITTED bytes=14893 sha256=' + identity(doctor_raw)['sha256'] +
               '; programs_executed=0 strong_prerequisites=false]').encode()
projection = raws['LastTest.log'][:doctor_start] + replacement + raws['LastTest.log'][doctor_end:]
assert projection[:doctor_start] == raws['LastTest.log'][:doctor_start]
assert projection[doctor_start + len(replacement):] == raws['LastTest.log'][doctor_end:]
projection.decode('utf-8', errors='strict')
assert b'\x00' not in projection
rawsave('safe-projections/LastTest.log.projection.txt', projection)
save('terminal-log-projection-recipes.json', {
     'projections': [{'source_path': str(IDENTITY / 'ctest-logs/LastTest.log'),
       'source_identity': identity(raws['LastTest.log']), 'private_snapshot': 'private-originals/LastTest.log',
       'prepared_path': str(OUT / 'safe-projections/LastTest.log.projection.txt'),
       'projection_identity': identity(projection),
       'algorithm': 'BYTE_RANGE_REPLACE_V1; every byte outside this file-specific interval retained',
       'replacements': [{'byte_start': doctor_start, 'byte_end': doctor_end,
          'original_range_identity': identity(doctor_raw), 'replacement_utf8': replacement.decode(),
          'replacement_identity': identity(replacement),
          'reason': 'Actual host doctor observation:17 fields,8 absolute paths and environment topology. Not classified as a request/result dictionary; safe observation-only fields retained.'}],
       'preserved_intervals': [{'original_start': 0, 'original_end': doctor_start,
                               **identity(raws['LastTest.log'][:doctor_start])},
                              {'original_start': doctor_end, 'original_end': len(raws['LastTest.log']),
                               **identity(raws['LastTest.log'][doctor_end:])}],
       'original_publication_approved': False, 'final_explicit_member_and_archive_review_required': True}],
     'console_and_JUnit_require_no_projection_after_bounded_classification': True,
     'JUnit_bytes_and_all_outcome_elements_unchanged': True,
     'no_GCC_or_UBSan_offsets_reused': True, 'doctor_known_safe_fields': known_doctor,
     'no_directory_copy_authorized': True})

# Independently validate the source-defined billing summary instead of dropping it.
billing_line_start, billing_line_end = 186311, 187736
billing_line = raws['LastTest.log'][billing_line_start:billing_line_end]
assert identity(billing_line) == {'bytes': 1425, 'sha256': 'e5ea063c2a67c3557b1e04d1e309ef79fbf604f1a4ba86188ef3bffb07c49b75'}
assert billing_line.startswith(b'INDEPENDENT_PAIRED_RESULT ')
billing_raw = raws['LastTest.log'][186337:187735]
assert identity(billing_raw) == {'bytes': 1398, 'sha256': 'ce470d58ddb98d09fb1a5bf0051caadf49cfb44bfe1505d183c09715ed32ead2'}
billing = json.loads(billing_raw)
assert set(billing) == {'contract', 'counts', 'expected_cells', 'observed_cells', 'provider_quality_acceptance_established', 'rows'}
assert type(billing['contract']) is int and billing['contract'] == 3
assert billing['counts'] == {'passed': 10}
assert billing['expected_cells'] == billing['observed_cells'] == 10
assert billing['provider_quality_acceptance_established'] is False
assert len(billing['rows']) == 10
evaluation_tree = ast.parse(source_bytes['scripts/evaluate_r3.py'])
tasks_assignment = next(node for node in evaluation_tree.body if isinstance(node, ast.Assign)
                        and any(isinstance(target, ast.Name) and target.id == 'TASKS' for target in node.targets))
task_ids = [ast.literal_eval(item.elts[0]) for item in tasks_assignment.value.elts]
assert len(task_ids) == len(set(task_ids)) == 5
conditions = ['single_agent', 'multi_agent']
pairs = []
for row in billing['rows']:
    assert set(row) == {'task_id', 'condition', 'attempts', 'elapsed_ms', 'known_cost_micro_usd'}
    assert row['task_id'] in task_ids and row['condition'] in conditions
    assert all(type(row[key]) is int and row[key] >= 0 for key in ['attempts', 'elapsed_ms', 'known_cost_micro_usd'])
    pairs.append((row['task_id'], row['condition']))
assert sorted(pairs) == sorted((task, condition) for task in task_ids for condition in conditions)
billing_source_lines = source_bytes['tests/test_billing_baseline_e2e.py'].decode().splitlines()
assert "print('INDEPENDENT_PAIRED_RESULT '" in billing_source_lines[747]
save('billing-summary-classification.json', {
     'original_LastTest_line_range': [billing_line_start, billing_line_end], 'line_identity': identity(billing_line),
     'JSON_range': [186337, 187735], 'JSON_identity': identity(billing_raw),
     'source_emission': 'tests/test_billing_baseline_e2e.py:748', 'source_task_catalog': 'scripts/evaluate_r3.py:TASKS',
     'classification': 'Validated fixed-schema numerical benchmark summary; retained unchanged, not a raw request/result payload.',
     'top_level_fields': sorted(billing), 'row_fields': ['task_id', 'condition', 'attempts', 'elapsed_ms', 'known_cost_micro_usd'],
     'contract_version': 3, 'passed_cells': 10, 'expected_cells': 10, 'observed_cells': 10,
     'five_source_defined_tasks_by_two_source_conditions': True,
     'provider_quality_acceptance_established': False, 'no_paths_request_ids_responses_or_extra_keys': True,
     'same_one_CTest_registration_not_ten_additional_suites': True,
     'root_cause_or_provider_quality_inference': False,
     'unittest_summaries': re.findall(r'^Ran \d+ tests? in [0-9.]+s$', last_blocks['billing_baseline_e2e'], re.M),
     'unittest_result_OK': bool(re.search(r'^OK$', last_blocks['billing_baseline_e2e'], re.M))})
stage('exact_host_observation_projection_and_source_defined_billing_summary')

# Bound every credential-word line to a source test title, without printing values.
python_functions = {}
cpp_sources = {}
for relative, raw in source_bytes.items():
    if relative.startswith('tests/') and relative.endswith('.py'):
        for node in ast.walk(ast.parse(raw)):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                python_functions.setdefault(node.name, []).append({'source': relative, 'line': node.lineno})
    elif relative.startswith('tests/') and relative.endswith('.cpp'):
        cpp_sources[relative] = raw.decode()
patterns = {'private_key': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
            'github_token': rb'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b',
            'aws_key': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
            'bearer_material': rb'(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{12,}'}
word_pattern = re.compile(rb'(?i)(?:authorization|api[_ -]?key|token|bearer|credential|password|secret)')
full_marker = re.compile(rb'^(test_[A-Za-z0-9_]+) \([A-Za-z0-9_. ]+\) \.\.\. (?:ok|FAIL|ERROR)$')
last_lines = projection.splitlines()
scans = []
for label, raw in [('stdout.log', raws['stdout.log']), ('stderr.log', raws['stderr.log']),
                   ('LastTest.log.projection.txt', projection), ('ctest.xml', raws['ctest.xml'])]:
    candidates = []
    for rule, pattern in patterns.items():
        for match in re.finditer(pattern, raw):
            candidates.append({'rule': rule, 'byte_range': [match.start(), match.end()], **identity(match.group())})
    assert not candidates, 'credential-value pattern candidate requires additional private review'
    markers = []
    structured = []
    position = 0
    for line in raw.splitlines(keepends=True):
        if re.search(rb'[\{\[]\s*["\']', line):
            assert label == 'LastTest.log.projection.txt' and line == billing_line
            structured.append({'byte_range': [position, position + len(line)], 'identity': identity(line),
                               'classification': 'exact previously schema-validated numerical billing summary'})
        if word_pattern.search(line):
            normalized = line.strip().removeprefix(b'<system-out>').removesuffix(b'</system-out>')
            match = full_marker.match(normalized)
            marker = {'byte_range': [position, position + len(line)], 'identity': identity(line)}
            if match:
                name = match.group(1).decode()
                assert name in python_functions
                marker.update({'classification': 'source-backed unittest method/result marker',
                               'source_declarations': python_functions[name]})
            else:
                cpp = re.match(rb'^(?:START|PASS|FAIL|\[PASS\]) (.+)$', normalized)
                if cpp:
                    literal = '"' + cpp.group(1).decode() + '"'
                    matches = [relative for relative, content in cpp_sources.items() if literal in content]
                    assert matches
                    marker.update({'classification': 'source-backed C++ test title', 'source_files': matches})
                else:
                    assert label == 'ctest.xml' and normalized.endswith(b'...')
                    prefix = normalized[:-3]
                    matches = [full for full in last_lines if full.startswith(prefix) and full_marker.match(full)]
                    assert len(matches) == 1
                    name = full_marker.match(matches[0]).group(1).decode()
                    assert name in python_functions
                    marker.update({'classification': 'truncated unittest title prefix plus literal ellipsis',
                                   'full_LastTest_marker_identity': identity(matches[0]),
                                   'source_declarations': python_functions[name]})
            markers.append(marker)
        position += len(line)
    scans.append({'file': label, 'identity': identity(raw), 'credential_value_candidates': candidates,
                  'credential_word_marker_count': len(markers), 'marker_classifications': markers,
                  'structured_literal_classifications': structured})
assert sum(len(scan['structured_literal_classifications']) for scan in scans) == 1
save('bounded-privacy-scan.json', {
     'scope': 'Final console/stderr/JUnit originals and one exact LastTest projection. Values parsed privately; only bounded schema/test-title metadata emitted.',
     'patterns': {key: value.decode() for key, value in patterns.items()}, 'files': scans,
     'unresolved_candidates': 0, 'raw_request_result_dict_or_argv_values_printed': False,
     'limits': 'Finite pattern and schema review, not a proof that every possible private value is absent. JUnit truncation does not establish internal-output completeness.'})
stage('bounded_privacy_classification_without_raw_payload_output')

original_candidates = []
for phase in ['event-clang-configure-01', 'event-clang-build-01', 'event-full-clang-01']:
    for leaf in ['command.json', 'completion.json', 'source-before.json', 'source-after.json']:
        path = EVIDENCE / phase / leaf
        original_candidates.append({'path': str(path), **inputs[str(path.relative_to(TASK))],
                                    'classification': 'candidate_original_metadata'})
for relative in ['receipt.json', 'binary-before.json', 'binary-after.json', 'test-plan.json',
                 'ctest-logs/CTestCostData.txt', 'ctest.xml']:
    path = IDENTITY / relative
    original_candidates.append({'path': str(path), **inputs[str(path.relative_to(TASK))],
                                'classification': 'candidate_original_metadata_or_JUnit_after_bounded_review'})
for leaf in ['stdout.log', 'stderr.log']:
    path = RUN / leaf
    original_candidates.append({'path': str(path), **identity(raws[leaf]),
                                'classification': 'candidate_original_terminal_log_after_bounded_review'})
assert len(original_candidates) == 20
save('public-candidate-policy.json', {
     'status': 'EXPLICIT_CANDIDATES_ONLY_NOT_PUBLICATION_OR_FINAL_ZIP_APPROVAL',
     'original_candidates': original_candidates,
     'terminal_projection_candidate': {'path': str(OUT / 'safe-projections/LastTest.log.projection.txt'),
                                       **identity(projection)},
     'private_originals': [str(IDENTITY / 'ctest-logs/LastTest.log')],
     'all_private_snapshot_copies_remain_private_even_when_original_is_separately_eligible': True,
     'raw_host_observation_files_private': [str(EVIDENCE / phase / 'observations.jsonl') for phase in
                                         ['event-clang-configure-01', 'event-clang-build-01', 'event-full-clang-01']],
     'configure_build_console_logs_not_selected': True,
     'audit_reports_are_candidates_after_final_exact_hash_review': True,
     'no_directory_glob_or_recursive_copy_authorized': True})
save('input-identities.json', inputs)
save('completion-receipt.json', {'reviewer': '/root/delivery_report', 'started_at': started,
     'finished_at': datetime.now(timezone.utc).isoformat(), 'uid': os.getuid(), 'gid': os.getgid(),
     'CLANG_PHASE_TERMINAL_AUDIT_COMPLETE': True, 'CLANG_PHASE_TESTS_PASS': True,
     'LOCAL_VALIDATION_COMPLETE': False, 'FULL_MATRIX_TERMINAL_ATTESTED_BY_THIS_PHASE_AUDIT': False,
     'whole_driver_receipt': 'Root separately owns actual outer tool exit observation; not synthesized here.',
     'product_executions_or_builds': 0, 'source_changes': 0, 'active_partial_diagnostic_logs_read': 0,
     'private_CLI99_logs_read': 0, 'source_paths_verified': 794, 'binary_control_files_verified': 61,
     'registered_and_classified_CTest': 92, 'counts': {'Passed': 92, 'Timeout': 0, 'Failed': 0},
     'CTest_exit': 0, 'sanitizer_failure_root_causes_still_open': True,
     'final_zip_created': False, 'projection_scan_unresolved_candidates': 0,
     'preaudit_schema_probe_exit1_preserved_separately': True})
print(json.dumps({'audit_complete': True, 'Clang_passed': 92, 'source_paths': 794,
                  'binary_controls': 61, 'LastTest_projections': 1, 'public_original_candidates': 20,
                  'whole_driver_attested_by_this_audit': False, 'product_runs': 0}), flush=True)
