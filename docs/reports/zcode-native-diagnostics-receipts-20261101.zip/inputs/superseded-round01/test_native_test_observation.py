#!/usr/bin/env python3
"""Explicit runner selfcheck for the native test observation contract.

This file is an opt-in diagnostic runner, not one of the 92 registered CTest
cases, and it is deliberately absent from CMake/Make/CI. Run it directly:

    python3 tests/test_native_test_observation.py

It compiles one throwaway helper translation unit that includes only
tests/test_support.hpp (no product sources, Store, network or credentials)
and then verifies, on Linux, through a pipe line handshake plus SIGKILL and
without any timed sleep:

  * every method emits an immediately flushed START/PASS/FAIL line, so a
    completed and a failed method stay observable after a later method
    blocks and the process is killed;
  * a released blocker keeps the original failure totals ("3 passed,
    1 failed"), the failure exit code 1, and test::run's umask
    isolation/restore behavior;
  * failure text containing quotes, spaces and a backslash survives verbatim
    instead of being escaped or truncated.

select() guards only turn a hung helper into a selfcheck failure; they never
synchronize with the child and never extend any product test deadline.
"""

import os
import select
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HELPER_NAME = "native_observation_helper"
COMPILE_GUARD_SECONDS = 120.0
LINE_GUARD_SECONDS = 30.0
BLOCKER_START = "START blocks until released"
FAIL_PREFIX = "FAIL failed original method: "
ESCAPED_FRAGMENT = 'synthetic "quoted" expression\\path'

HELPER_SOURCE = r'''
#include "test_support.hpp"

#include <iostream>
#include <string>

namespace {
int umask_inside_methods = -1;

void completing_method() {}

void failing_method() {
    // Escaping probe: quotes, spaces and a backslash must survive verbatim.
    ::test::check(false, "synthetic \"quoted\" expression\\path", __FILE__, __LINE__);
}

void umask_probe_method() {
    const mode_t inside = ::umask(0);
    (void)::umask(inside);
    umask_inside_methods = static_cast<int>(inside);
}

void blocking_method() {
    // Deterministic handshake with the parent: block until it releases the
    // pipe or kills the process. No polling loop and no sleep is involved.
    std::string release;
    std::getline(std::cin, release);
}
} // namespace

int main() {
    const mode_t before = ::umask(0);
    (void)::umask(before);
    const int code = test::run({
        {"completed original method", completing_method},
        {"failed original method", failing_method},
        {"umask probe method", umask_probe_method},
        {"blocks until released", blocking_method},
    });
    const mode_t after = ::umask(0);
    (void)::umask(after);
    if (umask_inside_methods != 0077 || after != before) {
        std::cerr << "UMASK-BROKEN inside=" << umask_inside_methods
                  << " before=" << before << " after=" << after << std::endl;
        return 100 + code;
    }
    std::cout << "UMASK-RESTORED " << before << std::endl;
    return code;
}
'''


class SelfcheckError(Exception):
    """The observation contract is broken or the helper misbehaved."""


class LineReader:
    """Reads whole lines from a child pipe, bounded by a failure-only guard.

    select() decides when bytes exist; guard expiry only reports a hung
    child. The guard never synchronizes with the helper.
    """

    def __init__(self, pipe):
        self._pipe = pipe
        self._buffer = bytearray()

    def line(self):
        deadline = time.monotonic() + LINE_GUARD_SECONDS
        while b"\n" not in self._buffer:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([self._pipe], [], [], remaining)[0]:
                raise SelfcheckError("no flushed helper line arrived within the guard window")
            chunk = os.read(self._pipe.fileno(), 4096)
            if not chunk:
                raise SelfcheckError("helper exited before producing the expected line")
            self._buffer.extend(chunk)
        line, _, rest = self._buffer.partition(b"\n")
        self._buffer = bytearray(rest)
        return line.decode("utf-8", "replace")


def require(condition, message):
    if not condition:
        raise SelfcheckError(message)


def spawn_helper(helper):
    # argv lists everywhere; the selfcheck never builds a shell string.
    return subprocess.Popen([str(helper)], stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            bufsize=0, cwd=str(helper.parent))


def collect_until_blocker(child):
    """Handshake: return the reader plus every flushed line through the
    blocker's START line, proving the earlier methods were already observed."""
    reader = LineReader(child.stdout)
    lines = []
    while not lines or lines[-1] != BLOCKER_START:
        line = reader.line()
        if line.startswith("RESULT"):
            raise SelfcheckError(
                "helper finished before the blocking method started: %r" % (lines + [line],))
        lines.append(line)
    return reader, lines


def close_child(child):
    if child.poll() is None:
        child.kill()
    child.wait()
    for stream in (child.stdin, child.stdout):
        if stream is not None:
            try:
                stream.close()
            except OSError:
                pass


def observe_killed_blocker(helper):
    child = spawn_helper(helper)
    try:
        _, lines = collect_until_blocker(child)
        require(child.poll() is None,
                "the blocking method exited before the kill; handshake invalid: %r" % (lines,))
        child.kill()  # SIGKILL: the process cannot flush anything while dying.
        exit_status = child.wait()
    finally:
        close_child(child)
    require(exit_status < 0,
            "expected death by signal, got exit status %r" % exit_status)
    expected_markers = [
        "START completed original method",
        "PASS completed original method",
        "START failed original method",
        "START umask probe method",
        "PASS umask probe method",
        BLOCKER_START,
    ]
    markers = [line for line in lines if not line.startswith(FAIL_PREFIX)]
    require(markers == expected_markers,
            "killed run lost or reordered method observations: %r" % (lines,))
    failures = [line for line in lines if line.startswith(FAIL_PREFIX)]
    require(len(failures) == 1, "expected exactly one FAIL observation, got %r" % (lines,))
    require(ESCAPED_FRAGMENT in failures[0],
            "failure text was mangled; expected %r inside %r" % (ESCAPED_FRAGMENT, failures[0]))
    require(not any(line.startswith("RESULT") for line in lines),
            "a killed run must not reach RESULT: %r" % (lines,))
    return lines


def observe_released_blocker(helper):
    child = spawn_helper(helper)
    try:
        reader, lines = collect_until_blocker(child)
        written = os.write(child.stdin.fileno(), b"release\n")
        require(written == len(b"release\n"),
                "short release write %r; handshake incomplete" % written)
        lines.append(reader.line())  # PASS blocks until released
        lines.append(reader.line())  # RESULT 3 passed, 1 failed
        lines.append(reader.line())  # UMASK-RESTORED <umask>
        exit_status = child.wait()
    finally:
        close_child(child)
    require(exit_status == 1,
            "failure exit code not preserved: expected 1, got %r" % exit_status)
    require(lines[-3] == "PASS blocks until released",
            "released blocker did not complete: %r" % (lines[-3:],))
    require(lines[-2] == "RESULT 3 passed, 1 failed",
            "failure totals changed: %r" % (lines[-3:],))
    require(lines[-1].startswith("UMASK-RESTORED "),
            "umask isolation/restore marker missing: %r" % (lines[-1:],))
    require(any(line.startswith(FAIL_PREFIX) and ESCAPED_FRAGMENT in line for line in lines),
            "released run lost the escaped FAIL observation: %r" % (lines,))
    return lines


def main():
    tests_dir = Path(__file__).resolve().parent
    require((tests_dir / "test_support.hpp").is_file(),
            "tests/test_support.hpp not found next to this selfcheck")
    compiler = os.environ.get("CXX", "g++")
    with tempfile.TemporaryDirectory(prefix="wls861-observation-selfcheck-") as work:
        work_dir = Path(work)
        source_path = work_dir / (HELPER_NAME + ".cpp")
        helper_path = work_dir / HELPER_NAME
        source_path.write_text(HELPER_SOURCE, encoding="utf-8")
        compiled = subprocess.run(
            [compiler, "-std=c++20", "-I", str(tests_dir), str(source_path),
             "-o", str(helper_path)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            timeout=COMPILE_GUARD_SECONDS)
        if compiled.returncode != 0:
            sys.stdout.write(compiled.stdout.decode("utf-8", "replace"))
            raise SelfcheckError("helper compilation failed under %s" % compiler)
        scenarios = (
            ("killed blocker run", observe_killed_blocker),
            ("released blocker run", observe_released_blocker),
        )
        for name, scenario in scenarios:
            try:
                scenario(helper_path)
            except SelfcheckError as error:
                raise SelfcheckError("[%s] %s" % (name, error))
    print("native test observation selfcheck PASS: killed and released blocker runs kept "
          "START/PASS/FAIL lines, escaping, totals '3 passed, 1 failed', exit 1 and umask behavior")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (SelfcheckError, subprocess.TimeoutExpired) as failure:
        print("native test observation selfcheck FAIL: %s" % failure, file=sys.stderr)
        sys.exit(1)
