add_test(fairness-profile "/mnt/d/codex-workspace/wls861-zcode-followup-20261101-wvm7aclp/evidence/fairness-cpu-profile-01/fairness-profile")
set_tests_properties(fairness-profile PROPERTIES TIMEOUT 180 WORKING_DIRECTORY "/mnt/d/codex-workspace/wls861-zcode-followup-20261101-wvm7aclp/evidence/fairness-cpu-profile-01")
