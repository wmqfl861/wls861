#define main original_async_suite_main
#include "/mnt/d/codex-workspace/wls861-zcode-followup-20261101-wvm7aclp/evidence/diagnostic-preparation-01/tests/async_coordinator_tests.cpp"
#undef main
int main() {
    schemas = std::make_shared<SchemaRegistry>(source / "schemas");
    base_sql = read_runtime_file(source / "db/schema.sql");
    store_sql = read_runtime_file(source / "db/migrations/004_s1_store.sql");
    tools_sql = read_runtime_file(source / "db/migrations/005_worker_tools.sql");
    events_sql = read_runtime_file(source / "db/migrations/006_event_runtime.sql");
    workflow_sql = read_runtime_file(source / "db/migrations/007_workflow_runtime.sql");
    acceptance_sql = read_runtime_file(source / "db/migrations/008_acceptance_runtime.sql");
    return test::run({{"queued S1 requests and teams rotate under sustained load", queued_s1_requests_and_teams_rotate_without_starvation}});
}
