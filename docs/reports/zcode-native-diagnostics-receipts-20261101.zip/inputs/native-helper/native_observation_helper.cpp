
#include "test_support.hpp"

#include <sys/stat.h>
#include <unistd.h>

#include <cstring>
#include <iostream>
#include <string>

namespace {
int umask_inside_methods = -1;

void completing_method() {}

void failing_method() {
    // Escaping probe: quotes, spaces and a backslash must survive verbatim.
    ::test::check(false, "synthetic \"quoted\" expression\\path", __FILE__, __LINE__);
}

void umask_probe_method() {
    const mode_t inside = ::umask(0);
    (void)::umask(inside);
    umask_inside_methods = static_cast<int>(inside);
}

void reached_marker() {
    // Fixture-only handshake written straight to the pipe: it must not go
    // through the cout buffering this selfcheck verifies.
    const char* const marker = "REACHED-BLOCKER\n";
    const std::size_t total = std::strlen(marker);
    std::size_t remaining = total;
    while (remaining > 0) {
        const ssize_t written = ::write(STDERR_FILENO, marker + (total - remaining), remaining);
        if (written <= 0) return; // release or kill still drives every scenario
        remaining -= static_cast<std::size_t>(written);
    }
}

void blocking_method() {
    reached_marker();
    // Raw wait for release: no iostream tie, so nothing flushes cout for us,
    // and the process stays inside this read until the parent acts.
    char release = 0;
    const ssize_t received = ::read(STDIN_FILENO, &release, 1);
    (void)received;
}
} // namespace

int main(int argc, char** argv) {
    const bool all_pass = argc > 1 && std::string(argv[1]) == "all-pass";
    const mode_t before = ::umask(0);
    (void)::umask(before);
    int code = 0;
    if (all_pass) {
        code = test::run({
            {"completed original method", completing_method},
            {"umask probe method", umask_probe_method},
            {"blocks until released", blocking_method},
        });
    } else {
        code = test::run({
            {"completed original method", completing_method},
            {"failed original method", failing_method},
            {"umask probe method", umask_probe_method},
            {"blocks until released", blocking_method},
        });
    }
    const mode_t after = ::umask(0);
    (void)::umask(after);
    if (umask_inside_methods != 0077 || after != before) {
        std::cerr << "UMASK-BROKEN inside=" << umask_inside_methods
                  << " before=" << before << " after=" << after << std::endl;
        return 100 + code;
    }
    std::cout << "UMASK-RESTORED " << before << std::endl;
    return code;
}
