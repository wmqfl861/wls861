最终六文件独立只读复审结论：**NO_BLOCKING_FINDINGS_IN_LIMITED_TEST_TOOL_SCOPE**。前轮提出的单clock、独立握手、精确SIGKILL、完整顺序、固定umask、有界等待、参数解包及失败子进程回执问题均已修正；本轮不要求继续增加非必要测试控制。认可这六文件作为测试观测、工具兼容和CI自检的限定改动，root可继续既定native自检红绿及后续正常提交准备。native执行尚待root完成，不能提前标记测试通过；正式PR采纳、产品完整矩阵和历史失败不在本次认可范围。

审核者：`/root/evidence_audit`，同模型非作者工程复核。基线 `7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a`。精确六文件及已有fairness执行身份冻结在 `reviewed-inputs-and-fairness-evidence.json`，SHA-256 `3b77a250c41e1d4824e7403831ae600c84e09f4fe5217b3b06509dbbcb95ed48`。输入副本位于 `reviewed-inputs/`，tracked diff另存 `reviewed-tracked.patch`。完成本报告前再次核六个当前文件与冻结哈希相同。本审核未修改源码，也未编译、运行测试或模型。

| 文件 | 最终SHA-256 |
| --- | --- |
| .github/workflows/ci.yml | `b86d320bf38e7a314685d980db23e968c020e74b57f3955b53ae6960e4992f27` |
| scripts/run_a4_fairness_red_green.py | `5347e26f53724a39dda0cdb269da1523f254891e8f610a05d95b538862b64727` |
| tests/async_coordinator_tests.cpp | `c6d97d89ee087a4f74a896aac2c86c4687bd8aa34550e369f9dc4cd324ae4c48` |
| tests/test_a4_fairness_gate.py | `d7daa243d10ee199b589f090befc2f8ca540062150e20060ccb45c244af8c3ad` |
| tests/test_support.hpp | `5b44c995a3c1a8e93774aa5d4f3a672a23d49571e34e6f45fd8ea197aad20922` |
| tests/test_native_test_observation.py | `5fd83d75567861d61d8ab4438d833ab03125e9f01a988d1aaba2d70dfc5ca694` |

最终静态结论：

- support在每个方法开始及原PASS/FAIL/RESULT时显式刷新；vector调用顺序、std::exception捕获、失败计数、最终0/1返回值、0077隔离及恢复不变。Async until只取一个checked_at同时判定日志和CHECK，原5秒、predicate/poll/失败/yield次序保持。
- native selfcheck使用原始write/read独立marker，不经cin tie刷新；新旧support均可达到marker，旧版失败应是明确观测缺失，不能再使用round01等待新增START导致的guard红作为有效反例。完整prefix保留FAIL位置和固定转义文本，kill精确要求-9；释放失败/全成功分别核原总数及1/0返回；初始umask0022，helper核内部0077和恢复。
- cleanup在成功和异常路径均emit scenario-child，包含pid、实际returncode、reaped、cleanup和已传入的observed。wait超时记录reaped=false，正常路径转失败；已有验证异常保持原因为主。旧support的握手后缺行失败路径现可保留实际清理退出码，不再只有成功场景回执。严格C++20警告参数、数据盘TMPDIR及合成helper范围保持。
- fairness classify严格二选一接受旧输出或一条同名START前缀；原exit、空stderr/原目标业务错误的path-line-expression匹配保持。错误标签、重复、乱序、缺RESULT、附加文本及错误stderr不会被吞掉。新增拒绝测试现统一为(code,out,err)，不再把字符串传入退出码。
- workflow仅增加strict/ASan两路线的一处独立native自检步骤。产品src/include/db、CMakeLists、Makefile、92项名称/期限目录及Windows模块无差异，diff-check退出0。独立Windows support与PASS/RESULT解析保持原作用域，不需要新增兼容改动。ASan CI lane中的合成helper自检不能计为产品ASan套件或新的CTest注册。

已执行fairness工具证据（root运行，本审核只读核对）：

| 轮次 | 命令/结果 | 身份及原日志核对 |
| --- | --- | --- |
| fairness-classifier-old-red-01 | Python -B运行相同新版9方法，配基线旧classify；8PASS/1FAIL，exit1，0.805665秒，outer_timeout=false | 唯一失败是新START格式的NOT_GREEN != EXPECTED_GREEN，非TypeError、编译或guard错误。 |
| fairness-classifier-zcode-green-01 | Python -B运行候选9方法；9PASS，exit0，0.788449秒，outer_timeout=false | 原格式/新增格式及拒绝项全部通过。 |

两轮UID1000，外层umask0022；各792项被跟踪输入before=after。当前分类器/测试与各轮源码清单匹配。旧输入目录的classifier逐字等于7dc80ed原Git内容；其新版测试与当前测试逐字相同，冻结业务probe字节相同。原始command/completion/stdout/stderr与各摘要在本次机器核验记录中列明。该9方法是一套工具自检，不是9套产品测试；native工具尚未执行，不能用fairness绿色替代。

审核记录时点更正：round03首次直接读取/工具输出确实显示反序(out,code,err)，当时B1指出的是该读入版本；并行修正后，round03稍后冻结的测试副本已为当前d7daa243版本。因此round03报告将B1行号归于其“冻结候选”不准确。本报告明确纠正该归属；旧报告、直接工具输出和冻结副本保持不改。最终认可依据本次六文件身份及已核实的9/9结果，不沿用过时B1结论。

剩余动作保持原计划：root串行执行同一冻结native selfcheck配原support与新support；原版须编译成功并已到独立marker后目标缺观测失败，新版三场景必须真实-9/1/0及完整行/计数/umask/转义通过，原输出/身份/退出和reap收据保留。完成这些已计划的工具验证后，本审核对六文件限定test-only提交无代码阻断；如出现新失败，记录真实结果再评估。Async日志调用点的实际触发、适用产品矩阵及新提交CI由其独立执行证据判断。

历史三个正式Timeout、ASan资源探针断言FAIL、历史GCC/Clang/live_workflow根因继续OPEN。此补丁不改变生产行为，不解释原失败，也不授予LOCAL_VALIDATION_COMPLETE、产品验收、第二模型评审或合并批准。前期ZCode退出0仅是生成任务结束，实际工程结果仍按上述精确文件和真实执行证据区分。
