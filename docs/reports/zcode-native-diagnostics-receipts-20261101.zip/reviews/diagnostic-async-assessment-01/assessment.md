# ASan Async 观测诊断：结果与输入评估

结论：本轮诊断确实失败，CTest exit 8、Timeout，不能计入本地验证通过。新增日志将其中一个 5 秒失败定位到了 fairness 方法的第一项出队观察；套件在第 22 个方法已经 START、尚无结果时达到原 180 秒整套期限。仍无证据证明第 22 个方法发生死锁，或证明本轮与历史 resource 失败属于同一根因。

本报告只读既有证据并计算身份，没有编译、运行测试/产品、重跑、修改源码或旧证据。所有新产物仅在 `evidence/diagnostic-async-assessment-01/`。`LOCAL_VALIDATION_COMPLETE=false`，所有历史失败保持开放。

## 实际执行记录

任务根目录：`/mnt/d/codex-workspace/wls861-zcode-followup-20261101-wvm7aclp`。

| 事实 | 记录 |
| --- | --- |
| 基线 HEAD | `7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a` |
| 编译 | `diag-asan-async-compile-01`，30.360118989 秒，exit 0，source_unchanged=true |
| 诊断执行 | `diag-asan-async-run-01` |
| 开始/结束 | `2026-11-01T03:05:11.278711+00:00` / `03:08:12.313939+00:00` |
| CTest 子项时长 | JUnit 180.175 秒；控制台四舍五入显示 180.18 秒 |
| recorder 总时长 | 181.034784194 秒 |
| 实际退出 | CTest exit 8；outer_timeout=false |
| 原期限 | CTest 180 秒，外层 recorder 210 秒；helper 原 5 秒 |
| 身份/环境 | UID/GID 1000，umask 0002，独立数据盘 TMPDIR |
| sanitizer | `ASAN_OPTIONS=halt_on_error=1:detect_leaks=1`，UBSan halt_on_error/print_stacktrace |
| 分类 | `DIAGNOSTIC_NOT_FULL_GATE` |

命令是对 `^asan-async$` 的一次 CTest verbose 执行，仍只有一个 CTest 子项；29 个方法不是 29 个独立 CTest 套件。实际 argv、环境和退出值保存在该轮 command/completion 原记录；本报告没有改写它们。

本轮 current `/proc` 只读检查时，记录的 PGID `2309027` 没有成员；这是进程组现状证据，不能替代业务结算/清理证据。

## 方法计数与失败位置

原 stdout 和 JUnit 的方法输出逐字节对应。准确计数为 **22 START、20 PASS、1 FAIL、0 RESULT、7 个方法未开始**。共有 21 个方法产生结果，不能写成 21 PASS。

| 原登记序号 | 结果 | 说明 |
| --- | --- | --- |
| 1–17 | 17 PASS | 从并发入场到 management/Worker review reserve |
| 18 | FAIL | `queued_s1_requests_and_teams_rotate_without_starvation` 的原 5 秒等待失败 |
| 19–21 | 3 PASS | 同资源跨池 FIFO、host limits、callback 同池 child 拒绝 |
| 22 | START 后无结果 | `logical_question_wait_releases_slot_without_releasing_unknown_budget` |
| 23–29 | 未开始 | 四调用 resource 方法，以及其后六个资源生命周期方法 |

全部登记名、函数和结果保存在 `method-assessment.json`。

第 18 方法有两个明确的诊断行：

```text
UNTIL-DEADLINE .../diagnostic-preparation-01/tests/async_coordinator_tests.cpp:895 in void {anonymous}::queued_s1_requests_and_teams_rotate_without_starvation() exceeded its original 5s wait
FAIL queued S1 requests and teams rotate under sustained load: .../async_coordinator_tests.cpp:172: checked_at < deadline
```

第 895 行是释放第一个 blocker 后，等待 `sequence->read().size() >= 1` 的首项 selection 观察；它不是该方法唯一或最早的 until。第 861 行“8 个 blocker 均入场”的 until 已经返回，随后真实 Store 准备 busy/sibling 请求与五个 queued Worker 也已完成，才会到 895。895 失败之后，序列 `a1-first`、`b1`、`a2` 的顺序断言及该方法后续预算/证据断言尚未执行，不能宣称公平顺序已被证明错误。

原 helper 在 poll 返回后、再次检查 predicate 前判断 deadline。因此定位行证明该轮 post-poll 时刻越过 5 秒，不证明 `sequence` 仍为空，也不证明单次 poll 的耗时、调度死锁或模型未开始。没有逐阶段时长、CPU 样本或调用栈，不能把主机负载、ASan 成本或 umask 作为已证实原因。

第 18 方法能产生 FAIL，且后续三方法 PASS，表明本轮它的异常展开已返回到 runner，并非停在该方法的析构中。

第 22 方法只有 START。它内部先建立夹具/真实请求/任务，再 submit 和 drain，后面才有另一个 until；当前输出不足以区分处于 setup、poll/drain、业务断言或析构。更重要的是 180 秒是整套截止时间：没有方法 START 时间戳，不能算出第 22 方法已经运行多久，不能将整套 180 秒描述为这个方法独占的超时。未进入的第 23 resource 案例不能从这一轮获得通过或失败结论。

## source_unchanged=false 的真实范围

recorder 的 `source_identity()` 使用 `git ls-files`，本轮 before/after 各 792 个 tracked 文件。两者恰有以下两个差异，其余 790 项的字节数、SHA-256 和 mode 一致：

| tracked 文件 | before SHA-256 | after SHA-256 |
| --- | --- | --- |
| `scripts/run_a4_fairness_red_green.py` | `fec6a7d8a43af7181d85accc432df5a93f23bdb89067fa72f1311477eece8c7b` | `5347e26f53724a39dda0cdb269da1523f254891e8f610a05d95b538862b64727` |
| `tests/test_a4_fairness_gate.py` | `4dd3d22ea4f410a6020ef76cc2501145f5f36da6d97953fb4e9200fd455dd2f3` | `62d3909bdbbd2ff48c99073167d1390475744e19295e741189774d1082240d6a` |

ZCode round03 于 03:03:59–03:08:03 执行，其报告说明在做 fairness runner 对 START 格式的兼容和相关 Python 测试修改，时间与本轮重叠。这与两个 tracked 文件变化相符。它还声明修改未跟踪的 `tests/test_native_test_observation.py`；该文件不在 792 项清单内。因此必须说“两个 tracked 文件差异”，不能写“整个工作区只有两个文件变化”。

这些 Python 源不参与该 native C++ 编译命令，也没有被被冻结测试及 src/include 引用为运行入口。本轮执行的是既有 ASan 二进制；它的源测试副本、原库以及二进制身份另行匹配。由此可保留这个限定诊断的定位价值，但不能把 `source_unchanged=false` 改成 true，也不能当作全候选运行输入全程冻结的正式 gate。

本报告对 current tracked 状态的检查又发现一个后续差异：`tests/test_a4_fairness_gate.py` 在 run-after 后已变为 SHA `d7daa243d10ee199b589f090befc2f8ca540062150e20060ccb45c244af8c3ad`，仍为 8303 字节。当前其余 791 tracked 项与 run-after 一致。这个后续观察独立记录，不回填运行时快照。

并行编辑的存在不证明 CPU 竞争导致失败；环境 observations 是主机样本，没有给出每方法或目标线程归因，不能用它免除该失败。

## 冻结 native 输入、库与二进制

本轮重新计算 14 项 SHA-256，全部匹配各自 before/已审记录：6 个冻结 test/wrapper 文件、4 个计划中的 ASan/Release archive、实际执行 Async 二进制，以及 3 个已审计划/清单文件。详细路径、字节数和对比值在 `input-identity-assessment.json`。

其中实际执行 Async 二进制：

```text
path: evidence/diagnostic-preparation-01/asan-async-observed
bytes: 36371960
SHA-256: e862b6d4ed808a10ec8ac42003f52ee01130c2a9f1b72cdb7ffe56eb2865dd39
```

这说明当前留存二进制仍与执行前记录匹配，所审冻结测试和库也没有变化。此结论是对现有 before/current 快照的比较，不伪造新的运行时采样。系统库、编译器等未在这些 14 项 before 中另行列出，不能把范围扩大为所有 OS 依赖逐项重新认证。

本报告引用独立轮次的 stdout、completion、manifest 和 `asan-async-01.xml`。共享 `diagnostic-preparation-01/Testing/Temporary/LastTest.log` 已由后续 03:11 resource 轮次更新，不能作为 Async 的原 LastTest 引用。建议以后每轮结束立即在该轮目录归档 CTest 临时日志；目前 Async 的独立 stdout/JUnit 仍保留完整方法输出。

## 下一步的最小 profiling 方案

下一步建议见 `profiling-proposal.md`：在父 Agent 完成既定的一次资源诊断后，可用一个单方法测试 wrapper、只为测试翻译单元增加 `-pg`，继续链接原 ASan archive，获取 gprof 的 flat PC/self CPU 样本。它不能提供未插桩库的完整 call graph，也不能解释 off-CPU 等待；若进程被 kill 而无 gmon，则报告没有 profile，不改变原逻辑来制造输出。

该方案本轮没有执行，不能替代本次或历史门禁。原 5 秒、180 秒、LSan 配置、真实退出状态和原业务案例必须保留。
