ZCode round01三文件候选的独立只读审核结论：**CHANGES_REQUIRED_FOR_OBSERVATION_EVIDENCE**。没有发现生产源码或权限守卫被修改，但当前观测实现和selfcheck有下列必须修正项，尚不能据此声明可靠的旧版红例/新版绿例。本审核未编译、运行selfcheck或产品测试；以下反例推断是静态结论，不冒称实际红例。

审核者 `/root/evidence_audit`，非本补丁作者；这是同模型工程复核，不是主协调者批准。精确输入为 `reviewed-inputs.json` 和 `reviewed-tracked.patch`，基线 `7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a`。三个文件已复制到本审核目录 `reviewed-inputs/` 冻结，未修改作者工作树。补丁SHA-256：`24b4be7069cc2a8e6ee65c78f9a68a8f2d69f43c19955a5fa327ee81c9acf446`。行号以下均指该冻结候选。

| 必须修改项 | 位置与可证问题 | 最小修正 |
| --- | --- | --- |
| R1：期限失败可能缺少调用点日志 | async_coordinator_tests.cpp:160、168分别读取steady_clock。第一次 `< deadline`、第二次 `>= deadline` 时，CHECK失败而UNTIL-DEADLINE完全不打印，恰好违反本次定位目的。 | poll后只捕获一次checked_at，日志条件和CHECK使用同一值，仍核原5秒期限；不增加重试、sleep或放宽边界。source_location在调用处默认捕获本身正确。 |
| R2：握手依赖被测输出，旧版红只能是guard失败；cin会掩盖缺flush | selfcheck:64–68、136–147。父端等待新增START；旧support永远没有此行，所以预测旧版要等30秒guard再失败。阻塞函数使用getline(cin)，cin默认tie到cout，会额外刷新被测cout，可能使删除PASS显式flush的变体也通过。旧版cerr也会通过默认tie刷新前面的cout。 | 阻塞方法用原始write输出独立fixture到达标记，然后用原始read等待父端；不要经cin/cerr的iostream tie做握手。父端以独立标记同步，再断言原START/PASS/FAIL序列。新旧支持头都应能到达相同握手，旧红是明确缺观测断言而非耗尽guard。保留目标原support文件字节、编译成功证据和原日志。 |
| R3：SIGKILL检查过宽 | selfcheck:172仅要求exit_status<0，任何其他信号均满足，不能证明要求的SIGKILL路径。 | 引入signal，明确要求exit_status == -signal.SIGKILL。继续保留kill前活进程检查和kill后wait/reap。 |
| R4：FAIL位置和释放分支完整顺序未验证 | selfcheck:182先过滤FAIL再比顺序，因此FAIL移到其他位置仍能通过；201–216只核末尾3行及any匹配FAIL，未核释放分支前缀的完整顺序/单次失败。 | kill/release复用一个完整前缀校验；动态file:line可正规化，但FAIL必须在原固定位置且恰好一次。释放后精确检查原总数、退出1、最后PASS和umask恢复；不把两次helper进程写成两套产品测试。 |
| R5：umask恢复检查可能无区分度 | selfcheck:73–84只继承父umask。如果父为0077，即使漏掉test::run恢复也仍满足after==before。 | spawn_helper显式使用一个非0077起始umask，例如Popen(umask=0o022)，或明确跑0022/0002；内部仍必须0077，结束必须恢复该已知值。原header的隔离/恢复语句本轮未修改。 |

上述R2不意味着原FAIL字节已被证明丢失：旧support本来写cerr且默认unitbuf/tie有效。应该准确报告旧工具缺少当前方法START、以及未显式刷新后续PASS可在kill时丢失；不能为新工具捏造旧FAIL必丢失的产品缺陷。独立握手后仍应确认死亡为-9，且没有RESULT，保存kill前已取得的完整行。release应证明函数真实完成，而不是仅看到一个由test::run在调用前打印的START。

建议一并收紧退出收尾：selfcheck:153、169、204的child.wait没有timeout；即使行读取有guard，helper在输出最后标记后异常停住仍会让selfcheck无限等待。可复用现有LINE_GUARD_SECONDS作为wait超时，finally kill并有界reap。此guard只约束工具，不改产品期限。全成功返回0路径目前未动态检查；若交付声称0/1两条退出语义均经运行验证，再补一个小的全成功release变体，否则只报告当前计划验证退出1，返回0不变由静态diff支持。

已核对并保持的范围：

- test_support.hpp仍按原vector顺序调用每个function；catch范围仍是std::exception，failed只在原catch递增，RESULT计数表达式和failed?1:0保持；umask0077与恢复保持。新增START和std::endl是测试日志观测，没有跳过原业务函数或吞掉失败。
- async until仍是原5秒deadline，predicate/poll/CHECK/yield顺序保持；但R1必须消除日志与断言的第二次读取窗口。观测只打印源码位置和函数名，不打印request/Store内容。
- CMake/Make、92注册目录、原90/180秒等期限及生产源码均未出现在本候选diff。source_location需要的C++20已是项目原标准。
- selfcheck使用argv列表、独立TemporaryDirectory及合成固定失败文本。引号/空格/反斜杠的C++字面量与Python期望片段相符；这属于测试工具自检，不是产品sanitizer结果。Linux文件描述符select路径与本轮平台相符。
- 新START在try外；在默认未启用iostream异常掩码的普通运行中没有改变原function异常计数。此静态审核不额外证明人为修改流异常掩码或所有I/O故障的行为一致。

Linux CI最小接入建议：在现有 `.github/workflows/ci.yml` 的工具自检步骤旁加一处，仅strict lane执行 `.local/test-venv/bin/python -B tests/test_native_test_observation.py`。保持CMake/Make及92产品注册不变，不把它添加进产品CTest目录；更新selfcheck开头“deliberately absent from ... CI”的过时说明。自检内部编译的是只包含test_support.hpp的合成helper，不是原产品ASan套件。该CI修改由root实施，本审核没有写workflow。

修订后的最小执行证据要求：同一个selfcheck及helper源分别配旧基线support与新support，记录两份support SHA、完整编译命令/成功退出、执行argv、已到达独立握手的原始日志、准确缺失观测断言或PASS、SIGKILL=-9和释放exit1；不要让基线红来自编译错误、30秒guard或目录错误。冻结原始候选和失败，不覆盖本round01。native selfcheck没有包含Async运行时，因此它自身不证明UNTIL-DEADLINE调用点分支已经实测；该分支需原期限下的实际诊断或单列静态结论。修复此观测工具也不会关闭三个正式Timeout或既有ASan resource断言失败。
