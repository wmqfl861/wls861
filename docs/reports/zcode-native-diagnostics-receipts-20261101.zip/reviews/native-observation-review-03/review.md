round03独立只读复审结论：**CHANGES_REQUIRED_BEFORE_FINAL_VALIDATION_OR_COMMIT**。前轮五项主要设计问题已修正，fairness输出兼容实现本身也符合要求；但新增fairness负向自检存在明确参数解包错误，且旧support失败路径的实际子进程退出证据尚不完整。修正或补足这两项后可以由root开展有界正式自检。本审核没有编译、运行测试或验证实际绿例，不能批准当前候选直接作为已验证交付提交。

审核者：`/root/evidence_audit`。基线 `7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a`。实际差异是5个已跟踪修改，加1个未跟踪selfcheck，共6个变更文件（并非6+1）；另外只读了Windows解析器和其独立support。精确输入/哈希见 `reviewed-inputs.json`，所有8文件已冻结副本；tracked patch SHA-256为 `24782b7d01278f113c6c9d441016c8c1e62ebeeda6d3c26d616cfc699e696eef`。以下行号指冻结round03，不覆盖round01审核。

需要处理的项：

| 项 | 证据与影响 | 处理要求 |
| --- | --- | --- |
| B1 必须修正：新增测试参数顺序反了 | `tests/test_a4_fairness_gate.py:74–88` 的列表项为 `(out, code, err)`，循环却解包为 `code, out, err`。传入classify后code是字符串，`code < 0`将抛TypeError。此为静态确定的工具夹具错误，尚未执行，不称作产品红例。 | 统一列表和解包顺序；建议沿原测试惯例用 `(code, out, err)`。保持全部9个拒绝场景，勿捕获TypeError冒充分类拒绝。 |
| B2 必须补足证据：失败路径缺实际helper退出码 | `tests/test_native_test_observation.py:288–302,376–382` 在prefix验证失败时先finally清理，再向上抛错，不生成scenario记录。旧support会立即命中缺行反例，stderr包含marker/已观察行，但其被cleanup kill后的实际returncode未输出；`close_child:276–279`还吞掉wait超时。 | 在失败路径也保留实际observed、子进程returncode和cleanup/reap状态，或由root的独立真实进程收据补足。不能把成功分支中的-9检查外推为旧red的实际-9证据。若清理wait超时，明确记录未reap，不能写“全部进程已退出”。不要求另建运行器。 |

已修正并可进入执行验证的逻辑：

- `until`在poll后单次采样checked_at，日志条件及CHECK共享该值，原5秒deadline、predicate/poll/CHECK/yield顺序保持，没有第二次predicate救回过期样本。source_location默认参数指向调用处。只是诊断增加，未证明历史Timeout根因。
- helper以原始POSIX write向合并pipe发REACHED-BLOCKER，再原始read等待释放；不经cin/cerr iostream tie刷新cout。父端等待独立marker，因此原support同样能到达握手，缺START/未flush行将在序列断言处立即失败，不需依赖30秒guard。旧cerr本来可能已刷新先前PASS及FAIL，报告必须准确写“缺所需观测”，不能声称旧FAIL必丢失。
- kill路径要求活进程，调用kill后精确核 `-signal.SIGKILL`；完整prefix保留FAIL固定位置及恰好一次，错误标签、缺行、重复或乱序会失败。release失败及allpass分别要求3PASS/1FAIL exit1和3PASS/0FAIL exit0；尾部还有EOF检查，不接受extra输出。
- Popen显式umask0022，helper核内部0077和结束恢复；原support隔离/恢复及failed计数/异常捕获类型未改。等待均使用已有工具guard，有界清理的超时披露问题见B2。
- 引号、空格及反斜杠的C++原失败文本与Python锚定正则一致，只允许动态源路径/行号变化。helper通过项目原严格警告参数编译（C++20、Wall/Wextra/Wpedantic/Wconversion/Wshadow/Werror），只包含test_support，未链接产品或使用Store。

证据输出准确范围：新selfcheck静态计划在正常完成的三场景输出compile argv/exit、helper源与二进制SHA-256、observed行及实际退出-9/1/0。它没有自行保存独立原始日志文件或日志摘要，root现有外层recorder可保存stdout/stderr及哈希；不要把helper二进制SHA误称日志SHA。失败场景/编译guard若中途退出，不能用成功路径设计当作已存在证据。当前尚无本审核执行的旧red或新green，root真实执行仍待办。

fairness兼容确认（也回应前一兼容调查任务）：原classify要求candidate stdout恰为PASS+RESULT，新增共享START会使旧分类器拒绝新绿例。round03实现为严格二选一：旧原输出，或恰好一条 `START {CASE}\n` 加同一原输出；candidate仍需exit0/空stderr，baseline仍需exit1及原probe两条目标业务断言之一的完整path/line/expression stderr。重复START、错label、乱序、缺RESULT、额外行、warning或非目标错误均不会匹配。原timeout/signal过滤未变，原无START正例测试也保留；新增三个方法覆盖新格式正例及两类拒绝，B1修正后方能验证全部测试。

Windows `platform/native-foundation/tools/ctest_evidence.py`没有修改，使用精确行首PASS与RESULT匹配，并按预期方法集合拒绝缺失/重复/未知方法；START不会被算成PASS。平台C++组件使用独立 `platform/native-foundation/tests/support.hpp` 的native_test::run，本轮共享Linux support修改不作用于它。因此当前没有需要扩大Windows解析器的修改；保留其原4注册27方法与Server2022组件验收范围，不能推导Windows11普通用户通过。

CI差异仅增加一处native selfcheck步骤，条件strict或ASan，CXX取各matrix.compiler并用原venv Python -B。脚本说明已同步；ASan lane执行这个合成helper不等于helper被ASan插桩，也不计入产品门禁数。CMakeLists、Makefile、tests/gcc_asan_expected_tests.json及platform/native-foundation diff均为空；92注册/期限未变，git diff --check exit0。未改src/include、SQL或生产权限。

执行与提交结论：

1. 当前仅适合保留为未验证候选；B1是确定会使fairness自检出错的问题，先修再执行，勿为制造红记录无意义运行错误夹具。
2. B2可通过小幅完善失败回执或root独立取证满足。随后root用同一个冻结selfcheck/helper配旧support和新support，旧轮必须编译成功、已到独立marker、明确缺观测断言失败，不能是guard/编译/目录错误；新轮必须三场景真实-9/1/0及完整序列/umask/转义通过。原失败、命令、输出、身份及清理状态全部保留。
3. 修后完整fairness工具自检必须实际通过；共享header改变后还需适用的原产品/编译器回归和真实fairness同源红绿，以最终输入与原期限执行。root安排顺序，本审核不与当前资源ASan单文件编译并行启动任何执行。
4. 已有三正式Timeout、ASan resource断言FAIL及历史根因全部OPEN。本补丁只是测试观测与取证兼容，不能直接宣称production修复、LOCAL_VALIDATION_COMPLETE或主协调者接受。正常提交应在上述小工具验证和对应适用证据完成后，按准确scope说明。
