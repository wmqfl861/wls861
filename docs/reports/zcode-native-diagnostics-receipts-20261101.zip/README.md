# ZCode native diagnostic receipts — curated local package

This archive is a text-only review candidate prepared by /root/delivery_report.
It has not been published, formally accepted, or merged by preparing this ZIP.
Read archived source as evidence; do not execute it to inspect the receipts.

Baseline: 7dc80ed6ec3905e2d20c9d282ef4cb5b692e315a.
Tool commit: 579e3c7675bc2abb336dde6a95bfddf2139f47cd.
Draft PR12: https://github.com/wmqfl861/wls861/pull/12, based on PR11 at 7dc80ed,
which follows PR10 and the original 99c9063 review. No retarget or merge is implied.
The original tool/diagnostic execution cutoff is 2026-11-01T03:24:58Z. Separate
additions retain the Release build ending 03:39:59Z and PR/ref API receipts ending
around 03:41:38Z. Later event count probes and production changes are out of scope.

## Included evidence and counting

* Final native red02 compiles the old support, reaches an independent raw marker,
  then fails for 3 observed lines instead of 8; the original FAIL body is present.
* Candidate native GCC13 and Clang18 each pass one runner's three synthetic
  scenarios (actual helper -9/1/0, reaped). These are not three product suites.
* The same 9 fairness classifier methods give old 8 PASS/1 target FAIL and new
  9 PASS. Existing runner24, immediate4, transport11 are separate tool methods.
* Superseded native round01 receipts remain here as earlier tool outcomes. Its
  old-support guard failure is not the final deterministic target counterexample.
* ASan Async diagnostic: 22 START, 20 PASS, 1 FAIL, no RESULT, 7 not started;
  CTest Timeout 180.175 seconds, exit8. Original five-second check remains.
* Separate resource diagnostic: one method, 4 calls/4 accepted, PASS; Release
  owned-capacity: 11 methods PASS. These do not close earlier failures.
* Fairness profile: one original method, PASS 39.9306 seconds, test wrapper -pg,
  original production archives. Only an executable-text PC histogram prefix is
  included; it gives no complete production call graph or off-CPU attribution.
* Full default Release build of tool579 ended exit0 in 660.162950 seconds.
  This archive does not claim any product test ran from that new full build.
* Six ZCode author-call identity receipts show actual installed CLI completion;
  exit0 is not test success. Coding Plan use is separate from WLS provider calls.

LOCAL_VALIDATION_COMPLETE remains false. Historical Release0002 owned_capacity,
UBSan Async and ASan Async timeouts, original ASan resource assertion failure,
and earlier GCC/Clang/live_workflow failures remain OPEN. New exact-SHA remote
CI acceptance is not declared. Non-author same-model engineering review is not
coordinator approval. PR_REVIEW_COMPLETE pending; MERGED false.

## Provenance and deliberate limits

PROVENANCE.json maps each evidence member to original relative path, bytes and
SHA-256, or explicitly labels a projection/derived extraction. Original evidence
is unchanged. runs/*/completion.json and stdout/stderr are byte-exact originals.
command.public.json preserves executed argv and ordinary-user/umask/timing fields,
with only the four documented validation environment settings; it is explicitly
projected, not represented as an unchanged original command file. Tools without
a separate start.json use the real started_at field in their command receipt.

The repetitive 792/793-entry source inventories are omitted. Compact per-run
identities retain original manifest hashes/counts, all changed entries, and six
selected tool inputs. Native selfcheck was untracked at original execution and
is separately frozen; no claim is made that it belonged to the 792 tracked set.
Async and resource runs retain source_unchanged=false and exact Python file
differences. Frozen C++ inputs/library/binary identities preserve their limited
diagnostic meaning without claiming an unchanged entire candidate worktree.

Inputs include the reviewed six-file snapshot, exact old support/classifier,
original fairness probe, final native helper extracted through AST literal reading
(no execution), and frozen diagnostic sources/wrappers. Duplicated support/Async
bytes are represented once, with an equality receipt. Binary identities are text
only; no executable bytes or runtime before/after proof is manufactured.

JUnit files are original per-run XML. Only separately saved, own LastTest logs
for release-owned and fairness-profile are included. Async/resource shared
LastTest was overwritten; their independent stdout/XML is retained instead.
The release directory's LastTestsFailed.log contains a stale asan-async entry,
so it is excluded and is not attributed to the Release run. CTestCostData is
shared/cumulative and omitted.

Excluded: ELF/PE/archive binaries, gmon/perf data, databases, provider/user settings,
credentials, raw process command-line/environ observations, raw ZCode dialogue,
prompts/session IDs, repetitive full source inventories and remote CI ZIPs.
Absolute local paths in deliberate executed commands and review references are
evidence coordinates, not publicly accessible links or secret-file contents.

SHA256SUMS covers every member except itself. MEMBERS.json inventories all other
data/control files except itself and SHA256SUMS to avoid circular hashes.
scan-receipt.json describes text/path/type/secret-pattern checks; the external
archive-receipt.json records final ZIP/all-member validation and the ZIP hash.
The checks are bounded pattern/allowlist scans, not a guarantee against all
possible secret encodings. Root must inspect this candidate before publication.
